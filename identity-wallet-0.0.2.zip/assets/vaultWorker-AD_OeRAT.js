var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
(function() {
  "use strict";
  /**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: Apache-2.0
   */
  const proxyMarker = Symbol("Comlink.proxy");
  const createEndpoint = Symbol("Comlink.endpoint");
  const releaseProxy = Symbol("Comlink.releaseProxy");
  const finalizer = Symbol("Comlink.finalizer");
  const throwMarker = Symbol("Comlink.thrown");
  const isObject = (val) => typeof val === "object" && val !== null || typeof val === "function";
  const proxyTransferHandler = {
    canHandle: (val) => isObject(val) && val[proxyMarker],
    serialize(obj) {
      const { port1, port2 } = new MessageChannel();
      expose(obj, port1);
      return [port2, [port2]];
    },
    deserialize(port) {
      port.start();
      return wrap(port);
    }
  };
  const throwTransferHandler = {
    canHandle: (value) => isObject(value) && throwMarker in value,
    serialize({ value }) {
      let serialized;
      if (value instanceof Error) {
        serialized = {
          isError: true,
          value: {
            message: value.message,
            name: value.name,
            stack: value.stack
          }
        };
      } else {
        serialized = { isError: false, value };
      }
      return [serialized, []];
    },
    deserialize(serialized) {
      if (serialized.isError) {
        throw Object.assign(new Error(serialized.value.message), serialized.value);
      }
      throw serialized.value;
    }
  };
  const transferHandlers = /* @__PURE__ */ new Map([
    ["proxy", proxyTransferHandler],
    ["throw", throwTransferHandler]
  ]);
  function isAllowedOrigin(allowedOrigins, origin) {
    for (const allowedOrigin of allowedOrigins) {
      if (origin === allowedOrigin || allowedOrigin === "*") {
        return true;
      }
      if (allowedOrigin instanceof RegExp && allowedOrigin.test(origin)) {
        return true;
      }
    }
    return false;
  }
  function expose(obj, ep = globalThis, allowedOrigins = ["*"]) {
    ep.addEventListener("message", function callback(ev) {
      if (!ev || !ev.data) {
        return;
      }
      if (!isAllowedOrigin(allowedOrigins, ev.origin)) {
        console.warn(`Invalid origin '${ev.origin}' for comlink proxy`);
        return;
      }
      const { id: id2, type, path } = Object.assign({ path: [] }, ev.data);
      const argumentList = (ev.data.argumentList || []).map(fromWireValue);
      let returnValue;
      try {
        const parent = path.slice(0, -1).reduce((obj2, prop) => obj2[prop], obj);
        const rawValue = path.reduce((obj2, prop) => obj2[prop], obj);
        switch (type) {
          case "GET":
            {
              returnValue = rawValue;
            }
            break;
          case "SET":
            {
              parent[path.slice(-1)[0]] = fromWireValue(ev.data.value);
              returnValue = true;
            }
            break;
          case "APPLY":
            {
              returnValue = rawValue.apply(parent, argumentList);
            }
            break;
          case "CONSTRUCT":
            {
              const value = new rawValue(...argumentList);
              returnValue = proxy(value);
            }
            break;
          case "ENDPOINT":
            {
              const { port1, port2 } = new MessageChannel();
              expose(obj, port2);
              returnValue = transfer(port1, [port1]);
            }
            break;
          case "RELEASE":
            {
              returnValue = void 0;
            }
            break;
          default:
            return;
        }
      } catch (value) {
        returnValue = { value, [throwMarker]: 0 };
      }
      Promise.resolve(returnValue).catch((value) => {
        return { value, [throwMarker]: 0 };
      }).then((returnValue2) => {
        const [wireValue, transferables] = toWireValue(returnValue2);
        ep.postMessage(Object.assign(Object.assign({}, wireValue), { id: id2 }), transferables);
        if (type === "RELEASE") {
          ep.removeEventListener("message", callback);
          closeEndPoint(ep);
          if (finalizer in obj && typeof obj[finalizer] === "function") {
            obj[finalizer]();
          }
        }
      }).catch((error) => {
        const [wireValue, transferables] = toWireValue({
          value: new TypeError("Unserializable return value"),
          [throwMarker]: 0
        });
        ep.postMessage(Object.assign(Object.assign({}, wireValue), { id: id2 }), transferables);
      });
    });
    if (ep.start) {
      ep.start();
    }
  }
  function isMessagePort(endpoint) {
    return endpoint.constructor.name === "MessagePort";
  }
  function closeEndPoint(endpoint) {
    if (isMessagePort(endpoint))
      endpoint.close();
  }
  function wrap(ep, target) {
    const pendingListeners = /* @__PURE__ */ new Map();
    ep.addEventListener("message", function handleMessage(ev) {
      const { data } = ev;
      if (!data || !data.id) {
        return;
      }
      const resolver = pendingListeners.get(data.id);
      if (!resolver) {
        return;
      }
      try {
        resolver(data);
      } finally {
        pendingListeners.delete(data.id);
      }
    });
    return createProxy(ep, pendingListeners, [], target);
  }
  function throwIfProxyReleased(isReleased) {
    if (isReleased) {
      throw new Error("Proxy has been released and is not useable");
    }
  }
  function releaseEndpoint(ep) {
    return requestResponseMessage(ep, /* @__PURE__ */ new Map(), {
      type: "RELEASE"
    }).then(() => {
      closeEndPoint(ep);
    });
  }
  const proxyCounter = /* @__PURE__ */ new WeakMap();
  const proxyFinalizers = "FinalizationRegistry" in globalThis && new FinalizationRegistry((ep) => {
    const newCount = (proxyCounter.get(ep) || 0) - 1;
    proxyCounter.set(ep, newCount);
    if (newCount === 0) {
      releaseEndpoint(ep);
    }
  });
  function registerProxy(proxy2, ep) {
    const newCount = (proxyCounter.get(ep) || 0) + 1;
    proxyCounter.set(ep, newCount);
    if (proxyFinalizers) {
      proxyFinalizers.register(proxy2, ep, proxy2);
    }
  }
  function unregisterProxy(proxy2) {
    if (proxyFinalizers) {
      proxyFinalizers.unregister(proxy2);
    }
  }
  function createProxy(ep, pendingListeners, path = [], target = function() {
  }) {
    let isProxyReleased = false;
    const proxy2 = new Proxy(target, {
      get(_target, prop) {
        throwIfProxyReleased(isProxyReleased);
        if (prop === releaseProxy) {
          return () => {
            unregisterProxy(proxy2);
            releaseEndpoint(ep);
            pendingListeners.clear();
            isProxyReleased = true;
          };
        }
        if (prop === "then") {
          if (path.length === 0) {
            return { then: () => proxy2 };
          }
          const r2 = requestResponseMessage(ep, pendingListeners, {
            type: "GET",
            path: path.map((p2) => p2.toString())
          }).then(fromWireValue);
          return r2.then.bind(r2);
        }
        return createProxy(ep, pendingListeners, [...path, prop]);
      },
      set(_target, prop, rawValue) {
        throwIfProxyReleased(isProxyReleased);
        const [value, transferables] = toWireValue(rawValue);
        return requestResponseMessage(ep, pendingListeners, {
          type: "SET",
          path: [...path, prop].map((p2) => p2.toString()),
          value
        }, transferables).then(fromWireValue);
      },
      apply(_target, _thisArg, rawArgumentList) {
        throwIfProxyReleased(isProxyReleased);
        const last = path[path.length - 1];
        if (last === createEndpoint) {
          return requestResponseMessage(ep, pendingListeners, {
            type: "ENDPOINT"
          }).then(fromWireValue);
        }
        if (last === "bind") {
          return createProxy(ep, pendingListeners, path.slice(0, -1));
        }
        const [argumentList, transferables] = processArguments(rawArgumentList);
        return requestResponseMessage(ep, pendingListeners, {
          type: "APPLY",
          path: path.map((p2) => p2.toString()),
          argumentList
        }, transferables).then(fromWireValue);
      },
      construct(_target, rawArgumentList) {
        throwIfProxyReleased(isProxyReleased);
        const [argumentList, transferables] = processArguments(rawArgumentList);
        return requestResponseMessage(ep, pendingListeners, {
          type: "CONSTRUCT",
          path: path.map((p2) => p2.toString()),
          argumentList
        }, transferables).then(fromWireValue);
      }
    });
    registerProxy(proxy2, ep);
    return proxy2;
  }
  function myFlat(arr) {
    return Array.prototype.concat.apply([], arr);
  }
  function processArguments(argumentList) {
    const processed = argumentList.map(toWireValue);
    return [processed.map((v2) => v2[0]), myFlat(processed.map((v2) => v2[1]))];
  }
  const transferCache = /* @__PURE__ */ new WeakMap();
  function transfer(obj, transfers) {
    transferCache.set(obj, transfers);
    return obj;
  }
  function proxy(obj) {
    return Object.assign(obj, { [proxyMarker]: true });
  }
  function toWireValue(value) {
    for (const [name, handler] of transferHandlers) {
      if (handler.canHandle(value)) {
        const [serializedValue, transferables] = handler.serialize(value);
        return [
          {
            type: "HANDLER",
            name,
            value: serializedValue
          },
          transferables
        ];
      }
    }
    return [
      {
        type: "RAW",
        value
      },
      transferCache.get(value) || []
    ];
  }
  function fromWireValue(value) {
    switch (value.type) {
      case "HANDLER":
        return transferHandlers.get(value.name).deserialize(value.value);
      case "RAW":
        return value.value;
    }
  }
  function requestResponseMessage(ep, pendingListeners, msg, transfers) {
    return new Promise((resolve) => {
      const id2 = generateUUID();
      pendingListeners.set(id2, resolve);
      if (ep.start) {
        ep.start();
      }
      ep.postMessage(Object.assign({ id: id2 }, msg), transfers);
    });
  }
  function generateUUID() {
    return new Array(4).fill(0).map(() => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16)).join("-");
  }
  let wasm$1;
  const heap$1 = new Array(128).fill(void 0);
  heap$1.push(void 0, null, true, false);
  function getObject$1(idx) {
    return heap$1[idx];
  }
  let heap_next$1 = heap$1.length;
  function dropObject$1(idx) {
    if (idx < 132) return;
    heap$1[idx] = heap_next$1;
    heap_next$1 = idx;
  }
  function takeObject$1(idx) {
    const ret = getObject$1(idx);
    dropObject$1(idx);
    return ret;
  }
  function addHeapObject$1(obj) {
    if (heap_next$1 === heap$1.length) heap$1.push(heap$1.length + 1);
    const idx = heap_next$1;
    heap_next$1 = heap$1[idx];
    heap$1[idx] = obj;
    return idx;
  }
  const cachedTextDecoder$1 = typeof TextDecoder !== "undefined" ? new TextDecoder("utf-8", { ignoreBOM: true, fatal: true }) : { decode: () => {
    throw Error("TextDecoder not available");
  } };
  if (typeof TextDecoder !== "undefined") {
    cachedTextDecoder$1.decode();
  }
  let cachedUint8Memory0$1 = null;
  function getUint8Memory0$1() {
    if (cachedUint8Memory0$1 === null || cachedUint8Memory0$1.byteLength === 0) {
      cachedUint8Memory0$1 = new Uint8Array(wasm$1.memory.buffer);
    }
    return cachedUint8Memory0$1;
  }
  function getStringFromWasm0$1(ptr, len) {
    ptr = ptr >>> 0;
    return cachedTextDecoder$1.decode(getUint8Memory0$1().subarray(ptr, ptr + len));
  }
  let WASM_VECTOR_LEN$1 = 0;
  const cachedTextEncoder$1 = typeof TextEncoder !== "undefined" ? new TextEncoder("utf-8") : { encode: () => {
    throw Error("TextEncoder not available");
  } };
  const encodeString$1 = typeof cachedTextEncoder$1.encodeInto === "function" ? function(arg, view) {
    return cachedTextEncoder$1.encodeInto(arg, view);
  } : function(arg, view) {
    const buf = cachedTextEncoder$1.encode(arg);
    view.set(buf);
    return {
      read: arg.length,
      written: buf.length
    };
  };
  function passStringToWasm0$1(arg, malloc, realloc) {
    if (realloc === void 0) {
      const buf = cachedTextEncoder$1.encode(arg);
      const ptr2 = malloc(buf.length, 1) >>> 0;
      getUint8Memory0$1().subarray(ptr2, ptr2 + buf.length).set(buf);
      WASM_VECTOR_LEN$1 = buf.length;
      return ptr2;
    }
    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;
    const mem = getUint8Memory0$1();
    let offset = 0;
    for (; offset < len; offset++) {
      const code = arg.charCodeAt(offset);
      if (code > 127) break;
      mem[ptr + offset] = code;
    }
    if (offset !== len) {
      if (offset !== 0) {
        arg = arg.slice(offset);
      }
      ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
      const view = getUint8Memory0$1().subarray(ptr + offset, ptr + len);
      const ret = encodeString$1(arg, view);
      offset += ret.written;
      ptr = realloc(ptr, len, offset, 1) >>> 0;
    }
    WASM_VECTOR_LEN$1 = offset;
    return ptr;
  }
  let cachedInt32Memory0$1 = null;
  function getInt32Memory0$1() {
    if (cachedInt32Memory0$1 === null || cachedInt32Memory0$1.byteLength === 0) {
      cachedInt32Memory0$1 = new Int32Array(wasm$1.memory.buffer);
    }
    return cachedInt32Memory0$1;
  }
  function isLikeNone$1(x2) {
    return x2 === void 0 || x2 === null;
  }
  function debugString$1(val) {
    const type = typeof val;
    if (type == "number" || type == "boolean" || val == null) {
      return `${val}`;
    }
    if (type == "string") {
      return `"${val}"`;
    }
    if (type == "symbol") {
      const description = val.description;
      if (description == null) {
        return "Symbol";
      } else {
        return `Symbol(${description})`;
      }
    }
    if (type == "function") {
      const name = val.name;
      if (typeof name == "string" && name.length > 0) {
        return `Function(${name})`;
      } else {
        return "Function";
      }
    }
    if (Array.isArray(val)) {
      const length = val.length;
      let debug = "[";
      if (length > 0) {
        debug += debugString$1(val[0]);
      }
      for (let i2 = 1; i2 < length; i2++) {
        debug += ", " + debugString$1(val[i2]);
      }
      debug += "]";
      return debug;
    }
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches.length > 1) {
      className = builtInMatches[1];
    } else {
      return toString.call(val);
    }
    if (className == "Object") {
      try {
        return "Object(" + JSON.stringify(val) + ")";
      } catch (_) {
        return "Object";
      }
    }
    if (val instanceof Error) {
      return `${val.name}: ${val.message}
${val.stack}`;
    }
    return className;
  }
  const CLOSURE_DTORS$1 = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((state) => {
    wasm$1.__wbindgen_export_2.get(state.dtor)(state.a, state.b);
  });
  function makeMutClosure$1(arg0, arg1, dtor, f) {
    const state = { a: arg0, b: arg1, cnt: 1, dtor };
    const real = (...args) => {
      state.cnt++;
      const a = state.a;
      state.a = 0;
      try {
        return f(a, state.b, ...args);
      } finally {
        if (--state.cnt === 0) {
          wasm$1.__wbindgen_export_2.get(state.dtor)(a, state.b);
          CLOSURE_DTORS$1.unregister(state);
        } else {
          state.a = a;
        }
      }
    };
    real.original = state;
    CLOSURE_DTORS$1.register(real, state, state);
    return real;
  }
  function __wbg_adapter_32(arg0, arg1, arg2) {
    wasm$1._dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h9e40349767bda10f(arg0, arg1, addHeapObject$1(arg2));
  }
  function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
      throw new Error(`expected instance of ${klass.name}`);
    }
    return instance.ptr;
  }
  let stack_pointer = 128;
  function addBorrowedObject(obj) {
    if (stack_pointer == 1) throw new Error("out of js stack");
    heap$1[--stack_pointer] = obj;
    return stack_pointer;
  }
  function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8Memory0$1().subarray(ptr / 1, ptr / 1 + len);
  }
  function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8Memory0$1().set(arg, ptr / 1);
    WASM_VECTOR_LEN$1 = arg.length;
    return ptr;
  }
  let cachedUint32Memory0 = null;
  function getUint32Memory0() {
    if (cachedUint32Memory0 === null || cachedUint32Memory0.byteLength === 0) {
      cachedUint32Memory0 = new Uint32Array(wasm$1.memory.buffer);
    }
    return cachedUint32Memory0;
  }
  function passArrayJsValueToWasm0(array, malloc) {
    const ptr = malloc(array.length * 4, 4) >>> 0;
    const mem = getUint32Memory0();
    for (let i2 = 0; i2 < array.length; i2++) {
      mem[ptr / 4 + i2] = addHeapObject$1(array[i2]);
    }
    WASM_VECTOR_LEN$1 = array.length;
    return ptr;
  }
  function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getUint32Memory0();
    const slice = mem.subarray(ptr / 4, ptr / 4 + len);
    const result = [];
    for (let i2 = 0; i2 < slice.length; i2++) {
      result.push(takeObject$1(slice[i2]));
    }
    return result;
  }
  function getArrayU32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint32Memory0().subarray(ptr / 4, ptr / 4 + len);
  }
  function encodeB64(data) {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passArray8ToWasm0(data, wasm$1.__wbindgen_malloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.encodeB64(retptr, ptr0, len0);
      var r0 = getInt32Memory0$1()[retptr / 4 + 0];
      var r1 = getInt32Memory0$1()[retptr / 4 + 1];
      deferred2_0 = r0;
      deferred2_1 = r1;
      return getStringFromWasm0$1(r0, r1);
    } finally {
      wasm$1.__wbindgen_add_to_stack_pointer(16);
      wasm$1.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
  }
  function handleError$1(f, args) {
    try {
      return f.apply(this, args);
    } catch (e2) {
      wasm$1.__wbindgen_exn_store(addHeapObject$1(e2));
    }
  }
  function __wbg_adapter_881(arg0, arg1, arg2, arg3) {
    wasm$1.wasm_bindgen__convert__closures__invoke2_mut__h2074d6741f1d4f19(arg0, arg1, addHeapObject$1(arg2), addHeapObject$1(arg3));
  }
  const CompositeJwkFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_compositejwk_free(ptr >>> 0));
  class CompositeJwk {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(CompositeJwk.prototype);
      obj.__wbg_ptr = ptr;
      CompositeJwkFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      CompositeJwkFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_compositejwk_free(ptr);
    }
    /**
    * @param {IJwkParams} jwk
    */
    constructor(jwk) {
      const ret = wasm$1.compositejwk_new(addHeapObject$1(jwk));
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
    /**
    * Get the `algId` value.
    * @returns {CompositeAlgId}
    */
    alg_id() {
      const ret = wasm$1.compositejwk_alg_id(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Get the post-quantum public key in Jwk format.
    * @returns {Jwk}
    */
    pq_public_key() {
      const ret = wasm$1.compositejwk_pq_public_key(this.__wbg_ptr);
      return Jwk.__wrap(ret);
    }
    /**
    * Get the traditional public key in Jwk format.
    * @returns {Jwk}
    */
    traditional_public_key() {
      const ret = wasm$1.compositejwk_traditional_public_key(this.__wbg_ptr);
      return Jwk.__wrap(ret);
    }
  }
  const CoreDIDFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_coredid_free(ptr >>> 0));
  class CoreDID {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(CoreDID.prototype);
      obj.__wbg_ptr = ptr;
      CoreDIDFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      CoreDIDFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_coredid_free(ptr);
    }
    /**
    * Parses a {@link CoreDID} from the given `input`.
    *
    * ### Errors
    *
    * Throws an error if the input is not a valid {@link CoreDID}.
    * @param {string} input
    * @returns {CoreDID}
    */
    static parse(input) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(input, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.coredid_parse(retptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return CoreDID.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Set the method name of the {@link CoreDID}.
    * @param {string} value
    */
    setMethodName(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.coredid_setMethodName(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Validates whether a string is a valid DID method name.
    * @param {string} value
    * @returns {boolean}
    */
    static validMethodName(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      const ret = wasm$1.coredid_validMethodName(ptr0, len0);
      return ret !== 0;
    }
    /**
    * Set the method-specific-id of the `DID`.
    * @param {string} value
    */
    setMethodId(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.coredid_setMethodId(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Validates whether a string is a valid `DID` method-id.
    * @param {string} value
    * @returns {boolean}
    */
    static validMethodId(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      const ret = wasm$1.coredid_validMethodId(ptr0, len0);
      return ret !== 0;
    }
    /**
    * Returns the {@link CoreDID} scheme.
    *
    * E.g.
    * - `"did:example:12345678" -> "did"`
    * - `"did:iota:smr:12345678" -> "did"`
    * @returns {string}
    */
    scheme() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredid_scheme(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the {@link CoreDID} authority: the method name and method-id.
    *
    * E.g.
    * - `"did:example:12345678" -> "example:12345678"`
    * - `"did:iota:smr:12345678" -> "iota:smr:12345678"`
    * @returns {string}
    */
    authority() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredid_authority(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the {@link CoreDID} method name.
    *
    * E.g.
    * - `"did:example:12345678" -> "example"`
    * - `"did:iota:smr:12345678" -> "iota"`
    * @returns {string}
    */
    method() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredid_method(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the {@link CoreDID} method-specific ID.
    *
    * E.g.
    * - `"did:example:12345678" -> "12345678"`
    * - `"did:iota:smr:12345678" -> "smr:12345678"`
    * @returns {string}
    */
    methodId() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredid_methodId(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Construct a new {@link DIDUrl} by joining with a relative DID Url string.
    * @param {string} segment
    * @returns {DIDUrl}
    */
    join(segment) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(segment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.coredid_join(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return DIDUrl.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Clones the {@link CoreDID} into a {@link DIDUrl}.
    * @returns {DIDUrl}
    */
    toUrl() {
      const ret = wasm$1.coredid_toUrl(this.__wbg_ptr);
      return DIDUrl.__wrap(ret);
    }
    /**
    * Converts the {@link CoreDID} into a {@link DIDUrl}, consuming it.
    * @returns {DIDUrl}
    */
    intoUrl() {
      const ptr = this.__destroy_into_raw();
      const ret = wasm$1.coredid_intoUrl(ptr);
      return DIDUrl.__wrap(ret);
    }
    /**
    * Returns the {@link CoreDID} as a string.
    * @returns {string}
    */
    toString() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredid_toString(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * @returns {CoreDID}
    */
    toCoreDid() {
      const ret = wasm$1.coredid_clone(this.__wbg_ptr);
      return CoreDID.__wrap(ret);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredid_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {CoreDID}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredid_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return CoreDID.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {CoreDID}
    */
    clone() {
      const ret = wasm$1.coredid_clone(this.__wbg_ptr);
      return CoreDID.__wrap(ret);
    }
  }
  const CoreDocumentFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_coredocument_free(ptr >>> 0));
  class CoreDocument {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(CoreDocument.prototype);
      obj.__wbg_ptr = ptr;
      CoreDocumentFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      CoreDocumentFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_coredocument_free(ptr);
    }
    /**
    * Creates a new {@link CoreDocument} with the given properties.
    * @param {ICoreDocument} values
    */
    constructor(values) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_new(retptr, addHeapObject$1(values));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the DID Document `id`.
    * @returns {CoreDID}
    */
    id() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_id(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return CoreDID.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the DID of the document.
    *
    * ### Warning
    *
    * Changing the identifier can drastically alter the results of
    * `resolve_method`, `resolve_service` and the related
    * [DID URL dereferencing](https://w3c-ccg.github.io/did-resolution/#dereferencing) algorithm.
    * @param {CoreDID} id
    */
    setId(id2) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(id2, CoreDID);
        wasm$1.coredocument_setId(retptr, this.__wbg_ptr, id2.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the document controllers.
    * @returns {Array<CoreDID>}
    */
    controller() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_controller(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the controllers of the DID Document.
    *
    * Note: Duplicates will be ignored.
    * Use `null` to remove all controllers.
    * @param {CoreDID | CoreDID[] | null} controllers
    */
    setController(controllers) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_setController(retptr, this.__wbg_ptr, addBorrowedObject(controllers));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Returns a copy of the document's `alsoKnownAs` set.
    * @returns {Array<string>}
    */
    alsoKnownAs() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_alsoKnownAs(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the `alsoKnownAs` property in the DID document.
    * @param {string | string[] | null} urls
    */
    setAlsoKnownAs(urls) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_setAlsoKnownAs(retptr, this.__wbg_ptr, addBorrowedObject(urls));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Returns a copy of the document's `verificationMethod` set.
    * @returns {VerificationMethod[]}
    */
    verificationMethod() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_verificationMethod(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the document's `authentication` set.
    * @returns {Array<DIDUrl | VerificationMethod>}
    */
    authentication() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_authentication(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the document's `assertionMethod` set.
    * @returns {Array<DIDUrl | VerificationMethod>}
    */
    assertionMethod() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_assertionMethod(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the document's `keyAgreement` set.
    * @returns {Array<DIDUrl | VerificationMethod>}
    */
    keyAgreement() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_keyAgreement(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the document's `capabilityDelegation` set.
    * @returns {Array<DIDUrl | VerificationMethod>}
    */
    capabilityDelegation() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_capabilityDelegation(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the document's `capabilityInvocation` set.
    * @returns {Array<DIDUrl | VerificationMethod>}
    */
    capabilityInvocation() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_capabilityInvocation(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the custom DID Document properties.
    * @returns {Map<string, any>}
    */
    properties() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_properties(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a custom property in the DID Document.
    * If the value is set to `null`, the custom property will be removed.
    *
    * ### WARNING
    *
    * This method can overwrite existing properties like `id` and result in an invalid document.
    * @param {string} key
    * @param {any} value
    */
    setPropertyUnchecked(key, value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(key, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.coredocument_setPropertyUnchecked(retptr, this.__wbg_ptr, ptr0, len0, addBorrowedObject(value));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Returns a set of all {@link Service} in the document.
    * @returns {Service[]}
    */
    service() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_service(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Add a new {@link Service} to the document.
    *
    * Errors if there already exists a service or verification method with the same id.
    * @param {Service} service
    */
    insertService(service) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(service, Service);
        wasm$1.coredocument_insertService(retptr, this.__wbg_ptr, service.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Remove a {@link Service} identified by the given {@link DIDUrl} from the document.
    *
    * Returns `true` if the service was removed.
    * @param {DIDUrl} didUrl
    * @returns {Service | undefined}
    */
    removeService(didUrl) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(didUrl, DIDUrl);
        wasm$1.coredocument_removeService(retptr, this.__wbg_ptr, didUrl.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 === 0 ? void 0 : Service.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the first {@link Service} with an `id` property matching the provided `query`,
    * if present.
    * @param {DIDUrl | string} query
    * @returns {Service | undefined}
    */
    resolveService(query) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_resolveService(retptr, this.__wbg_ptr, addBorrowedObject(query));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 === 0 ? void 0 : Service.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Returns a list of all {@link VerificationMethod} in the DID Document,
    * whose verification relationship matches `scope`.
    *
    * If `scope` is not set, a list over the **embedded** methods is returned.
    * @param {MethodScope | undefined} [scope]
    * @returns {VerificationMethod[]}
    */
    methods(scope) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_methods(retptr, this.__wbg_ptr, isLikeNone$1(scope) ? 0 : addHeapObject$1(scope));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns an array of all verification relationships.
    * @returns {Array<DIDUrl | VerificationMethod>}
    */
    verificationRelationships() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_verificationRelationships(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Adds a new `method` to the document in the given `scope`.
    * @param {VerificationMethod} method
    * @param {MethodScope} scope
    */
    insertMethod(method, scope) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(method, VerificationMethod);
        _assertClass(scope, MethodScope);
        wasm$1.coredocument_insertMethod(retptr, this.__wbg_ptr, method.__wbg_ptr, scope.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Removes all references to the specified Verification Method.
    * @param {DIDUrl} did
    * @returns {VerificationMethod | undefined}
    */
    removeMethod(did) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(did, DIDUrl);
        wasm$1.coredocument_removeMethod(retptr, this.__wbg_ptr, did.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 === 0 ? void 0 : VerificationMethod.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the first verification method with an `id` property
    * matching the provided `query` and the verification relationship
    * specified by `scope`, if present.
    * @param {DIDUrl | string} query
    * @param {MethodScope | undefined} [scope]
    * @returns {VerificationMethod | undefined}
    */
    resolveMethod(query, scope) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_resolveMethod(retptr, this.__wbg_ptr, addBorrowedObject(query), isLikeNone$1(scope) ? 0 : addHeapObject$1(scope));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 === 0 ? void 0 : VerificationMethod.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Attaches the relationship to the given method, if the method exists.
    *
    * Note: The method needs to be in the set of verification methods,
    * so it cannot be an embedded one.
    * @param {DIDUrl} didUrl
    * @param {MethodRelationship} relationship
    * @returns {boolean}
    */
    attachMethodRelationship(didUrl, relationship) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(didUrl, DIDUrl);
        wasm$1.coredocument_attachMethodRelationship(retptr, this.__wbg_ptr, didUrl.__wbg_ptr, relationship);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 !== 0;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Detaches the given relationship from the given method, if the method exists.
    * @param {DIDUrl} didUrl
    * @param {MethodRelationship} relationship
    * @returns {boolean}
    */
    detachMethodRelationship(didUrl, relationship) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(didUrl, DIDUrl);
        wasm$1.coredocument_detachMethodRelationship(retptr, this.__wbg_ptr, didUrl.__wbg_ptr, relationship);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 !== 0;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Decodes and verifies the provided JWS according to the passed `options` and `signatureVerifier`.
    * If a `signatureVerifier` is provided it will be used when
    * verifying decoded JWS signatures, otherwise a default verifier capable of handling the `EdDSA`, `ES256`, `ES256K`
    * algorithms will be used.
    *
    * Regardless of which options are passed the following conditions must be met in order for a verification attempt to
    * take place.
    * - The JWS must be encoded according to the JWS compact serialization.
    * - The `kid` value in the protected header must be an identifier of a verification method in this DID document,
    * or set explicitly in the `options`.
    * @param {Jws} jws
    * @param {JwsVerificationOptions} options
    * @param {IJwsVerifier | undefined} [signatureVerifier]
    * @param {string | undefined} [detachedPayload]
    * @returns {DecodedJws}
    */
    verifyJws(jws, options, signatureVerifier, detachedPayload) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(jws, Jws);
        _assertClass(options, JwsVerificationOptions);
        var ptr0 = isLikeNone$1(detachedPayload) ? 0 : passStringToWasm0$1(detachedPayload, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN$1;
        wasm$1.coredocument_verifyJws(retptr, this.__wbg_ptr, jws.__wbg_ptr, options.__wbg_ptr, isLikeNone$1(signatureVerifier) ? 0 : addHeapObject$1(signatureVerifier), ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return DecodedJws.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * If the document has a {@link RevocationBitmap} service identified by `serviceQuery`,
    * revoke all specified `indices`.
    * @param {DIDUrl | string} serviceQuery
    * @param {number | number[]} indices
    */
    revokeCredentials(serviceQuery, indices) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_revokeCredentials(retptr, this.__wbg_ptr, addBorrowedObject(serviceQuery), addHeapObject$1(indices));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * If the document has a {@link RevocationBitmap} service identified by `serviceQuery`,
    * unrevoke all specified `indices`.
    * @param {DIDUrl | string} serviceQuery
    * @param {number | number[]} indices
    */
    unrevokeCredentials(serviceQuery, indices) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_unrevokeCredentials(retptr, this.__wbg_ptr, addBorrowedObject(serviceQuery), addHeapObject$1(indices));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the {@link CoreDocument}.
    * @returns {CoreDocument}
    */
    clone() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_clone(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return CoreDocument.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * ### Warning
    * This is for internal use only. Do not rely on or call this method.
    * @returns {CoreDocument}
    */
    _shallowCloneInternal() {
      const ret = wasm$1.coredocument__shallowCloneInternal(this.__wbg_ptr);
      return CoreDocument.__wrap(ret);
    }
    /**
    * ### Warning
    * This is for internal use only. Do not rely on or call this method.
    * @returns {number}
    */
    _strongCountInternal() {
      const ret = wasm$1.coredocument__strongCountInternal(this.__wbg_ptr);
      return ret >>> 0;
    }
    /**
    * Serializes to a plain JS representation.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a plain JS representation.
    * @param {any} json
    * @returns {CoreDocument}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return CoreDocument.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Generate new key material in the given `storage` and insert a new verification method with the corresponding
    * public key material into the DID document.
    *
    * - If no fragment is given the `kid` of the generated JWK is used, if it is set, otherwise an error is returned.
    * - The `keyType` must be compatible with the given `storage`. `Storage`s are expected to export key type constants
    * for that use case.
    *
    * The fragment of the generated method is returned.
    * @param {Storage} storage
    * @param {string} keyType
    * @param {JwsAlgorithm} alg
    * @param {string | undefined} fragment
    * @param {MethodScope} scope
    * @returns {Promise<string>}
    */
    generateMethod(storage, keyType, alg, fragment, scope) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(keyType, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        var ptr1 = isLikeNone$1(fragment) ? 0 : passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN$1;
        _assertClass(scope, MethodScope);
        var ptr2 = scope.__destroy_into_raw();
        wasm$1.coredocument_generateMethod(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, addHeapObject$1(alg), ptr1, len1, ptr2);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Remove the method identified by the `fragment` from the document and delete the corresponding key material in
    * the `storage`.
    * @param {Storage} storage
    * @param {DIDUrl} id
    * @returns {Promise<void>}
    */
    purgeMethod(storage, id2) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        _assertClass(id2, DIDUrl);
        wasm$1.coredocument_purgeMethod(retptr, this.__wbg_ptr, storage.__wbg_ptr, id2.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sign the `payload` according to `options` with the storage backed private key corresponding to the public key
    * material in the verification method identified by the given `fragment.
    *
    * Upon success a string representing a JWS encoded according to the Compact JWS Serialization format is returned.
    * See [RFC7515 section 3.1](https://www.rfc-editor.org/rfc/rfc7515#section-3.1).
    * @param {Storage} storage
    * @param {string} fragment
    * @param {string} payload
    * @param {JwsSignatureOptions} options
    * @returns {Promise<Jws>}
    */
    createJws(storage, fragment, payload, options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        const ptr1 = passStringToWasm0$1(payload, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN$1;
        _assertClass(options, JwsSignatureOptions);
        wasm$1.coredocument_createJws(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, ptr1, len1, options.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Produces a JWT where the payload is produced from the given `credential`
    * in accordance with [VC Data Model v1.1](https://www.w3.org/TR/vc-data-model/#json-web-token).
    *
    * Unless the `kid` is explicitly set in the options, the `kid` in the protected header is the `id`
    * of the method identified by `fragment` and the JWS signature will be produced by the corresponding
    * private key backed by the `storage` in accordance with the passed `options`.
    *
    * The `custom_claims` can be used to set additional claims on the resulting JWT.
    * @param {Storage} storage
    * @param {string} fragment
    * @param {Credential} credential
    * @param {JwsSignatureOptions} options
    * @param {Record<string, any> | undefined} [custom_claims]
    * @returns {Promise<Jwt>}
    */
    createCredentialJwt(storage, fragment, credential, options, custom_claims) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        _assertClass(credential, Credential);
        _assertClass(options, JwsSignatureOptions);
        wasm$1.coredocument_createCredentialJwt(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, credential.__wbg_ptr, options.__wbg_ptr, isLikeNone$1(custom_claims) ? 0 : addHeapObject$1(custom_claims));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Produces a JWT where the payload is produced from the given presentation.
    * in accordance with [VC Data Model v1.1](https://www.w3.org/TR/vc-data-model/#json-web-token).
    *
    * Unless the `kid` is explicitly set in the options, the `kid` in the protected header is the `id`
    * of the method identified by `fragment` and the JWS signature will be produced by the corresponding
    * private key backed by the `storage` in accordance with the passed `options`.
    * @param {Storage} storage
    * @param {string} fragment
    * @param {Presentation} presentation
    * @param {JwsSignatureOptions} signature_options
    * @param {JwtPresentationOptions} presentation_options
    * @returns {Promise<Jwt>}
    */
    createPresentationJwt(storage, fragment, presentation, signature_options, presentation_options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        _assertClass(presentation, Presentation);
        _assertClass(signature_options, JwsSignatureOptions);
        _assertClass(presentation_options, JwtPresentationOptions);
        wasm$1.coredocument_createPresentationJwt(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, presentation.__wbg_ptr, signature_options.__wbg_ptr, presentation_options.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Creates a {@link CoreDocument} from the given {@link DIDJwk}.
    * @param {DIDJwk} did
    * @returns {CoreDocument}
    */
    static expandDIDJwk(did) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(did, DIDJwk);
        var ptr0 = did.__destroy_into_raw();
        wasm$1.coredocument_expandDIDJwk(retptr, ptr0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return CoreDocument.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Creates a {@link CoreDocument} from the given {@link DIDCompositeJwk}.
    * @param {DIDCompositeJwk} did
    * @returns {CoreDocument}
    */
    static expandDIDCompositeJwk(did) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(did, DIDCompositeJwk);
        var ptr0 = did.__destroy_into_raw();
        wasm$1.coredocument_expandDIDCompositeJwk(retptr, ptr0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return CoreDocument.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {Storage} storage
    * @param {string} key_type
    * @param {JwsAlgorithm} alg
    * @returns {Promise<CoreDocument>}
    */
    static newDidJwk(storage, key_type, alg) {
      _assertClass(storage, Storage);
      const ptr0 = passStringToWasm0$1(key_type, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      const ret = wasm$1.coredocument_newDidJwk(storage.__wbg_ptr, ptr0, len0, addHeapObject$1(alg));
      return takeObject$1(ret);
    }
    /**
    * @param {Storage} storage
    * @param {string} key_type
    * @param {JwsAlgorithm} alg
    * @returns {Promise<CoreDocument>}
    */
    static newDidJwkPq(storage, key_type, alg) {
      _assertClass(storage, Storage);
      const ptr0 = passStringToWasm0$1(key_type, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      const ret = wasm$1.coredocument_newDidJwkPq(storage.__wbg_ptr, ptr0, len0, addHeapObject$1(alg));
      return takeObject$1(ret);
    }
    /**
    * @param {Storage} storage
    * @param {CompositeAlgId} alg
    * @returns {Promise<CoreDocument>}
    */
    static newDidCompositeJwk(storage, alg) {
      _assertClass(storage, Storage);
      const ret = wasm$1.coredocument_newDidCompositeJwk(storage.__wbg_ptr, addHeapObject$1(alg));
      return takeObject$1(ret);
    }
    /**
    * @param {Storage} storage
    * @param {ProofAlgorithm} alg
    * @returns {Promise<CoreDocument>}
    */
    static newDidJwkZk(storage, alg) {
      _assertClass(storage, Storage);
      const ret = wasm$1.coredocument_newDidJwkZk(storage.__wbg_ptr, alg);
      return takeObject$1(ret);
    }
    /**
    * @returns {string}
    */
    fragmentJwk() {
      let deferred1_0;
      let deferred1_1;
      try {
        const ptr = this.__destroy_into_raw();
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredocument_fragmentJwk(retptr, ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * @param {Storage} storage
    * @param {string} fragment
    * @param {string} payload
    * @param {JwsSignatureOptions} options
    * @returns {Promise<Jws>}
    */
    createHybridJws(storage, fragment, payload, options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        const ptr1 = passStringToWasm0$1(payload, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN$1;
        _assertClass(options, JwsSignatureOptions);
        wasm$1.coredocument_createHybridJws(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, ptr1, len1, options.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {Storage} storage
    * @param {string} fragment
    * @param {string} payload
    * @param {JwsSignatureOptions} options
    * @returns {Promise<Jws>}
    */
    createPqJws(storage, fragment, payload, options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        const ptr1 = passStringToWasm0$1(payload, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN$1;
        _assertClass(options, JwsSignatureOptions);
        wasm$1.coredocument_createPqJws(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, ptr1, len1, options.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {Storage} storage
    * @param {string} fragment
    * @param {Presentation} presentation
    * @param {JwsSignatureOptions} signature_options
    * @param {JwtPresentationOptions} presentation_options
    * @returns {Promise<Jwt>}
    */
    createPresentationJwtPqc(storage, fragment, presentation, signature_options, presentation_options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        _assertClass(presentation, Presentation);
        _assertClass(signature_options, JwsSignatureOptions);
        _assertClass(presentation_options, JwtPresentationOptions);
        wasm$1.coredocument_createPresentationJwtPqc(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, presentation.__wbg_ptr, signature_options.__wbg_ptr, presentation_options.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {Storage} storage
    * @param {string} fragment
    * @param {Presentation} presentation
    * @param {JwsSignatureOptions} signature_options
    * @param {JwtPresentationOptions} presentation_options
    * @returns {Promise<Jwt>}
    */
    createPresentationJwtHybrid(storage, fragment, presentation, signature_options, presentation_options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        _assertClass(presentation, Presentation);
        _assertClass(signature_options, JwsSignatureOptions);
        _assertClass(presentation_options, JwtPresentationOptions);
        wasm$1.coredocument_createPresentationJwtHybrid(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, presentation.__wbg_ptr, signature_options.__wbg_ptr, presentation_options.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {SelectiveDisclosurePresentation} presentation
    * @param {string} method_id
    * @param {JwpPresentationOptions} options
    * @returns {Promise<Jpt>}
    */
    createPresentationJpt(presentation, method_id, options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(presentation, SelectiveDisclosurePresentation);
        var ptr0 = presentation.__destroy_into_raw();
        const ptr1 = passStringToWasm0$1(method_id, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN$1;
        _assertClass(options, JwpPresentationOptions);
        var ptr2 = options.__destroy_into_raw();
        wasm$1.coredocument_createPresentationJpt(retptr, this.__wbg_ptr, ptr0, ptr1, len1, ptr2);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
  }
  const CredentialFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_credential_free(ptr >>> 0));
  class Credential {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Credential.prototype);
      obj.__wbg_ptr = ptr;
      CredentialFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      CredentialFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_credential_free(ptr);
    }
    /**
    * Returns the base JSON-LD context.
    * @returns {string}
    */
    static BaseContext() {
      let deferred2_0;
      let deferred2_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_BaseContext(retptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        var r3 = getInt32Memory0$1()[retptr / 4 + 3];
        var ptr1 = r0;
        var len1 = r1;
        if (r3) {
          ptr1 = 0;
          len1 = 0;
          throw takeObject$1(r2);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0$1(ptr1, len1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred2_0, deferred2_1, 1);
      }
    }
    /**
    * Returns the base type.
    * @returns {string}
    */
    static BaseType() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_BaseType(retptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Constructs a new {@link Credential}.
    * @param {ICredential} values
    */
    constructor(values) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_new(retptr, addHeapObject$1(values));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {IDomainLinkageCredential} values
    * @returns {Credential}
    */
    static createDomainLinkageCredential(values) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_createDomainLinkageCredential(retptr, addHeapObject$1(values));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Credential.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the JSON-LD context(s) applicable to the {@link Credential}.
    * @returns {Array<string | Record<string, any>>}
    */
    context() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_context(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the unique `URI` identifying the {@link Credential} .
    * @returns {string | undefined}
    */
    id() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_id(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the URIs defining the type of the {@link Credential}.
    * @returns {Array<string>}
    */
    type() {
      const ret = wasm$1.credential_type(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Returns a copy of the {@link Credential} subject(s).
    * @returns {Array<Subject>}
    */
    credentialSubject() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_credentialSubject(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the issuer of the {@link Credential}.
    * @returns {string | Issuer}
    */
    issuer() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_issuer(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the timestamp of when the {@link Credential} becomes valid.
    * @returns {Timestamp}
    */
    issuanceDate() {
      const ret = wasm$1.credential_issuanceDate(this.__wbg_ptr);
      return Timestamp.__wrap(ret);
    }
    /**
    * Returns a copy of the timestamp of when the {@link Credential} should no longer be considered valid.
    * @returns {Timestamp | undefined}
    */
    expirationDate() {
      const ret = wasm$1.credential_expirationDate(this.__wbg_ptr);
      return ret === 0 ? void 0 : Timestamp.__wrap(ret);
    }
    /**
    * Returns a copy of the information used to determine the current status of the {@link Credential}.
    * @returns {Array<Status>}
    */
    credentialStatus() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_credentialStatus(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the information used to assist in the enforcement of a specific {@link Credential} structure.
    * @returns {Array<Schema>}
    */
    credentialSchema() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_credentialSchema(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the service(s) used to refresh an expired {@link Credential}.
    * @returns {Array<RefreshService>}
    */
    refreshService() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_refreshService(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the terms-of-use specified by the {@link Credential} issuer.
    * @returns {Array<Policy>}
    */
    termsOfUse() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_termsOfUse(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the human-readable evidence used to support the claims within the {@link Credential}.
    * @returns {Array<Evidence>}
    */
    evidence() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_evidence(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns whether or not the {@link Credential} must only be contained within a  {@link Presentation}
    * with a proof issued from the {@link Credential} subject.
    * @returns {boolean | undefined}
    */
    nonTransferable() {
      const ret = wasm$1.credential_nonTransferable(this.__wbg_ptr);
      return ret === 16777215 ? void 0 : ret !== 0;
    }
    /**
    * Optional cryptographic proof, unrelated to JWT.
    * @returns {Proof | undefined}
    */
    proof() {
      const ret = wasm$1.credential_proof(this.__wbg_ptr);
      return ret === 0 ? void 0 : Proof.__wrap(ret);
    }
    /**
    * Returns a copy of the miscellaneous properties on the {@link Credential}.
    * @returns {Map<string, any>}
    */
    properties() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_properties(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the `proof` property of the {@link Credential}.
    *
    * Note that this proof is not related to JWT.
    * @param {Proof | undefined} [proof]
    */
    setProof(proof) {
      let ptr0 = 0;
      if (!isLikeNone$1(proof)) {
        _assertClass(proof, Proof);
        ptr0 = proof.__destroy_into_raw();
      }
      wasm$1.credential_setProof(this.__wbg_ptr, ptr0);
    }
    /**
    * Serializes the `Credential` as a JWT claims set
    * in accordance with [VC Data Model v1.1](https://www.w3.org/TR/vc-data-model/#json-web-token).
    *
    * The resulting object can be used as the payload of a JWS when issuing the credential.
    * @param {Record<string, any> | undefined} [custom_claims]
    * @returns {Record<string, any>}
    */
    toJwtClaims(custom_claims) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_toJwtClaims(retptr, this.__wbg_ptr, isLikeNone$1(custom_claims) ? 0 : addHeapObject$1(custom_claims));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {Credential}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.credential_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Credential.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {Credential}
    */
    clone() {
      const ret = wasm$1.credential_clone(this.__wbg_ptr);
      return Credential.__wrap(ret);
    }
  }
  const CustomMethodDataFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_custommethoddata_free(ptr >>> 0));
  class CustomMethodData {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(CustomMethodData.prototype);
      obj.__wbg_ptr = ptr;
      CustomMethodDataFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      CustomMethodDataFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_custommethoddata_free(ptr);
    }
    /**
    * @param {string} name
    * @param {any} data
    */
    constructor(name, data) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(name, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.custommethoddata_new(retptr, ptr0, len0, addHeapObject$1(data));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deep clones the object.
    * @returns {CustomMethodData}
    */
    clone() {
      const ret = wasm$1.custommethoddata_clone(this.__wbg_ptr);
      return CustomMethodData.__wrap(ret);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.custommethoddata_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {CustomMethodData}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.custommethoddata_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return CustomMethodData.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
  }
  const DIDCompositeJwkFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_didcompositejwk_free(ptr >>> 0));
  class DIDCompositeJwk {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(DIDCompositeJwk.prototype);
      obj.__wbg_ptr = ptr;
      DIDCompositeJwkFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      DIDCompositeJwkFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_didcompositejwk_free(ptr);
    }
    /**
    * Creates a new {@link DIDCompositeJwk} from a {@link CoreDID}.
    *
    * ### Errors
    * Throws an error if the given did is not a valid `did:compositejwk` DID.
    * @param {CoreDID | IToCoreDID} did
    */
    constructor(did) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didcompositejwk_new(retptr, addHeapObject$1(did));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Parses a {@link DIDCompositeJwk} from the given `input`.
    *
    * ### Errors
    *
    * Throws an error if the input is not a valid {@link DIDCompositeJwk}.
    * @param {string} input
    * @returns {DIDCompositeJwk}
    */
    static parse(input) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(input, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.didcompositejwk_parse(retptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return DIDCompositeJwk.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the JSON WEB KEY (JWK) encoded inside this `did:jwk`.
    * @returns {CompositeJwk}
    */
    composite_jwk() {
      const ret = wasm$1.didcompositejwk_composite_jwk(this.__wbg_ptr);
      return CompositeJwk.__wrap(ret);
    }
    /**
    * Returns the {@link CoreDID} scheme.
    *
    * E.g.
    * - `"did:example:12345678" -> "did"`
    * - `"did:iota:smr:12345678" -> "did"`
    * @returns {string}
    */
    scheme() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didcompositejwk_scheme(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the {@link CoreDID} authority: the method name and method-id.
    *
    * E.g.
    * - `"did:example:12345678" -> "example:12345678"`
    * - `"did:iota:smr:12345678" -> "iota:smr:12345678"`
    * @returns {string}
    */
    authority() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didcompositejwk_authority(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the {@link CoreDID} method name.
    *
    * E.g.
    * - `"did:example:12345678" -> "example"`
    * - `"did:iota:smr:12345678" -> "iota"`
    * @returns {string}
    */
    method() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didcompositejwk_method(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the {@link CoreDID} method-specific ID.
    *
    * E.g.
    * - `"did:example:12345678" -> "12345678"`
    * - `"did:iota:smr:12345678" -> "smr:12345678"`
    * @returns {string}
    */
    methodId() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didcompositejwk_methodId(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the {@link CoreDID} as a string.
    * @returns {string}
    */
    toString() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didcompositejwk_toString(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * @returns {CoreDID}
    */
    toCoreDid() {
      const ret = wasm$1.didcompositejwk_toCoreDid(this.__wbg_ptr);
      return CoreDID.__wrap(ret);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didcompositejwk_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {DIDCompositeJwk}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didcompositejwk_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return DIDCompositeJwk.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {DIDCompositeJwk}
    */
    clone() {
      const ret = wasm$1.didcompositejwk_clone(this.__wbg_ptr);
      return DIDCompositeJwk.__wrap(ret);
    }
  }
  const DIDJwkFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_didjwk_free(ptr >>> 0));
  class DIDJwk {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(DIDJwk.prototype);
      obj.__wbg_ptr = ptr;
      DIDJwkFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      DIDJwkFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_didjwk_free(ptr);
    }
    /**
    * Creates a new {@link DIDJwk} from a {@link CoreDID}.
    *
    * ### Errors
    * Throws an error if the given did is not a valid `did:jwk` DID.
    * @param {CoreDID | IToCoreDID} did
    */
    constructor(did) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didjwk_new(retptr, addHeapObject$1(did));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Parses a {@link DIDJwk} from the given `input`.
    *
    * ### Errors
    *
    * Throws an error if the input is not a valid {@link DIDJwk}.
    * @param {string} input
    * @returns {DIDJwk}
    */
    static parse(input) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(input, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.didjwk_parse(retptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return DIDJwk.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the JSON WEB KEY (JWK) encoded inside this `did:jwk`.
    * @returns {Jwk}
    */
    jwk() {
      const ret = wasm$1.didjwk_jwk(this.__wbg_ptr);
      return Jwk.__wrap(ret);
    }
    /**
    * Returns the {@link CoreDID} scheme.
    *
    * E.g.
    * - `"did:example:12345678" -> "did"`
    * - `"did:iota:smr:12345678" -> "did"`
    * @returns {string}
    */
    scheme() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didjwk_scheme(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the {@link CoreDID} authority: the method name and method-id.
    *
    * E.g.
    * - `"did:example:12345678" -> "example:12345678"`
    * - `"did:iota:smr:12345678" -> "iota:smr:12345678"`
    * @returns {string}
    */
    authority() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didjwk_authority(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the {@link CoreDID} method name.
    *
    * E.g.
    * - `"did:example:12345678" -> "example"`
    * - `"did:iota:smr:12345678" -> "iota"`
    * @returns {string}
    */
    method() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didjwk_method(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the {@link CoreDID} method-specific ID.
    *
    * E.g.
    * - `"did:example:12345678" -> "12345678"`
    * - `"did:iota:smr:12345678" -> "smr:12345678"`
    * @returns {string}
    */
    methodId() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didjwk_methodId(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the {@link CoreDID} as a string.
    * @returns {string}
    */
    toString() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didjwk_toString(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * @returns {CoreDID}
    */
    toCoreDid() {
      const ret = wasm$1.didjwk_toCoreDid(this.__wbg_ptr);
      return CoreDID.__wrap(ret);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didjwk_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {DIDJwk}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didjwk_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return DIDJwk.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {DIDJwk}
    */
    clone() {
      const ret = wasm$1.didjwk_clone(this.__wbg_ptr);
      return DIDJwk.__wrap(ret);
    }
  }
  const DIDUrlFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_didurl_free(ptr >>> 0));
  class DIDUrl {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(DIDUrl.prototype);
      obj.__wbg_ptr = ptr;
      DIDUrlFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      DIDUrlFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_didurl_free(ptr);
    }
    /**
    * Parses a {@link DIDUrl} from the input string.
    * @param {string} input
    * @returns {DIDUrl}
    */
    static parse(input) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(input, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.didurl_parse(retptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return DIDUrl.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Return a copy of the {@link CoreDID} section of the {@link DIDUrl}.
    * @returns {CoreDID}
    */
    did() {
      const ret = wasm$1.didurl_did(this.__wbg_ptr);
      return CoreDID.__wrap(ret);
    }
    /**
    * Return a copy of the relative DID Url as a string, including only the path, query, and fragment.
    * @returns {string}
    */
    urlStr() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didurl_urlStr(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns a copy of the {@link DIDUrl} method fragment, if any. Excludes the leading '#'.
    * @returns {string | undefined}
    */
    fragment() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didurl_fragment(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the `fragment` component of the {@link DIDUrl}.
    * @param {string | undefined} [value]
    */
    setFragment(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        var ptr0 = isLikeNone$1(value) ? 0 : passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN$1;
        wasm$1.didurl_setFragment(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the {@link DIDUrl} path.
    * @returns {string | undefined}
    */
    path() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didurl_path(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the `path` component of the {@link DIDUrl}.
    * @param {string | undefined} [value]
    */
    setPath(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        var ptr0 = isLikeNone$1(value) ? 0 : passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN$1;
        wasm$1.didurl_setPath(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the {@link DIDUrl} method query, if any. Excludes the leading '?'.
    * @returns {string | undefined}
    */
    query() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didurl_query(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the `query` component of the {@link DIDUrl}.
    * @param {string | undefined} [value]
    */
    setQuery(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        var ptr0 = isLikeNone$1(value) ? 0 : passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN$1;
        wasm$1.didurl_setQuery(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Append a string representing a path, query, and/or fragment, returning a new {@link DIDUrl}.
    *
    * Must begin with a valid delimiter character: '/', '?', '#'. Overwrites the existing URL
    * segment and any following segments in order of path, query, then fragment.
    *
    * I.e.
    * - joining a path will clear the query and fragment.
    * - joining a query will clear the fragment.
    * - joining a fragment will only overwrite the fragment.
    * @param {string} segment
    * @returns {DIDUrl}
    */
    join(segment) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(segment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.didurl_join(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return DIDUrl.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the {@link DIDUrl} as a string.
    * @returns {string}
    */
    toString() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didurl_toString(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didurl_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {DIDUrl}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.didurl_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return DIDUrl.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {DIDUrl}
    */
    clone() {
      const ret = wasm$1.didurl_clone(this.__wbg_ptr);
      return DIDUrl.__wrap(ret);
    }
  }
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_decodedjptcredential_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_decodedjptpresentation_free(ptr >>> 0));
  const DecodedJwsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_decodedjws_free(ptr >>> 0));
  class DecodedJws {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(DecodedJws.prototype);
      obj.__wbg_ptr = ptr;
      DecodedJwsFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      DecodedJwsFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_decodedjws_free(ptr);
    }
    /**
    * Returns a copy of the parsed claims represented as a string.
    *
    * # Errors
    * An error is thrown if the claims cannot be represented as a string.
    *
    * This error can only occur if the Token was decoded from a detached payload.
    * @returns {string}
    */
    claims() {
      let deferred2_0;
      let deferred2_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.decodedjws_claims(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        var r3 = getInt32Memory0$1()[retptr / 4 + 3];
        var ptr1 = r0;
        var len1 = r1;
        if (r3) {
          ptr1 = 0;
          len1 = 0;
          throw takeObject$1(r2);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0$1(ptr1, len1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred2_0, deferred2_1, 1);
      }
    }
    /**
    * Return a copy of the parsed claims represented as an array of bytes.
    * @returns {Uint8Array}
    */
    claimsBytes() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.decodedjws_claimsBytes(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var v1 = getArrayU8FromWasm0(r0, r1).slice();
        wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the protected header.
    * @returns {JwsHeader}
    */
    protectedHeader() {
      const ret = wasm$1.decodedjws_protectedHeader(this.__wbg_ptr);
      return JwsHeader.__wrap(ret);
    }
    /**
    * Deep clones the object.
    * @returns {DecodedJws}
    */
    clone() {
      const ret = wasm$1.decodedjws_clone(this.__wbg_ptr);
      return DecodedJws.__wrap(ret);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.decodedjws_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
  }
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_decodedjwtcredential_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_decodedjwtpresentation_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_disclosure_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_domainlinkageconfiguration_free(ptr >>> 0));
  const DurationFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_duration_free(ptr >>> 0));
  class Duration {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Duration.prototype);
      obj.__wbg_ptr = ptr;
      DurationFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      DurationFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_duration_free(ptr);
    }
    /**
    * Create a new {@link Duration} with the given number of seconds.
    * @param {number} seconds
    * @returns {Duration}
    */
    static seconds(seconds) {
      const ret = wasm$1.duration_seconds(seconds);
      return Duration.__wrap(ret);
    }
    /**
    * Create a new {@link Duration} with the given number of minutes.
    * @param {number} minutes
    * @returns {Duration}
    */
    static minutes(minutes) {
      const ret = wasm$1.duration_minutes(minutes);
      return Duration.__wrap(ret);
    }
    /**
    * Create a new {@link Duration} with the given number of hours.
    * @param {number} hours
    * @returns {Duration}
    */
    static hours(hours) {
      const ret = wasm$1.duration_hours(hours);
      return Duration.__wrap(ret);
    }
    /**
    * Create a new {@link Duration} with the given number of days.
    * @param {number} days
    * @returns {Duration}
    */
    static days(days) {
      const ret = wasm$1.duration_days(days);
      return Duration.__wrap(ret);
    }
    /**
    * Create a new {@link Duration} with the given number of weeks.
    * @param {number} weeks
    * @returns {Duration}
    */
    static weeks(weeks) {
      const ret = wasm$1.duration_weeks(weeks);
      return Duration.__wrap(ret);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.duration_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {Duration}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.duration_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Duration.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
  }
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_ecdsajwsverifier_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_eddsajwsverifier_free(ptr >>> 0));
  const IotaDIDFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_iotadid_free(ptr >>> 0));
  class IotaDID {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(IotaDID.prototype);
      obj.__wbg_ptr = ptr;
      IotaDIDFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {
        METHOD: this.METHOD,
        DEFAULT_NETWORK: this.DEFAULT_NETWORK
      };
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      IotaDIDFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_iotadid_free(ptr);
    }
    /**
    * The IOTA DID method name (`"iota"`).
    * @returns {string}
    */
    static get METHOD() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadid_static_default_network(retptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * The default Tangle network (`"iota"`).
    * @returns {string}
    */
    static get DEFAULT_NETWORK() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadid_static_default_network(retptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Constructs a new {@link IotaDID} from a byte representation of the tag and the given
    * network name.
    *
    * See also {@link IotaDID.placeholder}.
    * @param {Uint8Array} bytes
    * @param {string} network
    */
    constructor(bytes2, network) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passArray8ToWasm0(bytes2, wasm$1.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN$1;
        const ptr1 = passStringToWasm0$1(network, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN$1;
        wasm$1.iotadid_new(retptr, ptr0, len0, ptr1, len1);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Constructs a new {@link IotaDID} from a hex representation of an Alias Id and the given
    * network name.
    * @param {string} aliasId
    * @param {string} network
    * @returns {IotaDID}
    */
    static fromAliasId(aliasId, network) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(aliasId, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        const ptr1 = passStringToWasm0$1(network, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN$1;
        wasm$1.iotadid_fromAliasId(retptr, ptr0, len0, ptr1, len1);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return IotaDID.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Creates a new placeholder {@link IotaDID} with the given network name.
    *
    * E.g. `did:iota:smr:0x0000000000000000000000000000000000000000000000000000000000000000`.
    * @param {string} network
    * @returns {IotaDID}
    */
    static placeholder(network) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(network, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.iotadid_placeholder(retptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return IotaDID.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Parses a {@link IotaDID} from the input string.
    * @param {string} input
    * @returns {IotaDID}
    */
    static parse(input) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(input, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.iotadid_parse(retptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return IotaDID.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the Tangle network name of the {@link IotaDID}.
    * @returns {string}
    */
    network() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadid_network(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns a copy of the unique tag of the {@link IotaDID}.
    * @returns {string}
    */
    tag() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadid_tag(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the DID represented as a {@link CoreDID}.
    * @returns {CoreDID}
    */
    toCoreDid() {
      const ret = wasm$1.coredid_clone(this.__wbg_ptr);
      return CoreDID.__wrap(ret);
    }
    /**
    * Returns the `DID` scheme.
    *
    * E.g.
    * - `"did:example:12345678" -> "did"`
    * - `"did:iota:main:12345678" -> "did"`
    * @returns {string}
    */
    scheme() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredid_scheme(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the `DID` authority: the method name and method-id.
    *
    * E.g.
    * - `"did:example:12345678" -> "example:12345678"`
    * - `"did:iota:main:12345678" -> "iota:main:12345678"`
    * @returns {string}
    */
    authority() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.coredid_authority(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the `DID` method name.
    *
    * E.g.
    * - `"did:example:12345678" -> "example"`
    * - `"did:iota:main:12345678" -> "iota"`
    * @returns {string}
    */
    method() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadid_method(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the `DID` method-specific ID.
    *
    * E.g.
    * - `"did:example:12345678" -> "12345678"`
    * - `"did:iota:main:12345678" -> "main:12345678"`
    * @returns {string}
    */
    methodId() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadid_methodId(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Construct a new {@link DIDUrl} by joining with a relative DID Url string.
    * @param {string} segment
    * @returns {DIDUrl}
    */
    join(segment) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(segment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.iotadid_join(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return DIDUrl.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Clones the `DID` into a {@link DIDUrl}.
    * @returns {DIDUrl}
    */
    toUrl() {
      const ret = wasm$1.iotadid_toUrl(this.__wbg_ptr);
      return DIDUrl.__wrap(ret);
    }
    /**
    * Returns the hex-encoded AliasId with a '0x' prefix, from the DID tag.
    * @returns {string}
    */
    toAliasId() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadid_toAliasId(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Converts the `DID` into a {@link DIDUrl}, consuming it.
    * @returns {DIDUrl}
    */
    intoUrl() {
      const ptr = this.__destroy_into_raw();
      const ret = wasm$1.iotadid_intoUrl(ptr);
      return DIDUrl.__wrap(ret);
    }
    /**
    * Returns the `DID` as a string.
    * @returns {string}
    */
    toString() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadid_toString(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadid_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {IotaDID}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadid_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return IotaDID.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {IotaDID}
    */
    clone() {
      const ret = wasm$1.iotadid_clone(this.__wbg_ptr);
      return IotaDID.__wrap(ret);
    }
  }
  const IotaDocumentFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_iotadocument_free(ptr >>> 0));
  class IotaDocument {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(IotaDocument.prototype);
      obj.__wbg_ptr = ptr;
      IotaDocumentFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      IotaDocumentFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_iotadocument_free(ptr);
    }
    /**
    * Constructs an empty IOTA DID Document with a {@link IotaDID.placeholder} identifier
    * for the given `network`.
    * @param {string} network
    */
    constructor(network) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(network, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.iotadocument_new(retptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Constructs an empty DID Document with the given identifier.
    * @param {IotaDID} id
    * @returns {IotaDocument}
    */
    static newWithId(id2) {
      _assertClass(id2, IotaDID);
      const ret = wasm$1.iotadocument_newWithId(id2.__wbg_ptr);
      return IotaDocument.__wrap(ret);
    }
    /**
    * Returns a copy of the DID Document `id`.
    * @returns {IotaDID}
    */
    id() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_id(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return IotaDID.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the list of document controllers.
    *
    * NOTE: controllers are determined by the `state_controller` unlock condition of the output
    * during resolution and are omitted when publishing.
    * @returns {IotaDID[]}
    */
    controller() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_controller(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the controllers of the document.
    *
    * Note: Duplicates will be ignored.
    * Use `null` to remove all controllers.
    * @param {IotaDID[] | null} controller
    */
    setController(controller) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_setController(retptr, this.__wbg_ptr, addBorrowedObject(controller));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Returns a copy of the document's `alsoKnownAs` set.
    * @returns {Array<string>}
    */
    alsoKnownAs() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_alsoKnownAs(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the `alsoKnownAs` property in the DID document.
    * @param {string | string[] | null} urls
    */
    setAlsoKnownAs(urls) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_setAlsoKnownAs(retptr, this.__wbg_ptr, addBorrowedObject(urls));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Returns a copy of the custom DID Document properties.
    * @returns {Map<string, any>}
    */
    properties() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_properties(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a custom property in the DID Document.
    * If the value is set to `null`, the custom property will be removed.
    *
    * ### WARNING
    *
    * This method can overwrite existing properties like `id` and result in an invalid document.
    * @param {string} key
    * @param {any} value
    */
    setPropertyUnchecked(key, value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(key, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.iotadocument_setPropertyUnchecked(retptr, this.__wbg_ptr, ptr0, len0, addBorrowedObject(value));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Return a set of all {@link Service} in the document.
    * @returns {Service[]}
    */
    service() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_service(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Add a new {@link Service} to the document.
    *
    * Returns `true` if the service was added.
    * @param {Service} service
    */
    insertService(service) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(service, Service);
        wasm$1.iotadocument_insertService(retptr, this.__wbg_ptr, service.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Remove a {@link Service} identified by the given {@link DIDUrl} from the document.
    *
    * Returns `true` if a service was removed.
    * @param {DIDUrl} did
    * @returns {Service | undefined}
    */
    removeService(did) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(did, DIDUrl);
        wasm$1.iotadocument_removeService(retptr, this.__wbg_ptr, did.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 === 0 ? void 0 : Service.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the first {@link Service} with an `id` property matching the provided `query`,
    * if present.
    * @param {DIDUrl | string} query
    * @returns {Service | undefined}
    */
    resolveService(query) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_resolveService(retptr, this.__wbg_ptr, addBorrowedObject(query));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 === 0 ? void 0 : Service.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Returns a list of all {@link VerificationMethod} in the DID Document,
    * whose verification relationship matches `scope`.
    *
    * If `scope` is not set, a list over the **embedded** methods is returned.
    * @param {MethodScope | undefined} [scope]
    * @returns {VerificationMethod[]}
    */
    methods(scope) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_methods(retptr, this.__wbg_ptr, isLikeNone$1(scope) ? 0 : addHeapObject$1(scope));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Adds a new `method` to the document in the given `scope`.
    * @param {VerificationMethod} method
    * @param {MethodScope} scope
    */
    insertMethod(method, scope) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(method, VerificationMethod);
        _assertClass(scope, MethodScope);
        wasm$1.iotadocument_insertMethod(retptr, this.__wbg_ptr, method.__wbg_ptr, scope.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Removes all references to the specified Verification Method.
    * @param {DIDUrl} did
    * @returns {VerificationMethod | undefined}
    */
    removeMethod(did) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(did, DIDUrl);
        wasm$1.iotadocument_removeMethod(retptr, this.__wbg_ptr, did.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 === 0 ? void 0 : VerificationMethod.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the first verification method with an `id` property
    * matching the provided `query` and the verification relationship
    * specified by `scope`, if present.
    * @param {DIDUrl | string} query
    * @param {MethodScope | undefined} [scope]
    * @returns {VerificationMethod | undefined}
    */
    resolveMethod(query, scope) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_resolveMethod(retptr, this.__wbg_ptr, addBorrowedObject(query), isLikeNone$1(scope) ? 0 : addHeapObject$1(scope));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 === 0 ? void 0 : VerificationMethod.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Attaches the relationship to the given method, if the method exists.
    *
    * Note: The method needs to be in the set of verification methods,
    * so it cannot be an embedded one.
    * @param {DIDUrl} didUrl
    * @param {MethodRelationship} relationship
    * @returns {boolean}
    */
    attachMethodRelationship(didUrl, relationship) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(didUrl, DIDUrl);
        wasm$1.iotadocument_attachMethodRelationship(retptr, this.__wbg_ptr, didUrl.__wbg_ptr, relationship);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 !== 0;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Detaches the given relationship from the given method, if the method exists.
    * @param {DIDUrl} didUrl
    * @param {MethodRelationship} relationship
    * @returns {boolean}
    */
    detachMethodRelationship(didUrl, relationship) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(didUrl, DIDUrl);
        wasm$1.iotadocument_detachMethodRelationship(retptr, this.__wbg_ptr, didUrl.__wbg_ptr, relationship);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 !== 0;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Decodes and verifies the provided JWS according to the passed `options` and `signatureVerifier`.
    * If a `signatureVerifier` is provided it will be used when
    * verifying decoded JWS signatures, otherwise a default verifier capable of handling the `EdDSA`, `ES256`, `ES256K`
    * algorithms will be used.
    *
    * Regardless of which options are passed the following conditions must be met in order for a verification attempt to
    * take place.
    * - The JWS must be encoded according to the JWS compact serialization.
    * - The `kid` value in the protected header must be an identifier of a verification method in this DID document.
    * @param {Jws} jws
    * @param {JwsVerificationOptions} options
    * @param {IJwsVerifier | undefined} [signatureVerifier]
    * @param {string | undefined} [detachedPayload]
    * @returns {DecodedJws}
    */
    verifyJws(jws, options, signatureVerifier, detachedPayload) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(jws, Jws);
        _assertClass(options, JwsVerificationOptions);
        var ptr0 = isLikeNone$1(detachedPayload) ? 0 : passStringToWasm0$1(detachedPayload, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN$1;
        wasm$1.iotadocument_verifyJws(retptr, this.__wbg_ptr, jws.__wbg_ptr, options.__wbg_ptr, isLikeNone$1(signatureVerifier) ? 0 : addHeapObject$1(signatureVerifier), ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return DecodedJws.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Serializes the document for inclusion in an Alias Output's state metadata
    * with the default {@link StateMetadataEncoding}.
    * @returns {Uint8Array}
    */
    pack() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_pack(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        var r3 = getInt32Memory0$1()[retptr / 4 + 3];
        if (r3) {
          throw takeObject$1(r2);
        }
        var v1 = getArrayU8FromWasm0(r0, r1).slice();
        wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Serializes the document for inclusion in an Alias Output's state metadata.
    * @param {StateMetadataEncoding} encoding
    * @returns {Uint8Array}
    */
    packWithEncoding(encoding) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_packWithEncoding(retptr, this.__wbg_ptr, encoding);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        var r3 = getInt32Memory0$1()[retptr / 4 + 3];
        if (r3) {
          throw takeObject$1(r2);
        }
        var v1 = getArrayU8FromWasm0(r0, r1).slice();
        wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes the document from an Alias Output.
    *
    * If `allowEmpty` is true, this will return an empty DID document marked as `deactivated`
    * if `stateMetadata` is empty.
    *
    * The `tokenSupply` must be equal to the token supply of the network the DID is associated with.
    *
    * NOTE: `did` is required since it is omitted from the serialized DID Document and
    * cannot be inferred from the state metadata. It also indicates the network, which is not
    * encoded in the `AliasId` alone.
    * @param {IotaDID} did
    * @param {AliasOutputBuilderParams} aliasOutput
    * @param {boolean} allowEmpty
    * @returns {IotaDocument}
    */
    static unpackFromOutput(did, aliasOutput, allowEmpty) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(did, IotaDID);
        wasm$1.iotadocument_unpackFromOutput(retptr, did.__wbg_ptr, addHeapObject$1(aliasOutput), allowEmpty);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return IotaDocument.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns all DID documents of the Alias Outputs contained in the block's transaction payload
    * outputs, if any.
    *
    * Errors if any Alias Output does not contain a valid or empty DID Document.
    * @param {string} network
    * @param {Block} block
    * @returns {IotaDocument[]}
    */
    static unpackFromBlock(network, block) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(network, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.iotadocument_unpackFromBlock(retptr, ptr0, len0, addBorrowedObject(block));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Returns a copy of the metadata associated with this document.
    *
    * NOTE: Copies all the metadata. See also `metadataCreated`, `metadataUpdated`,
    * `metadataPreviousMessageId`, `metadataProof` if only a subset of the metadata required.
    * @returns {IotaDocumentMetadata}
    */
    metadata() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_metadata(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return IotaDocumentMetadata.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the timestamp of when the DID document was created.
    * @returns {Timestamp | undefined}
    */
    metadataCreated() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_metadataCreated(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 === 0 ? void 0 : Timestamp.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the timestamp of when the DID document was created.
    * @param {Timestamp | undefined} timestamp
    */
    setMetadataCreated(timestamp) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_setMetadataCreated(retptr, this.__wbg_ptr, addHeapObject$1(timestamp));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the timestamp of the last DID document update.
    * @returns {Timestamp | undefined}
    */
    metadataUpdated() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_metadataUpdated(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 === 0 ? void 0 : Timestamp.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the timestamp of the last DID document update.
    * @param {Timestamp | undefined} timestamp
    */
    setMetadataUpdated(timestamp) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_setMetadataUpdated(retptr, this.__wbg_ptr, addHeapObject$1(timestamp));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the deactivated status of the DID document.
    * @returns {boolean | undefined}
    */
    metadataDeactivated() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_metadataDeactivated(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return r0 === 16777215 ? void 0 : r0 !== 0;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the deactivated status of the DID document.
    * @param {boolean | undefined} [deactivated]
    */
    setMetadataDeactivated(deactivated) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_setMetadataDeactivated(retptr, this.__wbg_ptr, isLikeNone$1(deactivated) ? 16777215 : deactivated ? 1 : 0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the Bech32-encoded state controller address, if present.
    * @returns {string | undefined}
    */
    metadataStateControllerAddress() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_metadataStateControllerAddress(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        var r3 = getInt32Memory0$1()[retptr / 4 + 3];
        if (r3) {
          throw takeObject$1(r2);
        }
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the Bech32-encoded governor address, if present.
    * @returns {string | undefined}
    */
    metadataGovernorAddress() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_metadataGovernorAddress(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        var r3 = getInt32Memory0$1()[retptr / 4 + 3];
        if (r3) {
          throw takeObject$1(r2);
        }
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a custom property in the document metadata.
    * If the value is set to `null`, the custom property will be removed.
    * @param {string} key
    * @param {any} value
    */
    setMetadataPropertyUnchecked(key, value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(key, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.iotadocument_setMetadataPropertyUnchecked(retptr, this.__wbg_ptr, ptr0, len0, addBorrowedObject(value));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * If the document has a {@link RevocationBitmap} service identified by `serviceQuery`,
    * revoke all specified `indices`.
    * @param {DIDUrl | string} serviceQuery
    * @param {number | number[]} indices
    */
    revokeCredentials(serviceQuery, indices) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_revokeCredentials(retptr, this.__wbg_ptr, addBorrowedObject(serviceQuery), addHeapObject$1(indices));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * If the document has a {@link RevocationBitmap} service identified by `serviceQuery`,
    * unrevoke all specified `indices`.
    * @param {DIDUrl | string} serviceQuery
    * @param {number | number[]} indices
    */
    unrevokeCredentials(serviceQuery, indices) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_unrevokeCredentials(retptr, this.__wbg_ptr, addBorrowedObject(serviceQuery), addHeapObject$1(indices));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Returns a deep clone of the {@link IotaDocument}.
    * @returns {IotaDocument}
    */
    clone() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_clone(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return IotaDocument.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * ### Warning
    * This is for internal use only. Do not rely on or call this method.
    * @returns {IotaDocument}
    */
    _shallowCloneInternal() {
      const ret = wasm$1.iotadocument__shallowCloneInternal(this.__wbg_ptr);
      return IotaDocument.__wrap(ret);
    }
    /**
    * ### Warning
    * This is for internal use only. Do not rely on or call this method.
    * @returns {number}
    */
    _strongCountInternal() {
      const ret = wasm$1.iotadocument__strongCountInternal(this.__wbg_ptr);
      return ret >>> 0;
    }
    /**
    * Serializes to a plain JS representation.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a plain JS representation.
    * @param {any} json
    * @returns {IotaDocument}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return IotaDocument.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Transforms the {@link IotaDocument} to its {@link CoreDocument} representation.
    * @returns {CoreDocument}
    */
    toCoreDocument() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocument_toCoreDocument(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return CoreDocument.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Generate new key material in the given `storage` and insert a new verification method with the corresponding
    * public key material into the DID document.
    *
    * - If no fragment is given the `kid` of the generated JWK is used, if it is set, otherwise an error is returned.
    * - The `keyType` must be compatible with the given `storage`. `Storage`s are expected to export key type constants
    * for that use case.
    *
    * The fragment of the generated method is returned.
    * @param {Storage} storage
    * @param {string} keyType
    * @param {JwsAlgorithm} alg
    * @param {string | undefined} fragment
    * @param {MethodScope} scope
    * @returns {Promise<string>}
    */
    generateMethod(storage, keyType, alg, fragment, scope) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(keyType, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        var ptr1 = isLikeNone$1(fragment) ? 0 : passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN$1;
        _assertClass(scope, MethodScope);
        var ptr2 = scope.__destroy_into_raw();
        wasm$1.iotadocument_generateMethod(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, addHeapObject$1(alg), ptr1, len1, ptr2);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Remove the method identified by the given fragment from the document and delete the corresponding key material in
    * the given `storage`.
    * @param {Storage} storage
    * @param {DIDUrl} id
    * @returns {Promise<void>}
    */
    purgeMethod(storage, id2) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        _assertClass(id2, DIDUrl);
        wasm$1.iotadocument_purgeMethod(retptr, this.__wbg_ptr, storage.__wbg_ptr, id2.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sign the `payload` according to `options` with the storage backed private key corresponding to the public key
    * material in the verification method identified by the given `fragment.
    *
    * Upon success a string representing a JWS encoded according to the Compact JWS Serialization format is returned.
    * See [RFC7515 section 3.1](https://www.rfc-editor.org/rfc/rfc7515#section-3.1).
    *
    * @deprecated Use `createJws()` instead.
    * @param {Storage} storage
    * @param {string} fragment
    * @param {string} payload
    * @param {JwsSignatureOptions} options
    * @returns {Promise<Jws>}
    */
    createJwt(storage, fragment, payload, options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        const ptr1 = passStringToWasm0$1(payload, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN$1;
        _assertClass(options, JwsSignatureOptions);
        wasm$1.iotadocument_createJwt(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, ptr1, len1, options.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sign the `payload` according to `options` with the storage backed private key corresponding to the public key
    * material in the verification method identified by the given `fragment.
    *
    * Upon success a string representing a JWS encoded according to the Compact JWS Serialization format is returned.
    * See [RFC7515 section 3.1](https://www.rfc-editor.org/rfc/rfc7515#section-3.1).
    * @param {Storage} storage
    * @param {string} fragment
    * @param {string} payload
    * @param {JwsSignatureOptions} options
    * @returns {Promise<Jws>}
    */
    createJws(storage, fragment, payload, options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        const ptr1 = passStringToWasm0$1(payload, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN$1;
        _assertClass(options, JwsSignatureOptions);
        wasm$1.iotadocument_createJws(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, ptr1, len1, options.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Produces a JWS where the payload is produced from the given `credential`
    * in accordance with [VC Data Model v1.1](https://www.w3.org/TR/vc-data-model/#json-web-token).
    *
    * Unless the `kid` is explicitly set in the options, the `kid` in the protected header is the `id`
    * of the method identified by `fragment` and the JWS signature will be produced by the corresponding
    * private key backed by the `storage` in accordance with the passed `options`.
    *
    * The `custom_claims` can be used to set additional claims on the resulting JWT.
    * @param {Storage} storage
    * @param {string} fragment
    * @param {Credential} credential
    * @param {JwsSignatureOptions} options
    * @param {Record<string, any> | undefined} [custom_claims]
    * @returns {Promise<Jwt>}
    */
    createCredentialJwt(storage, fragment, credential, options, custom_claims) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        _assertClass(credential, Credential);
        _assertClass(options, JwsSignatureOptions);
        wasm$1.iotadocument_createCredentialJwt(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, credential.__wbg_ptr, options.__wbg_ptr, isLikeNone$1(custom_claims) ? 0 : addHeapObject$1(custom_claims));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Produces a JWT where the payload is produced from the given presentation.
    * in accordance with [VC Data Model v1.1](https://www.w3.org/TR/vc-data-model/#json-web-token).
    *
    * Unless the `kid` is explicitly set in the options, the `kid` in the protected header is the `id`
    * of the method identified by `fragment` and the JWS signature will be produced by the corresponding
    * private key backed by the `storage` in accordance with the passed `options`.
    * @param {Storage} storage
    * @param {string} fragment
    * @param {Presentation} presentation
    * @param {JwsSignatureOptions} signature_options
    * @param {JwtPresentationOptions} presentation_options
    * @returns {Promise<Jwt>}
    */
    createPresentationJwt(storage, fragment, presentation, signature_options, presentation_options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        _assertClass(presentation, Presentation);
        _assertClass(signature_options, JwsSignatureOptions);
        _assertClass(presentation_options, JwtPresentationOptions);
        wasm$1.iotadocument_createPresentationJwt(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, presentation.__wbg_ptr, signature_options.__wbg_ptr, presentation_options.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {Storage} storage
    * @param {ProofAlgorithm} alg
    * @param {string | undefined} fragment
    * @param {MethodScope} scope
    * @returns {Promise<string>}
    */
    generateMethodJwp(storage, alg, fragment, scope) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        var ptr0 = isLikeNone$1(fragment) ? 0 : passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN$1;
        _assertClass(scope, MethodScope);
        var ptr1 = scope.__destroy_into_raw();
        wasm$1.iotadocument_generateMethodJwp(retptr, this.__wbg_ptr, storage.__wbg_ptr, alg, ptr0, len0, ptr1);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {Storage} storage
    * @param {string} fragment
    * @param {JptClaims} jpt_claims
    * @param {JwpCredentialOptions} options
    * @returns {Promise<string>}
    */
    createIssuedJwp(storage, fragment, jpt_claims, options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        _assertClass(options, JwpCredentialOptions);
        var ptr1 = options.__destroy_into_raw();
        wasm$1.iotadocument_createIssuedJwp(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, addHeapObject$1(jpt_claims), ptr1);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {SelectiveDisclosurePresentation} presentation
    * @param {string} method_id
    * @param {JwpPresentationOptions} options
    * @returns {Promise<string>}
    */
    createPresentedJwp(presentation, method_id, options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(presentation, SelectiveDisclosurePresentation);
        var ptr0 = presentation.__destroy_into_raw();
        const ptr1 = passStringToWasm0$1(method_id, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN$1;
        _assertClass(options, JwpPresentationOptions);
        var ptr2 = options.__destroy_into_raw();
        wasm$1.iotadocument_createPresentedJwp(retptr, this.__wbg_ptr, ptr0, ptr1, len1, ptr2);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {Credential} credential
    * @param {Storage} storage
    * @param {string} fragment
    * @param {JwpCredentialOptions} options
    * @param {Map<string, any> | undefined} [custom_claims]
    * @returns {Promise<Jpt>}
    */
    createCredentialJpt(credential, storage, fragment, options, custom_claims) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(credential, Credential);
        var ptr0 = credential.__destroy_into_raw();
        _assertClass(storage, Storage);
        const ptr1 = passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN$1;
        _assertClass(options, JwpCredentialOptions);
        var ptr2 = options.__destroy_into_raw();
        wasm$1.iotadocument_createCredentialJpt(retptr, this.__wbg_ptr, ptr0, storage.__wbg_ptr, ptr1, len1, ptr2, isLikeNone$1(custom_claims) ? 0 : addHeapObject$1(custom_claims));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {SelectiveDisclosurePresentation} presentation
    * @param {string} method_id
    * @param {JwpPresentationOptions} options
    * @returns {Promise<Jpt>}
    */
    createPresentationJpt(presentation, method_id, options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(presentation, SelectiveDisclosurePresentation);
        var ptr0 = presentation.__destroy_into_raw();
        const ptr1 = passStringToWasm0$1(method_id, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN$1;
        _assertClass(options, JwpPresentationOptions);
        var ptr2 = options.__destroy_into_raw();
        wasm$1.iotadocument_createPresentationJpt(retptr, this.__wbg_ptr, ptr0, ptr1, len1, ptr2);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {Storage} storage
    * @param {string} keyType
    * @param {JwsAlgorithm} alg
    * @param {string | undefined} fragment
    * @param {MethodScope} scope
    * @returns {Promise<string>}
    */
    generateMethodPQC(storage, keyType, alg, fragment, scope) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(storage, Storage);
        const ptr0 = passStringToWasm0$1(keyType, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        var ptr1 = isLikeNone$1(fragment) ? 0 : passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN$1;
        _assertClass(scope, MethodScope);
        var ptr2 = scope.__destroy_into_raw();
        wasm$1.iotadocument_generateMethodPQC(retptr, this.__wbg_ptr, storage.__wbg_ptr, ptr0, len0, addHeapObject$1(alg), ptr1, len1, ptr2);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
  }
  const IotaDocumentMetadataFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_iotadocumentmetadata_free(ptr >>> 0));
  class IotaDocumentMetadata {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(IotaDocumentMetadata.prototype);
      obj.__wbg_ptr = ptr;
      IotaDocumentMetadataFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      IotaDocumentMetadataFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_iotadocumentmetadata_free(ptr);
    }
    /**
    * Returns a copy of the timestamp of when the DID document was created.
    * @returns {Timestamp | undefined}
    */
    created() {
      const ret = wasm$1.iotadocumentmetadata_created(this.__wbg_ptr);
      return ret === 0 ? void 0 : Timestamp.__wrap(ret);
    }
    /**
    * Returns a copy of the timestamp of the last DID document update.
    * @returns {Timestamp | undefined}
    */
    updated() {
      const ret = wasm$1.iotadocumentmetadata_updated(this.__wbg_ptr);
      return ret === 0 ? void 0 : Timestamp.__wrap(ret);
    }
    /**
    * Returns a copy of the deactivated status of the DID document.
    * @returns {boolean | undefined}
    */
    deactivated() {
      const ret = wasm$1.iotadocumentmetadata_deactivated(this.__wbg_ptr);
      return ret === 16777215 ? void 0 : ret !== 0;
    }
    /**
    * Returns a copy of the Bech32-encoded state controller address, if present.
    * @returns {string | undefined}
    */
    stateControllerAddress() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocumentmetadata_stateControllerAddress(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the Bech32-encoded governor address, if present.
    * @returns {string | undefined}
    */
    governorAddress() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocumentmetadata_governorAddress(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the custom metadata properties.
    * @returns {Map<string, any>}
    */
    properties() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocumentmetadata_properties(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocumentmetadata_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {IotaDocumentMetadata}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.iotadocumentmetadata_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return IotaDocumentMetadata.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {IotaDocumentMetadata}
    */
    clone() {
      const ret = wasm$1.iotadocumentmetadata_clone(this.__wbg_ptr);
      return IotaDocumentMetadata.__wrap(ret);
    }
  }
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_iotaidentityclientext_free(ptr >>> 0));
  const IssuerProtectedHeaderFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_issuerprotectedheader_free(ptr >>> 0));
  class IssuerProtectedHeader {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(IssuerProtectedHeader.prototype);
      obj.__wbg_ptr = ptr;
      IssuerProtectedHeaderFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {
        typ: this.typ,
        alg: this.alg,
        kid: this.kid,
        cid: this.cid
      };
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      IssuerProtectedHeaderFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_issuerprotectedheader_free(ptr);
    }
    /**
    * JWP type (JPT).
    * @returns {string | undefined}
    */
    get typ() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.__wbg_get_issuerprotectedheader_typ(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * JWP type (JPT).
    * @param {string | undefined} [arg0]
    */
    set typ(arg0) {
      var ptr0 = isLikeNone$1(arg0) ? 0 : passStringToWasm0$1(arg0, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN$1;
      wasm$1.__wbg_set_issuerprotectedheader_typ(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Algorithm used for the JWP.
    * @returns {ProofAlgorithm}
    */
    get alg() {
      const ret = wasm$1.__wbg_get_issuerprotectedheader_alg(this.__wbg_ptr);
      return ret;
    }
    /**
    * Algorithm used for the JWP.
    * @param {ProofAlgorithm} arg0
    */
    set alg(arg0) {
      wasm$1.__wbg_set_issuerprotectedheader_alg(this.__wbg_ptr, arg0);
    }
    /**
    * ID for the key used for the JWP.
    * @returns {string | undefined}
    */
    get kid() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.__wbg_get_issuerprotectedheader_kid(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * ID for the key used for the JWP.
    * @param {string | undefined} [arg0]
    */
    set kid(arg0) {
      var ptr0 = isLikeNone$1(arg0) ? 0 : passStringToWasm0$1(arg0, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN$1;
      wasm$1.__wbg_set_issuerprotectedheader_kid(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Not handled for now. Will be used in the future to resolve external claims
    * @returns {string | undefined}
    */
    get cid() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.__wbg_get_issuerprotectedheader_cid(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Not handled for now. Will be used in the future to resolve external claims
    * @param {string | undefined} [arg0]
    */
    set cid(arg0) {
      var ptr0 = isLikeNone$1(arg0) ? 0 : passStringToWasm0$1(arg0, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN$1;
      wasm$1.__wbg_set_issuerprotectedheader_cid(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * @returns {(string)[]}
    */
    claims() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.issuerprotectedheader_claims(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var v1 = getArrayJsValueFromWasm0(r0, r1).slice();
        wasm$1.__wbindgen_free(r0, r1 * 4, 4);
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
  }
  const JptFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jpt_free(ptr >>> 0));
  class Jpt {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Jpt.prototype);
      obj.__wbg_ptr = ptr;
      JptFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JptFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jpt_free(ptr);
    }
    /**
    * Creates a new {@link Jpt}.
    * @param {string} jpt_string
    */
    constructor(jpt_string) {
      const ptr0 = passStringToWasm0$1(jpt_string, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      const ret = wasm$1.jpt_new(ptr0, len0);
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
    /**
    * @returns {string}
    */
    toString() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jpt_toString(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Deep clones the object.
    * @returns {Jpt}
    */
    clone() {
      const ret = wasm$1.jpt_clone(this.__wbg_ptr);
      return Jpt.__wrap(ret);
    }
  }
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jptcredentialvalidationoptions_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jptcredentialvalidator_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jptcredentialvalidatorutils_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jptpresentationvalidationoptions_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jptpresentationvalidator_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jptpresentationvalidatorutils_free(ptr >>> 0));
  const JwkFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwk_free(ptr >>> 0));
  class Jwk {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Jwk.prototype);
      obj.__wbg_ptr = ptr;
      JwkFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JwkFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jwk_free(ptr);
    }
    /**
    * @param {IJwkParams} jwk
    */
    constructor(jwk) {
      const ret = wasm$1.jwk_new(addHeapObject$1(jwk));
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
    /**
    * Returns the value for the key type parameter (kty).
    * @returns {JwkType}
    */
    kty() {
      const ret = wasm$1.jwk_kty(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Returns the value for the use property (use).
    * @returns {JwkUse | undefined}
    */
    use() {
      const ret = wasm$1.jwk_use(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * @returns {Array<JwkOperation>}
    */
    keyOps() {
      const ret = wasm$1.jwk_keyOps(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Returns the value for the algorithm property (alg).
    * @returns {JwsAlgorithm | undefined}
    */
    alg() {
      const ret = wasm$1.jwk_alg(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Returns the value of the key ID property (kid).
    * @returns {string | undefined}
    */
    kid() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwk_kid(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the value of the X.509 URL property (x5u).
    * @returns {string | undefined}
    */
    x5u() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwk_x5u(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the value of the X.509 certificate chain property (x5c).
    * @returns {Array<string>}
    */
    x5c() {
      const ret = wasm$1.jwk_x5c(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Returns the value of the X.509 certificate SHA-1 thumbprint property (x5t).
    * @returns {string | undefined}
    */
    x5t() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwk_x5t(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the value of the X.509 certificate SHA-256 thumbprint property (x5t#S256).
    * @returns {string | undefined}
    */
    x5t256() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwk_x5t256(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * If this JWK is of kty EC, returns those parameters.
    * @returns {JwkParamsEc | undefined}
    */
    paramsEc() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwk_paramsEc(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * If this JWK is of kty OKP, returns those parameters.
    * @returns {JwkParamsOkp | undefined}
    */
    paramsOkp() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwk_paramsOkp(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * If this JWK is of kty OCT, returns those parameters.
    * @returns {JwkParamsOct | undefined}
    */
    paramsOct() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwk_paramsOct(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * If this JWK is of kty RSA, returns those parameters.
    * @returns {JwkParamsRsa | undefined}
    */
    paramsRsa() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwk_paramsRsa(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @returns {JwkParamsPQ | undefined}
    */
    paramsMldsa() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwk_paramsMldsa(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a clone of the {@link Jwk} with _all_ private key components unset.
    * Nothing is returned when `kty = oct` as this key type is not considered public by this library.
    * @returns {Jwk | undefined}
    */
    toPublic() {
      const ret = wasm$1.jwk_toPublic(this.__wbg_ptr);
      return ret === 0 ? void 0 : Jwk.__wrap(ret);
    }
    /**
    * Returns `true` if _all_ private key components of the key are unset, `false` otherwise.
    * @returns {boolean}
    */
    isPublic() {
      const ret = wasm$1.jwk_isPublic(this.__wbg_ptr);
      return ret !== 0;
    }
    /**
    * Returns `true` if _all_ private key components of the key are set, `false` otherwise.
    * @returns {boolean}
    */
    isPrivate() {
      const ret = wasm$1.jwk_isPrivate(this.__wbg_ptr);
      return ret !== 0;
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwk_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {Jwk}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwk_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Jwk.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {Jwk}
    */
    clone() {
      const ret = wasm$1.jwk_clone(this.__wbg_ptr);
      return Jwk.__wrap(ret);
    }
  }
  const JwkGenOutputFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwkgenoutput_free(ptr >>> 0));
  class JwkGenOutput {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(JwkGenOutput.prototype);
      obj.__wbg_ptr = ptr;
      JwkGenOutputFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JwkGenOutputFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jwkgenoutput_free(ptr);
    }
    /**
    * @param {string} key_id
    * @param {Jwk} jwk
    */
    constructor(key_id, jwk) {
      const ptr0 = passStringToWasm0$1(key_id, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      _assertClass(jwk, Jwk);
      const ret = wasm$1.jwkgenoutput_new(ptr0, len0, jwk.__wbg_ptr);
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
    /**
    * Returns the generated public {@link Jwk}.
    * @returns {Jwk}
    */
    jwk() {
      const ret = wasm$1.jwkgenoutput_jwk(this.__wbg_ptr);
      return Jwk.__wrap(ret);
    }
    /**
    * Returns the key id of the generated {@link Jwk}.
    * @returns {string}
    */
    keyId() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwkgenoutput_keyId(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwkgenoutput_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {JwkGenOutput}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwkgenoutput_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return JwkGenOutput.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {JwkGenOutput}
    */
    clone() {
      const ret = wasm$1.jwkgenoutput_clone(this.__wbg_ptr);
      return JwkGenOutput.__wrap(ret);
    }
  }
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwkstorage_free(ptr >>> 0));
  const JwpCredentialOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwpcredentialoptions_free(ptr >>> 0));
  class JwpCredentialOptions {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(JwpCredentialOptions.prototype);
      obj.__wbg_ptr = ptr;
      JwpCredentialOptionsFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {
        kid: this.kid
      };
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JwpCredentialOptionsFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jwpcredentialoptions_free(ptr);
    }
    /**
    * @returns {string | undefined}
    */
    get kid() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.__wbg_get_jwpcredentialoptions_kid(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {string | undefined} [arg0]
    */
    set kid(arg0) {
      var ptr0 = isLikeNone$1(arg0) ? 0 : passStringToWasm0$1(arg0, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN$1;
      wasm$1.__wbg_set_jwpcredentialoptions_kid(this.__wbg_ptr, ptr0, len0);
    }
    /**
    */
    constructor() {
      const ret = wasm$1.jwpcredentialoptions_new();
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
    /**
    * @param {any} value
    * @returns {JwpCredentialOptions}
    */
    static fromJSON(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwpcredentialoptions_fromJSON(retptr, addHeapObject$1(value));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return JwpCredentialOptions.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwpcredentialoptions_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
  }
  const JwpIssuedFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwpissued_free(ptr >>> 0));
  class JwpIssued {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(JwpIssued.prototype);
      obj.__wbg_ptr = ptr;
      JwpIssuedFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JwpIssuedFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jwpissued_free(ptr);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwpissued_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {JwpIssued}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwpissued_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return JwpIssued.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {JwpIssued}
    */
    clone() {
      const ret = wasm$1.jwpissued_clone(this.__wbg_ptr);
      return JwpIssued.__wrap(ret);
    }
    /**
    * @param {SerializationType} serialization
    * @returns {string}
    */
    encode(serialization) {
      let deferred2_0;
      let deferred2_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwpissued_encode(retptr, this.__wbg_ptr, serialization);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        var r3 = getInt32Memory0$1()[retptr / 4 + 3];
        var ptr1 = r0;
        var len1 = r1;
        if (r3) {
          ptr1 = 0;
          len1 = 0;
          throw takeObject$1(r2);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0$1(ptr1, len1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred2_0, deferred2_1, 1);
      }
    }
    /**
    * @param {Uint8Array} proof
    */
    setProof(proof) {
      const ptr0 = passArray8ToWasm0(proof, wasm$1.__wbindgen_malloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwpissued_setProof(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * @returns {Uint8Array}
    */
    getProof() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwpissued_getProof(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var v1 = getArrayU8FromWasm0(r0, r1).slice();
        wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @returns {Payloads}
    */
    getPayloads() {
      const ret = wasm$1.jwpissued_getPayloads(this.__wbg_ptr);
      return Payloads.__wrap(ret);
    }
    /**
    * @param {Payloads} payloads
    */
    setPayloads(payloads) {
      _assertClass(payloads, Payloads);
      var ptr0 = payloads.__destroy_into_raw();
      wasm$1.jwpissued_setPayloads(this.__wbg_ptr, ptr0);
    }
    /**
    * @returns {IssuerProtectedHeader}
    */
    getIssuerProtectedHeader() {
      const ret = wasm$1.jwpissued_getIssuerProtectedHeader(this.__wbg_ptr);
      return IssuerProtectedHeader.__wrap(ret);
    }
  }
  const JwpPresentationOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwppresentationoptions_free(ptr >>> 0));
  class JwpPresentationOptions {
    toJSON() {
      return {
        audience: this.audience,
        nonce: this.nonce
      };
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JwpPresentationOptionsFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jwppresentationoptions_free(ptr);
    }
    /**
    * Sets the audience for presentation (`aud` property in JWP Presentation Header).
    * @returns {string | undefined}
    */
    get audience() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.__wbg_get_jwpcredentialoptions_kid(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets the audience for presentation (`aud` property in JWP Presentation Header).
    * @param {string | undefined} [arg0]
    */
    set audience(arg0) {
      var ptr0 = isLikeNone$1(arg0) ? 0 : passStringToWasm0$1(arg0, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN$1;
      wasm$1.__wbg_set_jwpcredentialoptions_kid(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * The nonce to be placed in the Presentation Protected Header.
    * @returns {string | undefined}
    */
    get nonce() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.__wbg_get_jwppresentationoptions_nonce(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * The nonce to be placed in the Presentation Protected Header.
    * @param {string | undefined} [arg0]
    */
    set nonce(arg0) {
      var ptr0 = isLikeNone$1(arg0) ? 0 : passStringToWasm0$1(arg0, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN$1;
      wasm$1.__wbg_set_jwppresentationoptions_nonce(this.__wbg_ptr, ptr0, len0);
    }
    /**
    */
    constructor() {
      const ret = wasm$1.jwppresentationoptions_new();
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
  }
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwpverificationoptions_free(ptr >>> 0));
  const JwsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jws_free(ptr >>> 0));
  class Jws {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Jws.prototype);
      obj.__wbg_ptr = ptr;
      JwsFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JwsFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jws_free(ptr);
    }
    /**
    * Creates a new {@link Jws} from the given string.
    * @param {string} jws_string
    */
    constructor(jws_string) {
      const ptr0 = passStringToWasm0$1(jws_string, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      const ret = wasm$1.jws_constructor(ptr0, len0);
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
    /**
    * Returns a clone of the JWS string.
    * @returns {string}
    */
    toString() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jws_toString(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
  }
  const JwsHeaderFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwsheader_free(ptr >>> 0));
  class JwsHeader {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(JwsHeader.prototype);
      obj.__wbg_ptr = ptr;
      JwsHeaderFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JwsHeaderFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jwsheader_free(ptr);
    }
    /**
    * Create a new empty {@link JwsHeader}.
    */
    constructor() {
      const ret = wasm$1.jwsheader_new();
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
    /**
    * Returns the value for the algorithm claim (alg).
    * @returns {JwsAlgorithm | undefined}
    */
    alg() {
      const ret = wasm$1.jwsheader_alg(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Sets a value for the algorithm claim (alg).
    * @param {JwsAlgorithm} value
    */
    setAlg(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_setAlg(retptr, this.__wbg_ptr, addHeapObject$1(value));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the value of the base64url-encode payload claim (b64).
    * @returns {boolean | undefined}
    */
    b64() {
      const ret = wasm$1.jwsheader_b64(this.__wbg_ptr);
      return ret === 16777215 ? void 0 : ret !== 0;
    }
    /**
    * Sets a value for the base64url-encode payload claim (b64).
    * @param {boolean} value
    */
    setB64(value) {
      wasm$1.jwsheader_setB64(this.__wbg_ptr, value);
    }
    /**
    * Additional header parameters.
    * @returns {Record<string, any> | undefined}
    */
    custom() {
      const ret = wasm$1.jwsheader_custom(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * @param {string} claim
    * @returns {boolean}
    */
    has(claim) {
      const ptr0 = passStringToWasm0$1(claim, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      const ret = wasm$1.jwsheader_has(this.__wbg_ptr, ptr0, len0);
      return ret !== 0;
    }
    /**
    * Returns `true` if none of the fields are set in both `self` and `other`.
    * @param {JwsHeader} other
    * @returns {boolean}
    */
    isDisjoint(other) {
      _assertClass(other, JwsHeader);
      const ret = wasm$1.jwsheader_isDisjoint(this.__wbg_ptr, other.__wbg_ptr);
      return ret !== 0;
    }
    /**
    * Returns the value of the JWK Set URL claim (jku).
    * @returns {string | undefined}
    */
    jku() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_jku(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a value for the JWK Set URL claim (jku).
    * @param {string} value
    */
    setJku(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.jwsheader_setJku(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the value of the JWK claim (jwk).
    * @returns {Jwk | undefined}
    */
    jwk() {
      const ret = wasm$1.jwsheader_jwk(this.__wbg_ptr);
      return ret === 0 ? void 0 : Jwk.__wrap(ret);
    }
    /**
    * Sets a value for the JWK claim (jwk).
    * @param {Jwk} value
    */
    setJwk(value) {
      _assertClass(value, Jwk);
      wasm$1.jwsheader_setJwk(this.__wbg_ptr, value.__wbg_ptr);
    }
    /**
    * Returns the value of the key ID claim (kid).
    * @returns {string | undefined}
    */
    kid() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_kid(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a value for the key ID claim (kid).
    * @param {string} value
    */
    setKid(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwsheader_setKid(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Returns the value of the X.509 URL claim (x5u).
    * @returns {string | undefined}
    */
    x5u() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_x5u(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a value for the X.509 URL claim (x5u).
    * @param {string} value
    */
    setX5u(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.jwsheader_setX5u(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the value of the X.509 certificate chain claim (x5c).
    * @returns {Array<string>}
    */
    x5c() {
      const ret = wasm$1.jwsheader_crit(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Sets values for the X.509 certificate chain claim (x5c).
    * @param {Array<string>} value
    */
    setX5c(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_setX5c(retptr, this.__wbg_ptr, addHeapObject$1(value));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the value of the X.509 certificate SHA-1 thumbprint claim (x5t).
    * @returns {string | undefined}
    */
    x5t() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_x5t(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a value for the X.509 certificate SHA-1 thumbprint claim (x5t).
    * @param {string} value
    */
    setX5t(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwsheader_setX5t(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Returns the value of the X.509 certificate SHA-256 thumbprint claim
    * (x5t#S256).
    * @returns {string | undefined}
    */
    x5tS256() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_x5tS256(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a value for the X.509 certificate SHA-256 thumbprint claim
    * (x5t#S256).
    * @param {string} value
    */
    setX5tS256(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwsheader_setX5tS256(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Returns the value of the token type claim (typ).
    * @returns {string | undefined}
    */
    typ() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_typ(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a value for the token type claim (typ).
    * @param {string} value
    */
    setTyp(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwsheader_setTyp(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Returns the value of the content type claim (cty).
    * @returns {string | undefined}
    */
    cty() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_cty(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a value for the content type claim (cty).
    * @param {string} value
    */
    setCty(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwsheader_setCty(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Returns the value of the critical claim (crit).
    * @returns {Array<string>}
    */
    crit() {
      const ret = wasm$1.jwsheader_crit(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Sets values for the critical claim (crit).
    * @param {Array<string>} value
    */
    setCrit(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_setCrit(retptr, this.__wbg_ptr, addHeapObject$1(value));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the value of the url claim (url).
    * @returns {string | undefined}
    */
    url() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_url(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a value for the url claim (url).
    * @param {string} value
    */
    setUrl(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.jwsheader_setUrl(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the value of the nonce claim (nonce).
    * @returns {string | undefined}
    */
    nonce() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_nonce(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets a value for the nonce claim (nonce).
    * @param {string} value
    */
    setNonce(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwsheader_setNonce(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {JwsHeader}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsheader_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return JwsHeader.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {JwsHeader}
    */
    clone() {
      const ret = wasm$1.decodedjws_protectedHeader(this.__wbg_ptr);
      return JwsHeader.__wrap(ret);
    }
  }
  const JwsSignatureOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwssignatureoptions_free(ptr >>> 0));
  class JwsSignatureOptions {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(JwsSignatureOptions.prototype);
      obj.__wbg_ptr = ptr;
      JwsSignatureOptionsFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JwsSignatureOptionsFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jwssignatureoptions_free(ptr);
    }
    /**
    * @param {IJwsSignatureOptions | undefined} [options]
    */
    constructor(options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwssignatureoptions_new(retptr, isLikeNone$1(options) ? 0 : addHeapObject$1(options));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Replace the value of the `attachJwk` field.
    * @param {boolean} value
    */
    setAttachJwk(value) {
      wasm$1.jwssignatureoptions_setAttachJwk(this.__wbg_ptr, value);
    }
    /**
    * Replace the value of the `b64` field.
    * @param {boolean} value
    */
    setB64(value) {
      wasm$1.jwssignatureoptions_setB64(this.__wbg_ptr, value);
    }
    /**
    * Replace the value of the `typ` field.
    * @param {string} value
    */
    setTyp(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwssignatureoptions_setTyp(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Replace the value of the `cty` field.
    * @param {string} value
    */
    setCty(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwssignatureoptions_setCty(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Replace the value of the `url` field.
    * @param {string} value
    */
    serUrl(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.jwssignatureoptions_serUrl(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Replace the value of the `nonce` field.
    * @param {string} value
    */
    setNonce(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwssignatureoptions_setNonce(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Replace the value of the `kid` field.
    * @param {string} value
    */
    setKid(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwssignatureoptions_setKid(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Replace the value of the `detached_payload` field.
    * @param {boolean} value
    */
    setDetachedPayload(value) {
      wasm$1.jwssignatureoptions_setDetachedPayload(this.__wbg_ptr, value);
    }
    /**
    * Add additional header parameters.
    * @param {Record<string, any>} value
    */
    setCustomHeaderParameters(value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwssignatureoptions_setCustomHeaderParameters(retptr, this.__wbg_ptr, addHeapObject$1(value));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwssignatureoptions_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {JwsSignatureOptions}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwssignatureoptions_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return JwsSignatureOptions.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {JwsSignatureOptions}
    */
    clone() {
      const ret = wasm$1.jwssignatureoptions_clone(this.__wbg_ptr);
      return JwsSignatureOptions.__wrap(ret);
    }
  }
  const JwsVerificationOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwsverificationoptions_free(ptr >>> 0));
  class JwsVerificationOptions {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(JwsVerificationOptions.prototype);
      obj.__wbg_ptr = ptr;
      JwsVerificationOptionsFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JwsVerificationOptionsFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jwsverificationoptions_free(ptr);
    }
    /**
    * Creates a new {@link JwsVerificationOptions} from the given fields.
    * @param {IJwsVerificationOptions | undefined} [options]
    */
    constructor(options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsverificationoptions_new(retptr, isLikeNone$1(options) ? 0 : addHeapObject$1(options));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Set the expected value for the `nonce` parameter of the protected header.
    * @param {string} value
    */
    setNonce(value) {
      const ptr0 = passStringToWasm0$1(value, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      wasm$1.jwsverificationoptions_setNonce(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Set the scope of the verification methods that may be used to verify the given JWS.
    * @param {MethodScope} value
    */
    setMethodScope(value) {
      _assertClass(value, MethodScope);
      wasm$1.jwsverificationoptions_setMethodScope(this.__wbg_ptr, value.__wbg_ptr);
    }
    /**
    * Set the DID URl of the method, whose JWK should be used to verify the JWS.
    * @param {DIDUrl} value
    */
    setMethodId(value) {
      _assertClass(value, DIDUrl);
      wasm$1.jwsverificationoptions_setMethodId(this.__wbg_ptr, value.__wbg_ptr);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsverificationoptions_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {JwsVerificationOptions}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwsverificationoptions_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return JwsVerificationOptions.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {JwsVerificationOptions}
    */
    clone() {
      const ret = wasm$1.jwsverificationoptions_clone(this.__wbg_ptr);
      return JwsVerificationOptions.__wrap(ret);
    }
  }
  const JwtFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwt_free(ptr >>> 0));
  class Jwt {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Jwt.prototype);
      obj.__wbg_ptr = ptr;
      JwtFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JwtFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jwt_free(ptr);
    }
    /**
    * Creates a new {@link Jwt} from the given string.
    * @param {string} jwt_string
    */
    constructor(jwt_string) {
      const ptr0 = passStringToWasm0$1(jwt_string, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      const ret = wasm$1.jwt_constructor(ptr0, len0);
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
    /**
    * Returns a clone of the JWT string.
    * @returns {string}
    */
    toString() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwt_toString(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwt_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {Jwt}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwt_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Jwt.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {Jwt}
    */
    clone() {
      const ret = wasm$1.jwt_clone(this.__wbg_ptr);
      return Jwt.__wrap(ret);
    }
  }
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwtcredentialvalidationoptions_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwtcredentialvalidator_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwtcredentialvalidatorhybrid_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwtdomainlinkagevalidator_free(ptr >>> 0));
  const JwtPresentationOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwtpresentationoptions_free(ptr >>> 0));
  class JwtPresentationOptions {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(JwtPresentationOptions.prototype);
      obj.__wbg_ptr = ptr;
      JwtPresentationOptionsFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      JwtPresentationOptionsFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_jwtpresentationoptions_free(ptr);
    }
    /**
    * Creates a new {@link JwtPresentationOptions} from the given fields.
    *
    * Throws an error if any of the options are invalid.
    * @param {IJwtPresentationOptions | undefined} [options]
    */
    constructor(options) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwtpresentationoptions_new(retptr, isLikeNone$1(options) ? 0 : addHeapObject$1(options));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwtpresentationoptions_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {JwtPresentationOptions}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.jwtpresentationoptions_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return JwtPresentationOptions.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {JwtPresentationOptions}
    */
    clone() {
      const ret = wasm$1.jwtpresentationoptions_clone(this.__wbg_ptr);
      return JwtPresentationOptions.__wrap(ret);
    }
  }
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwtpresentationvalidationoptions_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_jwtpresentationvalidator_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_keybindingjwtvalidationoptions_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_keybindingjwtclaims_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_linkeddomainservice_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_linkedverifiablepresentationservice_free(ptr >>> 0));
  const MethodDataFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_methoddata_free(ptr >>> 0));
  class MethodData {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(MethodData.prototype);
      obj.__wbg_ptr = ptr;
      MethodDataFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      MethodDataFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_methoddata_free(ptr);
    }
    /**
    * Creates a new {@link MethodData} variant with Base58-BTC encoded content.
    * @param {Uint8Array} data
    * @returns {MethodData}
    */
    static newBase58(data) {
      const ptr0 = passArray8ToWasm0(data, wasm$1.__wbindgen_malloc);
      const len0 = WASM_VECTOR_LEN$1;
      const ret = wasm$1.methoddata_newBase58(ptr0, len0);
      return MethodData.__wrap(ret);
    }
    /**
    * Creates a new {@link MethodData} variant with Multibase-encoded content.
    * @param {Uint8Array} data
    * @returns {MethodData}
    */
    static newMultibase(data) {
      const ptr0 = passArray8ToWasm0(data, wasm$1.__wbindgen_malloc);
      const len0 = WASM_VECTOR_LEN$1;
      const ret = wasm$1.methoddata_newMultibase(ptr0, len0);
      return MethodData.__wrap(ret);
    }
    /**
    * Creates a new {@link MethodData} variant consisting of the given `key`.
    *
    * ### Errors
    * An error is thrown if the given `key` contains any private components.
    * @param {Jwk} key
    * @returns {MethodData}
    */
    static newJwk(key) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(key, Jwk);
        wasm$1.methoddata_newJwk(retptr, key.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return MethodData.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Creates a new custom {@link MethodData}.
    * @param {string} name
    * @param {any} data
    * @returns {MethodData}
    */
    static newCustom(name, data) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(name, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.methoddata_newCustom(retptr, ptr0, len0, addHeapObject$1(data));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return MethodData.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the wrapped custom method data format is `Custom`.
    * @returns {CustomMethodData}
    */
    tryCustom() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methoddata_tryCustom(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return CustomMethodData.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a `Uint8Array` containing the decoded bytes of the {@link MethodData}.
    *
    * This is generally a public key identified by a {@link MethodData} value.
    *
    * ### Errors
    * Decoding can fail if {@link MethodData} has invalid content or cannot be
    * represented as a vector of bytes.
    * @returns {Uint8Array}
    */
    tryDecode() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methoddata_tryDecode(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        var r3 = getInt32Memory0$1()[retptr / 4 + 3];
        if (r3) {
          throw takeObject$1(r2);
        }
        var v1 = getArrayU8FromWasm0(r0, r1).slice();
        wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the wrapped {@link Jwk} if the format is `PublicKeyJwk`.
    * @returns {Jwk}
    */
    tryPublicKeyJwk() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methoddata_tryPublicKeyJwk(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Jwk.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methoddata_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {MethodData}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methoddata_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return MethodData.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {MethodData}
    */
    clone() {
      const ret = wasm$1.methoddata_clone(this.__wbg_ptr);
      return MethodData.__wrap(ret);
    }
  }
  const MethodDigestFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_methoddigest_free(ptr >>> 0));
  class MethodDigest {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(MethodDigest.prototype);
      obj.__wbg_ptr = ptr;
      MethodDigestFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      MethodDigestFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_methoddigest_free(ptr);
    }
    /**
    * @param {VerificationMethod} verification_method
    */
    constructor(verification_method) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(verification_method, VerificationMethod);
        wasm$1.methoddigest_new(retptr, verification_method.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Packs {@link MethodDigest} into bytes.
    * @returns {Uint8Array}
    */
    pack() {
      const ret = wasm$1.methoddigest_pack(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Unpacks bytes into {@link MethodDigest}.
    * @param {Uint8Array} bytes
    * @returns {MethodDigest}
    */
    static unpack(bytes2) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methoddigest_unpack(retptr, addBorrowedObject(bytes2));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return MethodDigest.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {MethodDigest}
    */
    clone() {
      const ret = wasm$1.methoddigest_clone(this.__wbg_ptr);
      return MethodDigest.__wrap(ret);
    }
  }
  const MethodScopeFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_methodscope_free(ptr >>> 0));
  class MethodScope {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(MethodScope.prototype);
      obj.__wbg_ptr = ptr;
      MethodScopeFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      MethodScopeFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_methodscope_free(ptr);
    }
    /**
    * @returns {MethodScope}
    */
    static VerificationMethod() {
      const ret = wasm$1.methodscope_VerificationMethod();
      return MethodScope.__wrap(ret);
    }
    /**
    * @returns {MethodScope}
    */
    static Authentication() {
      const ret = wasm$1.methodscope_Authentication();
      return MethodScope.__wrap(ret);
    }
    /**
    * @returns {MethodScope}
    */
    static AssertionMethod() {
      const ret = wasm$1.methodscope_AssertionMethod();
      return MethodScope.__wrap(ret);
    }
    /**
    * @returns {MethodScope}
    */
    static KeyAgreement() {
      const ret = wasm$1.methodscope_KeyAgreement();
      return MethodScope.__wrap(ret);
    }
    /**
    * @returns {MethodScope}
    */
    static CapabilityDelegation() {
      const ret = wasm$1.methodscope_CapabilityDelegation();
      return MethodScope.__wrap(ret);
    }
    /**
    * @returns {MethodScope}
    */
    static CapabilityInvocation() {
      const ret = wasm$1.methodscope_CapabilityInvocation();
      return MethodScope.__wrap(ret);
    }
    /**
    * Returns the {@link MethodScope} as a string.
    * @returns {string}
    */
    toString() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methodscope_toString(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methodscope_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {MethodScope}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methodscope_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return MethodScope.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {MethodScope}
    */
    clone() {
      const ret = wasm$1.methodscope_clone(this.__wbg_ptr);
      return MethodScope.__wrap(ret);
    }
  }
  const MethodTypeFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_methodtype_free(ptr >>> 0));
  class MethodType {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(MethodType.prototype);
      obj.__wbg_ptr = ptr;
      MethodTypeFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      MethodTypeFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_methodtype_free(ptr);
    }
    /**
    * @returns {MethodType}
    */
    static Ed25519VerificationKey2018() {
      const ret = wasm$1.methodtype_Ed25519VerificationKey2018();
      return MethodType.__wrap(ret);
    }
    /**
    * @returns {MethodType}
    */
    static X25519KeyAgreementKey2019() {
      const ret = wasm$1.methodtype_X25519KeyAgreementKey2019();
      return MethodType.__wrap(ret);
    }
    /**
    * @deprecated Use {@link JsonWebKey2020} instead.
    */
    static JsonWebKey() {
      const ret = wasm$1.methodtype_JsonWebKey();
      return MethodType.__wrap(ret);
    }
    /**
    * A verification method for use with JWT verification as prescribed by the {@link Jwk}
    * in the `publicKeyJwk` entry.
    * @returns {MethodType}
    */
    static JsonWebKey2020() {
      const ret = wasm$1.methodtype_JsonWebKey2020();
      return MethodType.__wrap(ret);
    }
    /**
    * A custom method.
    * @param {string} type_
    * @returns {MethodType}
    */
    static custom(type_) {
      const ptr0 = passStringToWasm0$1(type_, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN$1;
      const ret = wasm$1.methodtype_custom(ptr0, len0);
      return MethodType.__wrap(ret);
    }
    /**
    * Returns the {@link MethodType} as a string.
    * @returns {string}
    */
    toString() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methodtype_toString(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methodtype_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {MethodType}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.methodtype_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return MethodType.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {MethodType}
    */
    clone() {
      const ret = wasm$1.methodtype_clone(this.__wbg_ptr);
      return MethodType.__wrap(ret);
    }
  }
  const PayloadEntryFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_payloadentry_free(ptr >>> 0));
  class PayloadEntry {
    static __unwrap(jsValue) {
      if (!(jsValue instanceof PayloadEntry)) {
        return 0;
      }
      return jsValue.__destroy_into_raw();
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      PayloadEntryFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_payloadentry_free(ptr);
    }
    /**
    * @returns {PayloadType}
    */
    get 1() {
      const ret = wasm$1.__wbg_get_payloadentry_1(this.__wbg_ptr);
      return ret;
    }
    /**
    * @param {PayloadType} arg0
    */
    set 1(arg0) {
      wasm$1.__wbg_set_payloadentry_1(this.__wbg_ptr, arg0);
    }
    /**
    * @param {any} value
    */
    set value(value) {
      wasm$1.payloadentry_set_value(this.__wbg_ptr, addHeapObject$1(value));
    }
    /**
    * @returns {any}
    */
    get value() {
      const ret = wasm$1.payloadentry_value(this.__wbg_ptr);
      return takeObject$1(ret);
    }
  }
  const PayloadsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_payloads_free(ptr >>> 0));
  class Payloads {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Payloads.prototype);
      obj.__wbg_ptr = ptr;
      PayloadsFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      PayloadsFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_payloads_free(ptr);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.payloads_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {Payloads}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.payloads_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Payloads.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {Payloads}
    */
    clone() {
      const ret = wasm$1.payloads_clone(this.__wbg_ptr);
      return Payloads.__wrap(ret);
    }
    /**
    * @param {(PayloadEntry)[]} entries
    */
    constructor(entries) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passArrayJsValueToWasm0(entries, wasm$1.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.payloads_new(retptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @param {any[]} values
    * @returns {Payloads}
    */
    static newFromValues(values) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passArrayJsValueToWasm0(values, wasm$1.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.payloads_newFromValues(retptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Payloads.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @returns {any[]}
    */
    getValues() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.payloads_getValues(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        var r3 = getInt32Memory0$1()[retptr / 4 + 3];
        if (r3) {
          throw takeObject$1(r2);
        }
        var v1 = getArrayJsValueFromWasm0(r0, r1).slice();
        wasm$1.__wbindgen_free(r0, r1 * 4, 4);
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @returns {Uint32Array}
    */
    getUndisclosedIndexes() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.payloads_getUndisclosedIndexes(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var v1 = getArrayU32FromWasm0(r0, r1).slice();
        wasm$1.__wbindgen_free(r0, r1 * 4, 4);
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @returns {Uint32Array}
    */
    getDisclosedIndexes() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.payloads_getDisclosedIndexes(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var v1 = getArrayU32FromWasm0(r0, r1).slice();
        wasm$1.__wbindgen_free(r0, r1 * 4, 4);
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @returns {any[]}
    */
    getUndisclosedPayloads() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.payloads_getUndisclosedPayloads(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        var r3 = getInt32Memory0$1()[retptr / 4 + 3];
        if (r3) {
          throw takeObject$1(r2);
        }
        var v1 = getArrayJsValueFromWasm0(r0, r1).slice();
        wasm$1.__wbindgen_free(r0, r1 * 4, 4);
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * @returns {Payloads}
    */
    getDisclosedPayloads() {
      const ret = wasm$1.payloads_getDisclosedPayloads(this.__wbg_ptr);
      return Payloads.__wrap(ret);
    }
    /**
    * @param {number} index
    */
    setUndisclosed(index) {
      wasm$1.payloads_setUndisclosed(this.__wbg_ptr, index);
    }
    /**
    * @param {number} index
    * @param {any} value
    * @returns {any}
    */
    replacePayloadAtIndex(index, value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.payloads_replacePayloadAtIndex(retptr, this.__wbg_ptr, index, addHeapObject$1(value));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
  }
  const PresentationFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_presentation_free(ptr >>> 0));
  class Presentation {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Presentation.prototype);
      obj.__wbg_ptr = ptr;
      PresentationFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      PresentationFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_presentation_free(ptr);
    }
    /**
    * Returns the base JSON-LD context.
    * @returns {string}
    */
    static BaseContext() {
      let deferred2_0;
      let deferred2_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.presentation_BaseContext(retptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        var r3 = getInt32Memory0$1()[retptr / 4 + 3];
        var ptr1 = r0;
        var len1 = r1;
        if (r3) {
          ptr1 = 0;
          len1 = 0;
          throw takeObject$1(r2);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0$1(ptr1, len1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred2_0, deferred2_1, 1);
      }
    }
    /**
    * Returns the base type.
    * @returns {string}
    */
    static BaseType() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.presentation_BaseType(retptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Constructs a new presentation.
    * @param {IPresentation} values
    */
    constructor(values) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.presentation_new(retptr, addHeapObject$1(values));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the JSON-LD context(s) applicable to the presentation.
    * @returns {Array<string | Record<string, any>>}
    */
    context() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.presentation_context(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the unique `URI` identifying the presentation.
    * @returns {string | undefined}
    */
    id() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.presentation_id(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the URIs defining the type of the presentation.
    * @returns {Array<string>}
    */
    type() {
      const ret = wasm$1.presentation_type(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Returns the JWT credentials expressing the claims of the presentation.
    * @returns {Array<UnknownCredential>}
    */
    verifiableCredential() {
      const ret = wasm$1.presentation_verifiableCredential(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Returns a copy of the URI of the entity that generated the presentation.
    * @returns {string}
    */
    holder() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.presentation_holder(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns a copy of the service(s) used to refresh an expired {@link Credential} in the presentation.
    * @returns {Array<RefreshService>}
    */
    refreshService() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.presentation_refreshService(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the terms-of-use specified by the presentation holder
    * @returns {Array<Policy>}
    */
    termsOfUse() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.presentation_termsOfUse(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Optional cryptographic proof, unrelated to JWT.
    * @returns {Proof | undefined}
    */
    proof() {
      const ret = wasm$1.presentation_proof(this.__wbg_ptr);
      return ret === 0 ? void 0 : Proof.__wrap(ret);
    }
    /**
    * Sets the proof property of the {@link Presentation}.
    *
    * Note that this proof is not related to JWT.
    * @param {Proof | undefined} [proof]
    */
    setProof(proof) {
      let ptr0 = 0;
      if (!isLikeNone$1(proof)) {
        _assertClass(proof, Proof);
        ptr0 = proof.__destroy_into_raw();
      }
      wasm$1.presentation_setProof(this.__wbg_ptr, ptr0);
    }
    /**
    * Returns a copy of the miscellaneous properties on the presentation.
    * @returns {Map<string, any>}
    */
    properties() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.presentation_properties(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.presentation_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {Presentation}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.presentation_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Presentation.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {Presentation}
    */
    clone() {
      const ret = wasm$1.presentation_clone(this.__wbg_ptr);
      return Presentation.__wrap(ret);
    }
  }
  const PresentationProtectedHeaderFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_presentationprotectedheader_free(ptr >>> 0));
  class PresentationProtectedHeader {
    toJSON() {
      return {
        alg: this.alg,
        kid: this.kid,
        aud: this.aud,
        nonce: this.nonce
      };
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      PresentationProtectedHeaderFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_presentationprotectedheader_free(ptr);
    }
    /**
    * @returns {PresentationProofAlgorithm}
    */
    get alg() {
      const ret = wasm$1.__wbg_get_presentationprotectedheader_alg(this.__wbg_ptr);
      return ret;
    }
    /**
    * @param {PresentationProofAlgorithm} arg0
    */
    set alg(arg0) {
      wasm$1.__wbg_set_presentationprotectedheader_alg(this.__wbg_ptr, arg0);
    }
    /**
    * ID for the key used for the JWP.
    * @returns {string | undefined}
    */
    get kid() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.__wbg_get_jwpcredentialoptions_kid(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * ID for the key used for the JWP.
    * @param {string | undefined} [arg0]
    */
    set kid(arg0) {
      var ptr0 = isLikeNone$1(arg0) ? 0 : passStringToWasm0$1(arg0, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN$1;
      wasm$1.__wbg_set_jwpcredentialoptions_kid(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * Who have received the JPT.
    * @returns {string | undefined}
    */
    get aud() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.__wbg_get_jwppresentationoptions_nonce(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Who have received the JPT.
    * @param {string | undefined} [arg0]
    */
    set aud(arg0) {
      var ptr0 = isLikeNone$1(arg0) ? 0 : passStringToWasm0$1(arg0, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN$1;
      wasm$1.__wbg_set_jwppresentationoptions_nonce(this.__wbg_ptr, ptr0, len0);
    }
    /**
    * For replay attacks.
    * @returns {string | undefined}
    */
    get nonce() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.__wbg_get_presentationprotectedheader_nonce(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        let v1;
        if (r0 !== 0) {
          v1 = getStringFromWasm0$1(r0, r1).slice();
          wasm$1.__wbindgen_free(r0, r1 * 1, 1);
        }
        return v1;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * For replay attacks.
    * @param {string | undefined} [arg0]
    */
    set nonce(arg0) {
      var ptr0 = isLikeNone$1(arg0) ? 0 : passStringToWasm0$1(arg0, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN$1;
      wasm$1.__wbg_set_presentationprotectedheader_nonce(this.__wbg_ptr, ptr0, len0);
    }
  }
  const ProofFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_proof_free(ptr >>> 0));
  class Proof {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Proof.prototype);
      obj.__wbg_ptr = ptr;
      ProofFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      ProofFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_proof_free(ptr);
    }
    /**
    * @param {string} type_
    * @param {any} properties
    */
    constructor(type_, properties) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(type_, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.proof_constructor(retptr, ptr0, len0, addHeapObject$1(properties));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns the type of proof.
    * @returns {string}
    */
    type() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.proof_type(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Returns the properties of the proof.
    * @returns {any}
    */
    properties() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.proof_properties(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.proof_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {Proof}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.proof_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Proof.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {Proof}
    */
    clone() {
      const ret = wasm$1.proof_clone(this.__wbg_ptr);
      return Proof.__wrap(ret);
    }
  }
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_proofupdatectx_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_resolver_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_revocationbitmap_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_revocationtimeframestatus_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_sdjwt_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_sdjwtcredentialvalidator_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_sdobjectdecoder_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_sdobjectencoder_free(ptr >>> 0));
  const SelectiveDisclosurePresentationFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_selectivedisclosurepresentation_free(ptr >>> 0));
  class SelectiveDisclosurePresentation {
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      SelectiveDisclosurePresentationFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_selectivedisclosurepresentation_free(ptr);
    }
    /**
    * Initialize a presentation starting from an Issued JWP.
    * The properties `jti`, `nbf`, `issuanceDate`, `expirationDate` and `termsOfUse` are concealed by default.
    * @param {JwpIssued} issued_jwp
    */
    constructor(issued_jwp) {
      _assertClass(issued_jwp, JwpIssued);
      var ptr0 = issued_jwp.__destroy_into_raw();
      const ret = wasm$1.selectivedisclosurepresentation_new(ptr0);
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
    /**
    * Selectively disclose "credentialSubject" attributes.
    * # Example
    * ```
    * {
    *     "id": 1234,
    *     "name": "Alice",
    *     "mainCourses": ["Object-oriented Programming", "Mathematics"],
    *     "degree": {
    *         "type": "BachelorDegree",
    *         "name": "Bachelor of Science and Arts",
    *     },
    *     "GPA": "4.0",
    * }
    * ```
    * If you want to undisclose for example the Mathematics course and the name of the degree:
    * ```
    * undisclose_subject("mainCourses[1]");
    * undisclose_subject("degree.name");
    * ```
    * @param {string} path
    */
    concealInSubject(path) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(path, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.selectivedisclosurepresentation_concealInSubject(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Undiscloses "evidence" attributes.
    * @param {string} path
    */
    concealInEvidence(path) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(path, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.selectivedisclosurepresentation_concealInEvidence(retptr, this.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Sets presentation protected header.
    * @param {PresentationProtectedHeader} header
    */
    setPresentationHeader(header) {
      _assertClass(header, PresentationProtectedHeader);
      var ptr0 = header.__destroy_into_raw();
      wasm$1.selectivedisclosurepresentation_setPresentationHeader(this.__wbg_ptr, ptr0);
    }
  }
  const ServiceFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_service_free(ptr >>> 0));
  class Service {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Service.prototype);
      obj.__wbg_ptr = ptr;
      ServiceFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      ServiceFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_service_free(ptr);
    }
    /**
    * @param {IService} service
    */
    constructor(service) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.service_new(retptr, addHeapObject$1(service));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the {@link Service} id.
    * @returns {DIDUrl}
    */
    id() {
      const ret = wasm$1.service_id(this.__wbg_ptr);
      return DIDUrl.__wrap(ret);
    }
    /**
    * Returns a copy of the {@link Service} type.
    * @returns {Array<string>}
    */
    type() {
      const ret = wasm$1.service_type(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Returns a copy of the {@link Service} endpoint.
    * @returns {string | string[] | Map<string, string[]>}
    */
    serviceEndpoint() {
      const ret = wasm$1.service_serviceEndpoint(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Returns a copy of the custom properties on the {@link Service}.
    * @returns {Map<string, any>}
    */
    properties() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.service_properties(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.service_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {Service}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.service_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Service.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {Service}
    */
    clone() {
      const ret = wasm$1.service_clone(this.__wbg_ptr);
      return Service.__wrap(ret);
    }
  }
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_statuslist2021_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_statuslist2021credential_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_statuslist2021credentialbuilder_free(ptr >>> 0));
  typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_statuslist2021entry_free(ptr >>> 0));
  const StorageFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_storage_free(ptr >>> 0));
  class Storage {
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      StorageFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_storage_free(ptr);
    }
    /**
    * Constructs a new `Storage`.
    * @param {JwkStorage} jwkStorage
    * @param {KeyIdStorage} keyIdStorage
    */
    constructor(jwkStorage, keyIdStorage) {
      const ret = wasm$1.storage_new(addHeapObject$1(jwkStorage), addHeapObject$1(keyIdStorage));
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
    /**
    * Obtain the wrapped `KeyIdStorage`.
    * @returns {KeyIdStorage}
    */
    keyIdStorage() {
      const ret = wasm$1.storage_keyIdStorage(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Obtain the wrapped `JwkStorage`.
    * @returns {JwkStorage}
    */
    keyStorage() {
      const ret = wasm$1.storage_keyStorage(this.__wbg_ptr);
      return takeObject$1(ret);
    }
  }
  const TimestampFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_timestamp_free(ptr >>> 0));
  class Timestamp {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Timestamp.prototype);
      obj.__wbg_ptr = ptr;
      TimestampFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      TimestampFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_timestamp_free(ptr);
    }
    /**
    * Creates a new {@link Timestamp} with the current date and time.
    */
    constructor() {
      const ret = wasm$1.timestamp_new();
      this.__wbg_ptr = ret >>> 0;
      return this;
    }
    /**
    * Parses a {@link Timestamp} from the provided input string.
    * @param {string} input
    * @returns {Timestamp}
    */
    static parse(input) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(input, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.timestamp_parse(retptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Timestamp.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Creates a new {@link Timestamp} with the current date and time.
    * @returns {Timestamp}
    */
    static nowUTC() {
      const ret = wasm$1.timestamp_new();
      return Timestamp.__wrap(ret);
    }
    /**
    * Returns the {@link Timestamp} as an RFC 3339 `String`.
    * @returns {string}
    */
    toRFC3339() {
      let deferred1_0;
      let deferred1_1;
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.timestamp_toRFC3339(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0$1(r0, r1);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    }
    /**
    * Computes `self + duration`
    *
    * Returns `null` if the operation leads to a timestamp not in the valid range for [RFC 3339](https://tools.ietf.org/html/rfc3339).
    * @param {Duration} duration
    * @returns {Timestamp | undefined}
    */
    checkedAdd(duration) {
      _assertClass(duration, Duration);
      const ret = wasm$1.timestamp_checkedAdd(this.__wbg_ptr, duration.__wbg_ptr);
      return ret === 0 ? void 0 : Timestamp.__wrap(ret);
    }
    /**
    * Computes `self - duration`
    *
    * Returns `null` if the operation leads to a timestamp not in the valid range for [RFC 3339](https://tools.ietf.org/html/rfc3339).
    * @param {Duration} duration
    * @returns {Timestamp | undefined}
    */
    checkedSub(duration) {
      _assertClass(duration, Duration);
      const ret = wasm$1.timestamp_checkedSub(this.__wbg_ptr, duration.__wbg_ptr);
      return ret === 0 ? void 0 : Timestamp.__wrap(ret);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.timestamp_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {Timestamp}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.timestamp_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return Timestamp.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
  }
  const UnknownCredentialFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_unknowncredential_free(ptr >>> 0));
  class UnknownCredential {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(UnknownCredential.prototype);
      obj.__wbg_ptr = ptr;
      UnknownCredentialFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      UnknownCredentialFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_unknowncredential_free(ptr);
    }
    /**
    * Returns a {@link Jwt} if the credential is of type string, `undefined` otherwise.
    * @returns {Jwt | undefined}
    */
    tryIntoJwt() {
      const ret = wasm$1.unknowncredential_tryIntoJwt(this.__wbg_ptr);
      return ret === 0 ? void 0 : Jwt.__wrap(ret);
    }
    /**
    * Returns a {@link Credential} if the credential is of said type, `undefined` otherwise.
    * @returns {Credential | undefined}
    */
    tryIntoCredential() {
      const ret = wasm$1.unknowncredential_tryIntoCredential(this.__wbg_ptr);
      return ret === 0 ? void 0 : Credential.__wrap(ret);
    }
    /**
    * Returns the contained value as an Object, if it can be converted, `undefined` otherwise.
    * @returns {Record<string, any> | undefined}
    */
    tryIntoRaw() {
      const ret = wasm$1.unknowncredential_tryIntoRaw(this.__wbg_ptr);
      return takeObject$1(ret);
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.unknowncredential_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {UnknownCredential}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.unknowncredential_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return UnknownCredential.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {UnknownCredential}
    */
    clone() {
      const ret = wasm$1.unknowncredential_clone(this.__wbg_ptr);
      return UnknownCredential.__wrap(ret);
    }
  }
  const VerificationMethodFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
  }, unregister: () => {
  } } : new FinalizationRegistry((ptr) => wasm$1.__wbg_verificationmethod_free(ptr >>> 0));
  class VerificationMethod {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(VerificationMethod.prototype);
      obj.__wbg_ptr = ptr;
      VerificationMethodFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    toJSON() {
      return {};
    }
    toString() {
      return JSON.stringify(this);
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      VerificationMethodFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm$1.__wbg_verificationmethod_free(ptr);
    }
    /**
    * Creates a new {@link VerificationMethod} from the given `did` and {@link Jwk}. If `fragment` is not given
    * the `kid` value of the given `key` will be used, if present, otherwise an error is returned.
    *
    * ### Recommendations
    * The following recommendations are essentially taken from the `publicKeyJwk` description from the [DID specification](https://www.w3.org/TR/did-core/#dfn-publickeyjwk):
    * - It is recommended that verification methods that use `Jwks` to represent their public keys use the value of
    *   `kid` as their fragment identifier. This is
    * done automatically if `None` is passed in as the fragment.
    * - It is recommended that {@link Jwk} kid values are set to the public key fingerprint.
    * @param {CoreDID | IToCoreDID} did
    * @param {Jwk} key
    * @param {string | undefined} [fragment]
    * @returns {VerificationMethod}
    */
    static newFromJwk(did, key, fragment) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(key, Jwk);
        var ptr0 = isLikeNone$1(fragment) ? 0 : passStringToWasm0$1(fragment, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN$1;
        wasm$1.verificationmethod_newFromJwk(retptr, addBorrowedObject(did), key.__wbg_ptr, ptr0, len0);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return VerificationMethod.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Create a custom {@link VerificationMethod}.
    * @param {DIDUrl} id
    * @param {CoreDID} controller
    * @param {MethodType} type_
    * @param {MethodData} data
    */
    constructor(id2, controller, type_, data) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(id2, DIDUrl);
        _assertClass(controller, CoreDID);
        _assertClass(type_, MethodType);
        _assertClass(data, MethodData);
        wasm$1.verificationmethod_new(retptr, id2.__wbg_ptr, controller.__wbg_ptr, type_.__wbg_ptr, data.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        this.__wbg_ptr = r0 >>> 0;
        return this;
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the {@link DIDUrl} of the {@link VerificationMethod}'s `id`.
    * @returns {DIDUrl}
    */
    id() {
      const ret = wasm$1.verificationmethod_id(this.__wbg_ptr);
      return DIDUrl.__wrap(ret);
    }
    /**
    * Sets the id of the {@link VerificationMethod}.
    * @param {DIDUrl} id
    */
    setId(id2) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        _assertClass(id2, DIDUrl);
        wasm$1.verificationmethod_setId(retptr, this.__wbg_ptr, id2.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Returns a copy of the `controller` `DID` of the {@link VerificationMethod}.
    * @returns {CoreDID}
    */
    controller() {
      const ret = wasm$1.verificationmethod_controller(this.__wbg_ptr);
      return CoreDID.__wrap(ret);
    }
    /**
    * Sets the `controller` `DID` of the {@link VerificationMethod} object.
    * @param {CoreDID} did
    */
    setController(did) {
      _assertClass(did, CoreDID);
      wasm$1.verificationmethod_setController(this.__wbg_ptr, did.__wbg_ptr);
    }
    /**
    * Returns a copy of the {@link VerificationMethod} type.
    * @returns {MethodType}
    */
    type() {
      const ret = wasm$1.verificationmethod_type(this.__wbg_ptr);
      return MethodType.__wrap(ret);
    }
    /**
    * Sets the {@link VerificationMethod} type.
    * @param {MethodType} type_
    */
    setType(type_) {
      _assertClass(type_, MethodType);
      wasm$1.verificationmethod_setType(this.__wbg_ptr, type_.__wbg_ptr);
    }
    /**
    * Returns a copy of the {@link VerificationMethod} public key data.
    * @returns {MethodData}
    */
    data() {
      const ret = wasm$1.verificationmethod_data(this.__wbg_ptr);
      return MethodData.__wrap(ret);
    }
    /**
    * Sets {@link VerificationMethod} public key data.
    * @param {MethodData} data
    */
    setData(data) {
      _assertClass(data, MethodData);
      wasm$1.verificationmethod_setData(this.__wbg_ptr, data.__wbg_ptr);
    }
    /**
    * Get custom properties of the Verification Method.
    * @returns {Map<string, any>}
    */
    properties() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.verificationmethod_properties(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Adds a custom property to the Verification Method.
    * If the value is set to `null`, the custom property will be removed.
    *
    * ### WARNING
    * This method can overwrite existing properties like `id` and result
    * in an invalid Verification Method.
    * @param {string} key
    * @param {any} value
    */
    setPropertyUnchecked(key, value) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0$1(key, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN$1;
        wasm$1.verificationmethod_setPropertyUnchecked(retptr, this.__wbg_ptr, ptr0, len0, addBorrowedObject(value));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        if (r1) {
          throw takeObject$1(r0);
        }
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Serializes this to a JSON object.
    * @returns {any}
    */
    toJSON() {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.verificationmethod_toJSON(retptr, this.__wbg_ptr);
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return takeObject$1(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
      }
    }
    /**
    * Deserializes an instance from a JSON object.
    * @param {any} json
    * @returns {VerificationMethod}
    */
    static fromJSON(json) {
      try {
        const retptr = wasm$1.__wbindgen_add_to_stack_pointer(-16);
        wasm$1.verificationmethod_fromJSON(retptr, addBorrowedObject(json));
        var r0 = getInt32Memory0$1()[retptr / 4 + 0];
        var r1 = getInt32Memory0$1()[retptr / 4 + 1];
        var r2 = getInt32Memory0$1()[retptr / 4 + 2];
        if (r2) {
          throw takeObject$1(r1);
        }
        return VerificationMethod.__wrap(r0);
      } finally {
        wasm$1.__wbindgen_add_to_stack_pointer(16);
        heap$1[stack_pointer++] = void 0;
      }
    }
    /**
    * Deep clones the object.
    * @returns {VerificationMethod}
    */
    clone() {
      const ret = wasm$1.verificationmethod_clone(this.__wbg_ptr);
      return VerificationMethod.__wrap(ret);
    }
  }
  async function __wbg_load$1(module2, imports) {
    if (typeof Response === "function" && module2 instanceof Response) {
      if (typeof WebAssembly.instantiateStreaming === "function") {
        try {
          return await WebAssembly.instantiateStreaming(module2, imports);
        } catch (e2) {
          if (module2.headers.get("Content-Type") != "application/wasm") {
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e2);
          } else {
            throw e2;
          }
        }
      }
      const bytes2 = await module2.arrayBuffer();
      return await WebAssembly.instantiate(bytes2, imports);
    } else {
      const instance = await WebAssembly.instantiate(module2, imports);
      if (instance instanceof WebAssembly.Instance) {
        return { instance, module: module2 };
      } else {
        return instance;
      }
    }
  }
  function __wbg_get_imports$1() {
    const imports = {};
    imports.wbg = {};
    imports.wbg.__wbindgen_object_drop_ref = function(arg0) {
      takeObject$1(arg0);
    };
    imports.wbg.__wbg_verificationmethod_new = function(arg0) {
      const ret = VerificationMethod.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_service_new = function(arg0) {
      const ret = Service.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_didurl_new = function(arg0) {
      const ret = DIDUrl.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_jws_new = function(arg0) {
      const ret = Jws.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_coredocument_new = function(arg0) {
      const ret = CoreDocument.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_coredid_new = function(arg0) {
      const ret = CoreDID.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_iotadid_new = function(arg0) {
      const ret = IotaDID.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_jpt_new = function(arg0) {
      const ret = Jpt.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_iotadocument_new = function(arg0) {
      const ret = IotaDocument.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_unknowncredential_new = function(arg0) {
      const ret = UnknownCredential.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_jwt_new = function(arg0) {
      const ret = Jwt.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_jwkgenoutput_new = function(arg0) {
      const ret = JwkGenOutput.__wrap(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbindgen_object_clone_ref = function(arg0) {
      const ret = getObject$1(arg0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbindgen_string_new = function(arg0, arg1) {
      const ret = getStringFromWasm0$1(arg0, arg1);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbindgen_is_string = function(arg0) {
      const ret = typeof getObject$1(arg0) === "string";
      return ret;
    };
    imports.wbg.__wbg_getCoreDidCloneInternal_9d05a6ed9c0bc653 = function(arg0) {
      const ret = _getCoreDidCloneInternal(getObject$1(arg0));
      _assertClass(ret, CoreDID);
      var ptr1 = ret.__destroy_into_raw();
      return ptr1;
    };
    imports.wbg.__wbg_generate_7a89d14c93c6da18 = function(arg0, arg1, arg2, arg3, arg4) {
      let deferred0_0;
      let deferred0_1;
      let deferred1_0;
      let deferred1_1;
      try {
        deferred0_0 = arg1;
        deferred0_1 = arg2;
        deferred1_0 = arg3;
        deferred1_1 = arg4;
        const ret = getObject$1(arg0).generate(getStringFromWasm0$1(arg1, arg2), getStringFromWasm0$1(arg3, arg4));
        return addHeapObject$1(ret);
      } finally {
        wasm$1.__wbindgen_free(deferred0_0, deferred0_1, 1);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    };
    imports.wbg.__wbg_insert_da8b50c74383af0d = function(arg0, arg1) {
      const ret = getObject$1(arg0).insert(Jwk.__wrap(arg1));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_sign_421bfbd38dd4553a = function(arg0, arg1, arg2, arg3, arg4, arg5) {
      let deferred0_0;
      let deferred0_1;
      try {
        deferred0_0 = arg1;
        deferred0_1 = arg2;
        var v1 = getArrayU8FromWasm0(arg3, arg4).slice();
        wasm$1.__wbindgen_free(arg3, arg4 * 1, 1);
        const ret = getObject$1(arg0).sign(getStringFromWasm0$1(arg1, arg2), v1, Jwk.__wrap(arg5));
        return addHeapObject$1(ret);
      } finally {
        wasm$1.__wbindgen_free(deferred0_0, deferred0_1, 1);
      }
    };
    imports.wbg.__wbg_delete_2ee32e53cb78797f = function(arg0, arg1, arg2) {
      let deferred0_0;
      let deferred0_1;
      try {
        deferred0_0 = arg1;
        deferred0_1 = arg2;
        const ret = getObject$1(arg0).delete(getStringFromWasm0$1(arg1, arg2));
        return addHeapObject$1(ret);
      } finally {
        wasm$1.__wbindgen_free(deferred0_0, deferred0_1, 1);
      }
    };
    imports.wbg.__wbg_getkey_7593da5ee7e5f5f0 = function(arg0, arg1, arg2) {
      const ret = getObject$1(arg0)._get_key(getStringFromWasm0$1(arg1, arg2));
      let ptr1 = 0;
      if (!isLikeNone$1(ret)) {
        _assertClass(ret, Jwk);
        ptr1 = ret.__destroy_into_raw();
      }
      return ptr1;
    };
    imports.wbg.__wbg_generatePQKey_4620013c6d4fd36b = function(arg0, arg1, arg2, arg3, arg4) {
      let deferred0_0;
      let deferred0_1;
      let deferred1_0;
      let deferred1_1;
      try {
        deferred0_0 = arg1;
        deferred0_1 = arg2;
        deferred1_0 = arg3;
        deferred1_1 = arg4;
        const ret = getObject$1(arg0).generatePQKey(getStringFromWasm0$1(arg1, arg2), getStringFromWasm0$1(arg3, arg4));
        return addHeapObject$1(ret);
      } finally {
        wasm$1.__wbindgen_free(deferred0_0, deferred0_1, 1);
        wasm$1.__wbindgen_free(deferred1_0, deferred1_1, 1);
      }
    };
    imports.wbg.__wbg_id_81f123397a43f160 = function(arg0) {
      const ret = getObject$1(arg0).id;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_type_a6d92648720e7f8b = function(arg0) {
      const ret = getObject$1(arg0).type;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_serviceEndpoint_3133f0c11b566fad = function(arg0) {
      const ret = getObject$1(arg0).serviceEndpoint;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_properties_4246821a1cd87560 = function(arg0) {
      const ret = getObject$1(arg0).properties;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbindgen_error_new = function(arg0, arg1) {
      const ret = new Error(getStringFromWasm0$1(arg0, arg1));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_payloadentry_unwrap = function(arg0) {
      const ret = PayloadEntry.__unwrap(takeObject$1(arg0));
      return ret;
    };
    imports.wbg.__wbg_maybeGetIotaDocumentInternal_fd250ef4074a0c1e = function(arg0) {
      const ret = _maybeGetIotaDocumentInternal(getObject$1(arg0));
      let ptr1 = 0;
      if (!isLikeNone$1(ret)) {
        _assertClass(ret, IotaDocument);
        ptr1 = ret.__destroy_into_raw();
      }
      return ptr1;
    };
    imports.wbg.__wbg_getCoreDocumentInternal_e937cd8649fc1d76 = function(arg0) {
      const ret = _getCoreDocumentInternal(getObject$1(arg0));
      _assertClass(ret, CoreDocument);
      var ptr1 = ret.__destroy_into_raw();
      return ptr1;
    };
    imports.wbg.__wbg_verify_0b54d052c343c289 = function() {
      return handleError$1(function(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7) {
        let deferred0_0;
        let deferred0_1;
        try {
          deferred0_0 = arg1;
          deferred0_1 = arg2;
          var v1 = getArrayU8FromWasm0(arg3, arg4).slice();
          wasm$1.__wbindgen_free(arg3, arg4 * 1, 1);
          var v2 = getArrayU8FromWasm0(arg5, arg6).slice();
          wasm$1.__wbindgen_free(arg5, arg6 * 1, 1);
          getObject$1(arg0).verify(getStringFromWasm0$1(arg1, arg2), v1, v2, Jwk.__wrap(arg7));
        } finally {
          wasm$1.__wbindgen_free(deferred0_0, deferred0_1, 1);
        }
      }, arguments);
    };
    imports.wbg.__wbindgen_json_parse = function(arg0, arg1) {
      const ret = JSON.parse(getStringFromWasm0$1(arg0, arg1));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbindgen_json_serialize = function(arg0, arg1) {
      const obj = getObject$1(arg1);
      const ret = JSON.stringify(obj === void 0 ? null : obj);
      const ptr1 = passStringToWasm0$1(ret, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN$1;
      getInt32Memory0$1()[arg0 / 4 + 1] = len1;
      getInt32Memory0$1()[arg0 / 4 + 0] = ptr1;
    };
    imports.wbg.__wbg_getAliasOutput_cec17fa4c27f521a = function(arg0, arg1, arg2) {
      let deferred0_0;
      let deferred0_1;
      try {
        deferred0_0 = arg1;
        deferred0_1 = arg2;
        const ret = getObject$1(arg0).getAliasOutput(getStringFromWasm0$1(arg1, arg2));
        return addHeapObject$1(ret);
      } finally {
        wasm$1.__wbindgen_free(deferred0_0, deferred0_1, 1);
      }
    };
    imports.wbg.__wbg_getProtocolParameters_c2d053891e679b55 = function(arg0) {
      const ret = getObject$1(arg0).getProtocolParameters();
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_client_9b83f75e2726d87f = function(arg0) {
      const ret = getObject$1(arg0).client;
      return isLikeNone$1(ret) ? 0 : addHeapObject$1(ret);
    };
    imports.wbg.__wbg_handlers_faa84e527a39cdf8 = function(arg0) {
      const ret = getObject$1(arg0).handlers;
      return isLikeNone$1(ret) ? 0 : addHeapObject$1(ret);
    };
    imports.wbg.__wbg_insertKeyId_99b1ef8ced0ab42e = function(arg0, arg1, arg2, arg3) {
      let deferred0_0;
      let deferred0_1;
      try {
        deferred0_0 = arg2;
        deferred0_1 = arg3;
        const ret = getObject$1(arg0).insertKeyId(MethodDigest.__wrap(arg1), getStringFromWasm0$1(arg2, arg3));
        return addHeapObject$1(ret);
      } finally {
        wasm$1.__wbindgen_free(deferred0_0, deferred0_1, 1);
      }
    };
    imports.wbg.__wbg_getKeyId_5b3b70e12f7e53aa = function(arg0, arg1) {
      const ret = getObject$1(arg0).getKeyId(MethodDigest.__wrap(arg1));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_deleteKeyId_e47ce8f9b5a1d684 = function(arg0, arg1) {
      const ret = getObject$1(arg0).deleteKeyId(MethodDigest.__wrap(arg1));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbindgen_string_get = function(arg0, arg1) {
      const obj = getObject$1(arg1);
      const ret = typeof obj === "string" ? obj : void 0;
      var ptr1 = isLikeNone$1(ret) ? 0 : passStringToWasm0$1(ret, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      var len1 = WASM_VECTOR_LEN$1;
      getInt32Memory0$1()[arg0 / 4 + 1] = len1;
      getInt32Memory0$1()[arg0 / 4 + 0] = ptr1;
    };
    imports.wbg.__wbg_new_abda76e883ba8a5f = function() {
      const ret = new Error();
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_stack_658279fe44541cf6 = function(arg0, arg1) {
      const ret = getObject$1(arg1).stack;
      const ptr1 = passStringToWasm0$1(ret, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN$1;
      getInt32Memory0$1()[arg0 / 4 + 1] = len1;
      getInt32Memory0$1()[arg0 / 4 + 0] = ptr1;
    };
    imports.wbg.__wbg_error_f851667af71bcfc6 = function(arg0, arg1) {
      let deferred0_0;
      let deferred0_1;
      try {
        deferred0_0 = arg0;
        deferred0_1 = arg1;
        console.error(getStringFromWasm0$1(arg0, arg1));
      } finally {
        wasm$1.__wbindgen_free(deferred0_0, deferred0_1, 1);
      }
    };
    imports.wbg.__wbg_log_5bb5f88f245d7762 = function(arg0) {
      console.log(getObject$1(arg0));
    };
    imports.wbg.__wbg_queueMicrotask_3cbae2ec6b6cd3d6 = function(arg0) {
      const ret = getObject$1(arg0).queueMicrotask;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbindgen_is_function = function(arg0) {
      const ret = typeof getObject$1(arg0) === "function";
      return ret;
    };
    imports.wbg.__wbindgen_cb_drop = function(arg0) {
      const obj = takeObject$1(arg0).original;
      if (obj.cnt-- == 1) {
        obj.a = 0;
        return true;
      }
      const ret = false;
      return ret;
    };
    imports.wbg.__wbg_queueMicrotask_481971b0d87f3dd4 = function(arg0) {
      queueMicrotask(getObject$1(arg0));
    };
    imports.wbg.__wbg_crypto_1d1f22824a6a080c = function(arg0) {
      const ret = getObject$1(arg0).crypto;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbindgen_is_object = function(arg0) {
      const val = getObject$1(arg0);
      const ret = typeof val === "object" && val !== null;
      return ret;
    };
    imports.wbg.__wbg_process_4a72847cc503995b = function(arg0) {
      const ret = getObject$1(arg0).process;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_versions_f686565e586dd935 = function(arg0) {
      const ret = getObject$1(arg0).versions;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_node_104a2ff8d6ea03a2 = function(arg0) {
      const ret = getObject$1(arg0).node;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_require_cca90b1a94a0255b = function() {
      return handleError$1(function() {
        const ret = module.require;
        return addHeapObject$1(ret);
      }, arguments);
    };
    imports.wbg.__wbg_msCrypto_eb05e62b530a1508 = function(arg0) {
      const ret = getObject$1(arg0).msCrypto;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_getRandomValues_3aa56aa6edec874c = function() {
      return handleError$1(function(arg0, arg1) {
        getObject$1(arg0).getRandomValues(getObject$1(arg1));
      }, arguments);
    };
    imports.wbg.__wbg_randomFillSync_5c9c955aa56b6049 = function() {
      return handleError$1(function(arg0, arg1) {
        getObject$1(arg0).randomFillSync(takeObject$1(arg1));
      }, arguments);
    };
    imports.wbg.__wbg_get_bd8e338fbd5f5cc8 = function(arg0, arg1) {
      const ret = getObject$1(arg0)[arg1 >>> 0];
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_length_cd7af8117672b8b8 = function(arg0) {
      const ret = getObject$1(arg0).length;
      return ret;
    };
    imports.wbg.__wbg_new_16b304a2cfa7ff4a = function() {
      const ret = new Array();
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_newnoargs_e258087cd0daa0ea = function(arg0, arg1) {
      const ret = new Function(getStringFromWasm0$1(arg0, arg1));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_new_d9bc3a0147634640 = function() {
      const ret = /* @__PURE__ */ new Map();
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_next_196c84450b364254 = function() {
      return handleError$1(function(arg0) {
        const ret = getObject$1(arg0).next();
        return addHeapObject$1(ret);
      }, arguments);
    };
    imports.wbg.__wbg_done_298b57d23c0fc80c = function(arg0) {
      const ret = getObject$1(arg0).done;
      return ret;
    };
    imports.wbg.__wbg_value_d93c65011f51a456 = function(arg0) {
      const ret = getObject$1(arg0).value;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_call_27c0f87801dedf93 = function() {
      return handleError$1(function(arg0, arg1) {
        const ret = getObject$1(arg0).call(getObject$1(arg1));
        return addHeapObject$1(ret);
      }, arguments);
    };
    imports.wbg.__wbg_self_ce0dbfc45cf2f5be = function() {
      return handleError$1(function() {
        const ret = self.self;
        return addHeapObject$1(ret);
      }, arguments);
    };
    imports.wbg.__wbg_window_c6fb939a7f436783 = function() {
      return handleError$1(function() {
        const ret = window.window;
        return addHeapObject$1(ret);
      }, arguments);
    };
    imports.wbg.__wbg_globalThis_d1e6af4856ba331b = function() {
      return handleError$1(function() {
        const ret = globalThis.globalThis;
        return addHeapObject$1(ret);
      }, arguments);
    };
    imports.wbg.__wbg_global_207b558942527489 = function() {
      return handleError$1(function() {
        const ret = global.global;
        return addHeapObject$1(ret);
      }, arguments);
    };
    imports.wbg.__wbindgen_is_undefined = function(arg0) {
      const ret = getObject$1(arg0) === void 0;
      return ret;
    };
    imports.wbg.__wbg_from_89e3fc3ba5e6fb48 = function(arg0) {
      const ret = Array.from(getObject$1(arg0));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_isArray_2ab64d95e09ea0ae = function(arg0) {
      const ret = Array.isArray(getObject$1(arg0));
      return ret;
    };
    imports.wbg.__wbg_push_a5b05aedc7234f9f = function(arg0, arg1) {
      const ret = getObject$1(arg0).push(getObject$1(arg1));
      return ret;
    };
    imports.wbg.__wbg_instanceof_Error_e20bb56fd5591a93 = function(arg0) {
      let result;
      try {
        result = getObject$1(arg0) instanceof Error;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    };
    imports.wbg.__wbg_new_28c511d9baebfa89 = function(arg0, arg1) {
      const ret = new Error(getStringFromWasm0$1(arg0, arg1));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_setname_c145a9049d9af5bf = function(arg0, arg1, arg2) {
      getObject$1(arg0).name = getStringFromWasm0$1(arg1, arg2);
    };
    imports.wbg.__wbg_toString_ffe4c9ea3b3532e9 = function(arg0) {
      const ret = getObject$1(arg0).toString();
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_call_b3ca7c6051f9bec1 = function() {
      return handleError$1(function(arg0, arg1, arg2) {
        const ret = getObject$1(arg0).call(getObject$1(arg1), getObject$1(arg2));
        return addHeapObject$1(ret);
      }, arguments);
    };
    imports.wbg.__wbg_instanceof_Map_87917e0a7aaf4012 = function(arg0) {
      let result;
      try {
        result = getObject$1(arg0) instanceof Map;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    };
    imports.wbg.__wbg_get_596396f84e7b37c4 = function(arg0, arg1) {
      const ret = getObject$1(arg0).get(getObject$1(arg1));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_set_8417257aaedc936b = function(arg0, arg1, arg2) {
      const ret = getObject$1(arg0).set(getObject$1(arg1), getObject$1(arg2));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_keys_d92dce52cca47c30 = function(arg0) {
      const ret = getObject$1(arg0).keys();
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_now_3014639a94423537 = function() {
      const ret = Date.now();
      return ret;
    };
    imports.wbg.__wbg_fromEntries_c9d8ec8925e677a8 = function() {
      return handleError$1(function(arg0) {
        const ret = Object.fromEntries(getObject$1(arg0));
        return addHeapObject$1(ret);
      }, arguments);
    };
    imports.wbg.__wbg_new_81740750da40724f = function(arg0, arg1) {
      try {
        var state0 = { a: arg0, b: arg1 };
        var cb0 = (arg02, arg12) => {
          const a = state0.a;
          state0.a = 0;
          try {
            return __wbg_adapter_881(a, state0.b, arg02, arg12);
          } finally {
            state0.a = a;
          }
        };
        const ret = new Promise(cb0);
        return addHeapObject$1(ret);
      } finally {
        state0.a = state0.b = 0;
      }
    };
    imports.wbg.__wbg_resolve_b0083a7967828ec8 = function(arg0) {
      const ret = Promise.resolve(getObject$1(arg0));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_then_0c86a60e8fcfe9f6 = function(arg0, arg1) {
      const ret = getObject$1(arg0).then(getObject$1(arg1));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_then_a73caa9a87991566 = function(arg0, arg1, arg2) {
      const ret = getObject$1(arg0).then(getObject$1(arg1), getObject$1(arg2));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_buffer_12d079cc21e14bdb = function(arg0) {
      const ret = getObject$1(arg0).buffer;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_newwithbyteoffsetandlength_aa4a17c33a06e5cb = function(arg0, arg1, arg2) {
      const ret = new Uint8Array(getObject$1(arg0), arg1 >>> 0, arg2 >>> 0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_new_63b92bc8671ed464 = function(arg0) {
      const ret = new Uint8Array(getObject$1(arg0));
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_set_a47bac70306a19a7 = function(arg0, arg1, arg2) {
      getObject$1(arg0).set(getObject$1(arg1), arg2 >>> 0);
    };
    imports.wbg.__wbg_length_c20a40f15020d68a = function(arg0) {
      const ret = getObject$1(arg0).length;
      return ret;
    };
    imports.wbg.__wbg_instanceof_Uint8Array_2b3bbecd033d19f6 = function(arg0) {
      let result;
      try {
        result = getObject$1(arg0) instanceof Uint8Array;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    };
    imports.wbg.__wbg_newwithlength_e9b4878cebadb3d3 = function(arg0) {
      const ret = new Uint8Array(arg0 >>> 0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbg_subarray_a1f73cd4b5b42fe1 = function(arg0, arg1, arg2) {
      const ret = getObject$1(arg0).subarray(arg1 >>> 0, arg2 >>> 0);
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbindgen_debug_string = function(arg0, arg1) {
      const ret = debugString$1(getObject$1(arg1));
      const ptr1 = passStringToWasm0$1(ret, wasm$1.__wbindgen_malloc, wasm$1.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN$1;
      getInt32Memory0$1()[arg0 / 4 + 1] = len1;
      getInt32Memory0$1()[arg0 / 4 + 0] = ptr1;
    };
    imports.wbg.__wbindgen_throw = function(arg0, arg1) {
      throw new Error(getStringFromWasm0$1(arg0, arg1));
    };
    imports.wbg.__wbindgen_memory = function() {
      const ret = wasm$1.memory;
      return addHeapObject$1(ret);
    };
    imports.wbg.__wbindgen_closure_wrapper5482 = function(arg0, arg1, arg2) {
      const ret = makeMutClosure$1(arg0, arg1, 625, __wbg_adapter_32);
      return addHeapObject$1(ret);
    };
    return imports;
  }
  function __wbg_finalize_init$1(instance, module2) {
    wasm$1 = instance.exports;
    __wbg_init$1.__wbindgen_wasm_module = module2;
    cachedInt32Memory0$1 = null;
    cachedUint32Memory0 = null;
    cachedUint8Memory0$1 = null;
    wasm$1.__wbindgen_start();
    return wasm$1;
  }
  async function __wbg_init$1(input) {
    if (wasm$1 !== void 0) return wasm$1;
    const imports = __wbg_get_imports$1();
    if (typeof input === "string" || typeof Request === "function" && input instanceof Request || typeof URL === "function" && input instanceof URL) {
      input = fetch(input);
    }
    const { instance, module: module2 } = await __wbg_load$1(await input, imports);
    return __wbg_finalize_init$1(instance, module2);
  }
  let __initializedIotaWasm$1 = false;
  function init$1(path) {
    if (__initializedIotaWasm$1) {
      return Promise.resolve(wasm$1);
    }
    return __wbg_init$1(path || "identity_wasm_bg.wasm").then(() => {
      __initializedIotaWasm$1 = true;
      return wasm$1;
    });
  }
  function _getCoreDocumentInternal$1(arg) {
    if (arg instanceof CoreDocument) {
      return arg._shallowCloneInternal();
    } else {
      return arg.toCoreDocument()._shallowCloneInternal();
    }
  }
  function _maybeGetIotaDocumentInternal$1(arg) {
    if (arg instanceof IotaDocument) {
      return arg._shallowCloneInternal();
    } else {
      return;
    }
  }
  function _getCoreDidCloneInternal$1(arg) {
    if (arg instanceof IotaDID || arg instanceof CoreDID) {
      return arg.toCoreDid();
    } else {
      return arg.toCoreDid().clone();
    }
  }
  globalThis._getCoreDocumentInternal = _getCoreDocumentInternal$1;
  globalThis._maybeGetIotaDocumentInternal = _maybeGetIotaDocumentInternal$1;
  globalThis._getCoreDidCloneInternal = _getCoreDidCloneInternal$1;
  var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
  function getDefaultExportFromCjs(x2) {
    return x2 && x2.__esModule && Object.prototype.hasOwnProperty.call(x2, "default") ? x2["default"] : x2;
  }
  /*! *****************************************************************************
      Copyright (C) Microsoft. All rights reserved.
      Licensed under the Apache License, Version 2.0 (the "License"); you may not use
      this file except in compliance with the License. You may obtain a copy of the
      License at http://www.apache.org/licenses/LICENSE-2.0
  
      THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
      KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
      WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
      MERCHANTABLITY OR NON-INFRINGEMENT.
  
      See the Apache Version 2.0 License for specific language governing permissions
      and limitations under the License.
      ***************************************************************************** */
  var Reflect$1;
  (function(Reflect2) {
    (function(factory) {
      var root = typeof commonjsGlobal === "object" ? commonjsGlobal : typeof self === "object" ? self : typeof this === "object" ? this : Function("return this;")();
      var exporter = makeExporter(Reflect2);
      if (typeof root.Reflect === "undefined") {
        root.Reflect = Reflect2;
      } else {
        exporter = makeExporter(root.Reflect, exporter);
      }
      factory(exporter);
      function makeExporter(target, previous) {
        return function(key, value) {
          if (typeof target[key] !== "function") {
            Object.defineProperty(target, key, { configurable: true, writable: true, value });
          }
          if (previous)
            previous(key, value);
        };
      }
    })(function(exporter) {
      var hasOwn = Object.prototype.hasOwnProperty;
      var supportsSymbol = typeof Symbol === "function";
      var toPrimitiveSymbol = supportsSymbol && typeof Symbol.toPrimitive !== "undefined" ? Symbol.toPrimitive : "@@toPrimitive";
      var iteratorSymbol = supportsSymbol && typeof Symbol.iterator !== "undefined" ? Symbol.iterator : "@@iterator";
      var supportsCreate = typeof Object.create === "function";
      var supportsProto = { __proto__: [] } instanceof Array;
      var downLevel = !supportsCreate && !supportsProto;
      var HashMap = {
        // create an object in dictionary mode (a.k.a. "slow" mode in v8)
        create: supportsCreate ? function() {
          return MakeDictionary(/* @__PURE__ */ Object.create(null));
        } : supportsProto ? function() {
          return MakeDictionary({ __proto__: null });
        } : function() {
          return MakeDictionary({});
        },
        has: downLevel ? function(map, key) {
          return hasOwn.call(map, key);
        } : function(map, key) {
          return key in map;
        },
        get: downLevel ? function(map, key) {
          return hasOwn.call(map, key) ? map[key] : void 0;
        } : function(map, key) {
          return map[key];
        }
      };
      var functionPrototype = Object.getPrototypeOf(Function);
      var usePolyfill = typeof process === "object" && process["env"] && process["env"]["REFLECT_METADATA_USE_MAP_POLYFILL"] === "true";
      var _Map = !usePolyfill && typeof Map === "function" && typeof Map.prototype.entries === "function" ? Map : CreateMapPolyfill();
      var _Set = !usePolyfill && typeof Set === "function" && typeof Set.prototype.entries === "function" ? Set : CreateSetPolyfill();
      var _WeakMap = !usePolyfill && typeof WeakMap === "function" ? WeakMap : CreateWeakMapPolyfill();
      var Metadata = new _WeakMap();
      function decorate(decorators, target, propertyKey, attributes) {
        if (!IsUndefined(propertyKey)) {
          if (!IsArray(decorators))
            throw new TypeError();
          if (!IsObject(target))
            throw new TypeError();
          if (!IsObject(attributes) && !IsUndefined(attributes) && !IsNull(attributes))
            throw new TypeError();
          if (IsNull(attributes))
            attributes = void 0;
          propertyKey = ToPropertyKey(propertyKey);
          return DecorateProperty(decorators, target, propertyKey, attributes);
        } else {
          if (!IsArray(decorators))
            throw new TypeError();
          if (!IsConstructor(target))
            throw new TypeError();
          return DecorateConstructor(decorators, target);
        }
      }
      exporter("decorate", decorate);
      function metadata(metadataKey, metadataValue) {
        function decorator(target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey) && !IsPropertyKey(propertyKey))
            throw new TypeError();
          OrdinaryDefineOwnMetadata(metadataKey, metadataValue, target, propertyKey);
        }
        return decorator;
      }
      exporter("metadata", metadata);
      function defineMetadata(metadataKey, metadataValue, target, propertyKey) {
        if (!IsObject(target))
          throw new TypeError();
        if (!IsUndefined(propertyKey))
          propertyKey = ToPropertyKey(propertyKey);
        return OrdinaryDefineOwnMetadata(metadataKey, metadataValue, target, propertyKey);
      }
      exporter("defineMetadata", defineMetadata);
      function hasMetadata(metadataKey, target, propertyKey) {
        if (!IsObject(target))
          throw new TypeError();
        if (!IsUndefined(propertyKey))
          propertyKey = ToPropertyKey(propertyKey);
        return OrdinaryHasMetadata(metadataKey, target, propertyKey);
      }
      exporter("hasMetadata", hasMetadata);
      function hasOwnMetadata(metadataKey, target, propertyKey) {
        if (!IsObject(target))
          throw new TypeError();
        if (!IsUndefined(propertyKey))
          propertyKey = ToPropertyKey(propertyKey);
        return OrdinaryHasOwnMetadata(metadataKey, target, propertyKey);
      }
      exporter("hasOwnMetadata", hasOwnMetadata);
      function getMetadata(metadataKey, target, propertyKey) {
        if (!IsObject(target))
          throw new TypeError();
        if (!IsUndefined(propertyKey))
          propertyKey = ToPropertyKey(propertyKey);
        return OrdinaryGetMetadata(metadataKey, target, propertyKey);
      }
      exporter("getMetadata", getMetadata);
      function getOwnMetadata(metadataKey, target, propertyKey) {
        if (!IsObject(target))
          throw new TypeError();
        if (!IsUndefined(propertyKey))
          propertyKey = ToPropertyKey(propertyKey);
        return OrdinaryGetOwnMetadata(metadataKey, target, propertyKey);
      }
      exporter("getOwnMetadata", getOwnMetadata);
      function getMetadataKeys(target, propertyKey) {
        if (!IsObject(target))
          throw new TypeError();
        if (!IsUndefined(propertyKey))
          propertyKey = ToPropertyKey(propertyKey);
        return OrdinaryMetadataKeys(target, propertyKey);
      }
      exporter("getMetadataKeys", getMetadataKeys);
      function getOwnMetadataKeys(target, propertyKey) {
        if (!IsObject(target))
          throw new TypeError();
        if (!IsUndefined(propertyKey))
          propertyKey = ToPropertyKey(propertyKey);
        return OrdinaryOwnMetadataKeys(target, propertyKey);
      }
      exporter("getOwnMetadataKeys", getOwnMetadataKeys);
      function deleteMetadata(metadataKey, target, propertyKey) {
        if (!IsObject(target))
          throw new TypeError();
        if (!IsUndefined(propertyKey))
          propertyKey = ToPropertyKey(propertyKey);
        var metadataMap = GetOrCreateMetadataMap(
          target,
          propertyKey,
          /*Create*/
          false
        );
        if (IsUndefined(metadataMap))
          return false;
        if (!metadataMap.delete(metadataKey))
          return false;
        if (metadataMap.size > 0)
          return true;
        var targetMetadata = Metadata.get(target);
        targetMetadata.delete(propertyKey);
        if (targetMetadata.size > 0)
          return true;
        Metadata.delete(target);
        return true;
      }
      exporter("deleteMetadata", deleteMetadata);
      function DecorateConstructor(decorators, target) {
        for (var i2 = decorators.length - 1; i2 >= 0; --i2) {
          var decorator = decorators[i2];
          var decorated = decorator(target);
          if (!IsUndefined(decorated) && !IsNull(decorated)) {
            if (!IsConstructor(decorated))
              throw new TypeError();
            target = decorated;
          }
        }
        return target;
      }
      function DecorateProperty(decorators, target, propertyKey, descriptor) {
        for (var i2 = decorators.length - 1; i2 >= 0; --i2) {
          var decorator = decorators[i2];
          var decorated = decorator(target, propertyKey, descriptor);
          if (!IsUndefined(decorated) && !IsNull(decorated)) {
            if (!IsObject(decorated))
              throw new TypeError();
            descriptor = decorated;
          }
        }
        return descriptor;
      }
      function GetOrCreateMetadataMap(O, P, Create) {
        var targetMetadata = Metadata.get(O);
        if (IsUndefined(targetMetadata)) {
          if (!Create)
            return void 0;
          targetMetadata = new _Map();
          Metadata.set(O, targetMetadata);
        }
        var metadataMap = targetMetadata.get(P);
        if (IsUndefined(metadataMap)) {
          if (!Create)
            return void 0;
          metadataMap = new _Map();
          targetMetadata.set(P, metadataMap);
        }
        return metadataMap;
      }
      function OrdinaryHasMetadata(MetadataKey, O, P) {
        var hasOwn2 = OrdinaryHasOwnMetadata(MetadataKey, O, P);
        if (hasOwn2)
          return true;
        var parent = OrdinaryGetPrototypeOf(O);
        if (!IsNull(parent))
          return OrdinaryHasMetadata(MetadataKey, parent, P);
        return false;
      }
      function OrdinaryHasOwnMetadata(MetadataKey, O, P) {
        var metadataMap = GetOrCreateMetadataMap(
          O,
          P,
          /*Create*/
          false
        );
        if (IsUndefined(metadataMap))
          return false;
        return ToBoolean(metadataMap.has(MetadataKey));
      }
      function OrdinaryGetMetadata(MetadataKey, O, P) {
        var hasOwn2 = OrdinaryHasOwnMetadata(MetadataKey, O, P);
        if (hasOwn2)
          return OrdinaryGetOwnMetadata(MetadataKey, O, P);
        var parent = OrdinaryGetPrototypeOf(O);
        if (!IsNull(parent))
          return OrdinaryGetMetadata(MetadataKey, parent, P);
        return void 0;
      }
      function OrdinaryGetOwnMetadata(MetadataKey, O, P) {
        var metadataMap = GetOrCreateMetadataMap(
          O,
          P,
          /*Create*/
          false
        );
        if (IsUndefined(metadataMap))
          return void 0;
        return metadataMap.get(MetadataKey);
      }
      function OrdinaryDefineOwnMetadata(MetadataKey, MetadataValue, O, P) {
        var metadataMap = GetOrCreateMetadataMap(
          O,
          P,
          /*Create*/
          true
        );
        metadataMap.set(MetadataKey, MetadataValue);
      }
      function OrdinaryMetadataKeys(O, P) {
        var ownKeys = OrdinaryOwnMetadataKeys(O, P);
        var parent = OrdinaryGetPrototypeOf(O);
        if (parent === null)
          return ownKeys;
        var parentKeys = OrdinaryMetadataKeys(parent, P);
        if (parentKeys.length <= 0)
          return ownKeys;
        if (ownKeys.length <= 0)
          return parentKeys;
        var set = new _Set();
        var keys = [];
        for (var _i = 0, ownKeys_1 = ownKeys; _i < ownKeys_1.length; _i++) {
          var key = ownKeys_1[_i];
          var hasKey = set.has(key);
          if (!hasKey) {
            set.add(key);
            keys.push(key);
          }
        }
        for (var _a2 = 0, parentKeys_1 = parentKeys; _a2 < parentKeys_1.length; _a2++) {
          var key = parentKeys_1[_a2];
          var hasKey = set.has(key);
          if (!hasKey) {
            set.add(key);
            keys.push(key);
          }
        }
        return keys;
      }
      function OrdinaryOwnMetadataKeys(O, P) {
        var keys = [];
        var metadataMap = GetOrCreateMetadataMap(
          O,
          P,
          /*Create*/
          false
        );
        if (IsUndefined(metadataMap))
          return keys;
        var keysObj = metadataMap.keys();
        var iterator = GetIterator(keysObj);
        var k = 0;
        while (true) {
          var next = IteratorStep(iterator);
          if (!next) {
            keys.length = k;
            return keys;
          }
          var nextValue = IteratorValue(next);
          try {
            keys[k] = nextValue;
          } catch (e2) {
            try {
              IteratorClose(iterator);
            } finally {
              throw e2;
            }
          }
          k++;
        }
      }
      function Type2(x2) {
        if (x2 === null)
          return 1;
        switch (typeof x2) {
          case "undefined":
            return 0;
          case "boolean":
            return 2;
          case "string":
            return 3;
          case "symbol":
            return 4;
          case "number":
            return 5;
          case "object":
            return x2 === null ? 1 : 6;
          default:
            return 6;
        }
      }
      function IsUndefined(x2) {
        return x2 === void 0;
      }
      function IsNull(x2) {
        return x2 === null;
      }
      function IsSymbol(x2) {
        return typeof x2 === "symbol";
      }
      function IsObject(x2) {
        return typeof x2 === "object" ? x2 !== null : typeof x2 === "function";
      }
      function ToPrimitive(input, PreferredType) {
        switch (Type2(input)) {
          case 0:
            return input;
          case 1:
            return input;
          case 2:
            return input;
          case 3:
            return input;
          case 4:
            return input;
          case 5:
            return input;
        }
        var hint = "string";
        var exoticToPrim = GetMethod(input, toPrimitiveSymbol);
        if (exoticToPrim !== void 0) {
          var result = exoticToPrim.call(input, hint);
          if (IsObject(result))
            throw new TypeError();
          return result;
        }
        return OrdinaryToPrimitive(input);
      }
      function OrdinaryToPrimitive(O, hint) {
        var valueOf, result;
        {
          var toString_1 = O.toString;
          if (IsCallable(toString_1)) {
            var result = toString_1.call(O);
            if (!IsObject(result))
              return result;
          }
          var valueOf = O.valueOf;
          if (IsCallable(valueOf)) {
            var result = valueOf.call(O);
            if (!IsObject(result))
              return result;
          }
        }
        throw new TypeError();
      }
      function ToBoolean(argument) {
        return !!argument;
      }
      function ToString(argument) {
        return "" + argument;
      }
      function ToPropertyKey(argument) {
        var key = ToPrimitive(argument);
        if (IsSymbol(key))
          return key;
        return ToString(key);
      }
      function IsArray(argument) {
        return Array.isArray ? Array.isArray(argument) : argument instanceof Object ? argument instanceof Array : Object.prototype.toString.call(argument) === "[object Array]";
      }
      function IsCallable(argument) {
        return typeof argument === "function";
      }
      function IsConstructor(argument) {
        return typeof argument === "function";
      }
      function IsPropertyKey(argument) {
        switch (Type2(argument)) {
          case 3:
            return true;
          case 4:
            return true;
          default:
            return false;
        }
      }
      function GetMethod(V, P) {
        var func = V[P];
        if (func === void 0 || func === null)
          return void 0;
        if (!IsCallable(func))
          throw new TypeError();
        return func;
      }
      function GetIterator(obj) {
        var method = GetMethod(obj, iteratorSymbol);
        if (!IsCallable(method))
          throw new TypeError();
        var iterator = method.call(obj);
        if (!IsObject(iterator))
          throw new TypeError();
        return iterator;
      }
      function IteratorValue(iterResult) {
        return iterResult.value;
      }
      function IteratorStep(iterator) {
        var result = iterator.next();
        return result.done ? false : result;
      }
      function IteratorClose(iterator) {
        var f = iterator["return"];
        if (f)
          f.call(iterator);
      }
      function OrdinaryGetPrototypeOf(O) {
        var proto = Object.getPrototypeOf(O);
        if (typeof O !== "function" || O === functionPrototype)
          return proto;
        if (proto !== functionPrototype)
          return proto;
        var prototype = O.prototype;
        var prototypeProto = prototype && Object.getPrototypeOf(prototype);
        if (prototypeProto == null || prototypeProto === Object.prototype)
          return proto;
        var constructor = prototypeProto.constructor;
        if (typeof constructor !== "function")
          return proto;
        if (constructor === O)
          return proto;
        return constructor;
      }
      function CreateMapPolyfill() {
        var cacheSentinel = {};
        var arraySentinel = [];
        var MapIterator = (
          /** @class */
          function() {
            function MapIterator2(keys, values, selector) {
              this._index = 0;
              this._keys = keys;
              this._values = values;
              this._selector = selector;
            }
            MapIterator2.prototype["@@iterator"] = function() {
              return this;
            };
            MapIterator2.prototype[iteratorSymbol] = function() {
              return this;
            };
            MapIterator2.prototype.next = function() {
              var index = this._index;
              if (index >= 0 && index < this._keys.length) {
                var result = this._selector(this._keys[index], this._values[index]);
                if (index + 1 >= this._keys.length) {
                  this._index = -1;
                  this._keys = arraySentinel;
                  this._values = arraySentinel;
                } else {
                  this._index++;
                }
                return { value: result, done: false };
              }
              return { value: void 0, done: true };
            };
            MapIterator2.prototype.throw = function(error) {
              if (this._index >= 0) {
                this._index = -1;
                this._keys = arraySentinel;
                this._values = arraySentinel;
              }
              throw error;
            };
            MapIterator2.prototype.return = function(value) {
              if (this._index >= 0) {
                this._index = -1;
                this._keys = arraySentinel;
                this._values = arraySentinel;
              }
              return { value, done: true };
            };
            return MapIterator2;
          }()
        );
        return (
          /** @class */
          function() {
            function Map2() {
              this._keys = [];
              this._values = [];
              this._cacheKey = cacheSentinel;
              this._cacheIndex = -2;
            }
            Object.defineProperty(Map2.prototype, "size", {
              get: function() {
                return this._keys.length;
              },
              enumerable: true,
              configurable: true
            });
            Map2.prototype.has = function(key) {
              return this._find(
                key,
                /*insert*/
                false
              ) >= 0;
            };
            Map2.prototype.get = function(key) {
              var index = this._find(
                key,
                /*insert*/
                false
              );
              return index >= 0 ? this._values[index] : void 0;
            };
            Map2.prototype.set = function(key, value) {
              var index = this._find(
                key,
                /*insert*/
                true
              );
              this._values[index] = value;
              return this;
            };
            Map2.prototype.delete = function(key) {
              var index = this._find(
                key,
                /*insert*/
                false
              );
              if (index >= 0) {
                var size = this._keys.length;
                for (var i2 = index + 1; i2 < size; i2++) {
                  this._keys[i2 - 1] = this._keys[i2];
                  this._values[i2 - 1] = this._values[i2];
                }
                this._keys.length--;
                this._values.length--;
                if (key === this._cacheKey) {
                  this._cacheKey = cacheSentinel;
                  this._cacheIndex = -2;
                }
                return true;
              }
              return false;
            };
            Map2.prototype.clear = function() {
              this._keys.length = 0;
              this._values.length = 0;
              this._cacheKey = cacheSentinel;
              this._cacheIndex = -2;
            };
            Map2.prototype.keys = function() {
              return new MapIterator(this._keys, this._values, getKey);
            };
            Map2.prototype.values = function() {
              return new MapIterator(this._keys, this._values, getValue);
            };
            Map2.prototype.entries = function() {
              return new MapIterator(this._keys, this._values, getEntry);
            };
            Map2.prototype["@@iterator"] = function() {
              return this.entries();
            };
            Map2.prototype[iteratorSymbol] = function() {
              return this.entries();
            };
            Map2.prototype._find = function(key, insert) {
              if (this._cacheKey !== key) {
                this._cacheIndex = this._keys.indexOf(this._cacheKey = key);
              }
              if (this._cacheIndex < 0 && insert) {
                this._cacheIndex = this._keys.length;
                this._keys.push(key);
                this._values.push(void 0);
              }
              return this._cacheIndex;
            };
            return Map2;
          }()
        );
        function getKey(key, _) {
          return key;
        }
        function getValue(_, value) {
          return value;
        }
        function getEntry(key, value) {
          return [key, value];
        }
      }
      function CreateSetPolyfill() {
        return (
          /** @class */
          function() {
            function Set2() {
              this._map = new _Map();
            }
            Object.defineProperty(Set2.prototype, "size", {
              get: function() {
                return this._map.size;
              },
              enumerable: true,
              configurable: true
            });
            Set2.prototype.has = function(value) {
              return this._map.has(value);
            };
            Set2.prototype.add = function(value) {
              return this._map.set(value, value), this;
            };
            Set2.prototype.delete = function(value) {
              return this._map.delete(value);
            };
            Set2.prototype.clear = function() {
              this._map.clear();
            };
            Set2.prototype.keys = function() {
              return this._map.keys();
            };
            Set2.prototype.values = function() {
              return this._map.values();
            };
            Set2.prototype.entries = function() {
              return this._map.entries();
            };
            Set2.prototype["@@iterator"] = function() {
              return this.keys();
            };
            Set2.prototype[iteratorSymbol] = function() {
              return this.keys();
            };
            return Set2;
          }()
        );
      }
      function CreateWeakMapPolyfill() {
        var UUID_SIZE = 16;
        var keys = HashMap.create();
        var rootKey = CreateUniqueKey();
        return (
          /** @class */
          function() {
            function WeakMap2() {
              this._key = CreateUniqueKey();
            }
            WeakMap2.prototype.has = function(target) {
              var table = GetOrCreateWeakMapTable(
                target,
                /*create*/
                false
              );
              return table !== void 0 ? HashMap.has(table, this._key) : false;
            };
            WeakMap2.prototype.get = function(target) {
              var table = GetOrCreateWeakMapTable(
                target,
                /*create*/
                false
              );
              return table !== void 0 ? HashMap.get(table, this._key) : void 0;
            };
            WeakMap2.prototype.set = function(target, value) {
              var table = GetOrCreateWeakMapTable(
                target,
                /*create*/
                true
              );
              table[this._key] = value;
              return this;
            };
            WeakMap2.prototype.delete = function(target) {
              var table = GetOrCreateWeakMapTable(
                target,
                /*create*/
                false
              );
              return table !== void 0 ? delete table[this._key] : false;
            };
            WeakMap2.prototype.clear = function() {
              this._key = CreateUniqueKey();
            };
            return WeakMap2;
          }()
        );
        function CreateUniqueKey() {
          var key;
          do
            key = "@@WeakMap@@" + CreateUUID();
          while (HashMap.has(keys, key));
          keys[key] = true;
          return key;
        }
        function GetOrCreateWeakMapTable(target, create) {
          if (!hasOwn.call(target, rootKey)) {
            if (!create)
              return void 0;
            Object.defineProperty(target, rootKey, { value: HashMap.create() });
          }
          return target[rootKey];
        }
        function FillRandomBytes(buffer, size) {
          for (var i2 = 0; i2 < size; ++i2)
            buffer[i2] = Math.random() * 255 | 0;
          return buffer;
        }
        function GenRandomBytes(size) {
          if (typeof Uint8Array === "function") {
            if (typeof crypto !== "undefined")
              return crypto.getRandomValues(new Uint8Array(size));
            if (typeof msCrypto !== "undefined")
              return msCrypto.getRandomValues(new Uint8Array(size));
            return FillRandomBytes(new Uint8Array(size), size);
          }
          return FillRandomBytes(new Array(size), size);
        }
        function CreateUUID() {
          var data = GenRandomBytes(UUID_SIZE);
          data[6] = data[6] & 79 | 64;
          data[8] = data[8] & 191 | 128;
          var result = "";
          for (var offset = 0; offset < UUID_SIZE; ++offset) {
            var byte = data[offset];
            if (offset === 4 || offset === 6 || offset === 8)
              result += "-";
            if (byte < 16)
              result += "0";
            result += byte.toString(16).toLowerCase();
          }
          return result;
        }
      }
      function MakeDictionary(obj) {
        obj.__ = void 0;
        delete obj.__;
        return obj;
      }
    });
  })(Reflect$1 || (Reflect$1 = {}));
  let wasm;
  const heap = new Array(128).fill(void 0);
  heap.push(void 0, null, true, false);
  function getObject(idx) {
    return heap[idx];
  }
  let heap_next = heap.length;
  function dropObject(idx) {
    if (idx < 132) return;
    heap[idx] = heap_next;
    heap_next = idx;
  }
  function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
  }
  const cachedTextDecoder = typeof TextDecoder !== "undefined" ? new TextDecoder("utf-8", { ignoreBOM: true, fatal: true }) : { decode: () => {
    throw Error("TextDecoder not available");
  } };
  if (typeof TextDecoder !== "undefined") {
    cachedTextDecoder.decode();
  }
  let cachedUint8Memory0 = null;
  function getUint8Memory0() {
    if (cachedUint8Memory0 === null || cachedUint8Memory0.byteLength === 0) {
      cachedUint8Memory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8Memory0;
  }
  function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
  }
  function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];
    heap[idx] = obj;
    return idx;
  }
  function isLikeNone(x2) {
    return x2 === void 0 || x2 === null;
  }
  let cachedFloat64Memory0 = null;
  function getFloat64Memory0() {
    if (cachedFloat64Memory0 === null || cachedFloat64Memory0.byteLength === 0) {
      cachedFloat64Memory0 = new Float64Array(wasm.memory.buffer);
    }
    return cachedFloat64Memory0;
  }
  let cachedInt32Memory0 = null;
  function getInt32Memory0() {
    if (cachedInt32Memory0 === null || cachedInt32Memory0.byteLength === 0) {
      cachedInt32Memory0 = new Int32Array(wasm.memory.buffer);
    }
    return cachedInt32Memory0;
  }
  let WASM_VECTOR_LEN = 0;
  const cachedTextEncoder = typeof TextEncoder !== "undefined" ? new TextEncoder("utf-8") : { encode: () => {
    throw Error("TextEncoder not available");
  } };
  const encodeString = typeof cachedTextEncoder.encodeInto === "function" ? function(arg, view) {
    return cachedTextEncoder.encodeInto(arg, view);
  } : function(arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
      read: arg.length,
      written: buf.length
    };
  };
  function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === void 0) {
      const buf = cachedTextEncoder.encode(arg);
      const ptr2 = malloc(buf.length, 1) >>> 0;
      getUint8Memory0().subarray(ptr2, ptr2 + buf.length).set(buf);
      WASM_VECTOR_LEN = buf.length;
      return ptr2;
    }
    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;
    const mem = getUint8Memory0();
    let offset = 0;
    for (; offset < len; offset++) {
      const code = arg.charCodeAt(offset);
      if (code > 127) break;
      mem[ptr + offset] = code;
    }
    if (offset !== len) {
      if (offset !== 0) {
        arg = arg.slice(offset);
      }
      ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
      const view = getUint8Memory0().subarray(ptr + offset, ptr + len);
      const ret = encodeString(arg, view);
      offset += ret.written;
    }
    WASM_VECTOR_LEN = offset;
    return ptr;
  }
  function debugString(val) {
    const type = typeof val;
    if (type == "number" || type == "boolean" || val == null) {
      return `${val}`;
    }
    if (type == "string") {
      return `"${val}"`;
    }
    if (type == "symbol") {
      const description = val.description;
      if (description == null) {
        return "Symbol";
      } else {
        return `Symbol(${description})`;
      }
    }
    if (type == "function") {
      const name = val.name;
      if (typeof name == "string" && name.length > 0) {
        return `Function(${name})`;
      } else {
        return "Function";
      }
    }
    if (Array.isArray(val)) {
      const length = val.length;
      let debug = "[";
      if (length > 0) {
        debug += debugString(val[0]);
      }
      for (let i2 = 1; i2 < length; i2++) {
        debug += ", " + debugString(val[i2]);
      }
      debug += "]";
      return debug;
    }
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches.length > 1) {
      className = builtInMatches[1];
    } else {
      return toString.call(val);
    }
    if (className == "Object") {
      try {
        return "Object(" + JSON.stringify(val) + ")";
      } catch (_) {
        return "Object";
      }
    }
    if (val instanceof Error) {
      return `${val.name}: ${val.message}
${val.stack}`;
    }
    return className;
  }
  const CLOSURE_DTORS = new FinalizationRegistry((state) => {
    wasm.__wbindgen_export_2.get(state.dtor)(state.a, state.b);
  });
  function makeMutClosure(arg0, arg1, dtor, f) {
    const state = { a: arg0, b: arg1, cnt: 1, dtor };
    const real = (...args) => {
      state.cnt++;
      const a = state.a;
      state.a = 0;
      try {
        return f(a, state.b, ...args);
      } finally {
        if (--state.cnt === 0) {
          wasm.__wbindgen_export_2.get(state.dtor)(a, state.b);
          CLOSURE_DTORS.unregister(state);
        } else {
          state.a = a;
        }
      }
    };
    real.original = state;
    CLOSURE_DTORS.register(real, state, state);
    return real;
  }
  function __wbg_adapter_28(arg0, arg1) {
    wasm.__wbindgen_export_3(arg0, arg1);
  }
  function __wbg_adapter_31(arg0, arg1, arg2) {
    wasm.__wbindgen_export_4(arg0, arg1, addHeapObject(arg2));
  }
  function callUtilsMethodRust(method) {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm0(method, wasm.__wbindgen_export_0, wasm.__wbindgen_export_1);
      const len0 = WASM_VECTOR_LEN;
      wasm.callUtilsMethodRust(retptr, ptr0, len0);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
  function handleError(f, args) {
    try {
      return f.apply(this, args);
    } catch (e2) {
      wasm.__wbindgen_export_6(addHeapObject(e2));
    }
  }
  function __wbg_adapter_115(arg0, arg1, arg2, arg3) {
    wasm.__wbindgen_export_7(arg0, arg1, addHeapObject(arg2), addHeapObject(arg3));
  }
  const ClientMethodHandlerFinalization = new FinalizationRegistry((ptr) => wasm.__wbg_clientmethodhandler_free(ptr >>> 0));
  class ClientMethodHandler {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(ClientMethodHandler.prototype);
      obj.__wbg_ptr = ptr;
      ClientMethodHandlerFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      ClientMethodHandlerFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm.__wbg_clientmethodhandler_free(ptr);
    }
  }
  const SecretManagerMethodHandlerFinalization = new FinalizationRegistry((ptr) => wasm.__wbg_secretmanagermethodhandler_free(ptr >>> 0));
  class SecretManagerMethodHandler {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(SecretManagerMethodHandler.prototype);
      obj.__wbg_ptr = ptr;
      SecretManagerMethodHandlerFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      SecretManagerMethodHandlerFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm.__wbg_secretmanagermethodhandler_free(ptr);
    }
  }
  new FinalizationRegistry((ptr) => wasm.__wbg_walletmethodhandler_free(ptr >>> 0));
  async function __wbg_load(module2, imports) {
    if (typeof Response === "function" && module2 instanceof Response) {
      if (typeof WebAssembly.instantiateStreaming === "function") {
        try {
          return await WebAssembly.instantiateStreaming(module2, imports);
        } catch (e2) {
          if (module2.headers.get("Content-Type") != "application/wasm") {
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e2);
          } else {
            throw e2;
          }
        }
      }
      const bytes2 = await module2.arrayBuffer();
      return await WebAssembly.instantiate(bytes2, imports);
    } else {
      const instance = await WebAssembly.instantiate(module2, imports);
      if (instance instanceof WebAssembly.Instance) {
        return { instance, module: module2 };
      } else {
        return instance;
      }
    }
  }
  function __wbg_get_imports() {
    const imports = {};
    imports.wbg = {};
    imports.wbg.__wbg_now_86f7ca537c8b86d5 = function() {
      const ret = Date.now();
      return ret;
    };
    imports.wbg.__wbg_clientmethodhandler_new = function(arg0) {
      const ret = ClientMethodHandler.__wrap(arg0);
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_call_f6a2bc58c19c53c6 = function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = getObject(arg0).call(getObject(arg1), getObject(arg2));
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbindgen_object_drop_ref = function(arg0) {
      takeObject(arg0);
    };
    imports.wbg.__wbindgen_string_new = function(arg0, arg1) {
      const ret = getStringFromWasm0(arg0, arg1);
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_secretmanagermethodhandler_new = function(arg0) {
      const ret = SecretManagerMethodHandler.__wrap(arg0);
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_error_1f4e3e298a7c97f6 = function(arg0) {
      console.error(getObject(arg0));
    };
    imports.wbg.__wbg_length_d99b680fd68bf71b = function(arg0) {
      const ret = getObject(arg0).length;
      return ret;
    };
    imports.wbg.__wbg_keys_7dc65b03a1d1e0a3 = function(arg0) {
      const ret = getObject(arg0).keys();
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_next_267398d0e0761bf9 = function() {
      return handleError(function(arg0) {
        const ret = getObject(arg0).next();
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbg_done_506b44765ba84b9c = function(arg0) {
      const ret = getObject(arg0).done;
      return ret;
    };
    imports.wbg.__wbg_value_31485d8770eb06ab = function(arg0) {
      const ret = getObject(arg0).value;
      return addHeapObject(ret);
    };
    imports.wbg.__wbindgen_number_get = function(arg0, arg1) {
      const obj = getObject(arg1);
      const ret = typeof obj === "number" ? obj : void 0;
      getFloat64Memory0()[arg0 / 8 + 1] = isLikeNone(ret) ? 0 : ret;
      getInt32Memory0()[arg0 / 4 + 0] = !isLikeNone(ret);
    };
    imports.wbg.__wbg_abort_7792bf3f664d7bb3 = function(arg0) {
      getObject(arg0).abort();
    };
    imports.wbg.__wbindgen_cb_drop = function(arg0) {
      const obj = takeObject(arg0).original;
      if (obj.cnt-- == 1) {
        obj.a = 0;
        return true;
      }
      const ret = false;
      return ret;
    };
    imports.wbg.__wbg_clearTimeout_541ac0980ffcef74 = function(arg0) {
      const ret = clearTimeout(takeObject(arg0));
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_new_87d841e70661f6e9 = function() {
      const ret = new Object();
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_set_37a50e901587b477 = function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = Reflect.set(getObject(arg0), getObject(arg1), getObject(arg2));
        return ret;
      }, arguments);
    };
    imports.wbg.__wbg_new_a979e9eedc5e81a3 = function() {
      return handleError(function() {
        const ret = new Headers();
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbindgen_object_clone_ref = function(arg0) {
      const ret = getObject(arg0);
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_new_fa36281638875de8 = function() {
      return handleError(function() {
        const ret = new AbortController();
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbg_signal_7876560d9d0f914c = function(arg0) {
      const ret = getObject(arg0).signal;
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_append_047382169b61373d = function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4) {
        getObject(arg0).append(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
      }, arguments);
    };
    imports.wbg.__wbg_instanceof_Response_0d25bb8436a9cefe = function(arg0) {
      let result;
      try {
        result = getObject(arg0) instanceof Response;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    };
    imports.wbg.__wbg_status_351700a30c61ba61 = function(arg0) {
      const ret = getObject(arg0).status;
      return ret;
    };
    imports.wbg.__wbg_url_47f8307501523859 = function(arg0, arg1) {
      const ret = getObject(arg1).url;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_export_0, wasm.__wbindgen_export_1);
      const len1 = WASM_VECTOR_LEN;
      getInt32Memory0()[arg0 / 4 + 1] = len1;
      getInt32Memory0()[arg0 / 4 + 0] = ptr1;
    };
    imports.wbg.__wbg_headers_e38c00d713e8888c = function(arg0) {
      const ret = getObject(arg0).headers;
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_iterator_364187e1ee96b750 = function() {
      const ret = Symbol.iterator;
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_get_5027b32da70f39b1 = function() {
      return handleError(function(arg0, arg1) {
        const ret = Reflect.get(getObject(arg0), getObject(arg1));
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbindgen_is_function = function(arg0) {
      const ret = typeof getObject(arg0) === "function";
      return ret;
    };
    imports.wbg.__wbg_call_a79f1973a4f07d5e = function() {
      return handleError(function(arg0, arg1) {
        const ret = getObject(arg0).call(getObject(arg1));
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbindgen_is_object = function(arg0) {
      const val = getObject(arg0);
      const ret = typeof val === "object" && val !== null;
      return ret;
    };
    imports.wbg.__wbg_next_1938cf110c9491d4 = function(arg0) {
      const ret = getObject(arg0).next;
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_stringify_daa6661e90c04140 = function() {
      return handleError(function(arg0) {
        const ret = JSON.stringify(getObject(arg0));
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbindgen_string_get = function(arg0, arg1) {
      const obj = getObject(arg1);
      const ret = typeof obj === "string" ? obj : void 0;
      var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_export_0, wasm.__wbindgen_export_1);
      var len1 = WASM_VECTOR_LEN;
      getInt32Memory0()[arg0 / 4 + 1] = len1;
      getInt32Memory0()[arg0 / 4 + 0] = ptr1;
    };
    imports.wbg.__wbg_text_10c88c5e55f873c7 = function() {
      return handleError(function(arg0) {
        const ret = getObject(arg0).text();
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbg_arrayBuffer_ec4617b29bb0f61c = function() {
      return handleError(function(arg0) {
        const ret = getObject(arg0).arrayBuffer();
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbg_new_ace717933ad7117f = function(arg0) {
      const ret = new Uint8Array(getObject(arg0));
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_length_f0764416ba5bb237 = function(arg0) {
      const ret = getObject(arg0).length;
      return ret;
    };
    imports.wbg.__wbg_new_1d93771b84541aa5 = function(arg0, arg1) {
      try {
        var state0 = { a: arg0, b: arg1 };
        var cb0 = (arg02, arg12) => {
          const a = state0.a;
          state0.a = 0;
          try {
            return __wbg_adapter_115(a, state0.b, arg02, arg12);
          } finally {
            state0.a = a;
          }
        };
        const ret = new Promise(cb0);
        return addHeapObject(ret);
      } finally {
        state0.a = state0.b = 0;
      }
    };
    imports.wbg.__wbg_new_3a66822ed076951c = function(arg0, arg1) {
      const ret = new Error(getStringFromWasm0(arg0, arg1));
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_new_abda76e883ba8a5f = function() {
      const ret = new Error();
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_stack_658279fe44541cf6 = function(arg0, arg1) {
      const ret = getObject(arg1).stack;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_export_0, wasm.__wbindgen_export_1);
      const len1 = WASM_VECTOR_LEN;
      getInt32Memory0()[arg0 / 4 + 1] = len1;
      getInt32Memory0()[arg0 / 4 + 0] = ptr1;
    };
    imports.wbg.__wbg_error_f851667af71bcfc6 = function(arg0, arg1) {
      let deferred0_0;
      let deferred0_1;
      try {
        deferred0_0 = arg0;
        deferred0_1 = arg1;
        console.error(getStringFromWasm0(arg0, arg1));
      } finally {
        wasm.__wbindgen_export_5(deferred0_0, deferred0_1, 1);
      }
    };
    imports.wbg.__wbg_crypto_d05b68a3572bb8ca = function(arg0) {
      const ret = getObject(arg0).crypto;
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_process_b02b3570280d0366 = function(arg0) {
      const ret = getObject(arg0).process;
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_versions_c1cb42213cedf0f5 = function(arg0) {
      const ret = getObject(arg0).versions;
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_node_43b1089f407e4ec2 = function(arg0) {
      const ret = getObject(arg0).node;
      return addHeapObject(ret);
    };
    imports.wbg.__wbindgen_is_string = function(arg0) {
      const ret = typeof getObject(arg0) === "string";
      return ret;
    };
    imports.wbg.__wbg_msCrypto_10fc94afee92bd76 = function(arg0) {
      const ret = getObject(arg0).msCrypto;
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_newwithlength_728575f3bba9959b = function(arg0) {
      const ret = new Uint8Array(arg0 >>> 0);
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_require_9a7e0f667ead4995 = function() {
      return handleError(function() {
        const ret = module.require;
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbindgen_memory = function() {
      const ret = wasm.memory;
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_buffer_5d1b598a01b41a42 = function(arg0) {
      const ret = getObject(arg0).buffer;
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_newwithbyteoffsetandlength_d695c7957788f922 = function(arg0, arg1, arg2) {
      const ret = new Uint8Array(getObject(arg0), arg1 >>> 0, arg2 >>> 0);
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_randomFillSync_b70ccbdf4926a99d = function() {
      return handleError(function(arg0, arg1) {
        getObject(arg0).randomFillSync(takeObject(arg1));
      }, arguments);
    };
    imports.wbg.__wbg_subarray_7f7a652672800851 = function(arg0, arg1, arg2) {
      const ret = getObject(arg0).subarray(arg1 >>> 0, arg2 >>> 0);
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_getRandomValues_7e42b4fb8779dc6d = function() {
      return handleError(function(arg0, arg1) {
        getObject(arg0).getRandomValues(getObject(arg1));
      }, arguments);
    };
    imports.wbg.__wbg_set_74906aa30864df5a = function(arg0, arg1, arg2) {
      getObject(arg0).set(getObject(arg1), arg2 >>> 0);
    };
    imports.wbg.__wbg_setTimeout_7d81d052875b0f4f = function() {
      return handleError(function(arg0, arg1) {
        const ret = setTimeout(getObject(arg0), arg1);
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbg_now_65ff8ec2b863300c = function(arg0) {
      const ret = getObject(arg0).now();
      return ret;
    };
    imports.wbg.__wbg_self_086b5302bcafb962 = function() {
      return handleError(function() {
        const ret = self.self;
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbg_window_132fa5d7546f1de5 = function() {
      return handleError(function() {
        const ret = window.window;
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbg_globalThis_e5f801a37ad7d07b = function() {
      return handleError(function() {
        const ret = globalThis.globalThis;
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbg_global_f9a61fce4af6b7c1 = function() {
      return handleError(function() {
        const ret = global.global;
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbindgen_is_undefined = function(arg0) {
      const ret = getObject(arg0) === void 0;
      return ret;
    };
    imports.wbg.__wbg_newnoargs_5859b6d41c6fe9f7 = function(arg0, arg1) {
      const ret = new Function(getStringFromWasm0(arg0, arg1));
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_has_a2919659b7b645b3 = function() {
      return handleError(function(arg0, arg1) {
        const ret = Reflect.has(getObject(arg0), getObject(arg1));
        return ret;
      }, arguments);
    };
    imports.wbg.__wbg_fetch_06d656a1b748ac0d = function(arg0, arg1) {
      const ret = getObject(arg0).fetch(getObject(arg1));
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_fetch_6a2624d7f767e331 = function(arg0) {
      const ret = fetch(getObject(arg0));
      return addHeapObject(ret);
    };
    imports.wbg.__wbindgen_debug_string = function(arg0, arg1) {
      const ret = debugString(getObject(arg1));
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_export_0, wasm.__wbindgen_export_1);
      const len1 = WASM_VECTOR_LEN;
      getInt32Memory0()[arg0 / 4 + 1] = len1;
      getInt32Memory0()[arg0 / 4 + 0] = ptr1;
    };
    imports.wbg.__wbindgen_throw = function(arg0, arg1) {
      throw new Error(getStringFromWasm0(arg0, arg1));
    };
    imports.wbg.__wbg_then_5842e4e97f7beace = function(arg0, arg1, arg2) {
      const ret = getObject(arg0).then(getObject(arg1), getObject(arg2));
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_queueMicrotask_26a89c14c53809c0 = function(arg0) {
      const ret = getObject(arg0).queueMicrotask;
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_resolve_97ecd55ee839391b = function(arg0) {
      const ret = Promise.resolve(getObject(arg0));
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_then_7aeb7c5f1536640f = function(arg0, arg1) {
      const ret = getObject(arg0).then(getObject(arg1));
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_queueMicrotask_118eeb525d584d9a = function(arg0) {
      queueMicrotask(getObject(arg0));
    };
    imports.wbg.__wbg_error_8cf137381b3af25f = function(arg0, arg1, arg2, arg3) {
      console.error(getObject(arg0), getObject(arg1), getObject(arg2), getObject(arg3));
    };
    imports.wbg.__wbg_warn_ea08466617ec5d3a = function(arg0, arg1, arg2, arg3) {
      console.warn(getObject(arg0), getObject(arg1), getObject(arg2), getObject(arg3));
    };
    imports.wbg.__wbg_info_eb81e4fcae9ba8f1 = function(arg0, arg1, arg2, arg3) {
      console.info(getObject(arg0), getObject(arg1), getObject(arg2), getObject(arg3));
    };
    imports.wbg.__wbg_log_bd0951a507fbf762 = function(arg0, arg1, arg2, arg3) {
      console.log(getObject(arg0), getObject(arg1), getObject(arg2), getObject(arg3));
    };
    imports.wbg.__wbg_debug_0207b724052e591d = function(arg0, arg1, arg2, arg3) {
      console.debug(getObject(arg0), getObject(arg1), getObject(arg2), getObject(arg3));
    };
    imports.wbg.__wbg_newwithstrandinit_9fd2fc855c6327eb = function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = new Request(getStringFromWasm0(arg0, arg1), getObject(arg2));
        return addHeapObject(ret);
      }, arguments);
    };
    imports.wbg.__wbindgen_closure_wrapper3069 = function(arg0, arg1, arg2) {
      const ret = makeMutClosure(arg0, arg1, 150, __wbg_adapter_28);
      return addHeapObject(ret);
    };
    imports.wbg.__wbindgen_closure_wrapper5130 = function(arg0, arg1, arg2) {
      const ret = makeMutClosure(arg0, arg1, 150, __wbg_adapter_31);
      return addHeapObject(ret);
    };
    return imports;
  }
  function __wbg_finalize_init(instance, module2) {
    wasm = instance.exports;
    __wbg_init.__wbindgen_wasm_module = module2;
    cachedFloat64Memory0 = null;
    cachedInt32Memory0 = null;
    cachedUint8Memory0 = null;
    wasm.__wbindgen_start();
    return wasm;
  }
  async function __wbg_init(input) {
    if (wasm !== void 0) return wasm;
    const imports = __wbg_get_imports();
    if (typeof input === "string" || typeof Request === "function" && input instanceof Request || typeof URL === "function" && input instanceof URL) {
      input = fetch(input);
    }
    const { instance, module: module2 } = await __wbg_load(await input, imports);
    return __wbg_finalize_init(instance, module2);
  }
  let __initializedIotaWasm = false;
  function init(path) {
    if (__initializedIotaWasm) {
      return Promise.resolve(wasm);
    }
    return __wbg_init(path || "iota_sdk_wasm_bg.wasm").then(() => {
      __initializedIotaWasm = true;
      return wasm;
    });
  }
  var callUtilsMethod = function(method) {
    var response = JSON.parse(callUtilsMethodRust(JSON.stringify(method)));
    if (response.type == "error" || response.type == "panic") {
      throw response;
    } else {
      return response.payload;
    }
  };
  var __extends$h = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var InputType;
  (function(InputType2) {
    InputType2[InputType2["UTXO"] = 0] = "UTXO";
    InputType2[InputType2["Treasury"] = 1] = "Treasury";
  })(InputType || (InputType = {}));
  var Input = (
    /** @class */
    function() {
      function Input2(type) {
        this.type = type;
      }
      Input2.prototype.getType = function() {
        return this.type;
      };
      return Input2;
    }()
  );
  var TreasuryInput = (
    /** @class */
    function(_super) {
      __extends$h(TreasuryInput2, _super);
      function TreasuryInput2(milestoneId) {
        var _this = _super.call(this, InputType.Treasury) || this;
        _this.milestoneId = milestoneId;
        return _this;
      }
      return TreasuryInput2;
    }(Input)
  );
  var UTXOInput = (
    /** @class */
    function(_super) {
      __extends$h(UTXOInput2, _super);
      function UTXOInput2(transactionId, transactionOutputIndex) {
        var _this = _super.call(this, InputType.UTXO) || this;
        _this.transactionId = transactionId;
        _this.transactionOutputIndex = transactionOutputIndex;
        return _this;
      }
      UTXOInput2.fromOutputId = function(outputId) {
        return null;
      };
      return UTXOInput2;
    }(Input)
  );
  var InputDiscriminator = {
    property: "type",
    subTypes: [
      { value: TreasuryInput, name: InputType.Treasury },
      { value: UTXOInput, name: InputType.UTXO }
    ]
  };
  var TransformationType;
  (function(TransformationType2) {
    TransformationType2[TransformationType2["PLAIN_TO_CLASS"] = 0] = "PLAIN_TO_CLASS";
    TransformationType2[TransformationType2["CLASS_TO_PLAIN"] = 1] = "CLASS_TO_PLAIN";
    TransformationType2[TransformationType2["CLASS_TO_CLASS"] = 2] = "CLASS_TO_CLASS";
  })(TransformationType || (TransformationType = {}));
  var MetadataStorage = (
    /** @class */
    function() {
      function MetadataStorage2() {
        this._typeMetadatas = /* @__PURE__ */ new Map();
        this._transformMetadatas = /* @__PURE__ */ new Map();
        this._exposeMetadatas = /* @__PURE__ */ new Map();
        this._excludeMetadatas = /* @__PURE__ */ new Map();
        this._ancestorsMap = /* @__PURE__ */ new Map();
      }
      MetadataStorage2.prototype.addTypeMetadata = function(metadata) {
        if (!this._typeMetadatas.has(metadata.target)) {
          this._typeMetadatas.set(metadata.target, /* @__PURE__ */ new Map());
        }
        this._typeMetadatas.get(metadata.target).set(metadata.propertyName, metadata);
      };
      MetadataStorage2.prototype.addTransformMetadata = function(metadata) {
        if (!this._transformMetadatas.has(metadata.target)) {
          this._transformMetadatas.set(metadata.target, /* @__PURE__ */ new Map());
        }
        if (!this._transformMetadatas.get(metadata.target).has(metadata.propertyName)) {
          this._transformMetadatas.get(metadata.target).set(metadata.propertyName, []);
        }
        this._transformMetadatas.get(metadata.target).get(metadata.propertyName).push(metadata);
      };
      MetadataStorage2.prototype.addExposeMetadata = function(metadata) {
        if (!this._exposeMetadatas.has(metadata.target)) {
          this._exposeMetadatas.set(metadata.target, /* @__PURE__ */ new Map());
        }
        this._exposeMetadatas.get(metadata.target).set(metadata.propertyName, metadata);
      };
      MetadataStorage2.prototype.addExcludeMetadata = function(metadata) {
        if (!this._excludeMetadatas.has(metadata.target)) {
          this._excludeMetadatas.set(metadata.target, /* @__PURE__ */ new Map());
        }
        this._excludeMetadatas.get(metadata.target).set(metadata.propertyName, metadata);
      };
      MetadataStorage2.prototype.findTransformMetadatas = function(target, propertyName, transformationType) {
        return this.findMetadatas(this._transformMetadatas, target, propertyName).filter(function(metadata) {
          if (!metadata.options)
            return true;
          if (metadata.options.toClassOnly === true && metadata.options.toPlainOnly === true)
            return true;
          if (metadata.options.toClassOnly === true) {
            return transformationType === TransformationType.CLASS_TO_CLASS || transformationType === TransformationType.PLAIN_TO_CLASS;
          }
          if (metadata.options.toPlainOnly === true) {
            return transformationType === TransformationType.CLASS_TO_PLAIN;
          }
          return true;
        });
      };
      MetadataStorage2.prototype.findExcludeMetadata = function(target, propertyName) {
        return this.findMetadata(this._excludeMetadatas, target, propertyName);
      };
      MetadataStorage2.prototype.findExposeMetadata = function(target, propertyName) {
        return this.findMetadata(this._exposeMetadatas, target, propertyName);
      };
      MetadataStorage2.prototype.findExposeMetadataByCustomName = function(target, name) {
        return this.getExposedMetadatas(target).find(function(metadata) {
          return metadata.options && metadata.options.name === name;
        });
      };
      MetadataStorage2.prototype.findTypeMetadata = function(target, propertyName) {
        return this.findMetadata(this._typeMetadatas, target, propertyName);
      };
      MetadataStorage2.prototype.getStrategy = function(target) {
        var excludeMap = this._excludeMetadatas.get(target);
        var exclude = excludeMap && excludeMap.get(void 0);
        var exposeMap = this._exposeMetadatas.get(target);
        var expose2 = exposeMap && exposeMap.get(void 0);
        if (exclude && expose2 || !exclude && !expose2)
          return "none";
        return exclude ? "excludeAll" : "exposeAll";
      };
      MetadataStorage2.prototype.getExposedMetadatas = function(target) {
        return this.getMetadata(this._exposeMetadatas, target);
      };
      MetadataStorage2.prototype.getExcludedMetadatas = function(target) {
        return this.getMetadata(this._excludeMetadatas, target);
      };
      MetadataStorage2.prototype.getExposedProperties = function(target, transformationType) {
        return this.getExposedMetadatas(target).filter(function(metadata) {
          if (!metadata.options)
            return true;
          if (metadata.options.toClassOnly === true && metadata.options.toPlainOnly === true)
            return true;
          if (metadata.options.toClassOnly === true) {
            return transformationType === TransformationType.CLASS_TO_CLASS || transformationType === TransformationType.PLAIN_TO_CLASS;
          }
          if (metadata.options.toPlainOnly === true) {
            return transformationType === TransformationType.CLASS_TO_PLAIN;
          }
          return true;
        }).map(function(metadata) {
          return metadata.propertyName;
        });
      };
      MetadataStorage2.prototype.getExcludedProperties = function(target, transformationType) {
        return this.getExcludedMetadatas(target).filter(function(metadata) {
          if (!metadata.options)
            return true;
          if (metadata.options.toClassOnly === true && metadata.options.toPlainOnly === true)
            return true;
          if (metadata.options.toClassOnly === true) {
            return transformationType === TransformationType.CLASS_TO_CLASS || transformationType === TransformationType.PLAIN_TO_CLASS;
          }
          if (metadata.options.toPlainOnly === true) {
            return transformationType === TransformationType.CLASS_TO_PLAIN;
          }
          return true;
        }).map(function(metadata) {
          return metadata.propertyName;
        });
      };
      MetadataStorage2.prototype.clear = function() {
        this._typeMetadatas.clear();
        this._exposeMetadatas.clear();
        this._excludeMetadatas.clear();
        this._ancestorsMap.clear();
      };
      MetadataStorage2.prototype.getMetadata = function(metadatas, target) {
        var metadataFromTargetMap = metadatas.get(target);
        var metadataFromTarget;
        if (metadataFromTargetMap) {
          metadataFromTarget = Array.from(metadataFromTargetMap.values()).filter(function(meta) {
            return meta.propertyName !== void 0;
          });
        }
        var metadataFromAncestors = [];
        for (var _i = 0, _a2 = this.getAncestors(target); _i < _a2.length; _i++) {
          var ancestor = _a2[_i];
          var ancestorMetadataMap = metadatas.get(ancestor);
          if (ancestorMetadataMap) {
            var metadataFromAncestor = Array.from(ancestorMetadataMap.values()).filter(function(meta) {
              return meta.propertyName !== void 0;
            });
            metadataFromAncestors.push.apply(metadataFromAncestors, metadataFromAncestor);
          }
        }
        return metadataFromAncestors.concat(metadataFromTarget || []);
      };
      MetadataStorage2.prototype.findMetadata = function(metadatas, target, propertyName) {
        var metadataFromTargetMap = metadatas.get(target);
        if (metadataFromTargetMap) {
          var metadataFromTarget = metadataFromTargetMap.get(propertyName);
          if (metadataFromTarget) {
            return metadataFromTarget;
          }
        }
        for (var _i = 0, _a2 = this.getAncestors(target); _i < _a2.length; _i++) {
          var ancestor = _a2[_i];
          var ancestorMetadataMap = metadatas.get(ancestor);
          if (ancestorMetadataMap) {
            var ancestorResult = ancestorMetadataMap.get(propertyName);
            if (ancestorResult) {
              return ancestorResult;
            }
          }
        }
        return void 0;
      };
      MetadataStorage2.prototype.findMetadatas = function(metadatas, target, propertyName) {
        var metadataFromTargetMap = metadatas.get(target);
        var metadataFromTarget;
        if (metadataFromTargetMap) {
          metadataFromTarget = metadataFromTargetMap.get(propertyName);
        }
        var metadataFromAncestorsTarget = [];
        for (var _i = 0, _a2 = this.getAncestors(target); _i < _a2.length; _i++) {
          var ancestor = _a2[_i];
          var ancestorMetadataMap = metadatas.get(ancestor);
          if (ancestorMetadataMap) {
            if (ancestorMetadataMap.has(propertyName)) {
              metadataFromAncestorsTarget.push.apply(metadataFromAncestorsTarget, ancestorMetadataMap.get(propertyName));
            }
          }
        }
        return metadataFromAncestorsTarget.slice().reverse().concat((metadataFromTarget || []).slice().reverse());
      };
      MetadataStorage2.prototype.getAncestors = function(target) {
        if (!target)
          return [];
        if (!this._ancestorsMap.has(target)) {
          var ancestors = [];
          for (var baseClass = Object.getPrototypeOf(target.prototype.constructor); typeof baseClass.prototype !== "undefined"; baseClass = Object.getPrototypeOf(baseClass.prototype.constructor)) {
            ancestors.push(baseClass);
          }
          this._ancestorsMap.set(target, ancestors);
        }
        return this._ancestorsMap.get(target);
      };
      return MetadataStorage2;
    }()
  );
  var defaultMetadataStorage = new MetadataStorage();
  function getGlobal() {
    if (typeof globalThis !== "undefined") {
      return globalThis;
    }
    if (typeof global !== "undefined") {
      return global;
    }
    if (typeof window !== "undefined") {
      return window;
    }
    if (typeof self !== "undefined") {
      return self;
    }
  }
  function isPromise(p2) {
    return p2 !== null && typeof p2 === "object" && typeof p2.then === "function";
  }
  var __spreadArray = function(to, from, pack) {
    if (pack || arguments.length === 2) for (var i2 = 0, l = from.length, ar; i2 < l; i2++) {
      if (ar || !(i2 in from)) {
        if (!ar) ar = Array.prototype.slice.call(from, 0, i2);
        ar[i2] = from[i2];
      }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
  function instantiateArrayType(arrayType) {
    var array = new arrayType();
    if (!(array instanceof Set) && !("push" in array)) {
      return [];
    }
    return array;
  }
  var TransformOperationExecutor = (
    /** @class */
    function() {
      function TransformOperationExecutor2(transformationType, options) {
        this.transformationType = transformationType;
        this.options = options;
        this.recursionStack = /* @__PURE__ */ new Set();
      }
      TransformOperationExecutor2.prototype.transform = function(source, value, targetType, arrayType, isMap, level) {
        var _this = this;
        if (level === void 0) {
          level = 0;
        }
        if (Array.isArray(value) || value instanceof Set) {
          var newValue_1 = arrayType && this.transformationType === TransformationType.PLAIN_TO_CLASS ? instantiateArrayType(arrayType) : [];
          value.forEach(function(subValue, index) {
            var subSource = source ? source[index] : void 0;
            if (!_this.options.enableCircularCheck || !_this.isCircular(subValue)) {
              var realTargetType = void 0;
              if (typeof targetType !== "function" && targetType && targetType.options && targetType.options.discriminator && targetType.options.discriminator.property && targetType.options.discriminator.subTypes) {
                if (_this.transformationType === TransformationType.PLAIN_TO_CLASS) {
                  realTargetType = targetType.options.discriminator.subTypes.find(function(subType) {
                    return subType.name === subValue[targetType.options.discriminator.property];
                  });
                  var options = { newObject: newValue_1, object: subValue, property: void 0 };
                  var newType = targetType.typeFunction(options);
                  realTargetType === void 0 ? realTargetType = newType : realTargetType = realTargetType.value;
                  if (!targetType.options.keepDiscriminatorProperty)
                    delete subValue[targetType.options.discriminator.property];
                }
                if (_this.transformationType === TransformationType.CLASS_TO_CLASS) {
                  realTargetType = subValue.constructor;
                }
                if (_this.transformationType === TransformationType.CLASS_TO_PLAIN) {
                  subValue[targetType.options.discriminator.property] = targetType.options.discriminator.subTypes.find(function(subType) {
                    return subType.value === subValue.constructor;
                  }).name;
                }
              } else {
                realTargetType = targetType;
              }
              var value_1 = _this.transform(subSource, subValue, realTargetType, void 0, subValue instanceof Map, level + 1);
              if (newValue_1 instanceof Set) {
                newValue_1.add(value_1);
              } else {
                newValue_1.push(value_1);
              }
            } else if (_this.transformationType === TransformationType.CLASS_TO_CLASS) {
              if (newValue_1 instanceof Set) {
                newValue_1.add(subValue);
              } else {
                newValue_1.push(subValue);
              }
            }
          });
          return newValue_1;
        } else if (targetType === String && !isMap) {
          if (value === null || value === void 0)
            return value;
          return String(value);
        } else if (targetType === Number && !isMap) {
          if (value === null || value === void 0)
            return value;
          return Number(value);
        } else if (targetType === Boolean && !isMap) {
          if (value === null || value === void 0)
            return value;
          return Boolean(value);
        } else if ((targetType === Date || value instanceof Date) && !isMap) {
          if (value instanceof Date) {
            return new Date(value.valueOf());
          }
          if (value === null || value === void 0)
            return value;
          return new Date(value);
        } else if (!!getGlobal().Buffer && (targetType === Buffer || value instanceof Buffer) && !isMap) {
          if (value === null || value === void 0)
            return value;
          return Buffer.from(value);
        } else if (isPromise(value) && !isMap) {
          return new Promise(function(resolve, reject) {
            value.then(function(data) {
              return resolve(_this.transform(void 0, data, targetType, void 0, void 0, level + 1));
            }, reject);
          });
        } else if (!isMap && value !== null && typeof value === "object" && typeof value.then === "function") {
          return value;
        } else if (typeof value === "object" && value !== null) {
          if (!targetType && value.constructor !== Object)
            if (!Array.isArray(value) && value.constructor === Array) ;
            else {
              targetType = value.constructor;
            }
          if (!targetType && source)
            targetType = source.constructor;
          if (this.options.enableCircularCheck) {
            this.recursionStack.add(value);
          }
          var keys = this.getKeys(targetType, value, isMap);
          var newValue = source ? source : {};
          if (!source && (this.transformationType === TransformationType.PLAIN_TO_CLASS || this.transformationType === TransformationType.CLASS_TO_CLASS)) {
            if (isMap) {
              newValue = /* @__PURE__ */ new Map();
            } else if (targetType) {
              newValue = new targetType();
            } else {
              newValue = {};
            }
          }
          var _loop_1 = function(key2) {
            if (key2 === "__proto__" || key2 === "constructor") {
              return "continue";
            }
            var valueKey = key2;
            var newValueKey = key2, propertyName = key2;
            if (!this_1.options.ignoreDecorators && targetType) {
              if (this_1.transformationType === TransformationType.PLAIN_TO_CLASS) {
                var exposeMetadata = defaultMetadataStorage.findExposeMetadataByCustomName(targetType, key2);
                if (exposeMetadata) {
                  propertyName = exposeMetadata.propertyName;
                  newValueKey = exposeMetadata.propertyName;
                }
              } else if (this_1.transformationType === TransformationType.CLASS_TO_PLAIN || this_1.transformationType === TransformationType.CLASS_TO_CLASS) {
                var exposeMetadata = defaultMetadataStorage.findExposeMetadata(targetType, key2);
                if (exposeMetadata && exposeMetadata.options && exposeMetadata.options.name) {
                  newValueKey = exposeMetadata.options.name;
                }
              }
            }
            var subValue = void 0;
            if (this_1.transformationType === TransformationType.PLAIN_TO_CLASS) {
              subValue = value[valueKey];
            } else {
              if (value instanceof Map) {
                subValue = value.get(valueKey);
              } else if (value[valueKey] instanceof Function) {
                subValue = value[valueKey]();
              } else {
                subValue = value[valueKey];
              }
            }
            var type = void 0, isSubValueMap = subValue instanceof Map;
            if (targetType && isMap) {
              type = targetType;
            } else if (targetType) {
              var metadata_1 = defaultMetadataStorage.findTypeMetadata(targetType, propertyName);
              if (metadata_1) {
                var options = { newObject: newValue, object: value, property: propertyName };
                var newType = metadata_1.typeFunction ? metadata_1.typeFunction(options) : metadata_1.reflectedType;
                if (metadata_1.options && metadata_1.options.discriminator && metadata_1.options.discriminator.property && metadata_1.options.discriminator.subTypes) {
                  if (!(value[valueKey] instanceof Array)) {
                    if (this_1.transformationType === TransformationType.PLAIN_TO_CLASS) {
                      type = metadata_1.options.discriminator.subTypes.find(function(subType) {
                        if (subValue && subValue instanceof Object && metadata_1.options.discriminator.property in subValue) {
                          return subType.name === subValue[metadata_1.options.discriminator.property];
                        }
                      });
                      type === void 0 ? type = newType : type = type.value;
                      if (!metadata_1.options.keepDiscriminatorProperty) {
                        if (subValue && subValue instanceof Object && metadata_1.options.discriminator.property in subValue) {
                          delete subValue[metadata_1.options.discriminator.property];
                        }
                      }
                    }
                    if (this_1.transformationType === TransformationType.CLASS_TO_CLASS) {
                      type = subValue.constructor;
                    }
                    if (this_1.transformationType === TransformationType.CLASS_TO_PLAIN) {
                      if (subValue) {
                        subValue[metadata_1.options.discriminator.property] = metadata_1.options.discriminator.subTypes.find(function(subType) {
                          return subType.value === subValue.constructor;
                        }).name;
                      }
                    }
                  } else {
                    type = metadata_1;
                  }
                } else {
                  type = newType;
                }
                isSubValueMap = isSubValueMap || metadata_1.reflectedType === Map;
              } else if (this_1.options.targetMaps) {
                this_1.options.targetMaps.filter(function(map) {
                  return map.target === targetType && !!map.properties[propertyName];
                }).forEach(function(map) {
                  return type = map.properties[propertyName];
                });
              } else if (this_1.options.enableImplicitConversion && this_1.transformationType === TransformationType.PLAIN_TO_CLASS) {
                var reflectedType = Reflect.getMetadata("design:type", targetType.prototype, propertyName);
                if (reflectedType) {
                  type = reflectedType;
                }
              }
            }
            var arrayType_1 = Array.isArray(value[valueKey]) ? this_1.getReflectedType(targetType, propertyName) : void 0;
            var subSource = source ? source[valueKey] : void 0;
            if (newValue.constructor.prototype) {
              var descriptor = Object.getOwnPropertyDescriptor(newValue.constructor.prototype, newValueKey);
              if ((this_1.transformationType === TransformationType.PLAIN_TO_CLASS || this_1.transformationType === TransformationType.CLASS_TO_CLASS) && // eslint-disable-next-line @typescript-eslint/unbound-method
              (descriptor && !descriptor.set || newValue[newValueKey] instanceof Function))
                return "continue";
            }
            if (!this_1.options.enableCircularCheck || !this_1.isCircular(subValue)) {
              var transformKey = this_1.transformationType === TransformationType.PLAIN_TO_CLASS ? newValueKey : key2;
              var finalValue = void 0;
              if (this_1.transformationType === TransformationType.CLASS_TO_PLAIN) {
                finalValue = value[transformKey];
                finalValue = this_1.applyCustomTransformations(finalValue, targetType, transformKey, value, this_1.transformationType);
                finalValue = value[transformKey] === finalValue ? subValue : finalValue;
                finalValue = this_1.transform(subSource, finalValue, type, arrayType_1, isSubValueMap, level + 1);
              } else {
                if (subValue === void 0 && this_1.options.exposeDefaultValues) {
                  finalValue = newValue[newValueKey];
                } else {
                  finalValue = this_1.transform(subSource, subValue, type, arrayType_1, isSubValueMap, level + 1);
                  finalValue = this_1.applyCustomTransformations(finalValue, targetType, transformKey, value, this_1.transformationType);
                }
              }
              if (finalValue !== void 0 || this_1.options.exposeUnsetFields) {
                if (newValue instanceof Map) {
                  newValue.set(newValueKey, finalValue);
                } else {
                  newValue[newValueKey] = finalValue;
                }
              }
            } else if (this_1.transformationType === TransformationType.CLASS_TO_CLASS) {
              var finalValue = subValue;
              finalValue = this_1.applyCustomTransformations(finalValue, targetType, key2, value, this_1.transformationType);
              if (finalValue !== void 0 || this_1.options.exposeUnsetFields) {
                if (newValue instanceof Map) {
                  newValue.set(newValueKey, finalValue);
                } else {
                  newValue[newValueKey] = finalValue;
                }
              }
            }
          };
          var this_1 = this;
          for (var _i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
            var key = keys_1[_i];
            _loop_1(key);
          }
          if (this.options.enableCircularCheck) {
            this.recursionStack.delete(value);
          }
          return newValue;
        } else {
          return value;
        }
      };
      TransformOperationExecutor2.prototype.applyCustomTransformations = function(value, target, key, obj, transformationType) {
        var _this = this;
        var metadatas = defaultMetadataStorage.findTransformMetadatas(target, key, this.transformationType);
        if (this.options.version !== void 0) {
          metadatas = metadatas.filter(function(metadata) {
            if (!metadata.options)
              return true;
            return _this.checkVersion(metadata.options.since, metadata.options.until);
          });
        }
        if (this.options.groups && this.options.groups.length) {
          metadatas = metadatas.filter(function(metadata) {
            if (!metadata.options)
              return true;
            return _this.checkGroups(metadata.options.groups);
          });
        } else {
          metadatas = metadatas.filter(function(metadata) {
            return !metadata.options || !metadata.options.groups || !metadata.options.groups.length;
          });
        }
        metadatas.forEach(function(metadata) {
          value = metadata.transformFn({ value, key, obj, type: transformationType, options: _this.options });
        });
        return value;
      };
      TransformOperationExecutor2.prototype.isCircular = function(object) {
        return this.recursionStack.has(object);
      };
      TransformOperationExecutor2.prototype.getReflectedType = function(target, propertyName) {
        if (!target)
          return void 0;
        var meta = defaultMetadataStorage.findTypeMetadata(target, propertyName);
        return meta ? meta.reflectedType : void 0;
      };
      TransformOperationExecutor2.prototype.getKeys = function(target, object, isMap) {
        var _this = this;
        var strategy = defaultMetadataStorage.getStrategy(target);
        if (strategy === "none")
          strategy = this.options.strategy || "exposeAll";
        var keys = [];
        if (strategy === "exposeAll" || isMap) {
          if (object instanceof Map) {
            keys = Array.from(object.keys());
          } else {
            keys = Object.keys(object);
          }
        }
        if (isMap) {
          return keys;
        }
        if (this.options.ignoreDecorators && this.options.excludeExtraneousValues && target) {
          var exposedProperties = defaultMetadataStorage.getExposedProperties(target, this.transformationType);
          var excludedProperties = defaultMetadataStorage.getExcludedProperties(target, this.transformationType);
          keys = __spreadArray(__spreadArray([], exposedProperties, true), excludedProperties, true);
        }
        if (!this.options.ignoreDecorators && target) {
          var exposedProperties = defaultMetadataStorage.getExposedProperties(target, this.transformationType);
          if (this.transformationType === TransformationType.PLAIN_TO_CLASS) {
            exposedProperties = exposedProperties.map(function(key) {
              var exposeMetadata = defaultMetadataStorage.findExposeMetadata(target, key);
              if (exposeMetadata && exposeMetadata.options && exposeMetadata.options.name) {
                return exposeMetadata.options.name;
              }
              return key;
            });
          }
          if (this.options.excludeExtraneousValues) {
            keys = exposedProperties;
          } else {
            keys = keys.concat(exposedProperties);
          }
          var excludedProperties_1 = defaultMetadataStorage.getExcludedProperties(target, this.transformationType);
          if (excludedProperties_1.length > 0) {
            keys = keys.filter(function(key) {
              return !excludedProperties_1.includes(key);
            });
          }
          if (this.options.version !== void 0) {
            keys = keys.filter(function(key) {
              var exposeMetadata = defaultMetadataStorage.findExposeMetadata(target, key);
              if (!exposeMetadata || !exposeMetadata.options)
                return true;
              return _this.checkVersion(exposeMetadata.options.since, exposeMetadata.options.until);
            });
          }
          if (this.options.groups && this.options.groups.length) {
            keys = keys.filter(function(key) {
              var exposeMetadata = defaultMetadataStorage.findExposeMetadata(target, key);
              if (!exposeMetadata || !exposeMetadata.options)
                return true;
              return _this.checkGroups(exposeMetadata.options.groups);
            });
          } else {
            keys = keys.filter(function(key) {
              var exposeMetadata = defaultMetadataStorage.findExposeMetadata(target, key);
              return !exposeMetadata || !exposeMetadata.options || !exposeMetadata.options.groups || !exposeMetadata.options.groups.length;
            });
          }
        }
        if (this.options.excludePrefixes && this.options.excludePrefixes.length) {
          keys = keys.filter(function(key) {
            return _this.options.excludePrefixes.every(function(prefix) {
              return key.substr(0, prefix.length) !== prefix;
            });
          });
        }
        keys = keys.filter(function(key, index, self2) {
          return self2.indexOf(key) === index;
        });
        return keys;
      };
      TransformOperationExecutor2.prototype.checkVersion = function(since, until) {
        var decision = true;
        if (decision && since)
          decision = this.options.version >= since;
        if (decision && until)
          decision = this.options.version < until;
        return decision;
      };
      TransformOperationExecutor2.prototype.checkGroups = function(groups) {
        if (!groups)
          return true;
        return this.options.groups.some(function(optionGroup) {
          return groups.includes(optionGroup);
        });
      };
      return TransformOperationExecutor2;
    }()
  );
  var defaultOptions = {
    enableCircularCheck: false,
    enableImplicitConversion: false,
    excludeExtraneousValues: false,
    excludePrefixes: void 0,
    exposeDefaultValues: false,
    exposeUnsetFields: true,
    groups: void 0,
    ignoreDecorators: false,
    strategy: void 0,
    targetMaps: void 0,
    version: void 0
  };
  var __assign = function() {
    __assign = Object.assign || function(t2) {
      for (var s2, i2 = 1, n2 = arguments.length; i2 < n2; i2++) {
        s2 = arguments[i2];
        for (var p2 in s2) if (Object.prototype.hasOwnProperty.call(s2, p2))
          t2[p2] = s2[p2];
      }
      return t2;
    };
    return __assign.apply(this, arguments);
  };
  var ClassTransformer = (
    /** @class */
    function() {
      function ClassTransformer2() {
      }
      ClassTransformer2.prototype.instanceToPlain = function(object, options) {
        var executor = new TransformOperationExecutor(TransformationType.CLASS_TO_PLAIN, __assign(__assign({}, defaultOptions), options));
        return executor.transform(void 0, object, void 0, void 0, void 0, void 0);
      };
      ClassTransformer2.prototype.classToPlainFromExist = function(object, plainObject, options) {
        var executor = new TransformOperationExecutor(TransformationType.CLASS_TO_PLAIN, __assign(__assign({}, defaultOptions), options));
        return executor.transform(plainObject, object, void 0, void 0, void 0, void 0);
      };
      ClassTransformer2.prototype.plainToInstance = function(cls, plain, options) {
        var executor = new TransformOperationExecutor(TransformationType.PLAIN_TO_CLASS, __assign(__assign({}, defaultOptions), options));
        return executor.transform(void 0, plain, cls, void 0, void 0, void 0);
      };
      ClassTransformer2.prototype.plainToClassFromExist = function(clsObject, plain, options) {
        var executor = new TransformOperationExecutor(TransformationType.PLAIN_TO_CLASS, __assign(__assign({}, defaultOptions), options));
        return executor.transform(clsObject, plain, void 0, void 0, void 0, void 0);
      };
      ClassTransformer2.prototype.instanceToInstance = function(object, options) {
        var executor = new TransformOperationExecutor(TransformationType.CLASS_TO_CLASS, __assign(__assign({}, defaultOptions), options));
        return executor.transform(void 0, object, void 0, void 0, void 0, void 0);
      };
      ClassTransformer2.prototype.classToClassFromExist = function(object, fromObject, options) {
        var executor = new TransformOperationExecutor(TransformationType.CLASS_TO_CLASS, __assign(__assign({}, defaultOptions), options));
        return executor.transform(fromObject, object, void 0, void 0, void 0, void 0);
      };
      ClassTransformer2.prototype.serialize = function(object, options) {
        return JSON.stringify(this.instanceToPlain(object, options));
      };
      ClassTransformer2.prototype.deserialize = function(cls, json, options) {
        var jsonObject = JSON.parse(json);
        return this.plainToInstance(cls, jsonObject, options);
      };
      ClassTransformer2.prototype.deserializeArray = function(cls, json, options) {
        var jsonObject = JSON.parse(json);
        return this.plainToInstance(cls, jsonObject, options);
      };
      return ClassTransformer2;
    }()
  );
  function Transform(transformFn, options) {
    if (options === void 0) {
      options = {};
    }
    return function(target, propertyName) {
      defaultMetadataStorage.addTransformMetadata({
        target: target.constructor,
        propertyName,
        transformFn,
        options
      });
    };
  }
  function Type(typeFunction, options) {
    if (options === void 0) {
      options = {};
    }
    return function(target, propertyName) {
      var reflectedType = Reflect.getMetadata("design:type", target, propertyName);
      defaultMetadataStorage.addTypeMetadata({
        target: target.constructor,
        propertyName,
        reflectedType,
        typeFunction,
        options
      });
    };
  }
  var classTransformer = new ClassTransformer();
  function plainToInstance(cls, plain, options) {
    return classTransformer.plainToInstance(cls, plain, options);
  }
  var __extends$g = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var AddressType;
  (function(AddressType2) {
    AddressType2[AddressType2["Ed25519"] = 0] = "Ed25519";
    AddressType2[AddressType2["Alias"] = 8] = "Alias";
    AddressType2[AddressType2["Nft"] = 16] = "Nft";
  })(AddressType || (AddressType = {}));
  var Address = (
    /** @class */
    function() {
      function Address2(type) {
        this.type = type;
      }
      Address2.prototype.getType = function() {
        return this.type;
      };
      Address2.parse = function(data) {
        if (data.type == AddressType.Ed25519) {
          return plainToInstance(Ed25519Address, data);
        } else if (data.type == AddressType.Alias) {
          return plainToInstance(AliasAddress, data);
        } else if (data.type == AddressType.Nft) {
          return plainToInstance(NftAddress, data);
        }
        throw new Error("Invalid JSON");
      };
      return Address2;
    }()
  );
  var Ed25519Address = (
    /** @class */
    function(_super) {
      __extends$g(Ed25519Address2, _super);
      function Ed25519Address2(address) {
        var _this = _super.call(this, AddressType.Ed25519) || this;
        _this.pubKeyHash = address;
        return _this;
      }
      Ed25519Address2.prototype.getPubKeyHash = function() {
        return this.pubKeyHash;
      };
      Ed25519Address2.prototype.toString = function() {
        return this.getPubKeyHash();
      };
      return Ed25519Address2;
    }(Address)
  );
  var AliasAddress = (
    /** @class */
    function(_super) {
      __extends$g(AliasAddress2, _super);
      function AliasAddress2(address) {
        var _this = _super.call(this, AddressType.Alias) || this;
        _this.aliasId = address;
        return _this;
      }
      AliasAddress2.prototype.getAliasId = function() {
        return this.aliasId;
      };
      AliasAddress2.prototype.toString = function() {
        return this.getAliasId();
      };
      return AliasAddress2;
    }(Address)
  );
  var NftAddress = (
    /** @class */
    function(_super) {
      __extends$g(NftAddress2, _super);
      function NftAddress2(address) {
        var _this = _super.call(this, AddressType.Nft) || this;
        _this.nftId = address;
        return _this;
      }
      NftAddress2.prototype.getNftId = function() {
        return this.nftId;
      };
      NftAddress2.prototype.toString = function() {
        return this.getNftId();
      };
      return NftAddress2;
    }(Address)
  );
  var AddressDiscriminator = {
    property: "type",
    subTypes: [
      { value: Ed25519Address, name: AddressType.Ed25519 },
      { value: AliasAddress, name: AddressType.Alias },
      { value: NftAddress, name: AddressType.Nft }
    ]
  };
  var __extends$f = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __decorate$j = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var FeatureType;
  (function(FeatureType2) {
    FeatureType2[FeatureType2["Sender"] = 0] = "Sender";
    FeatureType2[FeatureType2["Issuer"] = 1] = "Issuer";
    FeatureType2[FeatureType2["Metadata"] = 2] = "Metadata";
    FeatureType2[FeatureType2["Tag"] = 3] = "Tag";
  })(FeatureType || (FeatureType = {}));
  var Feature = (
    /** @class */
    function() {
      function Feature2(type) {
        this.type = type;
      }
      Feature2.prototype.getType = function() {
        return this.type;
      };
      return Feature2;
    }()
  );
  var SenderFeature = (
    /** @class */
    function(_super) {
      __extends$f(SenderFeature2, _super);
      function SenderFeature2(sender) {
        var _this = _super.call(this, FeatureType.Sender) || this;
        _this.address = sender;
        return _this;
      }
      SenderFeature2.prototype.getSender = function() {
        return this.address;
      };
      __decorate$j([
        Type(function() {
          return Address;
        }, {
          discriminator: AddressDiscriminator
        })
      ], SenderFeature2.prototype, "address");
      return SenderFeature2;
    }(Feature)
  );
  var IssuerFeature = (
    /** @class */
    function(_super) {
      __extends$f(IssuerFeature2, _super);
      function IssuerFeature2(issuer) {
        var _this = _super.call(this, FeatureType.Issuer) || this;
        _this.address = issuer;
        return _this;
      }
      IssuerFeature2.prototype.getIssuer = function() {
        return this.address;
      };
      __decorate$j([
        Type(function() {
          return Address;
        }, {
          discriminator: AddressDiscriminator
        })
      ], IssuerFeature2.prototype, "address");
      return IssuerFeature2;
    }(Feature)
  );
  var MetadataFeature = (
    /** @class */
    function(_super) {
      __extends$f(MetadataFeature2, _super);
      function MetadataFeature2(data) {
        var _this = _super.call(this, FeatureType.Metadata) || this;
        _this.data = data;
        return _this;
      }
      MetadataFeature2.prototype.getData = function() {
        return this.data;
      };
      return MetadataFeature2;
    }(Feature)
  );
  var TagFeature = (
    /** @class */
    function(_super) {
      __extends$f(TagFeature2, _super);
      function TagFeature2(tag) {
        var _this = _super.call(this, FeatureType.Tag) || this;
        _this.tag = tag;
        return _this;
      }
      TagFeature2.prototype.getTag = function() {
        return this.tag;
      };
      return TagFeature2;
    }(Feature)
  );
  var FeatureDiscriminator = {
    property: "type",
    subTypes: [
      { value: SenderFeature, name: FeatureType.Sender },
      { value: IssuerFeature, name: FeatureType.Issuer },
      { value: MetadataFeature, name: FeatureType.Metadata },
      { value: TagFeature, name: FeatureType.Tag }
    ]
  };
  var __extends$e = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __decorate$i = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var UnlockConditionType;
  (function(UnlockConditionType2) {
    UnlockConditionType2[UnlockConditionType2["Address"] = 0] = "Address";
    UnlockConditionType2[UnlockConditionType2["StorageDepositReturn"] = 1] = "StorageDepositReturn";
    UnlockConditionType2[UnlockConditionType2["Timelock"] = 2] = "Timelock";
    UnlockConditionType2[UnlockConditionType2["Expiration"] = 3] = "Expiration";
    UnlockConditionType2[UnlockConditionType2["StateControllerAddress"] = 4] = "StateControllerAddress";
    UnlockConditionType2[UnlockConditionType2["GovernorAddress"] = 5] = "GovernorAddress";
    UnlockConditionType2[UnlockConditionType2["ImmutableAliasAddress"] = 6] = "ImmutableAliasAddress";
  })(UnlockConditionType || (UnlockConditionType = {}));
  var UnlockCondition = (
    /** @class */
    function() {
      function UnlockCondition2(type) {
        this.type = type;
      }
      UnlockCondition2.prototype.getType = function() {
        return this.type;
      };
      UnlockCondition2.parse = function(data) {
        if (data.type == UnlockConditionType.Address) {
          return plainToInstance(AddressUnlockCondition, data);
        } else if (data.type == UnlockConditionType.StorageDepositReturn) {
          return plainToInstance(StorageDepositReturnUnlockCondition, data);
        } else if (data.type == UnlockConditionType.Timelock) {
          return plainToInstance(TimelockUnlockCondition, data);
        } else if (data.type == UnlockConditionType.Expiration) {
          return plainToInstance(ExpirationUnlockCondition, data);
        } else if (data.type == UnlockConditionType.StateControllerAddress) {
          return plainToInstance(StateControllerAddressUnlockCondition, data);
        } else if (data.type == UnlockConditionType.GovernorAddress) {
          return plainToInstance(GovernorAddressUnlockCondition, data);
        } else if (data.type == UnlockConditionType.ImmutableAliasAddress) {
          return plainToInstance(ImmutableAliasAddressUnlockCondition, data);
        }
        throw new Error("Invalid JSON");
      };
      return UnlockCondition2;
    }()
  );
  var AddressUnlockCondition = (
    /** @class */
    function(_super) {
      __extends$e(AddressUnlockCondition2, _super);
      function AddressUnlockCondition2(address) {
        var _this = _super.call(this, UnlockConditionType.Address) || this;
        _this.address = address;
        return _this;
      }
      AddressUnlockCondition2.prototype.getAddress = function() {
        return this.address;
      };
      __decorate$i([
        Type(function() {
          return Address;
        }, {
          discriminator: AddressDiscriminator
        })
      ], AddressUnlockCondition2.prototype, "address");
      return AddressUnlockCondition2;
    }(
      UnlockCondition
      /*implements IAddressUnlockCondition*/
    )
  );
  var StorageDepositReturnUnlockCondition = (
    /** @class */
    function(_super) {
      __extends$e(StorageDepositReturnUnlockCondition2, _super);
      function StorageDepositReturnUnlockCondition2(returnAddress, amount) {
        var _this = _super.call(this, UnlockConditionType.StorageDepositReturn) || this;
        if (typeof amount == "bigint") {
          _this.amount = amount.toString(10);
        } else {
          _this.amount = amount;
        }
        _this.returnAddress = returnAddress;
        return _this;
      }
      StorageDepositReturnUnlockCondition2.prototype.getAmount = function() {
        return BigInt(this.amount);
      };
      StorageDepositReturnUnlockCondition2.prototype.getReturnAddress = function() {
        return this.returnAddress;
      };
      __decorate$i([
        Type(function() {
          return Address;
        }, {
          discriminator: AddressDiscriminator
        })
      ], StorageDepositReturnUnlockCondition2.prototype, "returnAddress");
      return StorageDepositReturnUnlockCondition2;
    }(
      UnlockCondition
      /*implements IStorageDepositReturnUnlockCondition*/
    )
  );
  var TimelockUnlockCondition = (
    /** @class */
    function(_super) {
      __extends$e(TimelockUnlockCondition2, _super);
      function TimelockUnlockCondition2(unixTime) {
        var _this = _super.call(this, UnlockConditionType.Timelock) || this;
        _this.unixTime = unixTime;
        return _this;
      }
      TimelockUnlockCondition2.prototype.getUnixTime = function() {
        return this.unixTime;
      };
      return TimelockUnlockCondition2;
    }(
      UnlockCondition
      /*implements ITimelockUnlockCondition*/
    )
  );
  var ExpirationUnlockCondition = (
    /** @class */
    function(_super) {
      __extends$e(ExpirationUnlockCondition2, _super);
      function ExpirationUnlockCondition2(returnAddress, unixTime) {
        var _this = _super.call(this, UnlockConditionType.Expiration) || this;
        _this.returnAddress = returnAddress;
        _this.unixTime = unixTime;
        return _this;
      }
      ExpirationUnlockCondition2.prototype.getUnixTime = function() {
        return this.unixTime;
      };
      ExpirationUnlockCondition2.prototype.getReturnAddress = function() {
        return this.returnAddress;
      };
      __decorate$i([
        Type(function() {
          return Address;
        }, {
          discriminator: AddressDiscriminator
        })
      ], ExpirationUnlockCondition2.prototype, "returnAddress");
      return ExpirationUnlockCondition2;
    }(
      UnlockCondition
      /*implements IExpirationUnlockCondition*/
    )
  );
  var StateControllerAddressUnlockCondition = (
    /** @class */
    function(_super) {
      __extends$e(StateControllerAddressUnlockCondition2, _super);
      function StateControllerAddressUnlockCondition2(address) {
        var _this = _super.call(this, UnlockConditionType.StateControllerAddress) || this;
        _this.address = address;
        return _this;
      }
      StateControllerAddressUnlockCondition2.prototype.getAddress = function() {
        return this.address;
      };
      __decorate$i([
        Type(function() {
          return Address;
        }, {
          discriminator: AddressDiscriminator
        })
      ], StateControllerAddressUnlockCondition2.prototype, "address");
      return StateControllerAddressUnlockCondition2;
    }(
      UnlockCondition
      /*implements IStateControllerAddressUnlockCondition*/
    )
  );
  var GovernorAddressUnlockCondition = (
    /** @class */
    function(_super) {
      __extends$e(GovernorAddressUnlockCondition2, _super);
      function GovernorAddressUnlockCondition2(address) {
        var _this = _super.call(this, UnlockConditionType.GovernorAddress) || this;
        _this.address = address;
        return _this;
      }
      GovernorAddressUnlockCondition2.prototype.getAddress = function() {
        return this.address;
      };
      __decorate$i([
        Type(function() {
          return Address;
        }, {
          discriminator: AddressDiscriminator
        })
      ], GovernorAddressUnlockCondition2.prototype, "address");
      return GovernorAddressUnlockCondition2;
    }(
      UnlockCondition
      /*implements IGovernorAddressUnlockCondition*/
    )
  );
  var ImmutableAliasAddressUnlockCondition = (
    /** @class */
    function(_super) {
      __extends$e(ImmutableAliasAddressUnlockCondition2, _super);
      function ImmutableAliasAddressUnlockCondition2(address) {
        var _this = _super.call(this, UnlockConditionType.ImmutableAliasAddress) || this;
        _this.address = address;
        return _this;
      }
      ImmutableAliasAddressUnlockCondition2.prototype.getAddress = function() {
        return this.address;
      };
      __decorate$i([
        Type(function() {
          return Address;
        }, {
          discriminator: AddressDiscriminator
        })
      ], ImmutableAliasAddressUnlockCondition2.prototype, "address");
      return ImmutableAliasAddressUnlockCondition2;
    }(
      UnlockCondition
      /*implements IImmutableAliasAddressUnlockCondition*/
    )
  );
  var UnlockConditionDiscriminator = {
    property: "type",
    subTypes: [
      {
        value: AddressUnlockCondition,
        name: UnlockConditionType.Address
      },
      {
        value: StorageDepositReturnUnlockCondition,
        name: UnlockConditionType.StorageDepositReturn
      },
      {
        value: TimelockUnlockCondition,
        name: UnlockConditionType.Timelock
      },
      {
        value: ExpirationUnlockCondition,
        name: UnlockConditionType.Expiration
      },
      {
        value: StateControllerAddressUnlockCondition,
        name: UnlockConditionType.StateControllerAddress
      },
      {
        value: GovernorAddressUnlockCondition,
        name: UnlockConditionType.GovernorAddress
      },
      {
        value: ImmutableAliasAddressUnlockCondition,
        name: UnlockConditionType.ImmutableAliasAddress
      }
    ]
  };
  function bigIntToHex(value) {
    return "0x" + value.toString(16);
  }
  function hexToBigInt(value) {
    if (!value.startsWith("0x")) {
      value = "0x" + value;
    }
    return BigInt(value);
  }
  var __extends$d = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __decorate$h = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var TokenSchemeType;
  (function(TokenSchemeType2) {
    TokenSchemeType2[TokenSchemeType2["Simple"] = 0] = "Simple";
  })(TokenSchemeType || (TokenSchemeType = {}));
  var TokenScheme = (
    /** @class */
    function() {
      function TokenScheme2(type) {
        this.type = type;
      }
      TokenScheme2.prototype.getType = function() {
        return this.type;
      };
      return TokenScheme2;
    }()
  );
  var SimpleTokenScheme = (
    /** @class */
    function(_super) {
      __extends$d(SimpleTokenScheme2, _super);
      function SimpleTokenScheme2(mintedTokens, meltedTokens, maximumSupply) {
        var _this = _super.call(this, TokenSchemeType.Simple) || this;
        if (typeof mintedTokens === "bigint") {
          _this.mintedTokens = mintedTokens;
        } else if (mintedTokens) {
          _this.mintedTokens = hexToBigInt(mintedTokens);
        } else {
          _this.mintedTokens = BigInt(0);
        }
        if (typeof meltedTokens === "bigint") {
          _this.meltedTokens = meltedTokens;
        } else if (meltedTokens) {
          _this.meltedTokens = hexToBigInt(meltedTokens);
        } else {
          _this.meltedTokens = BigInt(0);
        }
        if (typeof maximumSupply === "bigint") {
          _this.maximumSupply = maximumSupply;
        } else if (maximumSupply) {
          _this.maximumSupply = hexToBigInt(maximumSupply);
        } else {
          _this.maximumSupply = BigInt(0);
        }
        return _this;
      }
      SimpleTokenScheme2.prototype.getMintedTokens = function() {
        return this.mintedTokens;
      };
      SimpleTokenScheme2.prototype.getMeltedTokens = function() {
        return this.meltedTokens;
      };
      SimpleTokenScheme2.prototype.getMaximumSupply = function() {
        return this.maximumSupply;
      };
      __decorate$h([
        Transform(function(value) {
          return hexToBigInt(value.value);
        })
      ], SimpleTokenScheme2.prototype, "mintedTokens");
      __decorate$h([
        Transform(function(value) {
          return hexToBigInt(value.value);
        })
      ], SimpleTokenScheme2.prototype, "meltedTokens");
      __decorate$h([
        Transform(function(value) {
          return hexToBigInt(value.value);
        })
      ], SimpleTokenScheme2.prototype, "maximumSupply");
      return SimpleTokenScheme2;
    }(TokenScheme)
  );
  var TokenSchemeDiscriminator = {
    property: "type",
    subTypes: [
      { value: SimpleTokenScheme, name: TokenSchemeType.Simple }
    ]
  };
  var __decorate$g = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var OutputResponse = (
    /** @class */
    function() {
      function OutputResponse2() {
      }
      __decorate$g([
        Type(function() {
          return Output;
        }, {
          discriminator: OutputDiscriminator
        })
      ], OutputResponse2.prototype, "output");
      return OutputResponse2;
    }()
  );
  var MilestoneOptionType;
  (function(MilestoneOptionType2) {
    MilestoneOptionType2[MilestoneOptionType2["Receipt"] = 0] = "Receipt";
    MilestoneOptionType2[MilestoneOptionType2["ProtocolParams"] = 1] = "ProtocolParams";
  })(MilestoneOptionType || (MilestoneOptionType = {}));
  var MilestoneOption = (
    /** @class */
    function() {
      function MilestoneOption2(type) {
        this.type = type;
      }
      MilestoneOption2.prototype.getType = function() {
        return this.type;
      };
      return MilestoneOption2;
    }()
  );
  var __extends$c = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var ProtocolParamsMilestoneOption = (
    /** @class */
    function(_super) {
      __extends$c(ProtocolParamsMilestoneOption2, _super);
      function ProtocolParamsMilestoneOption2(targetMilestoneIndex, protocolVersion, params) {
        var _this = _super.call(this, MilestoneOptionType.Receipt) || this;
        _this.targetMilestoneIndex = targetMilestoneIndex;
        _this.protocolVersion = protocolVersion;
        _this.params = params;
        return _this;
      }
      return ProtocolParamsMilestoneOption2;
    }(MilestoneOption)
  );
  var PayloadType;
  (function(PayloadType2) {
    PayloadType2[PayloadType2["Milestone"] = 7] = "Milestone";
    PayloadType2[PayloadType2["TaggedData"] = 5] = "TaggedData";
    PayloadType2[PayloadType2["Transaction"] = 6] = "Transaction";
    PayloadType2[PayloadType2["TreasuryTransaction"] = 4] = "TreasuryTransaction";
  })(PayloadType || (PayloadType = {}));
  var Payload = (
    /** @class */
    function() {
      function Payload2(type) {
        this.type = type;
      }
      Payload2.prototype.getType = function() {
        return this.type;
      };
      return Payload2;
    }()
  );
  var __extends$b = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __decorate$f = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var TreasuryTransactionPayload = (
    /** @class */
    function(_super) {
      __extends$b(TreasuryTransactionPayload2, _super);
      function TreasuryTransactionPayload2(input, output2) {
        var _this = _super.call(this, PayloadType.Transaction) || this;
        _this.input = input;
        _this.output = output2;
        return _this;
      }
      __decorate$f([
        Type(function() {
          return TreasuryInput;
        })
      ], TreasuryTransactionPayload2.prototype, "input");
      __decorate$f([
        Type(function() {
          return TreasuryOutput;
        })
      ], TreasuryTransactionPayload2.prototype, "output");
      return TreasuryTransactionPayload2;
    }(Payload)
  );
  var __decorate$e = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var MigratedFunds = (
    /** @class */
    function() {
      function MigratedFunds2() {
      }
      __decorate$e([
        Type(function() {
          return Address;
        }, {
          discriminator: AddressDiscriminator
        })
      ], MigratedFunds2.prototype, "address");
      return MigratedFunds2;
    }()
  );
  var __extends$a = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __decorate$d = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var ReceiptMilestoneOption = (
    /** @class */
    function(_super) {
      __extends$a(ReceiptMilestoneOption2, _super);
      function ReceiptMilestoneOption2(migratedAt, final, funds, transaction) {
        var _this = _super.call(this, MilestoneOptionType.Receipt) || this;
        _this.migratedAt = migratedAt;
        _this.final = final;
        _this.funds = funds;
        _this.transaction = transaction;
        return _this;
      }
      __decorate$d([
        Type(function() {
          return MigratedFunds;
        })
      ], ReceiptMilestoneOption2.prototype, "funds");
      __decorate$d([
        Type(function() {
          return TreasuryTransactionPayload;
        })
      ], ReceiptMilestoneOption2.prototype, "transaction");
      return ReceiptMilestoneOption2;
    }(MilestoneOption)
  );
  var MilestoneOptionDiscriminator = {
    property: "type",
    subTypes: [
      {
        value: ReceiptMilestoneOption,
        name: MilestoneOptionType.Receipt
      },
      {
        value: ProtocolParamsMilestoneOption,
        name: MilestoneOptionType.ProtocolParams
      }
    ]
  };
  var __decorate$c = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  (function() {
    function ReceiptsResponse() {
    }
    __decorate$c([
      Type(function() {
        return MilestoneReceipt;
      })
    ], ReceiptsResponse.prototype, "receipts");
    return ReceiptsResponse;
  })();
  var MilestoneReceipt = (
    /** @class */
    function() {
      function MilestoneReceipt2() {
      }
      __decorate$c([
        Type(function() {
          return ReceiptMilestoneOption;
        })
      ], MilestoneReceipt2.prototype, "receipt");
      return MilestoneReceipt2;
    }()
  );
  var __extends$9 = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  (function(_super) {
    __extends$9(NodeInfoProtocolParamsMilestoneOpt, _super);
    function NodeInfoProtocolParamsMilestoneOpt() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    return NodeInfoProtocolParamsMilestoneOpt;
  })(ProtocolParamsMilestoneOption);
  var _a;
  var ConflictReason;
  (function(ConflictReason2) {
    ConflictReason2[ConflictReason2["none"] = 0] = "none";
    ConflictReason2[ConflictReason2["inputUTXOAlreadySpent"] = 1] = "inputUTXOAlreadySpent";
    ConflictReason2[ConflictReason2["inputUTXOAlreadySpentInThisMilestone"] = 2] = "inputUTXOAlreadySpentInThisMilestone";
    ConflictReason2[ConflictReason2["inputUTXONotFound"] = 3] = "inputUTXONotFound";
    ConflictReason2[ConflictReason2["inputOutputSumMismatch"] = 4] = "inputOutputSumMismatch";
    ConflictReason2[ConflictReason2["invalidSignature"] = 5] = "invalidSignature";
    ConflictReason2[ConflictReason2["invalidTimelock"] = 6] = "invalidTimelock";
    ConflictReason2[ConflictReason2["invalidNativeTokens"] = 7] = "invalidNativeTokens";
    ConflictReason2[ConflictReason2["returnAmountMismatch"] = 8] = "returnAmountMismatch";
    ConflictReason2[ConflictReason2["invalidInputUnlock"] = 9] = "invalidInputUnlock";
    ConflictReason2[ConflictReason2["invalidInputsCommitment"] = 10] = "invalidInputsCommitment";
    ConflictReason2[ConflictReason2["invalidSender"] = 11] = "invalidSender";
    ConflictReason2[ConflictReason2["invalidChainState"] = 12] = "invalidChainState";
    ConflictReason2[ConflictReason2["semanticValidationFailed"] = 255] = "semanticValidationFailed";
  })(ConflictReason || (ConflictReason = {}));
  _a = {}, _a[ConflictReason.none] = "The block has no conflict", _a[ConflictReason.inputUTXOAlreadySpent] = "The referenced UTXO was already spent", _a[ConflictReason.inputUTXOAlreadySpentInThisMilestone] = "The referenced UTXO was already spent while confirming this milestone", _a[ConflictReason.inputUTXONotFound] = "The referenced UTXO cannot be found", _a[ConflictReason.inputOutputSumMismatch] = "The sum of the inputs and output values does not match", _a[ConflictReason.invalidSignature] = "The unlock block signature is invalid", _a[ConflictReason.invalidTimelock] = "The configured timelock is not yet expired", _a[ConflictReason.invalidNativeTokens] = "The native tokens are invalid", _a[ConflictReason.returnAmountMismatch] = "The return amount in a transaction is not fulfilled by the output side", _a[ConflictReason.invalidInputUnlock] = "The input unlock is invalid", _a[ConflictReason.invalidInputsCommitment] = "The inputs commitment is invalid", _a[ConflictReason.invalidSender] = " The output contains a Sender with an ident (address) which is not unlocked", _a[ConflictReason.invalidChainState] = "The chain state transition is invalid", _a[ConflictReason.semanticValidationFailed] = "The semantic validation failed", _a;
  var __decorate$b = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var INativeToken = (
    /** @class */
    function() {
      function INativeToken2() {
      }
      __decorate$b([
        Transform(function(value) {
          return hexToBigInt(value.value);
        })
      ], INativeToken2.prototype, "amount");
      return INativeToken2;
    }()
  );
  var __extends$8 = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __decorate$a = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var OutputType;
  (function(OutputType2) {
    OutputType2[OutputType2["Treasury"] = 2] = "Treasury";
    OutputType2[OutputType2["Basic"] = 3] = "Basic";
    OutputType2[OutputType2["Alias"] = 4] = "Alias";
    OutputType2[OutputType2["Foundry"] = 5] = "Foundry";
    OutputType2[OutputType2["Nft"] = 6] = "Nft";
  })(OutputType || (OutputType = {}));
  var Output = (
    /** @class */
    function() {
      function Output2(type, amount) {
        this.type = type;
        if (typeof amount == "bigint") {
          this.amount = amount.toString(10);
        } else {
          this.amount = amount;
        }
      }
      Output2.prototype.getType = function() {
        return this.type;
      };
      Output2.prototype.getAmount = function() {
        return BigInt(this.amount);
      };
      Output2.parse = function(data) {
        if (data.type == OutputType.Treasury) {
          return plainToInstance(TreasuryOutput, data);
        } else if (data.type == OutputType.Basic) {
          return plainToInstance(BasicOutput, data);
        } else if (data.type == OutputType.Alias) {
          return plainToInstance(AliasOutput, data);
        } else if (data.type == OutputType.Foundry) {
          return plainToInstance(FoundryOutput, data);
        } else if (data.type == OutputType.Nft) {
          return plainToInstance(NftOutput, data);
        }
        throw new Error("Invalid JSON");
      };
      return Output2;
    }()
  );
  var CommonOutput = (
    /** @class */
    function(_super) {
      __extends$8(CommonOutput2, _super);
      function CommonOutput2(type, amount, unlockConditions) {
        var _this = _super.call(this, type, amount) || this;
        _this.unlockConditions = unlockConditions;
        return _this;
      }
      CommonOutput2.prototype.getUnlockConditions = function() {
        return this.unlockConditions;
      };
      CommonOutput2.prototype.getNativeTokens = function() {
        return this.nativeTokens;
      };
      CommonOutput2.prototype.getFeatures = function() {
        return this.features;
      };
      __decorate$a([
        Type(function() {
          return UnlockCondition;
        }, {
          discriminator: UnlockConditionDiscriminator
        })
      ], CommonOutput2.prototype, "unlockConditions");
      __decorate$a([
        Type(function() {
          return INativeToken;
        })
      ], CommonOutput2.prototype, "nativeTokens");
      __decorate$a([
        Type(function() {
          return Feature;
        }, {
          discriminator: FeatureDiscriminator
        })
      ], CommonOutput2.prototype, "features");
      return CommonOutput2;
    }(
      Output
      /*implements ICommonOutput*/
    )
  );
  var TreasuryOutput = (
    /** @class */
    function(_super) {
      __extends$8(TreasuryOutput2, _super);
      function TreasuryOutput2(amount) {
        return _super.call(this, OutputType.Treasury, amount) || this;
      }
      return TreasuryOutput2;
    }(
      Output
      /*implements ITreasuryOutput */
    )
  );
  var BasicOutput = (
    /** @class */
    function(_super) {
      __extends$8(BasicOutput2, _super);
      function BasicOutput2(amount, unlockConditions) {
        return _super.call(this, OutputType.Basic, amount, unlockConditions) || this;
      }
      return BasicOutput2;
    }(
      CommonOutput
      /*implements IBasicOutput*/
    )
  );
  var ImmutableFeaturesOutput = (
    /** @class */
    function(_super) {
      __extends$8(ImmutableFeaturesOutput2, _super);
      function ImmutableFeaturesOutput2(type, amount, unlockConditions) {
        return _super.call(this, type, amount, unlockConditions) || this;
      }
      ImmutableFeaturesOutput2.prototype.getImmutableFeatures = function() {
        return this.immutableFeatures;
      };
      __decorate$a([
        Type(function() {
          return Feature;
        }, {
          discriminator: FeatureDiscriminator
        })
      ], ImmutableFeaturesOutput2.prototype, "immutableFeatures");
      return ImmutableFeaturesOutput2;
    }(CommonOutput)
  );
  var StateMetadataOutput = (
    /** @class */
    function(_super) {
      __extends$8(StateMetadataOutput2, _super);
      function StateMetadataOutput2(type, amount, unlockConditions, stateMetadata) {
        var _this = _super.call(this, type, amount, unlockConditions) || this;
        _this.stateMetadata = stateMetadata;
        return _this;
      }
      StateMetadataOutput2.prototype.getStateMetadata = function() {
        return this.stateMetadata;
      };
      return StateMetadataOutput2;
    }(
      ImmutableFeaturesOutput
      /*implements IBasicOutput*/
    )
  );
  var AliasOutput = (
    /** @class */
    function(_super) {
      __extends$8(AliasOutput2, _super);
      function AliasOutput2(unlockConditions, amount, aliasId, stateIndex, foundryCounter, stateMetadata) {
        var _this = _super.call(this, OutputType.Alias, amount, unlockConditions, stateMetadata) || this;
        _this.aliasId = aliasId;
        _this.stateIndex = stateIndex;
        _this.foundryCounter = foundryCounter;
        return _this;
      }
      AliasOutput2.prototype.getAliasId = function() {
        return this.aliasId;
      };
      AliasOutput2.prototype.getStateIndex = function() {
        return this.stateIndex;
      };
      AliasOutput2.prototype.getFoundryCounter = function() {
        return this.foundryCounter;
      };
      return AliasOutput2;
    }(
      StateMetadataOutput
      /*implements IAliasOutput*/
    )
  );
  var NftOutput = (
    /** @class */
    function(_super) {
      __extends$8(NftOutput2, _super);
      function NftOutput2(amount, nftId, unlockConditions) {
        var _this = _super.call(this, OutputType.Nft, amount, unlockConditions) || this;
        _this.nftId = nftId;
        return _this;
      }
      NftOutput2.prototype.getNftId = function() {
        return this.nftId;
      };
      return NftOutput2;
    }(
      ImmutableFeaturesOutput
      /*implements INftOutput*/
    )
  );
  var FoundryOutput = (
    /** @class */
    function(_super) {
      __extends$8(FoundryOutput2, _super);
      function FoundryOutput2(amount, serialNumber, unlockConditions, tokenScheme) {
        var _this = _super.call(this, OutputType.Foundry, amount, unlockConditions) || this;
        _this.serialNumber = serialNumber;
        _this.tokenScheme = tokenScheme;
        return _this;
      }
      FoundryOutput2.prototype.getSerialNumber = function() {
        return this.serialNumber;
      };
      FoundryOutput2.prototype.getTokenScheme = function() {
        return this.tokenScheme;
      };
      __decorate$a([
        Type(function() {
          return TokenScheme;
        }, {
          discriminator: TokenSchemeDiscriminator
        })
      ], FoundryOutput2.prototype, "tokenScheme");
      return FoundryOutput2;
    }(
      ImmutableFeaturesOutput
      /*implements IFoundryOutput*/
    )
  );
  var OutputDiscriminator = {
    property: "type",
    subTypes: [
      { value: TreasuryOutput, name: OutputType.Treasury },
      { value: BasicOutput, name: OutputType.Basic },
      { value: AliasOutput, name: OutputType.Alias },
      { value: NftOutput, name: OutputType.Nft },
      { value: FoundryOutput, name: OutputType.Foundry }
    ]
  };
  var __extends$7 = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var SignatureType;
  (function(SignatureType2) {
    SignatureType2[SignatureType2["Ed25519"] = 0] = "Ed25519";
  })(SignatureType || (SignatureType = {}));
  var Signature = (
    /** @class */
    function() {
      function Signature2(type) {
        this.type = type;
      }
      Signature2.prototype.getType = function() {
        return this.type;
      };
      return Signature2;
    }()
  );
  var Ed25519Signature = (
    /** @class */
    function(_super) {
      __extends$7(Ed25519Signature2, _super);
      function Ed25519Signature2(publicKey, signature) {
        var _this = _super.call(this, SignatureType.Ed25519) || this;
        _this.publicKey = publicKey;
        _this.signature = signature;
        return _this;
      }
      return Ed25519Signature2;
    }(Signature)
  );
  var __extends$6 = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __decorate$9 = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var MilestonePayload = (
    /** @class */
    function(_super) {
      __extends$6(MilestonePayload2, _super);
      function MilestonePayload2() {
        return _super.call(this, PayloadType.Milestone) || this;
      }
      __decorate$9([
        Type(function() {
          return MilestoneOption;
        }, {
          discriminator: MilestoneOptionDiscriminator
        })
      ], MilestonePayload2.prototype, "options");
      __decorate$9([
        Type(function() {
          return Ed25519Signature;
        })
      ], MilestonePayload2.prototype, "signatures");
      return MilestonePayload2;
    }(Payload)
  );
  var __extends$5 = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var TaggedDataPayload = (
    /** @class */
    function(_super) {
      __extends$5(TaggedDataPayload2, _super);
      function TaggedDataPayload2(tag, data) {
        var _this = _super.call(this, PayloadType.TaggedData) || this;
        _this.tag = tag;
        _this.data = data;
        return _this;
      }
      return TaggedDataPayload2;
    }(Payload)
  );
  var __extends$4 = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __decorate$8 = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var TransactionEssenceType;
  (function(TransactionEssenceType2) {
    TransactionEssenceType2[TransactionEssenceType2["Regular"] = 1] = "Regular";
  })(TransactionEssenceType || (TransactionEssenceType = {}));
  var TransactionEssence = (
    /** @class */
    function() {
      function TransactionEssence2(type) {
        this.type = type;
      }
      TransactionEssence2.prototype.getType = function() {
        return this.type;
      };
      return TransactionEssence2;
    }()
  );
  var PayloadDiscriminator$1 = {
    property: "type",
    subTypes: [
      { value: TaggedDataPayload, name: PayloadType.TaggedData }
    ]
  };
  var RegularTransactionEssence = (
    /** @class */
    function(_super) {
      __extends$4(RegularTransactionEssence2, _super);
      function RegularTransactionEssence2(networkId, inputsCommitment, inputs, outputs, payload) {
        var _this = _super.call(this, TransactionEssenceType.Regular) || this;
        _this.networkId = networkId;
        _this.inputsCommitment = inputsCommitment;
        _this.inputs = inputs;
        _this.outputs = outputs;
        _this.payload = payload;
        return _this;
      }
      __decorate$8([
        Type(function() {
          return Input;
        }, {
          discriminator: InputDiscriminator
        })
      ], RegularTransactionEssence2.prototype, "inputs");
      __decorate$8([
        Type(function() {
          return Output;
        }, {
          discriminator: OutputDiscriminator
        })
      ], RegularTransactionEssence2.prototype, "outputs");
      __decorate$8([
        Type(function() {
          return Payload;
        }, {
          discriminator: PayloadDiscriminator$1
        })
      ], RegularTransactionEssence2.prototype, "payload");
      return RegularTransactionEssence2;
    }(TransactionEssence)
  );
  var TransactionEssenceDiscriminator = {
    property: "type",
    subTypes: [
      {
        value: RegularTransactionEssence,
        name: TransactionEssenceType.Regular
      }
    ]
  };
  var __extends$3 = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __decorate$7 = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var UnlockType;
  (function(UnlockType2) {
    UnlockType2[UnlockType2["Signature"] = 0] = "Signature";
    UnlockType2[UnlockType2["Reference"] = 1] = "Reference";
    UnlockType2[UnlockType2["Alias"] = 2] = "Alias";
    UnlockType2[UnlockType2["Nft"] = 3] = "Nft";
  })(UnlockType || (UnlockType = {}));
  var Unlock = (
    /** @class */
    function() {
      function Unlock2(type) {
        this.type = type;
      }
      Unlock2.prototype.getType = function() {
        return this.type;
      };
      return Unlock2;
    }()
  );
  var SignatureUnlock = (
    /** @class */
    function(_super) {
      __extends$3(SignatureUnlock2, _super);
      function SignatureUnlock2(signature) {
        var _this = _super.call(this, UnlockType.Signature) || this;
        _this.signature = signature;
        return _this;
      }
      __decorate$7([
        Type(function() {
          return Ed25519Signature;
        })
      ], SignatureUnlock2.prototype, "signature");
      return SignatureUnlock2;
    }(Unlock)
  );
  var ReferenceUnlock = (
    /** @class */
    function(_super) {
      __extends$3(ReferenceUnlock2, _super);
      function ReferenceUnlock2(reference) {
        var _this = _super.call(this, UnlockType.Reference) || this;
        _this.reference = reference;
        return _this;
      }
      return ReferenceUnlock2;
    }(Unlock)
  );
  var AliasUnlock = (
    /** @class */
    function(_super) {
      __extends$3(AliasUnlock2, _super);
      function AliasUnlock2(reference) {
        var _this = _super.call(this, UnlockType.Alias) || this;
        _this.reference = reference;
        return _this;
      }
      return AliasUnlock2;
    }(Unlock)
  );
  var NftUnlock = (
    /** @class */
    function(_super) {
      __extends$3(NftUnlock2, _super);
      function NftUnlock2(reference) {
        var _this = _super.call(this, UnlockType.Nft) || this;
        _this.reference = reference;
        return _this;
      }
      return NftUnlock2;
    }(Unlock)
  );
  var UnlockDiscriminator = {
    property: "type",
    subTypes: [
      {
        value: SignatureUnlock,
        name: UnlockType.Signature
      },
      {
        value: ReferenceUnlock,
        name: UnlockType.Reference
      },
      {
        value: AliasUnlock,
        name: UnlockType.Alias
      },
      {
        value: NftUnlock,
        name: UnlockType.Nft
      }
    ]
  };
  var __extends$2 = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __decorate$6 = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var TransactionPayload = (
    /** @class */
    function(_super) {
      __extends$2(TransactionPayload2, _super);
      function TransactionPayload2(essence, unlocks) {
        var _this = _super.call(this, PayloadType.Transaction) || this;
        _this.essence = essence;
        _this.unlocks = unlocks;
        return _this;
      }
      __decorate$6([
        Type(function() {
          return TransactionEssence;
        }, {
          discriminator: TransactionEssenceDiscriminator
        })
      ], TransactionPayload2.prototype, "essence");
      __decorate$6([
        Type(function() {
          return Unlock;
        }, {
          discriminator: UnlockDiscriminator
        })
      ], TransactionPayload2.prototype, "unlocks");
      return TransactionPayload2;
    }(Payload)
  );
  var PayloadDiscriminator = {
    property: "type",
    subTypes: [
      { value: MilestonePayload, name: PayloadType.Milestone },
      { value: TaggedDataPayload, name: PayloadType.TaggedData },
      { value: TransactionPayload, name: PayloadType.Transaction },
      {
        value: TreasuryTransactionPayload,
        name: PayloadType.TreasuryTransaction
      }
    ]
  };
  var __decorate$5 = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  (function() {
    function Block() {
    }
    __decorate$5([
      Type(function() {
        return Payload;
      }, {
        discriminator: PayloadDiscriminator
      })
    ], Block.prototype, "payload");
    return Block;
  })();
  var CoinType;
  (function(CoinType2) {
    CoinType2[CoinType2["IOTA"] = 4218] = "IOTA";
    CoinType2[CoinType2["Shimmer"] = 4219] = "Shimmer";
    CoinType2[CoinType2["Ether"] = 60] = "Ether";
  })(CoinType || (CoinType = {}));
  var LedgerDeviceType;
  (function(LedgerDeviceType2) {
    LedgerDeviceType2["LedgerNanoS"] = "ledgerNanoS";
    LedgerDeviceType2["LedgerNanoX"] = "ledgerNanoX";
    LedgerDeviceType2["LedgerNanoSPlus"] = "ledgerNanoSPlus";
  })(LedgerDeviceType || (LedgerDeviceType = {}));
  var Network;
  (function(Network2) {
    Network2[Network2["Mainnet"] = 0] = "Mainnet";
    Network2[Network2["Testnet"] = 1] = "Testnet";
  })(Network || (Network = {}));
  var __decorate$4 = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var PreparedTransactionData = (
    /** @class */
    function() {
      function PreparedTransactionData2() {
      }
      __decorate$4([
        Type(function() {
          return TransactionEssence;
        }, {
          discriminator: TransactionEssenceDiscriminator
        })
      ], PreparedTransactionData2.prototype, "essence");
      return PreparedTransactionData2;
    }()
  );
  var InputSigningData = (
    /** @class */
    function() {
      function InputSigningData2() {
      }
      __decorate$4([
        Type(function() {
          return Output;
        }, {
          discriminator: OutputDiscriminator
        })
      ], InputSigningData2.prototype, "output");
      return InputSigningData2;
    }()
  );
  (function() {
    function Remainder() {
    }
    __decorate$4([
      Type(function() {
        return Output;
      }, {
        discriminator: OutputDiscriminator
      })
    ], Remainder.prototype, "output");
    __decorate$4([
      Type(function() {
        return Address;
      }, {
        discriminator: AddressDiscriminator
      })
    ], Remainder.prototype, "address");
    return Remainder;
  })();
  var __extends$1 = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var WalletEventType;
  (function(WalletEventType2) {
    WalletEventType2[WalletEventType2["ConsolidationRequired"] = 0] = "ConsolidationRequired";
    WalletEventType2[WalletEventType2["LedgerAddressGeneration"] = 1] = "LedgerAddressGeneration";
    WalletEventType2[WalletEventType2["NewOutput"] = 2] = "NewOutput";
    WalletEventType2[WalletEventType2["SpentOutput"] = 3] = "SpentOutput";
    WalletEventType2[WalletEventType2["TransactionInclusion"] = 4] = "TransactionInclusion";
    WalletEventType2[WalletEventType2["TransactionProgress"] = 5] = "TransactionProgress";
  })(WalletEventType || (WalletEventType = {}));
  var WalletEvent = (
    /** @class */
    /* @__PURE__ */ function() {
      function WalletEvent2(type) {
        this.type = type;
      }
      return WalletEvent2;
    }()
  );
  (function(_super) {
    __extends$1(ConsolidationRequiredWalletEvent, _super);
    function ConsolidationRequiredWalletEvent() {
      return _super.call(this, WalletEventType.ConsolidationRequired) || this;
    }
    return ConsolidationRequiredWalletEvent;
  })(WalletEvent);
  (function(_super) {
    __extends$1(LedgerAddressGenerationWalletEvent, _super);
    function LedgerAddressGenerationWalletEvent(address) {
      var _this = _super.call(this, WalletEventType.LedgerAddressGeneration) || this;
      _this.address = address;
      return _this;
    }
    return LedgerAddressGenerationWalletEvent;
  })(WalletEvent);
  (function(_super) {
    __extends$1(NewOutputWalletEvent, _super);
    function NewOutputWalletEvent(output2, transaction, transactionInputs) {
      var _this = _super.call(this, WalletEventType.NewOutput) || this;
      _this.output = output2;
      _this.transaction = transaction;
      _this.transactionInputs = transactionInputs;
      return _this;
    }
    return NewOutputWalletEvent;
  })(WalletEvent);
  (function(_super) {
    __extends$1(SpentOutputWalletEvent, _super);
    function SpentOutputWalletEvent(output2) {
      var _this = _super.call(this, WalletEventType.SpentOutput) || this;
      _this.output = output2;
      return _this;
    }
    return SpentOutputWalletEvent;
  })(WalletEvent);
  (function(_super) {
    __extends$1(TransactionInclusionWalletEvent, _super);
    function TransactionInclusionWalletEvent(transactionId, inclusionState) {
      var _this = _super.call(this, WalletEventType.TransactionInclusion) || this;
      _this.transactionId = transactionId;
      _this.inclusionState = inclusionState;
      return _this;
    }
    return TransactionInclusionWalletEvent;
  })(WalletEvent);
  var TransactionProgressType;
  (function(TransactionProgressType2) {
    TransactionProgressType2[TransactionProgressType2["SelectingInputs"] = 0] = "SelectingInputs";
    TransactionProgressType2[TransactionProgressType2["GeneratingRemainderDepositAddress"] = 1] = "GeneratingRemainderDepositAddress";
    TransactionProgressType2[TransactionProgressType2["PreparedTransaction"] = 2] = "PreparedTransaction";
    TransactionProgressType2[TransactionProgressType2["PreparedTransactionEssenceHash"] = 3] = "PreparedTransactionEssenceHash";
    TransactionProgressType2[TransactionProgressType2["SigningTransaction"] = 4] = "SigningTransaction";
    TransactionProgressType2[TransactionProgressType2["PerformingPow"] = 5] = "PerformingPow";
    TransactionProgressType2[TransactionProgressType2["Broadcasting"] = 6] = "Broadcasting";
  })(TransactionProgressType || (TransactionProgressType = {}));
  (function(_super) {
    __extends$1(TransactionProgressWalletEvent, _super);
    function TransactionProgressWalletEvent(progress) {
      var _this = _super.call(this, WalletEventType.TransactionProgress) || this;
      _this.progress = progress;
      return _this;
    }
    return TransactionProgressWalletEvent;
  })(WalletEvent);
  var TransactionProgress = (
    /** @class */
    /* @__PURE__ */ function() {
      function TransactionProgress2(type) {
        this.type = type;
      }
      return TransactionProgress2;
    }()
  );
  (function(_super) {
    __extends$1(SelectingInputsProgress, _super);
    function SelectingInputsProgress() {
      return _super.call(this, TransactionProgressType.SelectingInputs) || this;
    }
    return SelectingInputsProgress;
  })(TransactionProgress);
  (function(_super) {
    __extends$1(GeneratingRemainderDepositAddressProgress, _super);
    function GeneratingRemainderDepositAddressProgress(address) {
      var _this = _super.call(this, TransactionProgressType.GeneratingRemainderDepositAddress) || this;
      _this.address = address;
      return _this;
    }
    return GeneratingRemainderDepositAddressProgress;
  })(TransactionProgress);
  (function(_super) {
    __extends$1(PreparedTransactionProgress, _super);
    function PreparedTransactionProgress(essence, inputsData, remainder) {
      var _this = _super.call(this, TransactionProgressType.PreparedTransaction) || this;
      _this.essence = essence;
      _this.inputsData = inputsData;
      _this.remainder = remainder;
      return _this;
    }
    return PreparedTransactionProgress;
  })(TransactionProgress);
  (function(_super) {
    __extends$1(PreparedTransactionEssenceHashProgress, _super);
    function PreparedTransactionEssenceHashProgress(hash) {
      var _this = _super.call(this, TransactionProgressType.PreparedTransactionEssenceHash) || this;
      _this.hash = hash;
      return _this;
    }
    return PreparedTransactionEssenceHashProgress;
  })(TransactionProgress);
  (function(_super) {
    __extends$1(SigningTransactionProgress, _super);
    function SigningTransactionProgress() {
      return _super.call(this, TransactionProgressType.SigningTransaction) || this;
    }
    return SigningTransactionProgress;
  })(TransactionProgress);
  (function(_super) {
    __extends$1(PerformingPowProgress, _super);
    function PerformingPowProgress() {
      return _super.call(this, TransactionProgressType.PerformingPow) || this;
    }
    return PerformingPowProgress;
  })(TransactionProgress);
  (function(_super) {
    __extends$1(BroadcastingProgress, _super);
    function BroadcastingProgress() {
      return _super.call(this, TransactionProgressType.Broadcasting) || this;
    }
    return BroadcastingProgress;
  })(TransactionProgress);
  var __decorate$3 = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var OutputsToClaim;
  (function(OutputsToClaim2) {
    OutputsToClaim2["MicroTransactions"] = "MicroTransactions";
    OutputsToClaim2["NativeTokens"] = "NativeTokens";
    OutputsToClaim2["Nfts"] = "Nfts";
    OutputsToClaim2["Amount"] = "Amount";
    OutputsToClaim2["All"] = "All";
  })(OutputsToClaim || (OutputsToClaim = {}));
  (function() {
    function OutputData() {
    }
    __decorate$3([
      Type(function() {
        return Output;
      }, {
        discriminator: OutputDiscriminator
      })
    ], OutputData.prototype, "output");
    __decorate$3([
      Type(function() {
        return Address;
      }, {
        discriminator: AddressDiscriminator
      })
    ], OutputData.prototype, "address");
    return OutputData;
  })();
  var ReturnStrategy;
  (function(ReturnStrategy2) {
    ReturnStrategy2["Return"] = "Return";
    ReturnStrategy2["Gift"] = "Gift";
  })(ReturnStrategy || (ReturnStrategy = {}));
  var EventStatus;
  (function(EventStatus2) {
    EventStatus2["Upcoming"] = "upcoming";
    EventStatus2["Commencing"] = "commencing";
    EventStatus2["Holding"] = "holding";
    EventStatus2["Ended"] = "ended";
  })(EventStatus || (EventStatus = {}));
  var ParticipationEventType;
  (function(ParticipationEventType2) {
    ParticipationEventType2[ParticipationEventType2["Voting"] = 0] = "Voting";
    ParticipationEventType2[ParticipationEventType2["Staking"] = 1] = "Staking";
  })(ParticipationEventType || (ParticipationEventType = {}));
  var __awaiter = function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  };
  var __generator = function(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t2[0] & 1) throw t2[1];
      return t2[1];
    }, trys: [], ops: [] }, f, y2, t2, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n2) {
      return function(v2) {
        return step([n2, v2]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y2 && (t2 = op[0] & 2 ? y2["return"] : op[0] ? y2["throw"] || ((t2 = y2["return"]) && t2.call(y2), 0) : y2.next) && !(t2 = t2.call(y2, op[1])).done) return t2;
        if (y2 = 0, t2) op = [op[0] & 2, t2.value];
        switch (op[0]) {
          case 0:
          case 1:
            t2 = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y2 = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t2 = _.trys, t2 = t2.length > 0 && t2[t2.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t2 || op[1] > t2[0] && op[1] < t2[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t2[1]) {
              _.label = t2[1];
              t2 = op;
              break;
            }
            if (t2 && _.label < t2[2]) {
              _.label = t2[2];
              _.ops.push(op);
              break;
            }
            if (t2[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y2 = 0;
      } finally {
        f = t2 = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  };
  var PreparedTransaction = (
    /** @class */
    function() {
      function PreparedTransaction2(preparedData, account) {
        this._preparedData = preparedData;
        this._account = account;
      }
      PreparedTransaction2.prototype.preparedTransactionData = function() {
        return this._preparedData;
      };
      PreparedTransaction2.prototype.send = function() {
        return __awaiter(this, void 0, void 0, function() {
          return __generator(this, function(_a2) {
            return [2, this.signAndSubmitTransaction()];
          });
        });
      };
      PreparedTransaction2.prototype.sign = function() {
        return __awaiter(this, void 0, void 0, function() {
          return __generator(this, function(_a2) {
            return [2, this._account.signTransactionEssence(this.preparedTransactionData())];
          });
        });
      };
      PreparedTransaction2.prototype.signAndSubmitTransaction = function() {
        return __awaiter(this, void 0, void 0, function() {
          return __generator(this, function(_a2) {
            return [2, this._account.signAndSubmitTransaction(this.preparedTransactionData())];
          });
        });
      };
      return PreparedTransaction2;
    }()
  );
  var __extends = /* @__PURE__ */ function() {
    var extendStatics = function(d2, b2) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
      };
      return extendStatics(d2, b2);
    };
    return function(d2, b2) {
      if (typeof b2 !== "function" && b2 !== null)
        throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
      extendStatics(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  (function(_super) {
    __extends(PreparedCreateNativeTokenTransaction, _super);
    function PreparedCreateNativeTokenTransaction(preparedData, account) {
      var _this = _super.call(this, preparedData.transaction, account) || this;
      _this._tokenId = preparedData.tokenId;
      return _this;
    }
    PreparedCreateNativeTokenTransaction.prototype.tokenId = function() {
      return this._tokenId;
    };
    return PreparedCreateNativeTokenTransaction;
  })(PreparedTransaction);
  var __decorate$2 = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  (function() {
    function SignedTransactionEssence() {
    }
    __decorate$2([
      Type(function() {
        return TransactionPayload;
      })
    ], SignedTransactionEssence.prototype, "transactionPayload");
    __decorate$2([
      Type(function() {
        return InputSigningData;
      })
    ], SignedTransactionEssence.prototype, "inputsData");
    return SignedTransactionEssence;
  })();
  var __decorate$1 = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  var InclusionState;
  (function(InclusionState2) {
    InclusionState2["Pending"] = "Pending";
    InclusionState2["Confirmed"] = "Confirmed";
    InclusionState2["Conflicting"] = "Conflicting";
    InclusionState2["UnknownPruned"] = "UnknownPruned";
  })(InclusionState || (InclusionState = {}));
  var Transaction = (
    /** @class */
    function() {
      function Transaction2() {
      }
      __decorate$1([
        Type(function() {
          return TransactionPayload;
        })
      ], Transaction2.prototype, "payload");
      __decorate$1([
        Type(function() {
          return OutputResponse;
        })
      ], Transaction2.prototype, "inputs");
      return Transaction2;
    }()
  );
  var __decorate = function(decorators, target, key, desc) {
    var c2 = arguments.length, r2 = c2 < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d2;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r2 = Reflect.decorate(decorators, target, key, desc);
    else for (var i2 = decorators.length - 1; i2 >= 0; i2--) if (d2 = decorators[i2]) r2 = (c2 < 3 ? d2(r2) : c2 > 3 ? d2(target, key, r2) : d2(target, key)) || r2;
    return c2 > 3 && r2 && Object.defineProperty(target, key, r2), r2;
  };
  (function() {
    function PreparedCreateNativeTokenTransactionData() {
    }
    __decorate([
      Type(function() {
        return PreparedTransactionData;
      })
    ], PreparedCreateNativeTokenTransactionData.prototype, "transaction");
    return PreparedCreateNativeTokenTransactionData;
  })();
  (function() {
    function CreateNativeTokenTransaction() {
    }
    __decorate([
      Type(function() {
        return Transaction;
      })
    ], CreateNativeTokenTransaction.prototype, "transaction");
    return CreateNativeTokenTransaction;
  })();
  (function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  });
  (function(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t2[0] & 1) throw t2[1];
      return t2[1];
    }, trys: [], ops: [] }, f, y2, t2, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n2) {
      return function(v2) {
        return step([n2, v2]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y2 && (t2 = op[0] & 2 ? y2["return"] : op[0] ? y2["throw"] || ((t2 = y2["return"]) && t2.call(y2), 0) : y2.next) && !(t2 = t2.call(y2, op[1])).done) return t2;
        if (y2 = 0, t2) op = [op[0] & 2, t2.value];
        switch (op[0]) {
          case 0:
          case 1:
            t2 = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y2 = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t2 = _.trys, t2 = t2.length > 0 && t2[t2.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t2 || op[1] > t2[0] && op[1] < t2[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t2[1]) {
              _.label = t2[1];
              t2 = op;
              break;
            }
            if (t2 && _.label < t2[2]) {
              _.label = t2[2];
              _.ops.push(op);
              break;
            }
            if (t2[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y2 = 0;
      } finally {
        f = t2 = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  });
  (function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  });
  (function(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t2[0] & 1) throw t2[1];
      return t2[1];
    }, trys: [], ops: [] }, f, y2, t2, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n2) {
      return function(v2) {
        return step([n2, v2]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y2 && (t2 = op[0] & 2 ? y2["return"] : op[0] ? y2["throw"] || ((t2 = y2["return"]) && t2.call(y2), 0) : y2.next) && !(t2 = t2.call(y2, op[1])).done) return t2;
        if (y2 = 0, t2) op = [op[0] & 2, t2.value];
        switch (op[0]) {
          case 0:
          case 1:
            t2 = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y2 = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t2 = _.trys, t2 = t2.length > 0 && t2[t2.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t2 || op[1] > t2[0] && op[1] < t2[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t2[1]) {
              _.label = t2[1];
              t2 = op;
              break;
            }
            if (t2 && _.label < t2[2]) {
              _.label = t2[2];
              _.ops.push(op);
              break;
            }
            if (t2[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y2 = 0;
      } finally {
        f = t2 = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  });
  (function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  });
  (function(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t2[0] & 1) throw t2[1];
      return t2[1];
    }, trys: [], ops: [] }, f, y2, t2, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n2) {
      return function(v2) {
        return step([n2, v2]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y2 && (t2 = op[0] & 2 ? y2["return"] : op[0] ? y2["throw"] || ((t2 = y2["return"]) && t2.call(y2), 0) : y2.next) && !(t2 = t2.call(y2, op[1])).done) return t2;
        if (y2 = 0, t2) op = [op[0] & 2, t2.value];
        switch (op[0]) {
          case 0:
          case 1:
            t2 = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y2 = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t2 = _.trys, t2 = t2.length > 0 && t2[t2.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t2 || op[1] > t2[0] && op[1] < t2[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t2[1]) {
              _.label = t2[1];
              t2 = op;
              break;
            }
            if (t2 && _.label < t2[2]) {
              _.label = t2[2];
              _.ops.push(op);
              break;
            }
            if (t2[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y2 = 0;
      } finally {
        f = t2 = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  });
  (function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  });
  (function(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t2[0] & 1) throw t2[1];
      return t2[1];
    }, trys: [], ops: [] }, f, y2, t2, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n2) {
      return function(v2) {
        return step([n2, v2]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y2 && (t2 = op[0] & 2 ? y2["return"] : op[0] ? y2["throw"] || ((t2 = y2["return"]) && t2.call(y2), 0) : y2.next) && !(t2 = t2.call(y2, op[1])).done) return t2;
        if (y2 = 0, t2) op = [op[0] & 2, t2.value];
        switch (op[0]) {
          case 0:
          case 1:
            t2 = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y2 = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t2 = _.trys, t2 = t2.length > 0 && t2[t2.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t2 || op[1] > t2[0] && op[1] < t2[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t2[1]) {
              _.label = t2[1];
              t2 = op;
              break;
            }
            if (t2 && _.label < t2[2]) {
              _.label = t2[2];
              _.ops.push(op);
              break;
            }
            if (t2[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y2 = 0;
      } finally {
        f = t2 = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  });
  (function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  });
  (function(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t2[0] & 1) throw t2[1];
      return t2[1];
    }, trys: [], ops: [] }, f, y2, t2, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n2) {
      return function(v2) {
        return step([n2, v2]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y2 && (t2 = op[0] & 2 ? y2["return"] : op[0] ? y2["throw"] || ((t2 = y2["return"]) && t2.call(y2), 0) : y2.next) && !(t2 = t2.call(y2, op[1])).done) return t2;
        if (y2 = 0, t2) op = [op[0] & 2, t2.value];
        switch (op[0]) {
          case 0:
          case 1:
            t2 = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y2 = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t2 = _.trys, t2 = t2.length > 0 && t2[t2.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t2 || op[1] > t2[0] && op[1] < t2[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t2[1]) {
              _.label = t2[1];
              t2 = op;
              break;
            }
            if (t2 && _.label < t2[2]) {
              _.label = t2[2];
              _.ops.push(op);
              break;
            }
            if (t2[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y2 = 0;
      } finally {
        f = t2 = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  });
  (function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  });
  (function(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t2[0] & 1) throw t2[1];
      return t2[1];
    }, trys: [], ops: [] }, f, y2, t2, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n2) {
      return function(v2) {
        return step([n2, v2]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y2 && (t2 = op[0] & 2 ? y2["return"] : op[0] ? y2["throw"] || ((t2 = y2["return"]) && t2.call(y2), 0) : y2.next) && !(t2 = t2.call(y2, op[1])).done) return t2;
        if (y2 = 0, t2) op = [op[0] & 2, t2.value];
        switch (op[0]) {
          case 0:
          case 1:
            t2 = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y2 = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t2 = _.trys, t2 = t2.length > 0 && t2[t2.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t2 || op[1] > t2[0] && op[1] < t2[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t2[1]) {
              _.label = t2[1];
              t2 = op;
              break;
            }
            if (t2 && _.label < t2[2]) {
              _.label = t2[2];
              _.ops.push(op);
              break;
            }
            if (t2[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y2 = 0;
      } finally {
        f = t2 = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  });
  (function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  });
  (function(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t2[0] & 1) throw t2[1];
      return t2[1];
    }, trys: [], ops: [] }, f, y2, t2, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n2) {
      return function(v2) {
        return step([n2, v2]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y2 && (t2 = op[0] & 2 ? y2["return"] : op[0] ? y2["throw"] || ((t2 = y2["return"]) && t2.call(y2), 0) : y2.next) && !(t2 = t2.call(y2, op[1])).done) return t2;
        if (y2 = 0, t2) op = [op[0] & 2, t2.value];
        switch (op[0]) {
          case 0:
          case 1:
            t2 = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y2 = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t2 = _.trys, t2 = t2.length > 0 && t2[t2.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t2 || op[1] > t2[0] && op[1] < t2[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t2[1]) {
              _.label = t2[1];
              t2 = op;
              break;
            }
            if (t2 && _.label < t2[2]) {
              _.label = t2[2];
              _.ops.push(op);
              break;
            }
            if (t2[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y2 = 0;
      } finally {
        f = t2 = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  });
  BigInt.prototype.toJSON = function() {
    return bigIntToHex(this);
  };
  Object.assign(UTXOInput, {
    /**
     * Creates a `UTXOInput` from an output id.
     */
    fromOutputId: function(outputId) {
      var input = callUtilsMethod({
        name: "outputIdToUtxoInput",
        data: {
          outputId
        }
      });
      return new UTXOInput(input.transactionId, input.transactionOutputIndex);
    }
  });
  (function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  });
  (function(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t2[0] & 1) throw t2[1];
      return t2[1];
    }, trys: [], ops: [] }, f, y2, t2, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n2) {
      return function(v2) {
        return step([n2, v2]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y2 && (t2 = op[0] & 2 ? y2["return"] : op[0] ? y2["throw"] || ((t2 = y2["return"]) && t2.call(y2), 0) : y2.next) && !(t2 = t2.call(y2, op[1])).done) return t2;
        if (y2 = 0, t2) op = [op[0] & 2, t2.value];
        switch (op[0]) {
          case 0:
          case 1:
            t2 = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y2 = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t2 = _.trys, t2 = t2.length > 0 && t2[t2.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t2 || op[1] > t2[0] && op[1] < t2[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t2[1]) {
              _.label = t2[1];
              t2 = op;
              break;
            }
            if (t2 && _.label < t2[2]) {
              _.label = t2[2];
              _.ops.push(op);
              break;
            }
            if (t2[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y2 = 0;
      } finally {
        f = t2 = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  });
  var EcCurve;
  (function(EcCurve2) {
    EcCurve2[EcCurve2["P256"] = 0] = "P256";
    EcCurve2[EcCurve2["P384"] = 1] = "P384";
    EcCurve2[EcCurve2["P521"] = 2] = "P521";
    EcCurve2[EcCurve2["Secp256K1"] = 3] = "Secp256K1";
  })(EcCurve || (EcCurve = {}));
  var EdCurve;
  (function(EdCurve2) {
    EdCurve2["Ed25519"] = "Ed25519";
    EdCurve2["Ed448"] = "Ed448";
  })(EdCurve || (EdCurve = {}));
  var JwkOperation;
  (function(JwkOperation2) {
    JwkOperation2["Sign"] = "sign";
    JwkOperation2["Verify"] = "verify";
    JwkOperation2["Encrypt"] = "encrypt";
    JwkOperation2["Decrypt"] = "decrypt";
    JwkOperation2["WrapKey"] = "wrapKey";
    JwkOperation2["UnwrapKey"] = "unwrapKey";
    JwkOperation2["DeriveKey"] = "deriveKey";
    JwkOperation2["DeriveBits"] = "deriveBits";
  })(JwkOperation || (JwkOperation = {}));
  var JwkType;
  (function(JwkType2) {
    JwkType2["Ec"] = "EC";
    JwkType2["Rsa"] = "RSA";
    JwkType2["Oct"] = "oct";
    JwkType2["Okp"] = "OKP";
    JwkType2["MLDSA"] = "ML-DSA";
  })(JwkType || (JwkType = {}));
  var JwkUse;
  (function(JwkUse2) {
    JwkUse2["Signature"] = "sig";
    JwkUse2["Encryption"] = "enc";
  })(JwkUse || (JwkUse = {}));
  var JwsAlgorithm;
  (function(JwsAlgorithm2) {
    JwsAlgorithm2["HS256"] = "HS256";
    JwsAlgorithm2["HS384"] = "HS384";
    JwsAlgorithm2["HS512"] = "HS512";
    JwsAlgorithm2["RS256"] = "RS256";
    JwsAlgorithm2["RS384"] = "RS384";
    JwsAlgorithm2["RS512"] = "RS512";
    JwsAlgorithm2["PS256"] = "PS256";
    JwsAlgorithm2["PS384"] = "PS384";
    JwsAlgorithm2["PS512"] = "PS512";
    JwsAlgorithm2["ES256"] = "ES256";
    JwsAlgorithm2["ES384"] = "ES384";
    JwsAlgorithm2["ES512"] = "ES512";
    JwsAlgorithm2["ES256K"] = "ES256K";
    JwsAlgorithm2["NONE"] = "none";
    JwsAlgorithm2["EdDSA"] = "EdDSA";
    JwsAlgorithm2["MLDSA44"] = "ML-DSA-44";
    JwsAlgorithm2["MLDSA65"] = "ML-DSA-65";
    JwsAlgorithm2["MLDSA87"] = "ML-DSA-87";
  })(JwsAlgorithm || (JwsAlgorithm = {}));
  var CompositeAlgId;
  (function(CompositeAlgId2) {
    CompositeAlgId2["IdMldsa44Ed25519Sha512"] = "id-MLDSA44-Ed25519-SHA512";
    CompositeAlgId2["IdMldsa65Ed25519Sha512"] = "id-MLDSA65-Ed25519-SHA512";
  })(CompositeAlgId || (CompositeAlgId = {}));
  var __viteBrowserExternal = new Proxy({}, {
    get(_, key) {
      throw new Error(`Module "" has been externalized for browser compatibility. Cannot access ".${key}" in client code.  See https://vite.dev/guide/troubleshooting.html#module-externalized-for-browser-compatibility for more details.`);
    }
  });
  var nodeCrypto = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    default: __viteBrowserExternal
  });
  /*! noble-ed25519 - MIT License (c) 2019 Paul Miller (paulmillr.com) */
  const _0n$5 = BigInt(0);
  const _1n$6 = BigInt(1);
  const _2n$5 = BigInt(2);
  const _8n$3 = BigInt(8);
  const CU_O = BigInt("7237005577332262213973186563042994240857116359379907606001950938285454250989");
  const CURVE = Object.freeze({
    a: BigInt(-1),
    d: BigInt("37095705934669439343138083508754565189542113879843219016388785533085940283555"),
    P: BigInt("57896044618658097711785492504343953926634992332820282019728792003956564819949"),
    l: CU_O,
    n: CU_O,
    h: BigInt(8),
    Gx: BigInt("15112221349535400772501151409588531511454012693041857206046113283949847762202"),
    Gy: BigInt("46316835694926478169428394003475163141307993866256225615783033603165251855960")
  });
  const POW_2_256 = BigInt("0x10000000000000000000000000000000000000000000000000000000000000000");
  const SQRT_M1 = BigInt("19681161376707505956807079304988542015446066515923890162744021073123829784752");
  BigInt("6853475219497561581579357271197624642482790079785650197046958215289687604742");
  const SQRT_AD_MINUS_ONE = BigInt("25063068953384623474111414158702152701244531502492656460079210482610430750235");
  const INVSQRT_A_MINUS_D = BigInt("54469307008909316920995813868745141605393597292927456921205312896311721017578");
  const ONE_MINUS_D_SQ = BigInt("1159843021668779879193775521855586647937357759715417654439879720876111806838");
  const D_MINUS_ONE_SQ = BigInt("40440834346308536858101042469323190826248399146238708352240133220865137265952");
  class ExtendedPoint {
    constructor(x2, y2, z2, t2) {
      this.x = x2;
      this.y = y2;
      this.z = z2;
      this.t = t2;
    }
    static fromAffine(p2) {
      if (!(p2 instanceof Point)) {
        throw new TypeError("ExtendedPoint#fromAffine: expected Point");
      }
      if (p2.equals(Point.ZERO))
        return ExtendedPoint.ZERO;
      return new ExtendedPoint(p2.x, p2.y, _1n$6, mod$2(p2.x * p2.y));
    }
    static toAffineBatch(points) {
      const toInv = invertBatch(points.map((p2) => p2.z));
      return points.map((p2, i2) => p2.toAffine(toInv[i2]));
    }
    static normalizeZ(points) {
      return this.toAffineBatch(points).map(this.fromAffine);
    }
    equals(other) {
      assertExtPoint(other);
      const { x: X1, y: Y1, z: Z1 } = this;
      const { x: X2, y: Y2, z: Z2 } = other;
      const X1Z2 = mod$2(X1 * Z2);
      const X2Z1 = mod$2(X2 * Z1);
      const Y1Z2 = mod$2(Y1 * Z2);
      const Y2Z1 = mod$2(Y2 * Z1);
      return X1Z2 === X2Z1 && Y1Z2 === Y2Z1;
    }
    negate() {
      return new ExtendedPoint(mod$2(-this.x), this.y, this.z, mod$2(-this.t));
    }
    double() {
      const { x: X1, y: Y1, z: Z1 } = this;
      const { a } = CURVE;
      const A2 = mod$2(X1 * X1);
      const B = mod$2(Y1 * Y1);
      const C = mod$2(_2n$5 * mod$2(Z1 * Z1));
      const D2 = mod$2(a * A2);
      const x1y1 = X1 + Y1;
      const E = mod$2(mod$2(x1y1 * x1y1) - A2 - B);
      const G = D2 + B;
      const F2 = G - C;
      const H = D2 - B;
      const X3 = mod$2(E * F2);
      const Y3 = mod$2(G * H);
      const T3 = mod$2(E * H);
      const Z3 = mod$2(F2 * G);
      return new ExtendedPoint(X3, Y3, Z3, T3);
    }
    add(other) {
      assertExtPoint(other);
      const { x: X1, y: Y1, z: Z1, t: T1 } = this;
      const { x: X2, y: Y2, z: Z2, t: T2 } = other;
      const A2 = mod$2((Y1 - X1) * (Y2 + X2));
      const B = mod$2((Y1 + X1) * (Y2 - X2));
      const F2 = mod$2(B - A2);
      if (F2 === _0n$5)
        return this.double();
      const C = mod$2(Z1 * _2n$5 * T2);
      const D2 = mod$2(T1 * _2n$5 * Z2);
      const E = D2 + C;
      const G = B + A2;
      const H = D2 - C;
      const X3 = mod$2(E * F2);
      const Y3 = mod$2(G * H);
      const T3 = mod$2(E * H);
      const Z3 = mod$2(F2 * G);
      return new ExtendedPoint(X3, Y3, Z3, T3);
    }
    subtract(other) {
      return this.add(other.negate());
    }
    precomputeWindow(W2) {
      const windows = 1 + 256 / W2;
      const points = [];
      let p2 = this;
      let base = p2;
      for (let window2 = 0; window2 < windows; window2++) {
        base = p2;
        points.push(base);
        for (let i2 = 1; i2 < 2 ** (W2 - 1); i2++) {
          base = base.add(p2);
          points.push(base);
        }
        p2 = base.double();
      }
      return points;
    }
    wNAF(n2, affinePoint) {
      if (!affinePoint && this.equals(ExtendedPoint.BASE))
        affinePoint = Point.BASE;
      const W2 = affinePoint && affinePoint._WINDOW_SIZE || 1;
      if (256 % W2) {
        throw new Error("Point#wNAF: Invalid precomputation window, must be power of 2");
      }
      let precomputes = affinePoint && pointPrecomputes$1.get(affinePoint);
      if (!precomputes) {
        precomputes = this.precomputeWindow(W2);
        if (affinePoint && W2 !== 1) {
          precomputes = ExtendedPoint.normalizeZ(precomputes);
          pointPrecomputes$1.set(affinePoint, precomputes);
        }
      }
      let p2 = ExtendedPoint.ZERO;
      let f = ExtendedPoint.BASE;
      const windows = 1 + 256 / W2;
      const windowSize = 2 ** (W2 - 1);
      const mask = BigInt(2 ** W2 - 1);
      const maxNumber = 2 ** W2;
      const shiftBy = BigInt(W2);
      for (let window2 = 0; window2 < windows; window2++) {
        const offset = window2 * windowSize;
        let wbits = Number(n2 & mask);
        n2 >>= shiftBy;
        if (wbits > windowSize) {
          wbits -= maxNumber;
          n2 += _1n$6;
        }
        const offset1 = offset;
        const offset2 = offset + Math.abs(wbits) - 1;
        const cond1 = window2 % 2 !== 0;
        const cond2 = wbits < 0;
        if (wbits === 0) {
          f = f.add(constTimeNegate(cond1, precomputes[offset1]));
        } else {
          p2 = p2.add(constTimeNegate(cond2, precomputes[offset2]));
        }
      }
      return ExtendedPoint.normalizeZ([p2, f])[0];
    }
    multiply(scalar, affinePoint) {
      return this.wNAF(normalizeScalar(scalar, CURVE.l), affinePoint);
    }
    multiplyUnsafe(scalar) {
      let n2 = normalizeScalar(scalar, CURVE.l, false);
      const G = ExtendedPoint.BASE;
      const P0 = ExtendedPoint.ZERO;
      if (n2 === _0n$5)
        return P0;
      if (this.equals(P0) || n2 === _1n$6)
        return this;
      if (this.equals(G))
        return this.wNAF(n2);
      let p2 = P0;
      let d2 = this;
      while (n2 > _0n$5) {
        if (n2 & _1n$6)
          p2 = p2.add(d2);
        d2 = d2.double();
        n2 >>= _1n$6;
      }
      return p2;
    }
    isSmallOrder() {
      return this.multiplyUnsafe(CURVE.h).equals(ExtendedPoint.ZERO);
    }
    isTorsionFree() {
      let p2 = this.multiplyUnsafe(CURVE.l / _2n$5).double();
      if (CURVE.l % _2n$5)
        p2 = p2.add(this);
      return p2.equals(ExtendedPoint.ZERO);
    }
    toAffine(invZ) {
      const { x: x2, y: y2, z: z2 } = this;
      const is0 = this.equals(ExtendedPoint.ZERO);
      if (invZ == null)
        invZ = is0 ? _8n$3 : invert$1(z2);
      const ax = mod$2(x2 * invZ);
      const ay = mod$2(y2 * invZ);
      const zz = mod$2(z2 * invZ);
      if (is0)
        return Point.ZERO;
      if (zz !== _1n$6)
        throw new Error("invZ was invalid");
      return new Point(ax, ay);
    }
    fromRistrettoBytes() {
      legacyRist();
    }
    toRistrettoBytes() {
      legacyRist();
    }
    fromRistrettoHash() {
      legacyRist();
    }
  }
  ExtendedPoint.BASE = new ExtendedPoint(CURVE.Gx, CURVE.Gy, _1n$6, mod$2(CURVE.Gx * CURVE.Gy));
  ExtendedPoint.ZERO = new ExtendedPoint(_0n$5, _1n$6, _1n$6, _0n$5);
  function constTimeNegate(condition, item) {
    const neg = item.negate();
    return condition ? neg : item;
  }
  function assertExtPoint(other) {
    if (!(other instanceof ExtendedPoint))
      throw new TypeError("ExtendedPoint expected");
  }
  function assertRstPoint(other) {
    if (!(other instanceof RistrettoPoint))
      throw new TypeError("RistrettoPoint expected");
  }
  function legacyRist() {
    throw new Error("Legacy method: switch to RistrettoPoint");
  }
  class RistrettoPoint {
    constructor(ep) {
      this.ep = ep;
    }
    static calcElligatorRistrettoMap(r0) {
      const { d: d2 } = CURVE;
      const r2 = mod$2(SQRT_M1 * r0 * r0);
      const Ns = mod$2((r2 + _1n$6) * ONE_MINUS_D_SQ);
      let c2 = BigInt(-1);
      const D2 = mod$2((c2 - d2 * r2) * mod$2(r2 + d2));
      let { isValid: Ns_D_is_sq, value: s2 } = uvRatio$1(Ns, D2);
      let s_ = mod$2(s2 * r0);
      if (!edIsNegative(s_))
        s_ = mod$2(-s_);
      if (!Ns_D_is_sq)
        s2 = s_;
      if (!Ns_D_is_sq)
        c2 = r2;
      const Nt = mod$2(c2 * (r2 - _1n$6) * D_MINUS_ONE_SQ - D2);
      const s22 = s2 * s2;
      const W0 = mod$2((s2 + s2) * D2);
      const W1 = mod$2(Nt * SQRT_AD_MINUS_ONE);
      const W2 = mod$2(_1n$6 - s22);
      const W3 = mod$2(_1n$6 + s22);
      return new ExtendedPoint(mod$2(W0 * W3), mod$2(W2 * W1), mod$2(W1 * W3), mod$2(W0 * W2));
    }
    static hashToCurve(hex) {
      hex = ensureBytes$2(hex, 64);
      const r1 = bytes255ToNumberLE(hex.slice(0, 32));
      const R1 = this.calcElligatorRistrettoMap(r1);
      const r2 = bytes255ToNumberLE(hex.slice(32, 64));
      const R2 = this.calcElligatorRistrettoMap(r2);
      return new RistrettoPoint(R1.add(R2));
    }
    static fromHex(hex) {
      hex = ensureBytes$2(hex, 32);
      const { a, d: d2 } = CURVE;
      const emsg = "RistrettoPoint.fromHex: the hex is not valid encoding of RistrettoPoint";
      const s2 = bytes255ToNumberLE(hex);
      if (!equalBytes$1(numberTo32BytesLE(s2), hex) || edIsNegative(s2))
        throw new Error(emsg);
      const s22 = mod$2(s2 * s2);
      const u1 = mod$2(_1n$6 + a * s22);
      const u2 = mod$2(_1n$6 - a * s22);
      const u1_2 = mod$2(u1 * u1);
      const u2_2 = mod$2(u2 * u2);
      const v2 = mod$2(a * d2 * u1_2 - u2_2);
      const { isValid, value: I2 } = invertSqrt(mod$2(v2 * u2_2));
      const Dx = mod$2(I2 * u2);
      const Dy = mod$2(I2 * Dx * v2);
      let x2 = mod$2((s2 + s2) * Dx);
      if (edIsNegative(x2))
        x2 = mod$2(-x2);
      const y2 = mod$2(u1 * Dy);
      const t2 = mod$2(x2 * y2);
      if (!isValid || edIsNegative(t2) || y2 === _0n$5)
        throw new Error(emsg);
      return new RistrettoPoint(new ExtendedPoint(x2, y2, _1n$6, t2));
    }
    toRawBytes() {
      let { x: x2, y: y2, z: z2, t: t2 } = this.ep;
      const u1 = mod$2(mod$2(z2 + y2) * mod$2(z2 - y2));
      const u2 = mod$2(x2 * y2);
      const u2sq = mod$2(u2 * u2);
      const { value: invsqrt } = invertSqrt(mod$2(u1 * u2sq));
      const D1 = mod$2(invsqrt * u1);
      const D2 = mod$2(invsqrt * u2);
      const zInv = mod$2(D1 * D2 * t2);
      let D3;
      if (edIsNegative(t2 * zInv)) {
        let _x = mod$2(y2 * SQRT_M1);
        let _y = mod$2(x2 * SQRT_M1);
        x2 = _x;
        y2 = _y;
        D3 = mod$2(D1 * INVSQRT_A_MINUS_D);
      } else {
        D3 = D2;
      }
      if (edIsNegative(x2 * zInv))
        y2 = mod$2(-y2);
      let s2 = mod$2((z2 - y2) * D3);
      if (edIsNegative(s2))
        s2 = mod$2(-s2);
      return numberTo32BytesLE(s2);
    }
    toHex() {
      return bytesToHex$1(this.toRawBytes());
    }
    toString() {
      return this.toHex();
    }
    equals(other) {
      assertRstPoint(other);
      const a = this.ep;
      const b2 = other.ep;
      const one = mod$2(a.x * b2.y) === mod$2(a.y * b2.x);
      const two = mod$2(a.y * b2.y) === mod$2(a.x * b2.x);
      return one || two;
    }
    add(other) {
      assertRstPoint(other);
      return new RistrettoPoint(this.ep.add(other.ep));
    }
    subtract(other) {
      assertRstPoint(other);
      return new RistrettoPoint(this.ep.subtract(other.ep));
    }
    multiply(scalar) {
      return new RistrettoPoint(this.ep.multiply(scalar));
    }
    multiplyUnsafe(scalar) {
      return new RistrettoPoint(this.ep.multiplyUnsafe(scalar));
    }
  }
  RistrettoPoint.BASE = new RistrettoPoint(ExtendedPoint.BASE);
  RistrettoPoint.ZERO = new RistrettoPoint(ExtendedPoint.ZERO);
  const pointPrecomputes$1 = /* @__PURE__ */ new WeakMap();
  class Point {
    constructor(x2, y2) {
      this.x = x2;
      this.y = y2;
    }
    _setWindowSize(windowSize) {
      this._WINDOW_SIZE = windowSize;
      pointPrecomputes$1.delete(this);
    }
    static fromHex(hex, strict = true) {
      const { d: d2, P } = CURVE;
      hex = ensureBytes$2(hex, 32);
      const normed = hex.slice();
      normed[31] = hex[31] & ~128;
      const y2 = bytesToNumberLE$1(normed);
      if (strict && y2 >= P)
        throw new Error("Expected 0 < hex < P");
      if (!strict && y2 >= POW_2_256)
        throw new Error("Expected 0 < hex < 2**256");
      const y22 = mod$2(y2 * y2);
      const u2 = mod$2(y22 - _1n$6);
      const v2 = mod$2(d2 * y22 + _1n$6);
      let { isValid, value: x2 } = uvRatio$1(u2, v2);
      if (!isValid)
        throw new Error("Point.fromHex: invalid y coordinate");
      const isXOdd = (x2 & _1n$6) === _1n$6;
      const isLastByteOdd = (hex[31] & 128) !== 0;
      if (isLastByteOdd !== isXOdd) {
        x2 = mod$2(-x2);
      }
      return new Point(x2, y2);
    }
    static async fromPrivateKey(privateKey) {
      return (await getExtendedPublicKey(privateKey)).point;
    }
    toRawBytes() {
      const bytes2 = numberTo32BytesLE(this.y);
      bytes2[31] |= this.x & _1n$6 ? 128 : 0;
      return bytes2;
    }
    toHex() {
      return bytesToHex$1(this.toRawBytes());
    }
    toX25519() {
      const { y: y2 } = this;
      const u2 = mod$2((_1n$6 + y2) * invert$1(_1n$6 - y2));
      return numberTo32BytesLE(u2);
    }
    isTorsionFree() {
      return ExtendedPoint.fromAffine(this).isTorsionFree();
    }
    equals(other) {
      return this.x === other.x && this.y === other.y;
    }
    negate() {
      return new Point(mod$2(-this.x), this.y);
    }
    add(other) {
      return ExtendedPoint.fromAffine(this).add(ExtendedPoint.fromAffine(other)).toAffine();
    }
    subtract(other) {
      return this.add(other.negate());
    }
    multiply(scalar) {
      return ExtendedPoint.fromAffine(this).multiply(scalar, this).toAffine();
    }
  }
  Point.BASE = new Point(CURVE.Gx, CURVE.Gy);
  Point.ZERO = new Point(_0n$5, _1n$6);
  function concatBytes$2(...arrays) {
    if (!arrays.every((a) => a instanceof Uint8Array))
      throw new Error("Expected Uint8Array list");
    if (arrays.length === 1)
      return arrays[0];
    const length = arrays.reduce((a, arr) => a + arr.length, 0);
    const result = new Uint8Array(length);
    for (let i2 = 0, pad = 0; i2 < arrays.length; i2++) {
      const arr = arrays[i2];
      result.set(arr, pad);
      pad += arr.length;
    }
    return result;
  }
  const hexes$1 = Array.from({ length: 256 }, (v2, i2) => i2.toString(16).padStart(2, "0"));
  function bytesToHex$1(uint8a) {
    if (!(uint8a instanceof Uint8Array))
      throw new Error("Uint8Array expected");
    let hex = "";
    for (let i2 = 0; i2 < uint8a.length; i2++) {
      hex += hexes$1[uint8a[i2]];
    }
    return hex;
  }
  function hexToBytes$1(hex) {
    if (typeof hex !== "string") {
      throw new TypeError("hexToBytes: expected string, got " + typeof hex);
    }
    if (hex.length % 2)
      throw new Error("hexToBytes: received invalid unpadded hex");
    const array = new Uint8Array(hex.length / 2);
    for (let i2 = 0; i2 < array.length; i2++) {
      const j2 = i2 * 2;
      const hexByte = hex.slice(j2, j2 + 2);
      const byte = Number.parseInt(hexByte, 16);
      if (Number.isNaN(byte) || byte < 0)
        throw new Error("Invalid byte sequence");
      array[i2] = byte;
    }
    return array;
  }
  function numberTo32BytesBE(num) {
    const length = 32;
    const hex = num.toString(16).padStart(length * 2, "0");
    return hexToBytes$1(hex);
  }
  function numberTo32BytesLE(num) {
    return numberTo32BytesBE(num).reverse();
  }
  function edIsNegative(num) {
    return (mod$2(num) & _1n$6) === _1n$6;
  }
  function bytesToNumberLE$1(uint8a) {
    if (!(uint8a instanceof Uint8Array))
      throw new Error("Expected Uint8Array");
    return BigInt("0x" + bytesToHex$1(Uint8Array.from(uint8a).reverse()));
  }
  const MAX_255B = BigInt("0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
  function bytes255ToNumberLE(bytes2) {
    return mod$2(bytesToNumberLE$1(bytes2) & MAX_255B);
  }
  function mod$2(a, b2 = CURVE.P) {
    const res = a % b2;
    return res >= _0n$5 ? res : b2 + res;
  }
  function invert$1(number, modulo = CURVE.P) {
    if (number === _0n$5 || modulo <= _0n$5) {
      throw new Error(`invert: expected positive integers, got n=${number} mod=${modulo}`);
    }
    let a = mod$2(number, modulo);
    let b2 = modulo;
    let x2 = _0n$5, u2 = _1n$6;
    while (a !== _0n$5) {
      const q = b2 / a;
      const r2 = b2 % a;
      const m2 = x2 - u2 * q;
      b2 = a, a = r2, x2 = u2, u2 = m2;
    }
    const gcd = b2;
    if (gcd !== _1n$6)
      throw new Error("invert: does not exist");
    return mod$2(x2, modulo);
  }
  function invertBatch(nums, p2 = CURVE.P) {
    const tmp = new Array(nums.length);
    const lastMultiplied = nums.reduce((acc, num, i2) => {
      if (num === _0n$5)
        return acc;
      tmp[i2] = acc;
      return mod$2(acc * num, p2);
    }, _1n$6);
    const inverted = invert$1(lastMultiplied, p2);
    nums.reduceRight((acc, num, i2) => {
      if (num === _0n$5)
        return acc;
      tmp[i2] = mod$2(acc * tmp[i2], p2);
      return mod$2(acc * num, p2);
    }, inverted);
    return tmp;
  }
  function pow2$1(x2, power) {
    const { P } = CURVE;
    let res = x2;
    while (power-- > _0n$5) {
      res *= res;
      res %= P;
    }
    return res;
  }
  function pow_2_252_3(x2) {
    const { P } = CURVE;
    const _5n2 = BigInt(5);
    const _10n = BigInt(10);
    const _20n = BigInt(20);
    const _40n = BigInt(40);
    const _80n = BigInt(80);
    const x22 = x2 * x2 % P;
    const b2 = x22 * x2 % P;
    const b4 = pow2$1(b2, _2n$5) * b2 % P;
    const b5 = pow2$1(b4, _1n$6) * x2 % P;
    const b10 = pow2$1(b5, _5n2) * b5 % P;
    const b20 = pow2$1(b10, _10n) * b10 % P;
    const b40 = pow2$1(b20, _20n) * b20 % P;
    const b80 = pow2$1(b40, _40n) * b40 % P;
    const b160 = pow2$1(b80, _80n) * b80 % P;
    const b240 = pow2$1(b160, _80n) * b80 % P;
    const b250 = pow2$1(b240, _10n) * b10 % P;
    const pow_p_5_8 = pow2$1(b250, _2n$5) * x2 % P;
    return { pow_p_5_8, b2 };
  }
  function uvRatio$1(u2, v2) {
    const v3 = mod$2(v2 * v2 * v2);
    const v7 = mod$2(v3 * v3 * v2);
    const pow3 = pow_2_252_3(u2 * v7).pow_p_5_8;
    let x2 = mod$2(u2 * v3 * pow3);
    const vx2 = mod$2(v2 * x2 * x2);
    const root1 = x2;
    const root2 = mod$2(x2 * SQRT_M1);
    const useRoot1 = vx2 === u2;
    const useRoot2 = vx2 === mod$2(-u2);
    const noRoot = vx2 === mod$2(-u2 * SQRT_M1);
    if (useRoot1)
      x2 = root1;
    if (useRoot2 || noRoot)
      x2 = root2;
    if (edIsNegative(x2))
      x2 = mod$2(-x2);
    return { isValid: useRoot1 || useRoot2, value: x2 };
  }
  function invertSqrt(number) {
    return uvRatio$1(_1n$6, number);
  }
  function modlLE(hash) {
    return mod$2(bytesToNumberLE$1(hash), CURVE.l);
  }
  function equalBytes$1(b1, b2) {
    if (b1.length !== b2.length) {
      return false;
    }
    for (let i2 = 0; i2 < b1.length; i2++) {
      if (b1[i2] !== b2[i2]) {
        return false;
      }
    }
    return true;
  }
  function ensureBytes$2(hex, expectedLength) {
    const bytes2 = hex instanceof Uint8Array ? Uint8Array.from(hex) : hexToBytes$1(hex);
    if (typeof expectedLength === "number" && bytes2.length !== expectedLength)
      throw new Error(`Expected ${expectedLength} bytes`);
    return bytes2;
  }
  function normalizeScalar(num, max, strict = true) {
    if (!max)
      throw new TypeError("Specify max value");
    if (typeof num === "number" && Number.isSafeInteger(num))
      num = BigInt(num);
    if (typeof num === "bigint" && num < max) {
      if (strict) {
        if (_0n$5 < num)
          return num;
      } else {
        if (_0n$5 <= num)
          return num;
      }
    }
    throw new TypeError("Expected valid scalar: 0 < scalar < max");
  }
  function adjustBytes25519(bytes2) {
    bytes2[0] &= 248;
    bytes2[31] &= 127;
    bytes2[31] |= 64;
    return bytes2;
  }
  function checkPrivateKey(key) {
    key = typeof key === "bigint" || typeof key === "number" ? numberTo32BytesBE(normalizeScalar(key, POW_2_256)) : ensureBytes$2(key);
    if (key.length !== 32)
      throw new Error(`Expected 32 bytes`);
    return key;
  }
  function getKeyFromHash(hashed) {
    const head = adjustBytes25519(hashed.slice(0, 32));
    const prefix = hashed.slice(32, 64);
    const scalar = modlLE(head);
    const point = Point.BASE.multiply(scalar);
    const pointBytes = point.toRawBytes();
    return { head, prefix, scalar, point, pointBytes };
  }
  let _sha512Sync;
  async function getExtendedPublicKey(key) {
    return getKeyFromHash(await utils.sha512(checkPrivateKey(key)));
  }
  Point.BASE._setWindowSize(8);
  const crypto$3 = {
    node: nodeCrypto,
    web: typeof self === "object" && "crypto" in self ? self.crypto : void 0
  };
  const utils = {
    bytesToHex: bytesToHex$1,
    hexToBytes: hexToBytes$1,
    concatBytes: concatBytes$2,
    getExtendedPublicKey,
    mod: mod$2,
    invert: invert$1,
    TORSION_SUBGROUP: [
      "0100000000000000000000000000000000000000000000000000000000000000",
      "c7176a703d4dd84fba3c0b760d10670f2a2053fa2c39ccc64ec7fd7792ac037a",
      "0000000000000000000000000000000000000000000000000000000000000080",
      "26e8958fc2b227b045c3f489f2ef98f0d5dfac05d3c63339b13802886d53fc05",
      "ecffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7f",
      "26e8958fc2b227b045c3f489f2ef98f0d5dfac05d3c63339b13802886d53fc85",
      "0000000000000000000000000000000000000000000000000000000000000000",
      "c7176a703d4dd84fba3c0b760d10670f2a2053fa2c39ccc64ec7fd7792ac03fa"
    ],
    hashToPrivateScalar: (hash) => {
      hash = ensureBytes$2(hash);
      if (hash.length < 40 || hash.length > 1024)
        throw new Error("Expected 40-1024 bytes of private key as per FIPS 186");
      return mod$2(bytesToNumberLE$1(hash), CURVE.l - _1n$6) + _1n$6;
    },
    randomBytes: (bytesLength = 32) => {
      if (crypto$3.web) {
        return crypto$3.web.getRandomValues(new Uint8Array(bytesLength));
      } else if (crypto$3.node) {
        const { randomBytes: randomBytes2 } = crypto$3.node;
        return new Uint8Array(randomBytes2(bytesLength).buffer);
      } else {
        throw new Error("The environment doesn't have randomBytes function");
      }
    },
    randomPrivateKey: () => {
      return utils.randomBytes(32);
    },
    sha512: async (...messages) => {
      const message = concatBytes$2(...messages);
      if (crypto$3.web) {
        const buffer = await crypto$3.web.subtle.digest("SHA-512", message.buffer);
        return new Uint8Array(buffer);
      } else if (crypto$3.node) {
        return Uint8Array.from(crypto$3.node.createHash("sha512").update(message).digest());
      } else {
        throw new Error("The environment doesn't have sha512 function");
      }
    },
    precompute(windowSize = 8, point = Point.BASE) {
      const cached = point.equals(Point.BASE) ? point : new Point(point.x, point.y);
      cached._setWindowSize(windowSize);
      cached.multiply(_2n$5);
      return cached;
    },
    sha512Sync: void 0
  };
  Object.defineProperties(utils, {
    sha512Sync: {
      configurable: false,
      get() {
        return _sha512Sync;
      },
      set(val) {
        if (!_sha512Sync)
          _sha512Sync = val;
      }
    }
  });
  function anumber(n2) {
    if (!Number.isSafeInteger(n2) || n2 < 0)
      throw new Error("positive integer expected, got " + n2);
  }
  function isBytes$2(a) {
    return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
  }
  function abytes$1(b2, ...lengths) {
    if (!isBytes$2(b2))
      throw new Error("Uint8Array expected");
    if (lengths.length > 0 && !lengths.includes(b2.length))
      throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b2.length);
  }
  function aexists(instance, checkFinished = true) {
    if (instance.destroyed)
      throw new Error("Hash instance has been destroyed");
    if (checkFinished && instance.finished)
      throw new Error("Hash#digest() has already been called");
  }
  function aoutput(out, instance) {
    abytes$1(out);
    const min = instance.outputLen;
    if (out.length < min) {
      throw new Error("digestInto() expects output buffer of length at least " + min);
    }
  }
  const U32_MASK64$1 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
  const _32n$1 = /* @__PURE__ */ BigInt(32);
  function fromBig$1(n2, le = false) {
    if (le)
      return { h: Number(n2 & U32_MASK64$1), l: Number(n2 >> _32n$1 & U32_MASK64$1) };
    return { h: Number(n2 >> _32n$1 & U32_MASK64$1) | 0, l: Number(n2 & U32_MASK64$1) | 0 };
  }
  function split$1(lst, le = false) {
    let Ah = new Uint32Array(lst.length);
    let Al = new Uint32Array(lst.length);
    for (let i2 = 0; i2 < lst.length; i2++) {
      const { h: h2, l } = fromBig$1(lst[i2], le);
      [Ah[i2], Al[i2]] = [h2, l];
    }
    return [Ah, Al];
  }
  const rotlSH$1 = (h2, l, s2) => h2 << s2 | l >>> 32 - s2;
  const rotlSL$1 = (h2, l, s2) => l << s2 | h2 >>> 32 - s2;
  const rotlBH$1 = (h2, l, s2) => l << s2 - 32 | h2 >>> 64 - s2;
  const rotlBL$1 = (h2, l, s2) => h2 << s2 - 32 | l >>> 64 - s2;
  const crypto$2 = typeof globalThis === "object" && "crypto" in globalThis ? globalThis.crypto : void 0;
  /*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */
  const u32 = (arr) => new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
  const isLE = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
  const byteSwap = (word) => word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
  function byteSwap32(arr) {
    for (let i2 = 0; i2 < arr.length; i2++) {
      arr[i2] = byteSwap(arr[i2]);
    }
  }
  function utf8ToBytes$1(str) {
    if (typeof str !== "string")
      throw new Error("utf8ToBytes expected string, got " + typeof str);
    return new Uint8Array(new TextEncoder().encode(str));
  }
  function toBytes$1(data) {
    if (typeof data === "string")
      data = utf8ToBytes$1(data);
    abytes$1(data);
    return data;
  }
  function concatBytes$1(...arrays) {
    let sum = 0;
    for (let i2 = 0; i2 < arrays.length; i2++) {
      const a = arrays[i2];
      abytes$1(a);
      sum += a.length;
    }
    const res = new Uint8Array(sum);
    for (let i2 = 0, pad = 0; i2 < arrays.length; i2++) {
      const a = arrays[i2];
      res.set(a, pad);
      pad += a.length;
    }
    return res;
  }
  let Hash$1 = class Hash {
    // Safe version that clones internal state
    clone() {
      return this._cloneInto();
    }
  };
  function wrapXOFConstructorWithOpts(hashCons) {
    const hashC = (msg, opts) => hashCons(opts).update(toBytes$1(msg)).digest();
    const tmp = hashCons({});
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = (opts) => hashCons(opts);
    return hashC;
  }
  function randomBytes$2(bytesLength = 32) {
    if (crypto$2 && typeof crypto$2.getRandomValues === "function") {
      return crypto$2.getRandomValues(new Uint8Array(bytesLength));
    }
    if (crypto$2 && typeof crypto$2.randomBytes === "function") {
      return crypto$2.randomBytes(bytesLength);
    }
    throw new Error("crypto.getRandomValues must be defined");
  }
  const SHA3_PI = [];
  const SHA3_ROTL = [];
  const _SHA3_IOTA = [];
  const _0n$4 = /* @__PURE__ */ BigInt(0);
  const _1n$5 = /* @__PURE__ */ BigInt(1);
  const _2n$4 = /* @__PURE__ */ BigInt(2);
  const _7n = /* @__PURE__ */ BigInt(7);
  const _256n = /* @__PURE__ */ BigInt(256);
  const _0x71n = /* @__PURE__ */ BigInt(113);
  for (let round = 0, R = _1n$5, x2 = 1, y2 = 0; round < 24; round++) {
    [x2, y2] = [y2, (2 * x2 + 3 * y2) % 5];
    SHA3_PI.push(2 * (5 * y2 + x2));
    SHA3_ROTL.push((round + 1) * (round + 2) / 2 % 64);
    let t2 = _0n$4;
    for (let j2 = 0; j2 < 7; j2++) {
      R = (R << _1n$5 ^ (R >> _7n) * _0x71n) % _256n;
      if (R & _2n$4)
        t2 ^= _1n$5 << (_1n$5 << /* @__PURE__ */ BigInt(j2)) - _1n$5;
    }
    _SHA3_IOTA.push(t2);
  }
  const [SHA3_IOTA_H, SHA3_IOTA_L] = /* @__PURE__ */ split$1(_SHA3_IOTA, true);
  const rotlH = (h2, l, s2) => s2 > 32 ? rotlBH$1(h2, l, s2) : rotlSH$1(h2, l, s2);
  const rotlL = (h2, l, s2) => s2 > 32 ? rotlBL$1(h2, l, s2) : rotlSL$1(h2, l, s2);
  function keccakP(s2, rounds = 24) {
    const B = new Uint32Array(5 * 2);
    for (let round = 24 - rounds; round < 24; round++) {
      for (let x2 = 0; x2 < 10; x2++)
        B[x2] = s2[x2] ^ s2[x2 + 10] ^ s2[x2 + 20] ^ s2[x2 + 30] ^ s2[x2 + 40];
      for (let x2 = 0; x2 < 10; x2 += 2) {
        const idx1 = (x2 + 8) % 10;
        const idx0 = (x2 + 2) % 10;
        const B0 = B[idx0];
        const B1 = B[idx0 + 1];
        const Th = rotlH(B0, B1, 1) ^ B[idx1];
        const Tl = rotlL(B0, B1, 1) ^ B[idx1 + 1];
        for (let y2 = 0; y2 < 50; y2 += 10) {
          s2[x2 + y2] ^= Th;
          s2[x2 + y2 + 1] ^= Tl;
        }
      }
      let curH = s2[2];
      let curL = s2[3];
      for (let t2 = 0; t2 < 24; t2++) {
        const shift = SHA3_ROTL[t2];
        const Th = rotlH(curH, curL, shift);
        const Tl = rotlL(curH, curL, shift);
        const PI = SHA3_PI[t2];
        curH = s2[PI];
        curL = s2[PI + 1];
        s2[PI] = Th;
        s2[PI + 1] = Tl;
      }
      for (let y2 = 0; y2 < 50; y2 += 10) {
        for (let x2 = 0; x2 < 10; x2++)
          B[x2] = s2[y2 + x2];
        for (let x2 = 0; x2 < 10; x2++)
          s2[y2 + x2] ^= ~B[(x2 + 2) % 10] & B[(x2 + 4) % 10];
      }
      s2[0] ^= SHA3_IOTA_H[round];
      s2[1] ^= SHA3_IOTA_L[round];
    }
    B.fill(0);
  }
  class Keccak extends Hash$1 {
    // NOTE: we accept arguments in bytes instead of bits here.
    constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24) {
      super();
      this.blockLen = blockLen;
      this.suffix = suffix;
      this.outputLen = outputLen;
      this.enableXOF = enableXOF;
      this.rounds = rounds;
      this.pos = 0;
      this.posOut = 0;
      this.finished = false;
      this.destroyed = false;
      anumber(outputLen);
      if (0 >= this.blockLen || this.blockLen >= 200)
        throw new Error("Sha3 supports only keccak-f1600 function");
      this.state = new Uint8Array(200);
      this.state32 = u32(this.state);
    }
    keccak() {
      if (!isLE)
        byteSwap32(this.state32);
      keccakP(this.state32, this.rounds);
      if (!isLE)
        byteSwap32(this.state32);
      this.posOut = 0;
      this.pos = 0;
    }
    update(data) {
      aexists(this);
      const { blockLen, state } = this;
      data = toBytes$1(data);
      const len = data.length;
      for (let pos = 0; pos < len; ) {
        const take = Math.min(blockLen - this.pos, len - pos);
        for (let i2 = 0; i2 < take; i2++)
          state[this.pos++] ^= data[pos++];
        if (this.pos === blockLen)
          this.keccak();
      }
      return this;
    }
    finish() {
      if (this.finished)
        return;
      this.finished = true;
      const { state, suffix, pos, blockLen } = this;
      state[pos] ^= suffix;
      if ((suffix & 128) !== 0 && pos === blockLen - 1)
        this.keccak();
      state[blockLen - 1] ^= 128;
      this.keccak();
    }
    writeInto(out) {
      aexists(this, false);
      abytes$1(out);
      this.finish();
      const bufferOut = this.state;
      const { blockLen } = this;
      for (let pos = 0, len = out.length; pos < len; ) {
        if (this.posOut >= blockLen)
          this.keccak();
        const take = Math.min(blockLen - this.posOut, len - pos);
        out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
        this.posOut += take;
        pos += take;
      }
      return out;
    }
    xofInto(out) {
      if (!this.enableXOF)
        throw new Error("XOF is not possible for this instance");
      return this.writeInto(out);
    }
    xof(bytes2) {
      anumber(bytes2);
      return this.xofInto(new Uint8Array(bytes2));
    }
    digestInto(out) {
      aoutput(out, this);
      if (this.finished)
        throw new Error("digest() was already called");
      this.writeInto(out);
      this.destroy();
      return out;
    }
    digest() {
      return this.digestInto(new Uint8Array(this.outputLen));
    }
    destroy() {
      this.destroyed = true;
      this.state.fill(0);
    }
    _cloneInto(to) {
      const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
      to || (to = new Keccak(blockLen, suffix, outputLen, enableXOF, rounds));
      to.state32.set(this.state32);
      to.pos = this.pos;
      to.posOut = this.posOut;
      to.finished = this.finished;
      to.rounds = rounds;
      to.suffix = suffix;
      to.outputLen = outputLen;
      to.enableXOF = enableXOF;
      to.destroyed = this.destroyed;
      return to;
    }
  }
  const genShake = (suffix, blockLen, outputLen) => wrapXOFConstructorWithOpts((opts = {}) => new Keccak(blockLen, suffix, opts.dkLen === void 0 ? outputLen : opts.dkLen, true));
  const shake128 = /* @__PURE__ */ genShake(31, 168, 128 / 8);
  const shake256 = /* @__PURE__ */ genShake(31, 136, 256 / 8);
  /*! noble-post-quantum - MIT License (c) 2024 Paul Miller (paulmillr.com) */
  const ensureBytes$1 = abytes$1;
  const randomBytes$1 = randomBytes$2;
  function equalBytes(a, b2) {
    if (a.length !== b2.length)
      return false;
    let diff = 0;
    for (let i2 = 0; i2 < a.length; i2++)
      diff |= a[i2] ^ b2[i2];
    return diff === 0;
  }
  function splitCoder(...lengths) {
    const getLength = (c2) => typeof c2 === "number" ? c2 : c2.bytesLen;
    const bytesLen = lengths.reduce((sum, a) => sum + getLength(a), 0);
    return {
      bytesLen,
      encode: (bufs) => {
        const res = new Uint8Array(bytesLen);
        for (let i2 = 0, pos = 0; i2 < lengths.length; i2++) {
          const c2 = lengths[i2];
          const l = getLength(c2);
          const b2 = typeof c2 === "number" ? bufs[i2] : c2.encode(bufs[i2]);
          ensureBytes$1(b2, l);
          res.set(b2, pos);
          if (typeof c2 !== "number")
            b2.fill(0);
          pos += l;
        }
        return res;
      },
      decode: (buf) => {
        ensureBytes$1(buf, bytesLen);
        const res = [];
        for (const c2 of lengths) {
          const l = getLength(c2);
          const b2 = buf.subarray(0, l);
          res.push(typeof c2 === "number" ? b2 : c2.decode(b2));
          buf = buf.subarray(l);
        }
        return res;
      }
    };
  }
  function vecCoder(c2, vecLen) {
    const bytesLen = vecLen * c2.bytesLen;
    return {
      bytesLen,
      encode: (u2) => {
        if (u2.length !== vecLen)
          throw new Error(`vecCoder.encode: wrong length=${u2.length}. Expected: ${vecLen}`);
        const res = new Uint8Array(bytesLen);
        for (let i2 = 0, pos = 0; i2 < u2.length; i2++) {
          const b2 = c2.encode(u2[i2]);
          res.set(b2, pos);
          b2.fill(0);
          pos += b2.length;
        }
        return res;
      },
      decode: (a) => {
        ensureBytes$1(a, bytesLen);
        const r2 = [];
        for (let i2 = 0; i2 < a.length; i2 += c2.bytesLen)
          r2.push(c2.decode(a.subarray(i2, i2 + c2.bytesLen)));
        return r2;
      }
    };
  }
  function cleanBytes(...list) {
    for (const t2 of list) {
      if (Array.isArray(t2))
        for (const b2 of t2)
          b2.fill(0);
      else
        t2.fill(0);
    }
  }
  function getMask(bits) {
    return (1 << bits) - 1;
  }
  /*! noble-post-quantum - MIT License (c) 2024 Paul Miller (paulmillr.com) */
  function bitReversal(n2, bits = 8) {
    const padded = n2.toString(2).padStart(8, "0");
    const sliced = padded.slice(-bits).padStart(7, "0");
    const revrsd = sliced.split("").reverse().join("");
    return Number.parseInt(revrsd, 2);
  }
  const genCrystals = (opts) => {
    const { newPoly: newPoly2, N: N2, Q: Q2, F: F2, ROOT_OF_UNITY: ROOT_OF_UNITY2, brvBits, isKyber } = opts;
    const mod2 = (a, modulo = Q2) => {
      const result = a % modulo | 0;
      return (result >= 0 ? result | 0 : modulo + result | 0) | 0;
    };
    const smod2 = (a, modulo = Q2) => {
      const r2 = mod2(a, modulo) | 0;
      return (r2 > modulo >> 1 ? r2 - modulo | 0 : r2) | 0;
    };
    function getZettas() {
      const out = newPoly2(N2);
      for (let i2 = 0; i2 < N2; i2++) {
        const b2 = bitReversal(i2, brvBits);
        const p2 = BigInt(ROOT_OF_UNITY2) ** BigInt(b2) % BigInt(Q2);
        out[i2] = Number(p2) | 0;
      }
      return out;
    }
    const nttZetas = getZettas();
    const LEN1 = isKyber ? 128 : N2;
    const LEN2 = isKyber ? 1 : 0;
    const NTT2 = {
      encode: (r2) => {
        for (let k = 1, len = 128; len > LEN2; len >>= 1) {
          for (let start = 0; start < N2; start += 2 * len) {
            const zeta = nttZetas[k++];
            for (let j2 = start; j2 < start + len; j2++) {
              const t2 = mod2(zeta * r2[j2 + len]);
              r2[j2 + len] = mod2(r2[j2] - t2) | 0;
              r2[j2] = mod2(r2[j2] + t2) | 0;
            }
          }
        }
        return r2;
      },
      decode: (r2) => {
        for (let k = LEN1 - 1, len = 1 + LEN2; len < LEN1 + LEN2; len <<= 1) {
          for (let start = 0; start < N2; start += 2 * len) {
            const zeta = nttZetas[k--];
            for (let j2 = start; j2 < start + len; j2++) {
              const t2 = r2[j2];
              r2[j2] = mod2(t2 + r2[j2 + len]);
              r2[j2 + len] = mod2(zeta * (r2[j2 + len] - t2));
            }
          }
        }
        for (let i2 = 0; i2 < r2.length; i2++)
          r2[i2] = mod2(F2 * r2[i2]);
        return r2;
      }
    };
    const bitsCoder2 = (d2, c2) => {
      const mask = getMask(d2);
      const bytesLen = d2 * (N2 / 8);
      return {
        bytesLen,
        encode: (poly) => {
          const r2 = new Uint8Array(bytesLen);
          for (let i2 = 0, buf = 0, bufLen = 0, pos = 0; i2 < poly.length; i2++) {
            buf |= (c2.encode(poly[i2]) & mask) << bufLen;
            bufLen += d2;
            for (; bufLen >= 8; bufLen -= 8, buf >>= 8)
              r2[pos++] = buf & getMask(bufLen);
          }
          return r2;
        },
        decode: (bytes2) => {
          const r2 = newPoly2(N2);
          for (let i2 = 0, buf = 0, bufLen = 0, pos = 0; i2 < bytes2.length; i2++) {
            buf |= bytes2[i2] << bufLen;
            bufLen += 8;
            for (; bufLen >= d2; bufLen -= d2, buf >>= d2)
              r2[pos++] = c2.decode(buf & mask);
          }
          return r2;
        }
      };
    };
    return { mod: mod2, smod: smod2, nttZetas, NTT: NTT2, bitsCoder: bitsCoder2 };
  };
  const createXofShake = (shake) => (seed, blockLen) => {
    if (!blockLen)
      blockLen = shake.blockLen;
    const _seed = new Uint8Array(seed.length + 2);
    _seed.set(seed);
    const seedLen = seed.length;
    const buf = new Uint8Array(blockLen);
    let h2 = shake.create({});
    let calls = 0;
    let xofs = 0;
    return {
      stats: () => ({ calls, xofs }),
      get: (x2, y2) => {
        _seed[seedLen + 0] = x2;
        _seed[seedLen + 1] = y2;
        h2.destroy();
        h2 = shake.create({}).update(_seed);
        calls++;
        return () => {
          xofs++;
          return h2.xofInto(buf);
        };
      },
      clean: () => {
        h2.destroy();
        buf.fill(0);
        _seed.fill(0);
      }
    };
  };
  const XOF128 = /* @__PURE__ */ createXofShake(shake128);
  const XOF256 = /* @__PURE__ */ createXofShake(shake256);
  /*! noble-post-quantum - MIT License (c) 2024 Paul Miller (paulmillr.com) */
  const N = 256;
  const Q = 8380417;
  const ROOT_OF_UNITY = 1753;
  const F = 8347681;
  const D = 13;
  const GAMMA2_1 = Math.floor((Q - 1) / 88) | 0;
  const GAMMA2_2 = Math.floor((Q - 1) / 32) | 0;
  const PARAMS = {
    2: { K: 4, L: 4, D, GAMMA1: 2 ** 17, GAMMA2: GAMMA2_1, TAU: 39, ETA: 2, OMEGA: 80 },
    3: { K: 6, L: 5, D, GAMMA1: 2 ** 19, GAMMA2: GAMMA2_2, TAU: 49, ETA: 4, OMEGA: 55 },
    5: { K: 8, L: 7, D, GAMMA1: 2 ** 19, GAMMA2: GAMMA2_2, TAU: 60, ETA: 2, OMEGA: 75 }
  };
  const newPoly = (n2) => new Int32Array(n2);
  const { mod: mod$1, smod, NTT, bitsCoder } = genCrystals({
    N,
    Q,
    F,
    ROOT_OF_UNITY,
    newPoly,
    isKyber: false,
    brvBits: 8
  });
  const id = (n2) => n2;
  const polyCoder = (d2, compress = id, verify = id) => bitsCoder(d2, {
    encode: (i2) => compress(verify(i2)),
    decode: (i2) => verify(compress(i2))
  });
  const polyAdd = (a, b2) => {
    for (let i2 = 0; i2 < a.length; i2++)
      a[i2] = mod$1(a[i2] + b2[i2]);
    return a;
  };
  const polySub = (a, b2) => {
    for (let i2 = 0; i2 < a.length; i2++)
      a[i2] = mod$1(a[i2] - b2[i2]);
    return a;
  };
  const polyShiftl = (p2) => {
    for (let i2 = 0; i2 < N; i2++)
      p2[i2] <<= D;
    return p2;
  };
  const polyChknorm = (p2, B) => {
    for (let i2 = 0; i2 < N; i2++)
      if (Math.abs(smod(p2[i2])) >= B)
        return true;
    return false;
  };
  const MultiplyNTTs = (a, b2) => {
    const c2 = newPoly(N);
    for (let i2 = 0; i2 < a.length; i2++)
      c2[i2] = mod$1(a[i2] * b2[i2]);
    return c2;
  };
  function RejNTTPoly(xof) {
    const r2 = newPoly(N);
    for (let j2 = 0; j2 < N; ) {
      const b2 = xof();
      if (b2.length % 3)
        throw new Error("RejNTTPoly: unaligned block");
      for (let i2 = 0; j2 < N && i2 <= b2.length - 3; i2 += 3) {
        const t2 = (b2[i2 + 0] | b2[i2 + 1] << 8 | b2[i2 + 2] << 16) & 8388607;
        if (t2 < Q)
          r2[j2++] = t2;
      }
    }
    return r2;
  }
  const EMPTY = new Uint8Array(0);
  function getDilithium(opts) {
    const { K, L, GAMMA1, GAMMA2, TAU, ETA, OMEGA } = opts;
    const { CRH_BYTES, TR_BYTES, C_TILDE_BYTES, XOF128: XOF1282, XOF256: XOF2562 } = opts;
    if (![2, 4].includes(ETA))
      throw new Error("Wrong ETA");
    if (![1 << 17, 1 << 19].includes(GAMMA1))
      throw new Error("Wrong GAMMA1");
    if (![GAMMA2_1, GAMMA2_2].includes(GAMMA2))
      throw new Error("Wrong GAMMA2");
    const BETA = TAU * ETA;
    const decompose = (r2) => {
      const rPlus = mod$1(r2);
      const r0 = smod(rPlus, 2 * GAMMA2) | 0;
      if (rPlus - r0 === Q - 1)
        return { r1: 0 | 0, r0: r0 - 1 | 0 };
      const r1 = Math.floor((rPlus - r0) / (2 * GAMMA2)) | 0;
      return { r1, r0 };
    };
    const HighBits = (r2) => decompose(r2).r1;
    const LowBits = (r2) => decompose(r2).r0;
    const MakeHint = (z2, r2) => {
      const res0 = z2 <= GAMMA2 || z2 > Q - GAMMA2 || z2 === Q - GAMMA2 && r2 === 0 ? 0 : 1;
      return res0;
    };
    const UseHint = (h2, r2) => {
      const m2 = Math.floor((Q - 1) / (2 * GAMMA2));
      const { r1, r0 } = decompose(r2);
      if (h2 === 1)
        return r0 > 0 ? mod$1(r1 + 1, m2) | 0 : mod$1(r1 - 1, m2) | 0;
      return r1 | 0;
    };
    const Power2Round = (r2) => {
      const rPlus = mod$1(r2);
      const r0 = smod(rPlus, 2 ** D) | 0;
      return { r1: Math.floor((rPlus - r0) / 2 ** D) | 0, r0 };
    };
    const hintCoder = {
      bytesLen: OMEGA + K,
      encode: (h2) => {
        if (h2 === false)
          throw new Error("hint.encode: hint is false");
        const res = new Uint8Array(OMEGA + K);
        for (let i2 = 0, k = 0; i2 < K; i2++) {
          for (let j2 = 0; j2 < N; j2++)
            if (h2[i2][j2] !== 0)
              res[k++] = j2;
          res[OMEGA + i2] = k;
        }
        return res;
      },
      decode: (buf) => {
        const h2 = [];
        let k = 0;
        for (let i2 = 0; i2 < K; i2++) {
          const hi = newPoly(N);
          if (buf[OMEGA + i2] < k || buf[OMEGA + i2] > OMEGA)
            return false;
          for (let j2 = k; j2 < buf[OMEGA + i2]; j2++) {
            if (j2 > k && buf[j2] <= buf[j2 - 1])
              return false;
            hi[buf[j2]] = 1;
          }
          k = buf[OMEGA + i2];
          h2.push(hi);
        }
        for (let j2 = k; j2 < OMEGA; j2++)
          if (buf[j2] !== 0)
            return false;
        return h2;
      }
    };
    const ETACoder = polyCoder(ETA === 2 ? 3 : 4, (i2) => ETA - i2, (i2) => {
      if (!(-ETA <= i2 && i2 <= ETA))
        throw new Error(`malformed key s1/s3 ${i2} outside of ETA range [${-ETA}, ${ETA}]`);
      return i2;
    });
    const T0Coder = polyCoder(13, (i2) => (1 << D - 1) - i2);
    const T1Coder = polyCoder(10);
    const ZCoder = polyCoder(GAMMA1 === 1 << 17 ? 18 : 20, (i2) => smod(GAMMA1 - i2));
    const W1Coder = polyCoder(GAMMA2 === GAMMA2_1 ? 6 : 4);
    const W1Vec = vecCoder(W1Coder, K);
    const publicCoder = splitCoder(32, vecCoder(T1Coder, K));
    const secretCoder = splitCoder(32, 32, TR_BYTES, vecCoder(ETACoder, L), vecCoder(ETACoder, K), vecCoder(T0Coder, K));
    const sigCoder = splitCoder(C_TILDE_BYTES, vecCoder(ZCoder, L), hintCoder);
    const CoefFromHalfByte = ETA === 2 ? (n2) => n2 < 15 ? 2 - n2 % 5 : false : (n2) => n2 < 9 ? 4 - n2 : false;
    function RejBoundedPoly(xof) {
      const r2 = newPoly(N);
      for (let j2 = 0; j2 < N; ) {
        const b2 = xof();
        for (let i2 = 0; j2 < N && i2 < b2.length; i2 += 1) {
          const d1 = CoefFromHalfByte(b2[i2] & 15);
          const d2 = CoefFromHalfByte(b2[i2] >> 4 & 15);
          if (d1 !== false)
            r2[j2++] = d1;
          if (j2 < N && d2 !== false)
            r2[j2++] = d2;
        }
      }
      return r2;
    }
    const SampleInBall = (seed) => {
      const pre = newPoly(N);
      const s2 = shake256.create({}).update(seed);
      const buf = new Uint8Array(shake256.blockLen);
      s2.xofInto(buf);
      const masks = buf.slice(0, 8);
      for (let i2 = N - TAU, pos = 8, maskPos = 0, maskBit = 0; i2 < N; i2++) {
        let b2 = i2 + 1;
        for (; b2 > i2; ) {
          b2 = buf[pos++];
          if (pos < shake256.blockLen)
            continue;
          s2.xofInto(buf);
          pos = 0;
        }
        pre[i2] = pre[b2];
        pre[b2] = 1 - ((masks[maskPos] >> maskBit++ & 1) << 1);
        if (maskBit >= 8) {
          maskPos++;
          maskBit = 0;
        }
      }
      return pre;
    };
    const polyPowerRound = (p2) => {
      const res0 = newPoly(N);
      const res1 = newPoly(N);
      for (let i2 = 0; i2 < p2.length; i2++) {
        const { r0, r1 } = Power2Round(p2[i2]);
        res0[i2] = r0;
        res1[i2] = r1;
      }
      return { r0: res0, r1: res1 };
    };
    const polyUseHint = (u2, h2) => {
      for (let i2 = 0; i2 < N; i2++)
        u2[i2] = UseHint(h2[i2], u2[i2]);
      return u2;
    };
    const polyMakeHint = (a, b2) => {
      const v2 = newPoly(N);
      let cnt = 0;
      for (let i2 = 0; i2 < N; i2++) {
        const h2 = MakeHint(a[i2], b2[i2]);
        v2[i2] = h2;
        cnt += h2;
      }
      return { v: v2, cnt };
    };
    const signRandBytes = 32;
    const seedCoder = splitCoder(32, 64, 32);
    const internal = {
      signRandBytes,
      keygen: (seed = randomBytes$1(32)) => {
        const seedDst = new Uint8Array(32 + 2);
        seedDst.set(seed);
        seedDst[32] = K;
        seedDst[33] = L;
        const [rho, rhoPrime, K_] = seedCoder.decode(shake256(seedDst, { dkLen: seedCoder.bytesLen }));
        const xofPrime = XOF2562(rhoPrime);
        const s1 = [];
        for (let i2 = 0; i2 < L; i2++)
          s1.push(RejBoundedPoly(xofPrime.get(i2 & 255, i2 >> 8 & 255)));
        const s2 = [];
        for (let i2 = L; i2 < L + K; i2++)
          s2.push(RejBoundedPoly(xofPrime.get(i2 & 255, i2 >> 8 & 255)));
        const s1Hat = s1.map((i2) => NTT.encode(i2.slice()));
        const t0 = [];
        const t1 = [];
        const xof = XOF1282(rho);
        const t2 = newPoly(N);
        for (let i2 = 0; i2 < K; i2++) {
          t2.fill(0);
          for (let j2 = 0; j2 < L; j2++) {
            const aij = RejNTTPoly(xof.get(j2, i2));
            polyAdd(t2, MultiplyNTTs(aij, s1Hat[j2]));
          }
          NTT.decode(t2);
          const { r0, r1 } = polyPowerRound(polyAdd(t2, s2[i2]));
          t0.push(r0);
          t1.push(r1);
        }
        const publicKey = publicCoder.encode([rho, t1]);
        const tr = shake256(publicKey, { dkLen: TR_BYTES });
        const secretKey = secretCoder.encode([rho, K_, tr, s1, s2, t0]);
        xof.clean();
        xofPrime.clean();
        cleanBytes(rho, rhoPrime, K_, s1, s2, s1Hat, t2, t0, t1, tr, seedDst);
        return { publicKey, secretKey };
      },
      // NOTE: random is optional.
      sign: (secretKey, msg, random) => {
        const [rho, _K, tr, s1, s2, t0] = secretCoder.decode(secretKey);
        const A2 = [];
        const xof = XOF1282(rho);
        for (let i2 = 0; i2 < K; i2++) {
          const pv = [];
          for (let j2 = 0; j2 < L; j2++)
            pv.push(RejNTTPoly(xof.get(j2, i2)));
          A2.push(pv);
        }
        xof.clean();
        for (let i2 = 0; i2 < L; i2++)
          NTT.encode(s1[i2]);
        for (let i2 = 0; i2 < K; i2++) {
          NTT.encode(s2[i2]);
          NTT.encode(t0[i2]);
        }
        const mu = shake256.create({ dkLen: CRH_BYTES }).update(tr).update(msg).digest();
        const rnd = random ? random : new Uint8Array(32);
        ensureBytes$1(rnd);
        const rhoprime = shake256.create({ dkLen: CRH_BYTES }).update(_K).update(rnd).update(mu).digest();
        ensureBytes$1(rhoprime, CRH_BYTES);
        const x256 = XOF2562(rhoprime, ZCoder.bytesLen);
        main_loop: for (let kappa = 0; ; ) {
          const y2 = [];
          for (let i2 = 0; i2 < L; i2++, kappa++)
            y2.push(ZCoder.decode(x256.get(kappa & 255, kappa >> 8)()));
          const z2 = y2.map((i2) => NTT.encode(i2.slice()));
          const w2 = [];
          for (let i2 = 0; i2 < K; i2++) {
            const wi = newPoly(N);
            for (let j2 = 0; j2 < L; j2++)
              polyAdd(wi, MultiplyNTTs(A2[i2][j2], z2[j2]));
            NTT.decode(wi);
            w2.push(wi);
          }
          const w1 = w2.map((j2) => j2.map(HighBits));
          const cTilde = shake256.create({ dkLen: C_TILDE_BYTES }).update(mu).update(W1Vec.encode(w1)).digest();
          const cHat = NTT.encode(SampleInBall(cTilde));
          const cs1 = s1.map((i2) => MultiplyNTTs(i2, cHat));
          for (let i2 = 0; i2 < L; i2++) {
            polyAdd(NTT.decode(cs1[i2]), y2[i2]);
            if (polyChknorm(cs1[i2], GAMMA1 - BETA))
              continue main_loop;
          }
          let cnt = 0;
          const h2 = [];
          for (let i2 = 0; i2 < K; i2++) {
            const cs2 = NTT.decode(MultiplyNTTs(s2[i2], cHat));
            const r0 = polySub(w2[i2], cs2).map(LowBits);
            if (polyChknorm(r0, GAMMA2 - BETA))
              continue main_loop;
            const ct0 = NTT.decode(MultiplyNTTs(t0[i2], cHat));
            if (polyChknorm(ct0, GAMMA2))
              continue main_loop;
            polyAdd(r0, ct0);
            const hint = polyMakeHint(r0, w1[i2]);
            h2.push(hint.v);
            cnt += hint.cnt;
          }
          if (cnt > OMEGA)
            continue;
          x256.clean();
          const res = sigCoder.encode([cTilde, cs1, h2]);
          cleanBytes(cTilde, cs1, h2, cHat, w1, w2, z2, y2, rhoprime, mu, s1, s2, t0, ...A2);
          return res;
        }
        throw new Error("Unreachable code path reached, report this error");
      },
      verify: (publicKey, msg, sig) => {
        const [rho, t1] = publicCoder.decode(publicKey);
        const tr = shake256(publicKey, { dkLen: TR_BYTES });
        if (sig.length !== sigCoder.bytesLen)
          return false;
        const [cTilde, z2, h2] = sigCoder.decode(sig);
        if (h2 === false)
          return false;
        for (let i2 = 0; i2 < L; i2++)
          if (polyChknorm(z2[i2], GAMMA1 - BETA))
            return false;
        const mu = shake256.create({ dkLen: CRH_BYTES }).update(tr).update(msg).digest();
        const c2 = NTT.encode(SampleInBall(cTilde));
        const zNtt = z2.map((i2) => i2.slice());
        for (let i2 = 0; i2 < L; i2++)
          NTT.encode(zNtt[i2]);
        const wTick1 = [];
        const xof = XOF1282(rho);
        for (let i2 = 0; i2 < K; i2++) {
          const ct12d = MultiplyNTTs(NTT.encode(polyShiftl(t1[i2])), c2);
          const Az = newPoly(N);
          for (let j2 = 0; j2 < L; j2++) {
            const aij = RejNTTPoly(xof.get(j2, i2));
            polyAdd(Az, MultiplyNTTs(aij, zNtt[j2]));
          }
          const wApprox = NTT.decode(polySub(Az, ct12d));
          wTick1.push(polyUseHint(wApprox, h2[i2]));
        }
        xof.clean();
        const c22 = shake256.create({ dkLen: C_TILDE_BYTES }).update(mu).update(W1Vec.encode(wTick1)).digest();
        for (const t2 of h2) {
          const sum = t2.reduce((acc, i2) => acc + i2, 0);
          if (!(sum <= OMEGA))
            return false;
        }
        for (const t2 of z2)
          if (polyChknorm(t2, GAMMA1 - BETA))
            return false;
        return equalBytes(cTilde, c22);
      }
    };
    const getMessage = (msg, ctx = EMPTY) => {
      ensureBytes$1(msg);
      ensureBytes$1(ctx);
      if (ctx.length > 255)
        throw new Error("context should be less than 255 bytes");
      return concatBytes$1(new Uint8Array([0, ctx.length]), ctx, msg);
    };
    return {
      internal,
      keygen: internal.keygen,
      signRandBytes: internal.signRandBytes,
      sign: (secretKey, msg, ctx = EMPTY, random) => {
        const M = getMessage(msg, ctx);
        const res = internal.sign(secretKey, M, random);
        M.fill(0);
        return res;
      },
      verify: (publicKey, msg, sig, ctx = EMPTY) => {
        return internal.verify(publicKey, getMessage(msg, ctx), sig);
      }
    };
  }
  const ml_dsa44 = /* @__PURE__ */ getDilithium({
    ...PARAMS[2],
    CRH_BYTES: 64,
    TR_BYTES: 64,
    C_TILDE_BYTES: 32,
    XOF128,
    XOF256
  });
  const ml_dsa65 = /* @__PURE__ */ getDilithium({
    ...PARAMS[3],
    CRH_BYTES: 64,
    TR_BYTES: 64,
    C_TILDE_BYTES: 48,
    XOF128,
    XOF256
  });
  const ml_dsa87 = /* @__PURE__ */ getDilithium({
    ...PARAMS[5],
    CRH_BYTES: 64,
    TR_BYTES: 64,
    C_TILDE_BYTES: 64,
    XOF128,
    XOF256
  });
  (function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  });
  (function(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t2[0] & 1) throw t2[1];
      return t2[1];
    }, trys: [], ops: [] }, f, y2, t2, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n2) {
      return function(v2) {
        return step([n2, v2]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y2 && (t2 = op[0] & 2 ? y2["return"] : op[0] ? y2["throw"] || ((t2 = y2["return"]) && t2.call(y2), 0) : y2.next) && !(t2 = t2.call(y2, op[1])).done) return t2;
        if (y2 = 0, t2) op = [op[0] & 2, t2.value];
        switch (op[0]) {
          case 0:
          case 1:
            t2 = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y2 = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t2 = _.trys, t2 = t2.length > 0 && t2[t2.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t2 || op[1] > t2[0] && op[1] < t2[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t2[1]) {
              _.label = t2[1];
              t2 = op;
              break;
            }
            if (t2 && _.label < t2[2]) {
              _.label = t2[2];
              _.ops.push(op);
              break;
            }
            if (t2[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y2 = 0;
      } finally {
        f = t2 = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  });
  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var lookup = typeof Uint8Array === "undefined" ? [] : new Uint8Array(256);
  for (var i$1 = 0; i$1 < chars.length; i$1++) {
    lookup[chars.charCodeAt(i$1)] = i$1;
  }
  var encode = function(arraybuffer) {
    var bytes2 = new Uint8Array(arraybuffer), i2, len = bytes2.length, base64 = "";
    for (i2 = 0; i2 < len; i2 += 3) {
      base64 += chars[bytes2[i2] >> 2];
      base64 += chars[(bytes2[i2] & 3) << 4 | bytes2[i2 + 1] >> 4];
      base64 += chars[(bytes2[i2 + 1] & 15) << 2 | bytes2[i2 + 2] >> 6];
      base64 += chars[bytes2[i2 + 2] & 63];
    }
    if (len % 3 === 2) {
      base64 = base64.substring(0, base64.length - 1) + "=";
    } else if (len % 3 === 1) {
      base64 = base64.substring(0, base64.length - 2) + "==";
    }
    return base64;
  };
  (function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  });
  (function(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t2[0] & 1) throw t2[1];
      return t2[1];
    }, trys: [], ops: [] }, f, y2, t2, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n2) {
      return function(v2) {
        return step([n2, v2]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y2 && (t2 = op[0] & 2 ? y2["return"] : op[0] ? y2["throw"] || ((t2 = y2["return"]) && t2.call(y2), 0) : y2.next) && !(t2 = t2.call(y2, op[1])).done) return t2;
        if (y2 = 0, t2) op = [op[0] & 2, t2.value];
        switch (op[0]) {
          case 0:
          case 1:
            t2 = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y2 = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t2 = _.trys, t2 = t2.length > 0 && t2[t2.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t2 || op[1] > t2[0] && op[1] < t2[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t2[1]) {
              _.label = t2[1];
              t2 = op;
              break;
            }
            if (t2 && _.label < t2[2]) {
              _.label = t2[2];
              _.ops.push(op);
              break;
            }
            if (t2[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y2 = 0;
      } finally {
        f = t2 = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  });
  const t = Symbol.for("@ts-pattern/matcher"), e = Symbol.for("@ts-pattern/isVariadic"), n = "@ts-pattern/anonymous-select-key", r = (t2) => Boolean(t2 && "object" == typeof t2), i = (e2) => e2 && !!e2[t], s = (n2, o2, c2) => {
    if (i(n2)) {
      const e2 = n2[t](), { matched: r2, selections: i2 } = e2.match(o2);
      return r2 && i2 && Object.keys(i2).forEach((t2) => c2(t2, i2[t2])), r2;
    }
    if (r(n2)) {
      if (!r(o2)) return false;
      if (Array.isArray(n2)) {
        if (!Array.isArray(o2)) return false;
        let t2 = [], r2 = [], a = [];
        for (const s2 of n2.keys()) {
          const o3 = n2[s2];
          i(o3) && o3[e] ? a.push(o3) : a.length ? r2.push(o3) : t2.push(o3);
        }
        if (a.length) {
          if (a.length > 1) throw new Error("Pattern error: Using `...P.array(...)` several times in a single pattern is not allowed.");
          if (o2.length < t2.length + r2.length) return false;
          const e2 = o2.slice(0, t2.length), n3 = 0 === r2.length ? [] : o2.slice(-r2.length), i2 = o2.slice(t2.length, 0 === r2.length ? Infinity : -r2.length);
          return t2.every((t3, n4) => s(t3, e2[n4], c2)) && r2.every((t3, e3) => s(t3, n3[e3], c2)) && (0 === a.length || s(a[0], i2, c2));
        }
        return n2.length === o2.length && n2.every((t3, e2) => s(t3, o2[e2], c2));
      }
      return Reflect.ownKeys(n2).every((e2) => {
        const r2 = n2[e2];
        return (e2 in o2 || i(a = r2) && "optional" === a[t]().matcherType) && s(r2, o2[e2], c2);
        var a;
      });
    }
    return Object.is(o2, n2);
  }, o = (e2) => {
    var n2, s2, a;
    return r(e2) ? i(e2) ? null != (n2 = null == (s2 = (a = e2[t]()).getSelectionKeys) ? void 0 : s2.call(a)) ? n2 : [] : Array.isArray(e2) ? c(e2, o) : c(Object.values(e2), o) : [];
  }, c = (t2, e2) => t2.reduce((t3, n2) => t3.concat(e2(n2)), []);
  function u(t2) {
    return Object.assign(t2, { optional: () => h(t2), and: (e2) => m(t2, e2), or: (e2) => d(t2, e2), select: (e2) => void 0 === e2 ? y(t2) : y(e2, t2) });
  }
  function h(e2) {
    return u({ [t]: () => ({ match: (t2) => {
      let n2 = {};
      const r2 = (t3, e3) => {
        n2[t3] = e3;
      };
      return void 0 === t2 ? (o(e2).forEach((t3) => r2(t3, void 0)), { matched: true, selections: n2 }) : { matched: s(e2, t2, r2), selections: n2 };
    }, getSelectionKeys: () => o(e2), matcherType: "optional" }) });
  }
  function m(...e2) {
    return u({ [t]: () => ({ match: (t2) => {
      let n2 = {};
      const r2 = (t3, e3) => {
        n2[t3] = e3;
      };
      return { matched: e2.every((e3) => s(e3, t2, r2)), selections: n2 };
    }, getSelectionKeys: () => c(e2, o), matcherType: "and" }) });
  }
  function d(...e2) {
    return u({ [t]: () => ({ match: (t2) => {
      let n2 = {};
      const r2 = (t3, e3) => {
        n2[t3] = e3;
      };
      return c(e2, o).forEach((t3) => r2(t3, void 0)), { matched: e2.some((e3) => s(e3, t2, r2)), selections: n2 };
    }, getSelectionKeys: () => c(e2, o), matcherType: "or" }) });
  }
  function p(e2) {
    return { [t]: () => ({ match: (t2) => ({ matched: Boolean(e2(t2)) }) }) };
  }
  function y(...e2) {
    const r2 = "string" == typeof e2[0] ? e2[0] : void 0, i2 = 2 === e2.length ? e2[1] : "string" == typeof e2[0] ? void 0 : e2[0];
    return u({ [t]: () => ({ match: (t2) => {
      let e3 = { [null != r2 ? r2 : n]: t2 };
      return { matched: void 0 === i2 || s(i2, t2, (t3, n2) => {
        e3[t3] = n2;
      }), selections: e3 };
    }, getSelectionKeys: () => [null != r2 ? r2 : n].concat(void 0 === i2 ? [] : o(i2)) }) });
  }
  function v(t2) {
    return "number" == typeof t2;
  }
  function b(t2) {
    return "string" == typeof t2;
  }
  function w(t2) {
    return "bigint" == typeof t2;
  }
  u(p(function(t2) {
    return true;
  }));
  const j = (t2) => Object.assign(u(t2), { startsWith: (e2) => {
    return j(m(t2, (n2 = e2, p((t3) => b(t3) && t3.startsWith(n2)))));
    var n2;
  }, endsWith: (e2) => {
    return j(m(t2, (n2 = e2, p((t3) => b(t3) && t3.endsWith(n2)))));
    var n2;
  }, minLength: (e2) => j(m(t2, ((t3) => p((e3) => b(e3) && e3.length >= t3))(e2))), length: (e2) => j(m(t2, ((t3) => p((e3) => b(e3) && e3.length === t3))(e2))), maxLength: (e2) => j(m(t2, ((t3) => p((e3) => b(e3) && e3.length <= t3))(e2))), includes: (e2) => {
    return j(m(t2, (n2 = e2, p((t3) => b(t3) && t3.includes(n2)))));
    var n2;
  }, regex: (e2) => {
    return j(m(t2, (n2 = e2, p((t3) => b(t3) && Boolean(t3.match(n2))))));
    var n2;
  } });
  j(p(b));
  const x = (t2) => Object.assign(u(t2), { between: (e2, n2) => x(m(t2, ((t3, e3) => p((n3) => v(n3) && t3 <= n3 && e3 >= n3))(e2, n2))), lt: (e2) => x(m(t2, ((t3) => p((e3) => v(e3) && e3 < t3))(e2))), gt: (e2) => x(m(t2, ((t3) => p((e3) => v(e3) && e3 > t3))(e2))), lte: (e2) => x(m(t2, ((t3) => p((e3) => v(e3) && e3 <= t3))(e2))), gte: (e2) => x(m(t2, ((t3) => p((e3) => v(e3) && e3 >= t3))(e2))), int: () => x(m(t2, p((t3) => v(t3) && Number.isInteger(t3)))), finite: () => x(m(t2, p((t3) => v(t3) && Number.isFinite(t3)))), positive: () => x(m(t2, p((t3) => v(t3) && t3 > 0))), negative: () => x(m(t2, p((t3) => v(t3) && t3 < 0))) });
  x(p(v));
  const A = (t2) => Object.assign(u(t2), { between: (e2, n2) => A(m(t2, ((t3, e3) => p((n3) => w(n3) && t3 <= n3 && e3 >= n3))(e2, n2))), lt: (e2) => A(m(t2, ((t3) => p((e3) => w(e3) && e3 < t3))(e2))), gt: (e2) => A(m(t2, ((t3) => p((e3) => w(e3) && e3 > t3))(e2))), lte: (e2) => A(m(t2, ((t3) => p((e3) => w(e3) && e3 <= t3))(e2))), gte: (e2) => A(m(t2, ((t3) => p((e3) => w(e3) && e3 >= t3))(e2))), positive: () => A(m(t2, p((t3) => w(t3) && t3 > 0))), negative: () => A(m(t2, p((t3) => w(t3) && t3 < 0))) });
  A(p(w));
  u(p(function(t2) {
    return "boolean" == typeof t2;
  }));
  u(p(function(t2) {
    return "symbol" == typeof t2;
  }));
  u(p(function(t2) {
    return null == t2;
  }));
  u(p(function(t2) {
    return null != t2;
  }));
  class W extends Error {
    constructor(t2) {
      let e2;
      try {
        e2 = JSON.stringify(t2);
      } catch (n2) {
        e2 = t2;
      }
      super(`Pattern matching error: no pattern matches value ${e2}`), this.input = void 0, this.input = t2;
    }
  }
  const $ = { matched: false, value: void 0 };
  function z(t2) {
    return new I(t2, $);
  }
  class I {
    constructor(t2, e2) {
      this.input = void 0, this.state = void 0, this.input = t2, this.state = e2;
    }
    with(...t2) {
      if (this.state.matched) return this;
      const e2 = t2[t2.length - 1], r2 = [t2[0]];
      let i2;
      3 === t2.length && "function" == typeof t2[1] ? i2 = t2[1] : t2.length > 2 && r2.push(...t2.slice(1, t2.length - 1));
      let o2 = false, c2 = {};
      const a = (t3, e3) => {
        o2 = true, c2[t3] = e3;
      }, u2 = !r2.some((t3) => s(t3, this.input, a)) || i2 && !Boolean(i2(this.input)) ? $ : { matched: true, value: e2(o2 ? n in c2 ? c2[n] : c2 : this.input, this.input) };
      return new I(this.input, u2);
    }
    when(t2, e2) {
      if (this.state.matched) return this;
      const n2 = Boolean(t2(this.input));
      return new I(this.input, n2 ? { matched: true, value: e2(this.input, this.input) } : $);
    }
    otherwise(t2) {
      return this.state.matched ? this.state.value : t2(this.input);
    }
    exhaustive() {
      if (this.state.matched) return this.state.value;
      throw new W(this.input);
    }
    run() {
      return this.exhaustive();
    }
    returnType() {
      return this;
    }
  }
  function isBytes$1(a) {
    return a instanceof Uint8Array || a != null && typeof a === "object" && a.constructor.name === "Uint8Array";
  }
  function bytes(b2, ...lengths) {
    if (!isBytes$1(b2))
      throw new Error("Uint8Array expected");
    if (lengths.length > 0 && !lengths.includes(b2.length))
      throw new Error(`Uint8Array expected of length ${lengths}, not of length=${b2.length}`);
  }
  function exists(instance, checkFinished = true) {
    if (instance.destroyed)
      throw new Error("Hash instance has been destroyed");
    if (checkFinished && instance.finished)
      throw new Error("Hash#digest() has already been called");
  }
  function output(out, instance) {
    bytes(out);
    const min = instance.outputLen;
    if (out.length < min) {
      throw new Error(`digestInto() expects output buffer of length at least ${min}`);
    }
  }
  const crypto$1 = typeof globalThis === "object" && "crypto" in globalThis ? globalThis.crypto : void 0;
  /*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */
  const createView = (arr) => new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
  new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
  function utf8ToBytes(str) {
    if (typeof str !== "string")
      throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
    return new Uint8Array(new TextEncoder().encode(str));
  }
  function toBytes(data) {
    if (typeof data === "string")
      data = utf8ToBytes(data);
    bytes(data);
    return data;
  }
  class Hash {
    // Safe version that clones internal state
    clone() {
      return this._cloneInto();
    }
  }
  function wrapConstructor(hashCons) {
    const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
    const tmp = hashCons();
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = () => hashCons();
    return hashC;
  }
  function randomBytes(bytesLength = 32) {
    if (crypto$1 && typeof crypto$1.getRandomValues === "function") {
      return crypto$1.getRandomValues(new Uint8Array(bytesLength));
    }
    if (crypto$1 && typeof crypto$1.randomBytes === "function") {
      return crypto$1.randomBytes(bytesLength);
    }
    throw new Error("crypto.getRandomValues must be defined");
  }
  function setBigUint64(view, byteOffset, value, isLE2) {
    if (typeof view.setBigUint64 === "function")
      return view.setBigUint64(byteOffset, value, isLE2);
    const _32n2 = BigInt(32);
    const _u32_max = BigInt(4294967295);
    const wh = Number(value >> _32n2 & _u32_max);
    const wl = Number(value & _u32_max);
    const h2 = isLE2 ? 4 : 0;
    const l = isLE2 ? 0 : 4;
    view.setUint32(byteOffset + h2, wh, isLE2);
    view.setUint32(byteOffset + l, wl, isLE2);
  }
  class HashMD extends Hash {
    constructor(blockLen, outputLen, padOffset, isLE2) {
      super();
      this.blockLen = blockLen;
      this.outputLen = outputLen;
      this.padOffset = padOffset;
      this.isLE = isLE2;
      this.finished = false;
      this.length = 0;
      this.pos = 0;
      this.destroyed = false;
      this.buffer = new Uint8Array(blockLen);
      this.view = createView(this.buffer);
    }
    update(data) {
      exists(this);
      const { view, buffer, blockLen } = this;
      data = toBytes(data);
      const len = data.length;
      for (let pos = 0; pos < len; ) {
        const take = Math.min(blockLen - this.pos, len - pos);
        if (take === blockLen) {
          const dataView = createView(data);
          for (; blockLen <= len - pos; pos += blockLen)
            this.process(dataView, pos);
          continue;
        }
        buffer.set(data.subarray(pos, pos + take), this.pos);
        this.pos += take;
        pos += take;
        if (this.pos === blockLen) {
          this.process(view, 0);
          this.pos = 0;
        }
      }
      this.length += data.length;
      this.roundClean();
      return this;
    }
    digestInto(out) {
      exists(this);
      output(out, this);
      this.finished = true;
      const { buffer, view, blockLen, isLE: isLE2 } = this;
      let { pos } = this;
      buffer[pos++] = 128;
      this.buffer.subarray(pos).fill(0);
      if (this.padOffset > blockLen - pos) {
        this.process(view, 0);
        pos = 0;
      }
      for (let i2 = pos; i2 < blockLen; i2++)
        buffer[i2] = 0;
      setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE2);
      this.process(view, 0);
      const oview = createView(out);
      const len = this.outputLen;
      if (len % 4)
        throw new Error("_sha2: outputLen should be aligned to 32bit");
      const outLen = len / 4;
      const state = this.get();
      if (outLen > state.length)
        throw new Error("_sha2: outputLen bigger than state");
      for (let i2 = 0; i2 < outLen; i2++)
        oview.setUint32(4 * i2, state[i2], isLE2);
    }
    digest() {
      const { buffer, outputLen } = this;
      this.digestInto(buffer);
      const res = buffer.slice(0, outputLen);
      this.destroy();
      return res;
    }
    _cloneInto(to) {
      to || (to = new this.constructor());
      to.set(...this.get());
      const { blockLen, buffer, length, finished, destroyed, pos } = this;
      to.length = length;
      to.pos = pos;
      to.finished = finished;
      to.destroyed = destroyed;
      if (length % blockLen)
        to.buffer.set(buffer);
      return to;
    }
  }
  const U32_MASK64 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
  const _32n = /* @__PURE__ */ BigInt(32);
  function fromBig(n2, le = false) {
    if (le)
      return { h: Number(n2 & U32_MASK64), l: Number(n2 >> _32n & U32_MASK64) };
    return { h: Number(n2 >> _32n & U32_MASK64) | 0, l: Number(n2 & U32_MASK64) | 0 };
  }
  function split(lst, le = false) {
    let Ah = new Uint32Array(lst.length);
    let Al = new Uint32Array(lst.length);
    for (let i2 = 0; i2 < lst.length; i2++) {
      const { h: h2, l } = fromBig(lst[i2], le);
      [Ah[i2], Al[i2]] = [h2, l];
    }
    return [Ah, Al];
  }
  const toBig = (h2, l) => BigInt(h2 >>> 0) << _32n | BigInt(l >>> 0);
  const shrSH = (h2, _l, s2) => h2 >>> s2;
  const shrSL = (h2, l, s2) => h2 << 32 - s2 | l >>> s2;
  const rotrSH = (h2, l, s2) => h2 >>> s2 | l << 32 - s2;
  const rotrSL = (h2, l, s2) => h2 << 32 - s2 | l >>> s2;
  const rotrBH = (h2, l, s2) => h2 << 64 - s2 | l >>> s2 - 32;
  const rotrBL = (h2, l, s2) => h2 >>> s2 - 32 | l << 64 - s2;
  const rotr32H = (_h, l) => l;
  const rotr32L = (h2, _l) => h2;
  const rotlSH = (h2, l, s2) => h2 << s2 | l >>> 32 - s2;
  const rotlSL = (h2, l, s2) => l << s2 | h2 >>> 32 - s2;
  const rotlBH = (h2, l, s2) => l << s2 - 32 | h2 >>> 64 - s2;
  const rotlBL = (h2, l, s2) => h2 << s2 - 32 | l >>> 64 - s2;
  function add(Ah, Al, Bh, Bl) {
    const l = (Al >>> 0) + (Bl >>> 0);
    return { h: Ah + Bh + (l / 2 ** 32 | 0) | 0, l: l | 0 };
  }
  const add3L = (Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0);
  const add3H = (low, Ah, Bh, Ch) => Ah + Bh + Ch + (low / 2 ** 32 | 0) | 0;
  const add4L = (Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0);
  const add4H = (low, Ah, Bh, Ch, Dh) => Ah + Bh + Ch + Dh + (low / 2 ** 32 | 0) | 0;
  const add5L = (Al, Bl, Cl, Dl, El) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0) + (El >>> 0);
  const add5H = (low, Ah, Bh, Ch, Dh, Eh) => Ah + Bh + Ch + Dh + Eh + (low / 2 ** 32 | 0) | 0;
  const u64 = {
    fromBig,
    split,
    toBig,
    shrSH,
    shrSL,
    rotrSH,
    rotrSL,
    rotrBH,
    rotrBL,
    rotr32H,
    rotr32L,
    rotlSH,
    rotlSL,
    rotlBH,
    rotlBL,
    add,
    add3L,
    add3H,
    add4L,
    add4H,
    add5H,
    add5L
  };
  const [SHA512_Kh, SHA512_Kl] = /* @__PURE__ */ (() => u64.split([
    "0x428a2f98d728ae22",
    "0x7137449123ef65cd",
    "0xb5c0fbcfec4d3b2f",
    "0xe9b5dba58189dbbc",
    "0x3956c25bf348b538",
    "0x59f111f1b605d019",
    "0x923f82a4af194f9b",
    "0xab1c5ed5da6d8118",
    "0xd807aa98a3030242",
    "0x12835b0145706fbe",
    "0x243185be4ee4b28c",
    "0x550c7dc3d5ffb4e2",
    "0x72be5d74f27b896f",
    "0x80deb1fe3b1696b1",
    "0x9bdc06a725c71235",
    "0xc19bf174cf692694",
    "0xe49b69c19ef14ad2",
    "0xefbe4786384f25e3",
    "0x0fc19dc68b8cd5b5",
    "0x240ca1cc77ac9c65",
    "0x2de92c6f592b0275",
    "0x4a7484aa6ea6e483",
    "0x5cb0a9dcbd41fbd4",
    "0x76f988da831153b5",
    "0x983e5152ee66dfab",
    "0xa831c66d2db43210",
    "0xb00327c898fb213f",
    "0xbf597fc7beef0ee4",
    "0xc6e00bf33da88fc2",
    "0xd5a79147930aa725",
    "0x06ca6351e003826f",
    "0x142929670a0e6e70",
    "0x27b70a8546d22ffc",
    "0x2e1b21385c26c926",
    "0x4d2c6dfc5ac42aed",
    "0x53380d139d95b3df",
    "0x650a73548baf63de",
    "0x766a0abb3c77b2a8",
    "0x81c2c92e47edaee6",
    "0x92722c851482353b",
    "0xa2bfe8a14cf10364",
    "0xa81a664bbc423001",
    "0xc24b8b70d0f89791",
    "0xc76c51a30654be30",
    "0xd192e819d6ef5218",
    "0xd69906245565a910",
    "0xf40e35855771202a",
    "0x106aa07032bbd1b8",
    "0x19a4c116b8d2d0c8",
    "0x1e376c085141ab53",
    "0x2748774cdf8eeb99",
    "0x34b0bcb5e19b48a8",
    "0x391c0cb3c5c95a63",
    "0x4ed8aa4ae3418acb",
    "0x5b9cca4f7763e373",
    "0x682e6ff3d6b2b8a3",
    "0x748f82ee5defb2fc",
    "0x78a5636f43172f60",
    "0x84c87814a1f0ab72",
    "0x8cc702081a6439ec",
    "0x90befffa23631e28",
    "0xa4506cebde82bde9",
    "0xbef9a3f7b2c67915",
    "0xc67178f2e372532b",
    "0xca273eceea26619c",
    "0xd186b8c721c0c207",
    "0xeada7dd6cde0eb1e",
    "0xf57d4f7fee6ed178",
    "0x06f067aa72176fba",
    "0x0a637dc5a2c898a6",
    "0x113f9804bef90dae",
    "0x1b710b35131c471b",
    "0x28db77f523047d84",
    "0x32caab7b40c72493",
    "0x3c9ebe0a15c9bebc",
    "0x431d67c49c100d4c",
    "0x4cc5d4becb3e42b6",
    "0x597f299cfc657e2a",
    "0x5fcb6fab3ad6faec",
    "0x6c44198c4a475817"
  ].map((n2) => BigInt(n2))))();
  const SHA512_W_H = /* @__PURE__ */ new Uint32Array(80);
  const SHA512_W_L = /* @__PURE__ */ new Uint32Array(80);
  class SHA512 extends HashMD {
    constructor() {
      super(128, 64, 16, false);
      this.Ah = 1779033703 | 0;
      this.Al = 4089235720 | 0;
      this.Bh = 3144134277 | 0;
      this.Bl = 2227873595 | 0;
      this.Ch = 1013904242 | 0;
      this.Cl = 4271175723 | 0;
      this.Dh = 2773480762 | 0;
      this.Dl = 1595750129 | 0;
      this.Eh = 1359893119 | 0;
      this.El = 2917565137 | 0;
      this.Fh = 2600822924 | 0;
      this.Fl = 725511199 | 0;
      this.Gh = 528734635 | 0;
      this.Gl = 4215389547 | 0;
      this.Hh = 1541459225 | 0;
      this.Hl = 327033209 | 0;
    }
    // prettier-ignore
    get() {
      const { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
      return [Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl];
    }
    // prettier-ignore
    set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl) {
      this.Ah = Ah | 0;
      this.Al = Al | 0;
      this.Bh = Bh | 0;
      this.Bl = Bl | 0;
      this.Ch = Ch | 0;
      this.Cl = Cl | 0;
      this.Dh = Dh | 0;
      this.Dl = Dl | 0;
      this.Eh = Eh | 0;
      this.El = El | 0;
      this.Fh = Fh | 0;
      this.Fl = Fl | 0;
      this.Gh = Gh | 0;
      this.Gl = Gl | 0;
      this.Hh = Hh | 0;
      this.Hl = Hl | 0;
    }
    process(view, offset) {
      for (let i2 = 0; i2 < 16; i2++, offset += 4) {
        SHA512_W_H[i2] = view.getUint32(offset);
        SHA512_W_L[i2] = view.getUint32(offset += 4);
      }
      for (let i2 = 16; i2 < 80; i2++) {
        const W15h = SHA512_W_H[i2 - 15] | 0;
        const W15l = SHA512_W_L[i2 - 15] | 0;
        const s0h = u64.rotrSH(W15h, W15l, 1) ^ u64.rotrSH(W15h, W15l, 8) ^ u64.shrSH(W15h, W15l, 7);
        const s0l = u64.rotrSL(W15h, W15l, 1) ^ u64.rotrSL(W15h, W15l, 8) ^ u64.shrSL(W15h, W15l, 7);
        const W2h = SHA512_W_H[i2 - 2] | 0;
        const W2l = SHA512_W_L[i2 - 2] | 0;
        const s1h = u64.rotrSH(W2h, W2l, 19) ^ u64.rotrBH(W2h, W2l, 61) ^ u64.shrSH(W2h, W2l, 6);
        const s1l = u64.rotrSL(W2h, W2l, 19) ^ u64.rotrBL(W2h, W2l, 61) ^ u64.shrSL(W2h, W2l, 6);
        const SUMl = u64.add4L(s0l, s1l, SHA512_W_L[i2 - 7], SHA512_W_L[i2 - 16]);
        const SUMh = u64.add4H(SUMl, s0h, s1h, SHA512_W_H[i2 - 7], SHA512_W_H[i2 - 16]);
        SHA512_W_H[i2] = SUMh | 0;
        SHA512_W_L[i2] = SUMl | 0;
      }
      let { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
      for (let i2 = 0; i2 < 80; i2++) {
        const sigma1h = u64.rotrSH(Eh, El, 14) ^ u64.rotrSH(Eh, El, 18) ^ u64.rotrBH(Eh, El, 41);
        const sigma1l = u64.rotrSL(Eh, El, 14) ^ u64.rotrSL(Eh, El, 18) ^ u64.rotrBL(Eh, El, 41);
        const CHIh = Eh & Fh ^ ~Eh & Gh;
        const CHIl = El & Fl ^ ~El & Gl;
        const T1ll = u64.add5L(Hl, sigma1l, CHIl, SHA512_Kl[i2], SHA512_W_L[i2]);
        const T1h = u64.add5H(T1ll, Hh, sigma1h, CHIh, SHA512_Kh[i2], SHA512_W_H[i2]);
        const T1l = T1ll | 0;
        const sigma0h = u64.rotrSH(Ah, Al, 28) ^ u64.rotrBH(Ah, Al, 34) ^ u64.rotrBH(Ah, Al, 39);
        const sigma0l = u64.rotrSL(Ah, Al, 28) ^ u64.rotrBL(Ah, Al, 34) ^ u64.rotrBL(Ah, Al, 39);
        const MAJh = Ah & Bh ^ Ah & Ch ^ Bh & Ch;
        const MAJl = Al & Bl ^ Al & Cl ^ Bl & Cl;
        Hh = Gh | 0;
        Hl = Gl | 0;
        Gh = Fh | 0;
        Gl = Fl | 0;
        Fh = Eh | 0;
        Fl = El | 0;
        ({ h: Eh, l: El } = u64.add(Dh | 0, Dl | 0, T1h | 0, T1l | 0));
        Dh = Ch | 0;
        Dl = Cl | 0;
        Ch = Bh | 0;
        Cl = Bl | 0;
        Bh = Ah | 0;
        Bl = Al | 0;
        const All = u64.add3L(T1l, sigma0l, MAJl);
        Ah = u64.add3H(All, T1h, sigma0h, MAJh);
        Al = All | 0;
      }
      ({ h: Ah, l: Al } = u64.add(this.Ah | 0, this.Al | 0, Ah | 0, Al | 0));
      ({ h: Bh, l: Bl } = u64.add(this.Bh | 0, this.Bl | 0, Bh | 0, Bl | 0));
      ({ h: Ch, l: Cl } = u64.add(this.Ch | 0, this.Cl | 0, Ch | 0, Cl | 0));
      ({ h: Dh, l: Dl } = u64.add(this.Dh | 0, this.Dl | 0, Dh | 0, Dl | 0));
      ({ h: Eh, l: El } = u64.add(this.Eh | 0, this.El | 0, Eh | 0, El | 0));
      ({ h: Fh, l: Fl } = u64.add(this.Fh | 0, this.Fl | 0, Fh | 0, Fl | 0));
      ({ h: Gh, l: Gl } = u64.add(this.Gh | 0, this.Gl | 0, Gh | 0, Gl | 0));
      ({ h: Hh, l: Hl } = u64.add(this.Hh | 0, this.Hl | 0, Hh | 0, Hl | 0));
      this.set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl);
    }
    roundClean() {
      SHA512_W_H.fill(0);
      SHA512_W_L.fill(0);
    }
    destroy() {
      this.buffer.fill(0);
      this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
  }
  const sha512 = /* @__PURE__ */ wrapConstructor(() => new SHA512());
  /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
  const _0n$3 = /* @__PURE__ */ BigInt(0);
  const _1n$4 = /* @__PURE__ */ BigInt(1);
  const _2n$3 = /* @__PURE__ */ BigInt(2);
  function isBytes(a) {
    return a instanceof Uint8Array || a != null && typeof a === "object" && a.constructor.name === "Uint8Array";
  }
  function abytes(item) {
    if (!isBytes(item))
      throw new Error("Uint8Array expected");
  }
  function abool(title, value) {
    if (typeof value !== "boolean")
      throw new Error(`${title} must be valid boolean, got "${value}".`);
  }
  const hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i2) => i2.toString(16).padStart(2, "0"));
  function bytesToHex(bytes2) {
    abytes(bytes2);
    let hex = "";
    for (let i2 = 0; i2 < bytes2.length; i2++) {
      hex += hexes[bytes2[i2]];
    }
    return hex;
  }
  function hexToNumber(hex) {
    if (typeof hex !== "string")
      throw new Error("hex string expected, got " + typeof hex);
    return BigInt(hex === "" ? "0" : `0x${hex}`);
  }
  const asciis = { _0: 48, _9: 57, _A: 65, _F: 70, _a: 97, _f: 102 };
  function asciiToBase16(char) {
    if (char >= asciis._0 && char <= asciis._9)
      return char - asciis._0;
    if (char >= asciis._A && char <= asciis._F)
      return char - (asciis._A - 10);
    if (char >= asciis._a && char <= asciis._f)
      return char - (asciis._a - 10);
    return;
  }
  function hexToBytes(hex) {
    if (typeof hex !== "string")
      throw new Error("hex string expected, got " + typeof hex);
    const hl = hex.length;
    const al = hl / 2;
    if (hl % 2)
      throw new Error("padded hex string expected, got unpadded hex of length " + hl);
    const array = new Uint8Array(al);
    for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
      const n1 = asciiToBase16(hex.charCodeAt(hi));
      const n2 = asciiToBase16(hex.charCodeAt(hi + 1));
      if (n1 === void 0 || n2 === void 0) {
        const char = hex[hi] + hex[hi + 1];
        throw new Error('hex string expected, got non-hex character "' + char + '" at index ' + hi);
      }
      array[ai] = n1 * 16 + n2;
    }
    return array;
  }
  function bytesToNumberBE(bytes2) {
    return hexToNumber(bytesToHex(bytes2));
  }
  function bytesToNumberLE(bytes2) {
    abytes(bytes2);
    return hexToNumber(bytesToHex(Uint8Array.from(bytes2).reverse()));
  }
  function numberToBytesBE(n2, len) {
    return hexToBytes(n2.toString(16).padStart(len * 2, "0"));
  }
  function numberToBytesLE(n2, len) {
    return numberToBytesBE(n2, len).reverse();
  }
  function ensureBytes(title, hex, expectedLength) {
    let res;
    if (typeof hex === "string") {
      try {
        res = hexToBytes(hex);
      } catch (e2) {
        throw new Error(`${title} must be valid hex string, got "${hex}". Cause: ${e2}`);
      }
    } else if (isBytes(hex)) {
      res = Uint8Array.from(hex);
    } else {
      throw new Error(`${title} must be hex string or Uint8Array`);
    }
    const len = res.length;
    if (typeof expectedLength === "number" && len !== expectedLength)
      throw new Error(`${title} expected ${expectedLength} bytes, got ${len}`);
    return res;
  }
  function concatBytes(...arrays) {
    let sum = 0;
    for (let i2 = 0; i2 < arrays.length; i2++) {
      const a = arrays[i2];
      abytes(a);
      sum += a.length;
    }
    const res = new Uint8Array(sum);
    for (let i2 = 0, pad = 0; i2 < arrays.length; i2++) {
      const a = arrays[i2];
      res.set(a, pad);
      pad += a.length;
    }
    return res;
  }
  const isPosBig = (n2) => typeof n2 === "bigint" && _0n$3 <= n2;
  function inRange(n2, min, max) {
    return isPosBig(n2) && isPosBig(min) && isPosBig(max) && min <= n2 && n2 < max;
  }
  function aInRange(title, n2, min, max) {
    if (!inRange(n2, min, max))
      throw new Error(`expected valid ${title}: ${min} <= n < ${max}, got ${typeof n2} ${n2}`);
  }
  function bitLen(n2) {
    let len;
    for (len = 0; n2 > _0n$3; n2 >>= _1n$4, len += 1)
      ;
    return len;
  }
  const bitMask = (n2) => (_2n$3 << BigInt(n2 - 1)) - _1n$4;
  const validatorFns = {
    bigint: (val) => typeof val === "bigint",
    function: (val) => typeof val === "function",
    boolean: (val) => typeof val === "boolean",
    string: (val) => typeof val === "string",
    stringOrUint8Array: (val) => typeof val === "string" || isBytes(val),
    isSafeInteger: (val) => Number.isSafeInteger(val),
    array: (val) => Array.isArray(val),
    field: (val, object) => object.Fp.isValid(val),
    hash: (val) => typeof val === "function" && Number.isSafeInteger(val.outputLen)
  };
  function validateObject(object, validators, optValidators = {}) {
    const checkField = (fieldName, type, isOptional) => {
      const checkVal = validatorFns[type];
      if (typeof checkVal !== "function")
        throw new Error(`Invalid validator "${type}", expected function`);
      const val = object[fieldName];
      if (isOptional && val === void 0)
        return;
      if (!checkVal(val, object)) {
        throw new Error(`Invalid param ${String(fieldName)}=${val} (${typeof val}), expected ${type}`);
      }
    };
    for (const [fieldName, type] of Object.entries(validators))
      checkField(fieldName, type, false);
    for (const [fieldName, type] of Object.entries(optValidators))
      checkField(fieldName, type, true);
    return object;
  }
  function memoized(fn) {
    const map = /* @__PURE__ */ new WeakMap();
    return (arg, ...args) => {
      const val = map.get(arg);
      if (val !== void 0)
        return val;
      const computed = fn(arg, ...args);
      map.set(arg, computed);
      return computed;
    };
  }
  /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
  const _0n$2 = BigInt(0), _1n$3 = BigInt(1), _2n$2 = BigInt(2), _3n = BigInt(3);
  const _4n = BigInt(4), _5n$1 = BigInt(5), _8n$2 = BigInt(8);
  BigInt(9);
  BigInt(16);
  function mod(a, b2) {
    const result = a % b2;
    return result >= _0n$2 ? result : b2 + result;
  }
  function pow(num, power, modulo) {
    if (modulo <= _0n$2 || power < _0n$2)
      throw new Error("Expected power/modulo > 0");
    if (modulo === _1n$3)
      return _0n$2;
    let res = _1n$3;
    while (power > _0n$2) {
      if (power & _1n$3)
        res = res * num % modulo;
      num = num * num % modulo;
      power >>= _1n$3;
    }
    return res;
  }
  function pow2(x2, power, modulo) {
    let res = x2;
    while (power-- > _0n$2) {
      res *= res;
      res %= modulo;
    }
    return res;
  }
  function invert(number, modulo) {
    if (number === _0n$2 || modulo <= _0n$2) {
      throw new Error(`invert: expected positive integers, got n=${number} mod=${modulo}`);
    }
    let a = mod(number, modulo);
    let b2 = modulo;
    let x2 = _0n$2, u2 = _1n$3;
    while (a !== _0n$2) {
      const q = b2 / a;
      const r2 = b2 % a;
      const m2 = x2 - u2 * q;
      b2 = a, a = r2, x2 = u2, u2 = m2;
    }
    const gcd = b2;
    if (gcd !== _1n$3)
      throw new Error("invert: does not exist");
    return mod(x2, modulo);
  }
  function tonelliShanks(P) {
    const legendreC = (P - _1n$3) / _2n$2;
    let Q2, S, Z;
    for (Q2 = P - _1n$3, S = 0; Q2 % _2n$2 === _0n$2; Q2 /= _2n$2, S++)
      ;
    for (Z = _2n$2; Z < P && pow(Z, legendreC, P) !== P - _1n$3; Z++)
      ;
    if (S === 1) {
      const p1div4 = (P + _1n$3) / _4n;
      return function tonelliFast(Fp2, n2) {
        const root = Fp2.pow(n2, p1div4);
        if (!Fp2.eql(Fp2.sqr(root), n2))
          throw new Error("Cannot find square root");
        return root;
      };
    }
    const Q1div2 = (Q2 + _1n$3) / _2n$2;
    return function tonelliSlow(Fp2, n2) {
      if (Fp2.pow(n2, legendreC) === Fp2.neg(Fp2.ONE))
        throw new Error("Cannot find square root");
      let r2 = S;
      let g = Fp2.pow(Fp2.mul(Fp2.ONE, Z), Q2);
      let x2 = Fp2.pow(n2, Q1div2);
      let b2 = Fp2.pow(n2, Q2);
      while (!Fp2.eql(b2, Fp2.ONE)) {
        if (Fp2.eql(b2, Fp2.ZERO))
          return Fp2.ZERO;
        let m2 = 1;
        for (let t2 = Fp2.sqr(b2); m2 < r2; m2++) {
          if (Fp2.eql(t2, Fp2.ONE))
            break;
          t2 = Fp2.sqr(t2);
        }
        const ge = Fp2.pow(g, _1n$3 << BigInt(r2 - m2 - 1));
        g = Fp2.sqr(ge);
        x2 = Fp2.mul(x2, ge);
        b2 = Fp2.mul(b2, g);
        r2 = m2;
      }
      return x2;
    };
  }
  function FpSqrt(P) {
    if (P % _4n === _3n) {
      const p1div4 = (P + _1n$3) / _4n;
      return function sqrt3mod4(Fp2, n2) {
        const root = Fp2.pow(n2, p1div4);
        if (!Fp2.eql(Fp2.sqr(root), n2))
          throw new Error("Cannot find square root");
        return root;
      };
    }
    if (P % _8n$2 === _5n$1) {
      const c1 = (P - _5n$1) / _8n$2;
      return function sqrt5mod8(Fp2, n2) {
        const n22 = Fp2.mul(n2, _2n$2);
        const v2 = Fp2.pow(n22, c1);
        const nv = Fp2.mul(n2, v2);
        const i2 = Fp2.mul(Fp2.mul(nv, _2n$2), v2);
        const root = Fp2.mul(nv, Fp2.sub(i2, Fp2.ONE));
        if (!Fp2.eql(Fp2.sqr(root), n2))
          throw new Error("Cannot find square root");
        return root;
      };
    }
    return tonelliShanks(P);
  }
  const isNegativeLE = (num, modulo) => (mod(num, modulo) & _1n$3) === _1n$3;
  const FIELD_FIELDS = [
    "create",
    "isValid",
    "is0",
    "neg",
    "inv",
    "sqrt",
    "sqr",
    "eql",
    "add",
    "sub",
    "mul",
    "pow",
    "div",
    "addN",
    "subN",
    "mulN",
    "sqrN"
  ];
  function validateField(field) {
    const initial = {
      ORDER: "bigint",
      MASK: "bigint",
      BYTES: "isSafeInteger",
      BITS: "isSafeInteger"
    };
    const opts = FIELD_FIELDS.reduce((map, val) => {
      map[val] = "function";
      return map;
    }, initial);
    return validateObject(field, opts);
  }
  function FpPow(f, num, power) {
    if (power < _0n$2)
      throw new Error("Expected power > 0");
    if (power === _0n$2)
      return f.ONE;
    if (power === _1n$3)
      return num;
    let p2 = f.ONE;
    let d2 = num;
    while (power > _0n$2) {
      if (power & _1n$3)
        p2 = f.mul(p2, d2);
      d2 = f.sqr(d2);
      power >>= _1n$3;
    }
    return p2;
  }
  function FpInvertBatch(f, nums) {
    const tmp = new Array(nums.length);
    const lastMultiplied = nums.reduce((acc, num, i2) => {
      if (f.is0(num))
        return acc;
      tmp[i2] = acc;
      return f.mul(acc, num);
    }, f.ONE);
    const inverted = f.inv(lastMultiplied);
    nums.reduceRight((acc, num, i2) => {
      if (f.is0(num))
        return acc;
      tmp[i2] = f.mul(acc, tmp[i2]);
      return f.mul(acc, num);
    }, inverted);
    return tmp;
  }
  function nLength(n2, nBitLength) {
    const _nBitLength = nBitLength !== void 0 ? nBitLength : n2.toString(2).length;
    const nByteLength = Math.ceil(_nBitLength / 8);
    return { nBitLength: _nBitLength, nByteLength };
  }
  function Field(ORDER, bitLen2, isLE2 = false, redef = {}) {
    if (ORDER <= _0n$2)
      throw new Error(`Expected Field ORDER > 0, got ${ORDER}`);
    const { nBitLength: BITS, nByteLength: BYTES } = nLength(ORDER, bitLen2);
    if (BYTES > 2048)
      throw new Error("Field lengths over 2048 bytes are not supported");
    const sqrtP = FpSqrt(ORDER);
    const f = Object.freeze({
      ORDER,
      BITS,
      BYTES,
      MASK: bitMask(BITS),
      ZERO: _0n$2,
      ONE: _1n$3,
      create: (num) => mod(num, ORDER),
      isValid: (num) => {
        if (typeof num !== "bigint")
          throw new Error(`Invalid field element: expected bigint, got ${typeof num}`);
        return _0n$2 <= num && num < ORDER;
      },
      is0: (num) => num === _0n$2,
      isOdd: (num) => (num & _1n$3) === _1n$3,
      neg: (num) => mod(-num, ORDER),
      eql: (lhs, rhs) => lhs === rhs,
      sqr: (num) => mod(num * num, ORDER),
      add: (lhs, rhs) => mod(lhs + rhs, ORDER),
      sub: (lhs, rhs) => mod(lhs - rhs, ORDER),
      mul: (lhs, rhs) => mod(lhs * rhs, ORDER),
      pow: (num, power) => FpPow(f, num, power),
      div: (lhs, rhs) => mod(lhs * invert(rhs, ORDER), ORDER),
      // Same as above, but doesn't normalize
      sqrN: (num) => num * num,
      addN: (lhs, rhs) => lhs + rhs,
      subN: (lhs, rhs) => lhs - rhs,
      mulN: (lhs, rhs) => lhs * rhs,
      inv: (num) => invert(num, ORDER),
      sqrt: redef.sqrt || ((n2) => sqrtP(f, n2)),
      invertBatch: (lst) => FpInvertBatch(f, lst),
      // TODO: do we really need constant cmov?
      // We don't have const-time bigints anyway, so probably will be not very useful
      cmov: (a, b2, c2) => c2 ? b2 : a,
      toBytes: (num) => isLE2 ? numberToBytesLE(num, BYTES) : numberToBytesBE(num, BYTES),
      fromBytes: (bytes2) => {
        if (bytes2.length !== BYTES)
          throw new Error(`Fp.fromBytes: expected ${BYTES}, got ${bytes2.length}`);
        return isLE2 ? bytesToNumberLE(bytes2) : bytesToNumberBE(bytes2);
      }
    });
    return Object.freeze(f);
  }
  /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
  const _0n$1 = BigInt(0);
  const _1n$2 = BigInt(1);
  const pointPrecomputes = /* @__PURE__ */ new WeakMap();
  const pointWindowSizes = /* @__PURE__ */ new WeakMap();
  function wNAF(c2, bits) {
    const constTimeNegate2 = (condition, item) => {
      const neg = item.negate();
      return condition ? neg : item;
    };
    const validateW = (W2) => {
      if (!Number.isSafeInteger(W2) || W2 <= 0 || W2 > bits)
        throw new Error(`Wrong window size=${W2}, should be [1..${bits}]`);
    };
    const opts = (W2) => {
      validateW(W2);
      const windows = Math.ceil(bits / W2) + 1;
      const windowSize = 2 ** (W2 - 1);
      return { windows, windowSize };
    };
    return {
      constTimeNegate: constTimeNegate2,
      // non-const time multiplication ladder
      unsafeLadder(elm, n2) {
        let p2 = c2.ZERO;
        let d2 = elm;
        while (n2 > _0n$1) {
          if (n2 & _1n$2)
            p2 = p2.add(d2);
          d2 = d2.double();
          n2 >>= _1n$2;
        }
        return p2;
      },
      /**
       * Creates a wNAF precomputation window. Used for caching.
       * Default window size is set by `utils.precompute()` and is equal to 8.
       * Number of precomputed points depends on the curve size:
       * 2^(𝑊−1) * (Math.ceil(𝑛 / 𝑊) + 1), where:
       * - 𝑊 is the window size
       * - 𝑛 is the bitlength of the curve order.
       * For a 256-bit curve and window size 8, the number of precomputed points is 128 * 33 = 4224.
       * @returns precomputed point tables flattened to a single array
       */
      precomputeWindow(elm, W2) {
        const { windows, windowSize } = opts(W2);
        const points = [];
        let p2 = elm;
        let base = p2;
        for (let window2 = 0; window2 < windows; window2++) {
          base = p2;
          points.push(base);
          for (let i2 = 1; i2 < windowSize; i2++) {
            base = base.add(p2);
            points.push(base);
          }
          p2 = base.double();
        }
        return points;
      },
      /**
       * Implements ec multiplication using precomputed tables and w-ary non-adjacent form.
       * @param W window size
       * @param precomputes precomputed tables
       * @param n scalar (we don't check here, but should be less than curve order)
       * @returns real and fake (for const-time) points
       */
      wNAF(W2, precomputes, n2) {
        const { windows, windowSize } = opts(W2);
        let p2 = c2.ZERO;
        let f = c2.BASE;
        const mask = BigInt(2 ** W2 - 1);
        const maxNumber = 2 ** W2;
        const shiftBy = BigInt(W2);
        for (let window2 = 0; window2 < windows; window2++) {
          const offset = window2 * windowSize;
          let wbits = Number(n2 & mask);
          n2 >>= shiftBy;
          if (wbits > windowSize) {
            wbits -= maxNumber;
            n2 += _1n$2;
          }
          const offset1 = offset;
          const offset2 = offset + Math.abs(wbits) - 1;
          const cond1 = window2 % 2 !== 0;
          const cond2 = wbits < 0;
          if (wbits === 0) {
            f = f.add(constTimeNegate2(cond1, precomputes[offset1]));
          } else {
            p2 = p2.add(constTimeNegate2(cond2, precomputes[offset2]));
          }
        }
        return { p: p2, f };
      },
      wNAFCached(P, n2, transform) {
        const W2 = pointWindowSizes.get(P) || 1;
        let comp = pointPrecomputes.get(P);
        if (!comp) {
          comp = this.precomputeWindow(P, W2);
          if (W2 !== 1)
            pointPrecomputes.set(P, transform(comp));
        }
        return this.wNAF(W2, comp, n2);
      },
      // We calculate precomputes for elliptic curve point multiplication
      // using windowed method. This specifies window size and
      // stores precomputed values. Usually only base point would be precomputed.
      setWindowSize(P, W2) {
        validateW(W2);
        pointWindowSizes.set(P, W2);
        pointPrecomputes.delete(P);
      }
    };
  }
  function pippenger(c2, field, points, scalars) {
    if (!Array.isArray(points) || !Array.isArray(scalars) || scalars.length !== points.length)
      throw new Error("arrays of points and scalars must have equal length");
    scalars.forEach((s2, i2) => {
      if (!field.isValid(s2))
        throw new Error(`wrong scalar at index ${i2}`);
    });
    points.forEach((p2, i2) => {
      if (!(p2 instanceof c2))
        throw new Error(`wrong point at index ${i2}`);
    });
    const wbits = bitLen(BigInt(points.length));
    const windowSize = wbits > 12 ? wbits - 3 : wbits > 4 ? wbits - 2 : wbits ? 2 : 1;
    const MASK = (1 << windowSize) - 1;
    const buckets = new Array(MASK + 1).fill(c2.ZERO);
    const lastBits = Math.floor((field.BITS - 1) / windowSize) * windowSize;
    let sum = c2.ZERO;
    for (let i2 = lastBits; i2 >= 0; i2 -= windowSize) {
      buckets.fill(c2.ZERO);
      for (let j2 = 0; j2 < scalars.length; j2++) {
        const scalar = scalars[j2];
        const wbits2 = Number(scalar >> BigInt(i2) & BigInt(MASK));
        buckets[wbits2] = buckets[wbits2].add(points[j2]);
      }
      let resI = c2.ZERO;
      for (let j2 = buckets.length - 1, sumI = c2.ZERO; j2 > 0; j2--) {
        sumI = sumI.add(buckets[j2]);
        resI = resI.add(sumI);
      }
      sum = sum.add(resI);
      if (i2 !== 0)
        for (let j2 = 0; j2 < windowSize; j2++)
          sum = sum.double();
    }
    return sum;
  }
  function validateBasic(curve) {
    validateField(curve.Fp);
    validateObject(curve, {
      n: "bigint",
      h: "bigint",
      Gx: "field",
      Gy: "field"
    }, {
      nBitLength: "isSafeInteger",
      nByteLength: "isSafeInteger"
    });
    return Object.freeze({
      ...nLength(curve.n, curve.nBitLength),
      ...curve,
      ...{ p: curve.Fp.ORDER }
    });
  }
  /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
  const _0n = BigInt(0), _1n$1 = BigInt(1), _2n$1 = BigInt(2), _8n$1 = BigInt(8);
  const VERIFY_DEFAULT = { zip215: true };
  function validateOpts(curve) {
    const opts = validateBasic(curve);
    validateObject(curve, {
      hash: "function",
      a: "bigint",
      d: "bigint",
      randomBytes: "function"
    }, {
      adjustScalarBytes: "function",
      domain: "function",
      uvRatio: "function",
      mapToCurve: "function"
    });
    return Object.freeze({ ...opts });
  }
  function twistedEdwards(curveDef) {
    const CURVE2 = validateOpts(curveDef);
    const { Fp: Fp2, n: CURVE_ORDER, prehash, hash: cHash, randomBytes: randomBytes2, nByteLength, h: cofactor } = CURVE2;
    const MASK = _2n$1 << BigInt(nByteLength * 8) - _1n$1;
    const modP = Fp2.create;
    const Fn = Field(CURVE2.n, CURVE2.nBitLength);
    const uvRatio2 = CURVE2.uvRatio || ((u2, v2) => {
      try {
        return { isValid: true, value: Fp2.sqrt(u2 * Fp2.inv(v2)) };
      } catch (e2) {
        return { isValid: false, value: _0n };
      }
    });
    const adjustScalarBytes2 = CURVE2.adjustScalarBytes || ((bytes2) => bytes2);
    const domain = CURVE2.domain || ((data, ctx, phflag) => {
      abool("phflag", phflag);
      if (ctx.length || phflag)
        throw new Error("Contexts/pre-hash are not supported");
      return data;
    });
    function aCoordinate(title, n2) {
      aInRange("coordinate " + title, n2, _0n, MASK);
    }
    function assertPoint(other) {
      if (!(other instanceof Point2))
        throw new Error("ExtendedPoint expected");
    }
    const toAffineMemo = memoized((p2, iz) => {
      const { ex: x2, ey: y2, ez: z2 } = p2;
      const is0 = p2.is0();
      if (iz == null)
        iz = is0 ? _8n$1 : Fp2.inv(z2);
      const ax = modP(x2 * iz);
      const ay = modP(y2 * iz);
      const zz = modP(z2 * iz);
      if (is0)
        return { x: _0n, y: _1n$1 };
      if (zz !== _1n$1)
        throw new Error("invZ was invalid");
      return { x: ax, y: ay };
    });
    const assertValidMemo = memoized((p2) => {
      const { a, d: d2 } = CURVE2;
      if (p2.is0())
        throw new Error("bad point: ZERO");
      const { ex: X, ey: Y, ez: Z, et: T } = p2;
      const X2 = modP(X * X);
      const Y2 = modP(Y * Y);
      const Z2 = modP(Z * Z);
      const Z4 = modP(Z2 * Z2);
      const aX2 = modP(X2 * a);
      const left = modP(Z2 * modP(aX2 + Y2));
      const right = modP(Z4 + modP(d2 * modP(X2 * Y2)));
      if (left !== right)
        throw new Error("bad point: equation left != right (1)");
      const XY = modP(X * Y);
      const ZT = modP(Z * T);
      if (XY !== ZT)
        throw new Error("bad point: equation left != right (2)");
      return true;
    });
    class Point2 {
      constructor(ex, ey, ez, et) {
        this.ex = ex;
        this.ey = ey;
        this.ez = ez;
        this.et = et;
        aCoordinate("x", ex);
        aCoordinate("y", ey);
        aCoordinate("z", ez);
        aCoordinate("t", et);
        Object.freeze(this);
      }
      get x() {
        return this.toAffine().x;
      }
      get y() {
        return this.toAffine().y;
      }
      static fromAffine(p2) {
        if (p2 instanceof Point2)
          throw new Error("extended point not allowed");
        const { x: x2, y: y2 } = p2 || {};
        aCoordinate("x", x2);
        aCoordinate("y", y2);
        return new Point2(x2, y2, _1n$1, modP(x2 * y2));
      }
      static normalizeZ(points) {
        const toInv = Fp2.invertBatch(points.map((p2) => p2.ez));
        return points.map((p2, i2) => p2.toAffine(toInv[i2])).map(Point2.fromAffine);
      }
      // Multiscalar Multiplication
      static msm(points, scalars) {
        return pippenger(Point2, Fn, points, scalars);
      }
      // "Private method", don't use it directly
      _setWindowSize(windowSize) {
        wnaf.setWindowSize(this, windowSize);
      }
      // Not required for fromHex(), which always creates valid points.
      // Could be useful for fromAffine().
      assertValidity() {
        assertValidMemo(this);
      }
      // Compare one point to another.
      equals(other) {
        assertPoint(other);
        const { ex: X1, ey: Y1, ez: Z1 } = this;
        const { ex: X2, ey: Y2, ez: Z2 } = other;
        const X1Z2 = modP(X1 * Z2);
        const X2Z1 = modP(X2 * Z1);
        const Y1Z2 = modP(Y1 * Z2);
        const Y2Z1 = modP(Y2 * Z1);
        return X1Z2 === X2Z1 && Y1Z2 === Y2Z1;
      }
      is0() {
        return this.equals(Point2.ZERO);
      }
      negate() {
        return new Point2(modP(-this.ex), this.ey, this.ez, modP(-this.et));
      }
      // Fast algo for doubling Extended Point.
      // https://hyperelliptic.org/EFD/g1p/auto-twisted-extended.html#doubling-dbl-2008-hwcd
      // Cost: 4M + 4S + 1*a + 6add + 1*2.
      double() {
        const { a } = CURVE2;
        const { ex: X1, ey: Y1, ez: Z1 } = this;
        const A2 = modP(X1 * X1);
        const B = modP(Y1 * Y1);
        const C = modP(_2n$1 * modP(Z1 * Z1));
        const D2 = modP(a * A2);
        const x1y1 = X1 + Y1;
        const E = modP(modP(x1y1 * x1y1) - A2 - B);
        const G2 = D2 + B;
        const F2 = G2 - C;
        const H = D2 - B;
        const X3 = modP(E * F2);
        const Y3 = modP(G2 * H);
        const T3 = modP(E * H);
        const Z3 = modP(F2 * G2);
        return new Point2(X3, Y3, Z3, T3);
      }
      // Fast algo for adding 2 Extended Points.
      // https://hyperelliptic.org/EFD/g1p/auto-twisted-extended.html#addition-add-2008-hwcd
      // Cost: 9M + 1*a + 1*d + 7add.
      add(other) {
        assertPoint(other);
        const { a, d: d2 } = CURVE2;
        const { ex: X1, ey: Y1, ez: Z1, et: T1 } = this;
        const { ex: X2, ey: Y2, ez: Z2, et: T2 } = other;
        if (a === BigInt(-1)) {
          const A3 = modP((Y1 - X1) * (Y2 + X2));
          const B2 = modP((Y1 + X1) * (Y2 - X2));
          const F3 = modP(B2 - A3);
          if (F3 === _0n)
            return this.double();
          const C2 = modP(Z1 * _2n$1 * T2);
          const D3 = modP(T1 * _2n$1 * Z2);
          const E2 = D3 + C2;
          const G3 = B2 + A3;
          const H2 = D3 - C2;
          const X32 = modP(E2 * F3);
          const Y32 = modP(G3 * H2);
          const T32 = modP(E2 * H2);
          const Z32 = modP(F3 * G3);
          return new Point2(X32, Y32, Z32, T32);
        }
        const A2 = modP(X1 * X2);
        const B = modP(Y1 * Y2);
        const C = modP(T1 * d2 * T2);
        const D2 = modP(Z1 * Z2);
        const E = modP((X1 + Y1) * (X2 + Y2) - A2 - B);
        const F2 = D2 - C;
        const G2 = D2 + C;
        const H = modP(B - a * A2);
        const X3 = modP(E * F2);
        const Y3 = modP(G2 * H);
        const T3 = modP(E * H);
        const Z3 = modP(F2 * G2);
        return new Point2(X3, Y3, Z3, T3);
      }
      subtract(other) {
        return this.add(other.negate());
      }
      wNAF(n2) {
        return wnaf.wNAFCached(this, n2, Point2.normalizeZ);
      }
      // Constant-time multiplication.
      multiply(scalar) {
        const n2 = scalar;
        aInRange("scalar", n2, _1n$1, CURVE_ORDER);
        const { p: p2, f } = this.wNAF(n2);
        return Point2.normalizeZ([p2, f])[0];
      }
      // Non-constant-time multiplication. Uses double-and-add algorithm.
      // It's faster, but should only be used when you don't care about
      // an exposed private key e.g. sig verification.
      // Does NOT allow scalars higher than CURVE.n.
      multiplyUnsafe(scalar) {
        const n2 = scalar;
        aInRange("scalar", n2, _0n, CURVE_ORDER);
        if (n2 === _0n)
          return I2;
        if (this.equals(I2) || n2 === _1n$1)
          return this;
        if (this.equals(G))
          return this.wNAF(n2).p;
        return wnaf.unsafeLadder(this, n2);
      }
      // Checks if point is of small order.
      // If you add something to small order point, you will have "dirty"
      // point with torsion component.
      // Multiplies point by cofactor and checks if the result is 0.
      isSmallOrder() {
        return this.multiplyUnsafe(cofactor).is0();
      }
      // Multiplies point by curve order and checks if the result is 0.
      // Returns `false` is the point is dirty.
      isTorsionFree() {
        return wnaf.unsafeLadder(this, CURVE_ORDER).is0();
      }
      // Converts Extended point to default (x, y) coordinates.
      // Can accept precomputed Z^-1 - for example, from invertBatch.
      toAffine(iz) {
        return toAffineMemo(this, iz);
      }
      clearCofactor() {
        const { h: cofactor2 } = CURVE2;
        if (cofactor2 === _1n$1)
          return this;
        return this.multiplyUnsafe(cofactor2);
      }
      // Converts hash string or Uint8Array to Point.
      // Uses algo from RFC8032 5.1.3.
      static fromHex(hex, zip215 = false) {
        const { d: d2, a } = CURVE2;
        const len = Fp2.BYTES;
        hex = ensureBytes("pointHex", hex, len);
        abool("zip215", zip215);
        const normed = hex.slice();
        const lastByte = hex[len - 1];
        normed[len - 1] = lastByte & ~128;
        const y2 = bytesToNumberLE(normed);
        const max = zip215 ? MASK : Fp2.ORDER;
        aInRange("pointHex.y", y2, _0n, max);
        const y22 = modP(y2 * y2);
        const u2 = modP(y22 - _1n$1);
        const v2 = modP(d2 * y22 - a);
        let { isValid, value: x2 } = uvRatio2(u2, v2);
        if (!isValid)
          throw new Error("Point.fromHex: invalid y coordinate");
        const isXOdd = (x2 & _1n$1) === _1n$1;
        const isLastByteOdd = (lastByte & 128) !== 0;
        if (!zip215 && x2 === _0n && isLastByteOdd)
          throw new Error("Point.fromHex: x=0 and x_0=1");
        if (isLastByteOdd !== isXOdd)
          x2 = modP(-x2);
        return Point2.fromAffine({ x: x2, y: y2 });
      }
      static fromPrivateKey(privKey) {
        return getExtendedPublicKey2(privKey).point;
      }
      toRawBytes() {
        const { x: x2, y: y2 } = this.toAffine();
        const bytes2 = numberToBytesLE(y2, Fp2.BYTES);
        bytes2[bytes2.length - 1] |= x2 & _1n$1 ? 128 : 0;
        return bytes2;
      }
      toHex() {
        return bytesToHex(this.toRawBytes());
      }
    }
    Point2.BASE = new Point2(CURVE2.Gx, CURVE2.Gy, _1n$1, modP(CURVE2.Gx * CURVE2.Gy));
    Point2.ZERO = new Point2(_0n, _1n$1, _1n$1, _0n);
    const { BASE: G, ZERO: I2 } = Point2;
    const wnaf = wNAF(Point2, nByteLength * 8);
    function modN(a) {
      return mod(a, CURVE_ORDER);
    }
    function modN_LE(hash) {
      return modN(bytesToNumberLE(hash));
    }
    function getExtendedPublicKey2(key) {
      const len = nByteLength;
      key = ensureBytes("private key", key, len);
      const hashed = ensureBytes("hashed private key", cHash(key), 2 * len);
      const head = adjustScalarBytes2(hashed.slice(0, len));
      const prefix = hashed.slice(len, 2 * len);
      const scalar = modN_LE(head);
      const point = G.multiply(scalar);
      const pointBytes = point.toRawBytes();
      return { head, prefix, scalar, point, pointBytes };
    }
    function getPublicKey(privKey) {
      return getExtendedPublicKey2(privKey).pointBytes;
    }
    function hashDomainToScalar(context = new Uint8Array(), ...msgs) {
      const msg = concatBytes(...msgs);
      return modN_LE(cHash(domain(msg, ensureBytes("context", context), !!prehash)));
    }
    function sign(msg, privKey, options = {}) {
      msg = ensureBytes("message", msg);
      if (prehash)
        msg = prehash(msg);
      const { prefix, scalar, pointBytes } = getExtendedPublicKey2(privKey);
      const r2 = hashDomainToScalar(options.context, prefix, msg);
      const R = G.multiply(r2).toRawBytes();
      const k = hashDomainToScalar(options.context, R, pointBytes, msg);
      const s2 = modN(r2 + k * scalar);
      aInRange("signature.s", s2, _0n, CURVE_ORDER);
      const res = concatBytes(R, numberToBytesLE(s2, Fp2.BYTES));
      return ensureBytes("result", res, nByteLength * 2);
    }
    const verifyOpts = VERIFY_DEFAULT;
    function verify(sig, msg, publicKey, options = verifyOpts) {
      const { context, zip215 } = options;
      const len = Fp2.BYTES;
      sig = ensureBytes("signature", sig, 2 * len);
      msg = ensureBytes("message", msg);
      if (zip215 !== void 0)
        abool("zip215", zip215);
      if (prehash)
        msg = prehash(msg);
      const s2 = bytesToNumberLE(sig.slice(len, 2 * len));
      let A2, R, SB;
      try {
        A2 = Point2.fromHex(publicKey, zip215);
        R = Point2.fromHex(sig.slice(0, len), zip215);
        SB = G.multiplyUnsafe(s2);
      } catch (error) {
        return false;
      }
      if (!zip215 && A2.isSmallOrder())
        return false;
      const k = hashDomainToScalar(context, R.toRawBytes(), A2.toRawBytes(), msg);
      const RkA = R.add(A2.multiplyUnsafe(k));
      return RkA.subtract(SB).clearCofactor().equals(Point2.ZERO);
    }
    G._setWindowSize(8);
    const utils2 = {
      getExtendedPublicKey: getExtendedPublicKey2,
      // ed25519 private keys are uniform 32b. No need to check for modulo bias, like in secp256k1.
      randomPrivateKey: () => randomBytes2(Fp2.BYTES),
      /**
       * We're doing scalar multiplication (used in getPublicKey etc) with precomputed BASE_POINT
       * values. This slows down first getPublicKey() by milliseconds (see Speed section),
       * but allows to speed-up subsequent getPublicKey() calls up to 20x.
       * @param windowSize 2, 4, 8, 16
       */
      precompute(windowSize = 8, point = Point2.BASE) {
        point._setWindowSize(windowSize);
        point.multiply(BigInt(3));
        return point;
      }
    };
    return {
      CURVE: CURVE2,
      getPublicKey,
      sign,
      verify,
      ExtendedPoint: Point2,
      utils: utils2
    };
  }
  /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
  const ED25519_P = BigInt("57896044618658097711785492504343953926634992332820282019728792003956564819949");
  const ED25519_SQRT_M1 = /* @__PURE__ */ BigInt("19681161376707505956807079304988542015446066515923890162744021073123829784752");
  BigInt(0);
  const _1n = BigInt(1), _2n = BigInt(2);
  BigInt(3);
  const _5n = BigInt(5), _8n = BigInt(8);
  function ed25519_pow_2_252_3(x2) {
    const _10n = BigInt(10), _20n = BigInt(20), _40n = BigInt(40), _80n = BigInt(80);
    const P = ED25519_P;
    const x22 = x2 * x2 % P;
    const b2 = x22 * x2 % P;
    const b4 = pow2(b2, _2n, P) * b2 % P;
    const b5 = pow2(b4, _1n, P) * x2 % P;
    const b10 = pow2(b5, _5n, P) * b5 % P;
    const b20 = pow2(b10, _10n, P) * b10 % P;
    const b40 = pow2(b20, _20n, P) * b20 % P;
    const b80 = pow2(b40, _40n, P) * b40 % P;
    const b160 = pow2(b80, _80n, P) * b80 % P;
    const b240 = pow2(b160, _80n, P) * b80 % P;
    const b250 = pow2(b240, _10n, P) * b10 % P;
    const pow_p_5_8 = pow2(b250, _2n, P) * x2 % P;
    return { pow_p_5_8, b2 };
  }
  function adjustScalarBytes(bytes2) {
    bytes2[0] &= 248;
    bytes2[31] &= 127;
    bytes2[31] |= 64;
    return bytes2;
  }
  function uvRatio(u2, v2) {
    const P = ED25519_P;
    const v3 = mod(v2 * v2 * v2, P);
    const v7 = mod(v3 * v3 * v2, P);
    const pow3 = ed25519_pow_2_252_3(u2 * v7).pow_p_5_8;
    let x2 = mod(u2 * v3 * pow3, P);
    const vx2 = mod(v2 * x2 * x2, P);
    const root1 = x2;
    const root2 = mod(x2 * ED25519_SQRT_M1, P);
    const useRoot1 = vx2 === u2;
    const useRoot2 = vx2 === mod(-u2, P);
    const noRoot = vx2 === mod(-u2 * ED25519_SQRT_M1, P);
    if (useRoot1)
      x2 = root1;
    if (useRoot2 || noRoot)
      x2 = root2;
    if (isNegativeLE(x2, P))
      x2 = mod(-x2, P);
    return { isValid: useRoot1 || useRoot2, value: x2 };
  }
  const Fp = /* @__PURE__ */ (() => Field(ED25519_P, void 0, true))();
  const ed25519Defaults = /* @__PURE__ */ (() => ({
    // Param: a
    a: BigInt(-1),
    // Fp.create(-1) is proper; our way still works and is faster
    // d is equal to -121665/121666 over finite field.
    // Negative number is P - number, and division is invert(number, P)
    d: BigInt("37095705934669439343138083508754565189542113879843219016388785533085940283555"),
    // Finite field 𝔽p over which we'll do calculations; 2n**255n - 19n
    Fp,
    // Subgroup order: how many points curve has
    // 2n**252n + 27742317777372353535851937790883648493n;
    n: BigInt("7237005577332262213973186563042994240857116359379907606001950938285454250989"),
    // Cofactor
    h: _8n,
    // Base point (x, y) aka generator point
    Gx: BigInt("15112221349535400772501151409588531511454012693041857206046113283949847762202"),
    Gy: BigInt("46316835694926478169428394003475163141307993866256225615783033603165251855960"),
    hash: sha512,
    randomBytes,
    adjustScalarBytes,
    // dom2
    // Ratio of u to v. Allows us to combine inversion and square root. Uses algo from RFC8032 5.1.3.
    // Constant-time, u/√v
    uvRatio
  }))();
  const ed25519 = /* @__PURE__ */ (() => twistedEdwards(ed25519Defaults))();
  var dexie = { exports: {} };
  (function(module2, exports) {
    (function(global2, factory) {
      module2.exports = factory();
    })(commonjsGlobal, function() {
      /*! *****************************************************************************
      Copyright (c) Microsoft Corporation.
      Permission to use, copy, modify, and/or distribute this software for any
      purpose with or without fee is hereby granted.
      THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
      REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
      AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
      INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
      LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
      OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
      PERFORMANCE OF THIS SOFTWARE.
      ***************************************************************************** */
      var extendStatics = function(d2, b2) {
        extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
          d3.__proto__ = b3;
        } || function(d3, b3) {
          for (var p2 in b3) if (Object.prototype.hasOwnProperty.call(b3, p2)) d3[p2] = b3[p2];
        };
        return extendStatics(d2, b2);
      };
      function __extends2(d2, b2) {
        if (typeof b2 !== "function" && b2 !== null)
          throw new TypeError("Class extends value " + String(b2) + " is not a constructor or null");
        extendStatics(d2, b2);
        function __() {
          this.constructor = d2;
        }
        d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
      }
      var __assign2 = function() {
        __assign2 = Object.assign || function __assign3(t2) {
          for (var s2, i2 = 1, n2 = arguments.length; i2 < n2; i2++) {
            s2 = arguments[i2];
            for (var p2 in s2) if (Object.prototype.hasOwnProperty.call(s2, p2)) t2[p2] = s2[p2];
          }
          return t2;
        };
        return __assign2.apply(this, arguments);
      };
      function __spreadArray2(to, from, pack) {
        for (var i2 = 0, l = from.length, ar; i2 < l; i2++) {
          if (ar || !(i2 in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i2);
            ar[i2] = from[i2];
          }
        }
        return to.concat(ar || Array.prototype.slice.call(from));
      }
      var _global = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : commonjsGlobal;
      var keys = Object.keys;
      var isArray = Array.isArray;
      if (typeof Promise !== "undefined" && !_global.Promise) {
        _global.Promise = Promise;
      }
      function extend(obj, extension) {
        if (typeof extension !== "object")
          return obj;
        keys(extension).forEach(function(key) {
          obj[key] = extension[key];
        });
        return obj;
      }
      var getProto = Object.getPrototypeOf;
      var _hasOwn = {}.hasOwnProperty;
      function hasOwn(obj, prop) {
        return _hasOwn.call(obj, prop);
      }
      function props(proto, extension) {
        if (typeof extension === "function")
          extension = extension(getProto(proto));
        (typeof Reflect === "undefined" ? keys : Reflect.ownKeys)(extension).forEach(function(key) {
          setProp(proto, key, extension[key]);
        });
      }
      var defineProperty = Object.defineProperty;
      function setProp(obj, prop, functionOrGetSet, options) {
        defineProperty(obj, prop, extend(functionOrGetSet && hasOwn(functionOrGetSet, "get") && typeof functionOrGetSet.get === "function" ? { get: functionOrGetSet.get, set: functionOrGetSet.set, configurable: true } : { value: functionOrGetSet, configurable: true, writable: true }, options));
      }
      function derive(Child) {
        return {
          from: function(Parent) {
            Child.prototype = Object.create(Parent.prototype);
            setProp(Child.prototype, "constructor", Child);
            return {
              extend: props.bind(null, Child.prototype)
            };
          }
        };
      }
      var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
      function getPropertyDescriptor(obj, prop) {
        var pd = getOwnPropertyDescriptor(obj, prop);
        var proto;
        return pd || (proto = getProto(obj)) && getPropertyDescriptor(proto, prop);
      }
      var _slice = [].slice;
      function slice(args, start, end) {
        return _slice.call(args, start, end);
      }
      function override(origFunc, overridedFactory) {
        return overridedFactory(origFunc);
      }
      function assert(b2) {
        if (!b2)
          throw new Error("Assertion Failed");
      }
      function asap$1(fn) {
        if (_global.setImmediate)
          setImmediate(fn);
        else
          setTimeout(fn, 0);
      }
      function arrayToObject(array, extractor) {
        return array.reduce(function(result, item, i2) {
          var nameAndValue = extractor(item, i2);
          if (nameAndValue)
            result[nameAndValue[0]] = nameAndValue[1];
          return result;
        }, {});
      }
      function getByKeyPath(obj, keyPath) {
        if (typeof keyPath === "string" && hasOwn(obj, keyPath))
          return obj[keyPath];
        if (!keyPath)
          return obj;
        if (typeof keyPath !== "string") {
          var rv = [];
          for (var i2 = 0, l = keyPath.length; i2 < l; ++i2) {
            var val = getByKeyPath(obj, keyPath[i2]);
            rv.push(val);
          }
          return rv;
        }
        var period = keyPath.indexOf(".");
        if (period !== -1) {
          var innerObj = obj[keyPath.substr(0, period)];
          return innerObj == null ? void 0 : getByKeyPath(innerObj, keyPath.substr(period + 1));
        }
        return void 0;
      }
      function setByKeyPath(obj, keyPath, value) {
        if (!obj || keyPath === void 0)
          return;
        if ("isFrozen" in Object && Object.isFrozen(obj))
          return;
        if (typeof keyPath !== "string" && "length" in keyPath) {
          assert(typeof value !== "string" && "length" in value);
          for (var i2 = 0, l = keyPath.length; i2 < l; ++i2) {
            setByKeyPath(obj, keyPath[i2], value[i2]);
          }
        } else {
          var period = keyPath.indexOf(".");
          if (period !== -1) {
            var currentKeyPath = keyPath.substr(0, period);
            var remainingKeyPath = keyPath.substr(period + 1);
            if (remainingKeyPath === "")
              if (value === void 0) {
                if (isArray(obj) && !isNaN(parseInt(currentKeyPath)))
                  obj.splice(currentKeyPath, 1);
                else
                  delete obj[currentKeyPath];
              } else
                obj[currentKeyPath] = value;
            else {
              var innerObj = obj[currentKeyPath];
              if (!innerObj || !hasOwn(obj, currentKeyPath))
                innerObj = obj[currentKeyPath] = {};
              setByKeyPath(innerObj, remainingKeyPath, value);
            }
          } else {
            if (value === void 0) {
              if (isArray(obj) && !isNaN(parseInt(keyPath)))
                obj.splice(keyPath, 1);
              else
                delete obj[keyPath];
            } else
              obj[keyPath] = value;
          }
        }
      }
      function delByKeyPath(obj, keyPath) {
        if (typeof keyPath === "string")
          setByKeyPath(obj, keyPath, void 0);
        else if ("length" in keyPath)
          [].map.call(keyPath, function(kp) {
            setByKeyPath(obj, kp, void 0);
          });
      }
      function shallowClone(obj) {
        var rv = {};
        for (var m2 in obj) {
          if (hasOwn(obj, m2))
            rv[m2] = obj[m2];
        }
        return rv;
      }
      var concat = [].concat;
      function flatten(a) {
        return concat.apply([], a);
      }
      var intrinsicTypeNames = "BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(flatten([8, 16, 32, 64].map(function(num) {
        return ["Int", "Uint", "Float"].map(function(t2) {
          return t2 + num + "Array";
        });
      }))).filter(function(t2) {
        return _global[t2];
      });
      var intrinsicTypes = new Set(intrinsicTypeNames.map(function(t2) {
        return _global[t2];
      }));
      function cloneSimpleObjectTree(o2) {
        var rv = {};
        for (var k in o2)
          if (hasOwn(o2, k)) {
            var v2 = o2[k];
            rv[k] = !v2 || typeof v2 !== "object" || intrinsicTypes.has(v2.constructor) ? v2 : cloneSimpleObjectTree(v2);
          }
        return rv;
      }
      function objectIsEmpty(o2) {
        for (var k in o2)
          if (hasOwn(o2, k))
            return false;
        return true;
      }
      var circularRefs = null;
      function deepClone(any) {
        circularRefs = /* @__PURE__ */ new WeakMap();
        var rv = innerDeepClone(any);
        circularRefs = null;
        return rv;
      }
      function innerDeepClone(x2) {
        if (!x2 || typeof x2 !== "object")
          return x2;
        var rv = circularRefs.get(x2);
        if (rv)
          return rv;
        if (isArray(x2)) {
          rv = [];
          circularRefs.set(x2, rv);
          for (var i2 = 0, l = x2.length; i2 < l; ++i2) {
            rv.push(innerDeepClone(x2[i2]));
          }
        } else if (intrinsicTypes.has(x2.constructor)) {
          rv = x2;
        } else {
          var proto = getProto(x2);
          rv = proto === Object.prototype ? {} : Object.create(proto);
          circularRefs.set(x2, rv);
          for (var prop in x2) {
            if (hasOwn(x2, prop)) {
              rv[prop] = innerDeepClone(x2[prop]);
            }
          }
        }
        return rv;
      }
      var toString2 = {}.toString;
      function toStringTag(o2) {
        return toString2.call(o2).slice(8, -1);
      }
      var iteratorSymbol = typeof Symbol !== "undefined" ? Symbol.iterator : "@@iterator";
      var getIteratorOf = typeof iteratorSymbol === "symbol" ? function(x2) {
        var i2;
        return x2 != null && (i2 = x2[iteratorSymbol]) && i2.apply(x2);
      } : function() {
        return null;
      };
      function delArrayItem(a, x2) {
        var i2 = a.indexOf(x2);
        if (i2 >= 0)
          a.splice(i2, 1);
        return i2 >= 0;
      }
      var NO_CHAR_ARRAY = {};
      function getArrayOf(arrayLike) {
        var i2, a, x2, it;
        if (arguments.length === 1) {
          if (isArray(arrayLike))
            return arrayLike.slice();
          if (this === NO_CHAR_ARRAY && typeof arrayLike === "string")
            return [arrayLike];
          if (it = getIteratorOf(arrayLike)) {
            a = [];
            while (x2 = it.next(), !x2.done)
              a.push(x2.value);
            return a;
          }
          if (arrayLike == null)
            return [arrayLike];
          i2 = arrayLike.length;
          if (typeof i2 === "number") {
            a = new Array(i2);
            while (i2--)
              a[i2] = arrayLike[i2];
            return a;
          }
          return [arrayLike];
        }
        i2 = arguments.length;
        a = new Array(i2);
        while (i2--)
          a[i2] = arguments[i2];
        return a;
      }
      var isAsyncFunction = typeof Symbol !== "undefined" ? function(fn) {
        return fn[Symbol.toStringTag] === "AsyncFunction";
      } : function() {
        return false;
      };
      var dexieErrorNames = [
        "Modify",
        "Bulk",
        "OpenFailed",
        "VersionChange",
        "Schema",
        "Upgrade",
        "InvalidTable",
        "MissingAPI",
        "NoSuchDatabase",
        "InvalidArgument",
        "SubTransaction",
        "Unsupported",
        "Internal",
        "DatabaseClosed",
        "PrematureCommit",
        "ForeignAwait"
      ];
      var idbDomErrorNames = [
        "Unknown",
        "Constraint",
        "Data",
        "TransactionInactive",
        "ReadOnly",
        "Version",
        "NotFound",
        "InvalidState",
        "InvalidAccess",
        "Abort",
        "Timeout",
        "QuotaExceeded",
        "Syntax",
        "DataClone"
      ];
      var errorList = dexieErrorNames.concat(idbDomErrorNames);
      var defaultTexts = {
        VersionChanged: "Database version changed by other database connection",
        DatabaseClosed: "Database has been closed",
        Abort: "Transaction aborted",
        TransactionInactive: "Transaction has already completed or failed",
        MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb"
      };
      function DexieError(name, msg) {
        this.name = name;
        this.message = msg;
      }
      derive(DexieError).from(Error).extend({
        toString: function() {
          return this.name + ": " + this.message;
        }
      });
      function getMultiErrorMessage(msg, failures) {
        return msg + ". Errors: " + Object.keys(failures).map(function(key) {
          return failures[key].toString();
        }).filter(function(v2, i2, s2) {
          return s2.indexOf(v2) === i2;
        }).join("\n");
      }
      function ModifyError(msg, failures, successCount, failedKeys) {
        this.failures = failures;
        this.failedKeys = failedKeys;
        this.successCount = successCount;
        this.message = getMultiErrorMessage(msg, failures);
      }
      derive(ModifyError).from(DexieError);
      function BulkError(msg, failures) {
        this.name = "BulkError";
        this.failures = Object.keys(failures).map(function(pos) {
          return failures[pos];
        });
        this.failuresByPos = failures;
        this.message = getMultiErrorMessage(msg, this.failures);
      }
      derive(BulkError).from(DexieError);
      var errnames = errorList.reduce(function(obj, name) {
        return obj[name] = name + "Error", obj;
      }, {});
      var BaseException = DexieError;
      var exceptions = errorList.reduce(function(obj, name) {
        var fullName = name + "Error";
        function DexieError2(msgOrInner, inner) {
          this.name = fullName;
          if (!msgOrInner) {
            this.message = defaultTexts[name] || fullName;
            this.inner = null;
          } else if (typeof msgOrInner === "string") {
            this.message = "".concat(msgOrInner).concat(!inner ? "" : "\n " + inner);
            this.inner = inner || null;
          } else if (typeof msgOrInner === "object") {
            this.message = "".concat(msgOrInner.name, " ").concat(msgOrInner.message);
            this.inner = msgOrInner;
          }
        }
        derive(DexieError2).from(BaseException);
        obj[name] = DexieError2;
        return obj;
      }, {});
      exceptions.Syntax = SyntaxError;
      exceptions.Type = TypeError;
      exceptions.Range = RangeError;
      var exceptionMap = idbDomErrorNames.reduce(function(obj, name) {
        obj[name + "Error"] = exceptions[name];
        return obj;
      }, {});
      function mapError(domError, message) {
        if (!domError || domError instanceof DexieError || domError instanceof TypeError || domError instanceof SyntaxError || !domError.name || !exceptionMap[domError.name])
          return domError;
        var rv = new exceptionMap[domError.name](message || domError.message, domError);
        if ("stack" in domError) {
          setProp(rv, "stack", { get: function() {
            return this.inner.stack;
          } });
        }
        return rv;
      }
      var fullNameExceptions = errorList.reduce(function(obj, name) {
        if (["Syntax", "Type", "Range"].indexOf(name) === -1)
          obj[name + "Error"] = exceptions[name];
        return obj;
      }, {});
      fullNameExceptions.ModifyError = ModifyError;
      fullNameExceptions.DexieError = DexieError;
      fullNameExceptions.BulkError = BulkError;
      function nop() {
      }
      function mirror(val) {
        return val;
      }
      function pureFunctionChain(f1, f2) {
        if (f1 == null || f1 === mirror)
          return f2;
        return function(val) {
          return f2(f1(val));
        };
      }
      function callBoth(on1, on2) {
        return function() {
          on1.apply(this, arguments);
          on2.apply(this, arguments);
        };
      }
      function hookCreatingChain(f1, f2) {
        if (f1 === nop)
          return f2;
        return function() {
          var res = f1.apply(this, arguments);
          if (res !== void 0)
            arguments[0] = res;
          var onsuccess = this.onsuccess, onerror = this.onerror;
          this.onsuccess = null;
          this.onerror = null;
          var res2 = f2.apply(this, arguments);
          if (onsuccess)
            this.onsuccess = this.onsuccess ? callBoth(onsuccess, this.onsuccess) : onsuccess;
          if (onerror)
            this.onerror = this.onerror ? callBoth(onerror, this.onerror) : onerror;
          return res2 !== void 0 ? res2 : res;
        };
      }
      function hookDeletingChain(f1, f2) {
        if (f1 === nop)
          return f2;
        return function() {
          f1.apply(this, arguments);
          var onsuccess = this.onsuccess, onerror = this.onerror;
          this.onsuccess = this.onerror = null;
          f2.apply(this, arguments);
          if (onsuccess)
            this.onsuccess = this.onsuccess ? callBoth(onsuccess, this.onsuccess) : onsuccess;
          if (onerror)
            this.onerror = this.onerror ? callBoth(onerror, this.onerror) : onerror;
        };
      }
      function hookUpdatingChain(f1, f2) {
        if (f1 === nop)
          return f2;
        return function(modifications) {
          var res = f1.apply(this, arguments);
          extend(modifications, res);
          var onsuccess = this.onsuccess, onerror = this.onerror;
          this.onsuccess = null;
          this.onerror = null;
          var res2 = f2.apply(this, arguments);
          if (onsuccess)
            this.onsuccess = this.onsuccess ? callBoth(onsuccess, this.onsuccess) : onsuccess;
          if (onerror)
            this.onerror = this.onerror ? callBoth(onerror, this.onerror) : onerror;
          return res === void 0 ? res2 === void 0 ? void 0 : res2 : extend(res, res2);
        };
      }
      function reverseStoppableEventChain(f1, f2) {
        if (f1 === nop)
          return f2;
        return function() {
          if (f2.apply(this, arguments) === false)
            return false;
          return f1.apply(this, arguments);
        };
      }
      function promisableChain(f1, f2) {
        if (f1 === nop)
          return f2;
        return function() {
          var res = f1.apply(this, arguments);
          if (res && typeof res.then === "function") {
            var thiz = this, i2 = arguments.length, args = new Array(i2);
            while (i2--)
              args[i2] = arguments[i2];
            return res.then(function() {
              return f2.apply(thiz, args);
            });
          }
          return f2.apply(this, arguments);
        };
      }
      var debug = typeof location !== "undefined" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);
      function setDebug(value, filter) {
        debug = value;
      }
      var INTERNAL = {};
      var ZONE_ECHO_LIMIT = 100, _a$1 = typeof Promise === "undefined" ? [] : function() {
        var globalP = Promise.resolve();
        if (typeof crypto === "undefined" || !crypto.subtle)
          return [globalP, getProto(globalP), globalP];
        var nativeP = crypto.subtle.digest("SHA-512", new Uint8Array([0]));
        return [
          nativeP,
          getProto(nativeP),
          globalP
        ];
      }(), resolvedNativePromise = _a$1[0], nativePromiseProto = _a$1[1], resolvedGlobalPromise = _a$1[2], nativePromiseThen = nativePromiseProto && nativePromiseProto.then;
      var NativePromise = resolvedNativePromise && resolvedNativePromise.constructor;
      var patchGlobalPromise = !!resolvedGlobalPromise;
      function schedulePhysicalTick() {
        queueMicrotask(physicalTick);
      }
      var asap = function(callback, args) {
        microtickQueue.push([callback, args]);
        if (needsNewPhysicalTick) {
          schedulePhysicalTick();
          needsNewPhysicalTick = false;
        }
      };
      var isOutsideMicroTick = true, needsNewPhysicalTick = true, unhandledErrors = [], rejectingErrors = [], rejectionMapper = mirror;
      var globalPSD = {
        id: "global",
        global: true,
        ref: 0,
        unhandleds: [],
        onunhandled: nop,
        pgp: false,
        env: {},
        finalize: nop
      };
      var PSD = globalPSD;
      var microtickQueue = [];
      var numScheduledCalls = 0;
      var tickFinalizers = [];
      function DexiePromise(fn) {
        if (typeof this !== "object")
          throw new TypeError("Promises must be constructed via new");
        this._listeners = [];
        this._lib = false;
        var psd = this._PSD = PSD;
        if (typeof fn !== "function") {
          if (fn !== INTERNAL)
            throw new TypeError("Not a function");
          this._state = arguments[1];
          this._value = arguments[2];
          if (this._state === false)
            handleRejection(this, this._value);
          return;
        }
        this._state = null;
        this._value = null;
        ++psd.ref;
        executePromiseTask(this, fn);
      }
      var thenProp = {
        get: function() {
          var psd = PSD, microTaskId = totalEchoes;
          function then(onFulfilled, onRejected) {
            var _this = this;
            var possibleAwait = !psd.global && (psd !== PSD || microTaskId !== totalEchoes);
            var cleanup = possibleAwait && !decrementExpectedAwaits();
            var rv = new DexiePromise(function(resolve, reject) {
              propagateToListener(_this, new Listener(nativeAwaitCompatibleWrap(onFulfilled, psd, possibleAwait, cleanup), nativeAwaitCompatibleWrap(onRejected, psd, possibleAwait, cleanup), resolve, reject, psd));
            });
            if (this._consoleTask)
              rv._consoleTask = this._consoleTask;
            return rv;
          }
          then.prototype = INTERNAL;
          return then;
        },
        set: function(value) {
          setProp(this, "then", value && value.prototype === INTERNAL ? thenProp : {
            get: function() {
              return value;
            },
            set: thenProp.set
          });
        }
      };
      props(DexiePromise.prototype, {
        then: thenProp,
        _then: function(onFulfilled, onRejected) {
          propagateToListener(this, new Listener(null, null, onFulfilled, onRejected, PSD));
        },
        catch: function(onRejected) {
          if (arguments.length === 1)
            return this.then(null, onRejected);
          var type2 = arguments[0], handler = arguments[1];
          return typeof type2 === "function" ? this.then(null, function(err) {
            return err instanceof type2 ? handler(err) : PromiseReject(err);
          }) : this.then(null, function(err) {
            return err && err.name === type2 ? handler(err) : PromiseReject(err);
          });
        },
        finally: function(onFinally) {
          return this.then(function(value) {
            return DexiePromise.resolve(onFinally()).then(function() {
              return value;
            });
          }, function(err) {
            return DexiePromise.resolve(onFinally()).then(function() {
              return PromiseReject(err);
            });
          });
        },
        timeout: function(ms, msg) {
          var _this = this;
          return ms < Infinity ? new DexiePromise(function(resolve, reject) {
            var handle = setTimeout(function() {
              return reject(new exceptions.Timeout(msg));
            }, ms);
            _this.then(resolve, reject).finally(clearTimeout.bind(null, handle));
          }) : this;
        }
      });
      if (typeof Symbol !== "undefined" && Symbol.toStringTag)
        setProp(DexiePromise.prototype, Symbol.toStringTag, "Dexie.Promise");
      globalPSD.env = snapShot();
      function Listener(onFulfilled, onRejected, resolve, reject, zone) {
        this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
        this.onRejected = typeof onRejected === "function" ? onRejected : null;
        this.resolve = resolve;
        this.reject = reject;
        this.psd = zone;
      }
      props(DexiePromise, {
        all: function() {
          var values = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
          return new DexiePromise(function(resolve, reject) {
            if (values.length === 0)
              resolve([]);
            var remaining = values.length;
            values.forEach(function(a, i2) {
              return DexiePromise.resolve(a).then(function(x2) {
                values[i2] = x2;
                if (!--remaining)
                  resolve(values);
              }, reject);
            });
          });
        },
        resolve: function(value) {
          if (value instanceof DexiePromise)
            return value;
          if (value && typeof value.then === "function")
            return new DexiePromise(function(resolve, reject) {
              value.then(resolve, reject);
            });
          var rv = new DexiePromise(INTERNAL, true, value);
          return rv;
        },
        reject: PromiseReject,
        race: function() {
          var values = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
          return new DexiePromise(function(resolve, reject) {
            values.map(function(value) {
              return DexiePromise.resolve(value).then(resolve, reject);
            });
          });
        },
        PSD: {
          get: function() {
            return PSD;
          },
          set: function(value) {
            return PSD = value;
          }
        },
        totalEchoes: { get: function() {
          return totalEchoes;
        } },
        newPSD: newScope,
        usePSD,
        scheduler: {
          get: function() {
            return asap;
          },
          set: function(value) {
            asap = value;
          }
        },
        rejectionMapper: {
          get: function() {
            return rejectionMapper;
          },
          set: function(value) {
            rejectionMapper = value;
          }
        },
        follow: function(fn, zoneProps) {
          return new DexiePromise(function(resolve, reject) {
            return newScope(function(resolve2, reject2) {
              var psd = PSD;
              psd.unhandleds = [];
              psd.onunhandled = reject2;
              psd.finalize = callBoth(function() {
                var _this = this;
                run_at_end_of_this_or_next_physical_tick(function() {
                  _this.unhandleds.length === 0 ? resolve2() : reject2(_this.unhandleds[0]);
                });
              }, psd.finalize);
              fn();
            }, zoneProps, resolve, reject);
          });
        }
      });
      if (NativePromise) {
        if (NativePromise.allSettled)
          setProp(DexiePromise, "allSettled", function() {
            var possiblePromises = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
            return new DexiePromise(function(resolve) {
              if (possiblePromises.length === 0)
                resolve([]);
              var remaining = possiblePromises.length;
              var results = new Array(remaining);
              possiblePromises.forEach(function(p2, i2) {
                return DexiePromise.resolve(p2).then(function(value) {
                  return results[i2] = { status: "fulfilled", value };
                }, function(reason) {
                  return results[i2] = { status: "rejected", reason };
                }).then(function() {
                  return --remaining || resolve(results);
                });
              });
            });
          });
        if (NativePromise.any && typeof AggregateError !== "undefined")
          setProp(DexiePromise, "any", function() {
            var possiblePromises = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
            return new DexiePromise(function(resolve, reject) {
              if (possiblePromises.length === 0)
                reject(new AggregateError([]));
              var remaining = possiblePromises.length;
              var failures = new Array(remaining);
              possiblePromises.forEach(function(p2, i2) {
                return DexiePromise.resolve(p2).then(function(value) {
                  return resolve(value);
                }, function(failure) {
                  failures[i2] = failure;
                  if (!--remaining)
                    reject(new AggregateError(failures));
                });
              });
            });
          });
        if (NativePromise.withResolvers)
          DexiePromise.withResolvers = NativePromise.withResolvers;
      }
      function executePromiseTask(promise, fn) {
        try {
          fn(function(value) {
            if (promise._state !== null)
              return;
            if (value === promise)
              throw new TypeError("A promise cannot be resolved with itself.");
            var shouldExecuteTick = promise._lib && beginMicroTickScope();
            if (value && typeof value.then === "function") {
              executePromiseTask(promise, function(resolve, reject) {
                value instanceof DexiePromise ? value._then(resolve, reject) : value.then(resolve, reject);
              });
            } else {
              promise._state = true;
              promise._value = value;
              propagateAllListeners(promise);
            }
            if (shouldExecuteTick)
              endMicroTickScope();
          }, handleRejection.bind(null, promise));
        } catch (ex) {
          handleRejection(promise, ex);
        }
      }
      function handleRejection(promise, reason) {
        rejectingErrors.push(reason);
        if (promise._state !== null)
          return;
        var shouldExecuteTick = promise._lib && beginMicroTickScope();
        reason = rejectionMapper(reason);
        promise._state = false;
        promise._value = reason;
        addPossiblyUnhandledError(promise);
        propagateAllListeners(promise);
        if (shouldExecuteTick)
          endMicroTickScope();
      }
      function propagateAllListeners(promise) {
        var listeners = promise._listeners;
        promise._listeners = [];
        for (var i2 = 0, len = listeners.length; i2 < len; ++i2) {
          propagateToListener(promise, listeners[i2]);
        }
        var psd = promise._PSD;
        --psd.ref || psd.finalize();
        if (numScheduledCalls === 0) {
          ++numScheduledCalls;
          asap(function() {
            if (--numScheduledCalls === 0)
              finalizePhysicalTick();
          }, []);
        }
      }
      function propagateToListener(promise, listener) {
        if (promise._state === null) {
          promise._listeners.push(listener);
          return;
        }
        var cb = promise._state ? listener.onFulfilled : listener.onRejected;
        if (cb === null) {
          return (promise._state ? listener.resolve : listener.reject)(promise._value);
        }
        ++listener.psd.ref;
        ++numScheduledCalls;
        asap(callListener, [cb, promise, listener]);
      }
      function callListener(cb, promise, listener) {
        try {
          var ret, value = promise._value;
          if (!promise._state && rejectingErrors.length)
            rejectingErrors = [];
          ret = debug && promise._consoleTask ? promise._consoleTask.run(function() {
            return cb(value);
          }) : cb(value);
          if (!promise._state && rejectingErrors.indexOf(value) === -1) {
            markErrorAsHandled(promise);
          }
          listener.resolve(ret);
        } catch (e2) {
          listener.reject(e2);
        } finally {
          if (--numScheduledCalls === 0)
            finalizePhysicalTick();
          --listener.psd.ref || listener.psd.finalize();
        }
      }
      function physicalTick() {
        usePSD(globalPSD, function() {
          beginMicroTickScope() && endMicroTickScope();
        });
      }
      function beginMicroTickScope() {
        var wasRootExec = isOutsideMicroTick;
        isOutsideMicroTick = false;
        needsNewPhysicalTick = false;
        return wasRootExec;
      }
      function endMicroTickScope() {
        var callbacks, i2, l;
        do {
          while (microtickQueue.length > 0) {
            callbacks = microtickQueue;
            microtickQueue = [];
            l = callbacks.length;
            for (i2 = 0; i2 < l; ++i2) {
              var item = callbacks[i2];
              item[0].apply(null, item[1]);
            }
          }
        } while (microtickQueue.length > 0);
        isOutsideMicroTick = true;
        needsNewPhysicalTick = true;
      }
      function finalizePhysicalTick() {
        var unhandledErrs = unhandledErrors;
        unhandledErrors = [];
        unhandledErrs.forEach(function(p2) {
          p2._PSD.onunhandled.call(null, p2._value, p2);
        });
        var finalizers = tickFinalizers.slice(0);
        var i2 = finalizers.length;
        while (i2)
          finalizers[--i2]();
      }
      function run_at_end_of_this_or_next_physical_tick(fn) {
        function finalizer2() {
          fn();
          tickFinalizers.splice(tickFinalizers.indexOf(finalizer2), 1);
        }
        tickFinalizers.push(finalizer2);
        ++numScheduledCalls;
        asap(function() {
          if (--numScheduledCalls === 0)
            finalizePhysicalTick();
        }, []);
      }
      function addPossiblyUnhandledError(promise) {
        if (!unhandledErrors.some(function(p2) {
          return p2._value === promise._value;
        }))
          unhandledErrors.push(promise);
      }
      function markErrorAsHandled(promise) {
        var i2 = unhandledErrors.length;
        while (i2)
          if (unhandledErrors[--i2]._value === promise._value) {
            unhandledErrors.splice(i2, 1);
            return;
          }
      }
      function PromiseReject(reason) {
        return new DexiePromise(INTERNAL, false, reason);
      }
      function wrap2(fn, errorCatcher) {
        var psd = PSD;
        return function() {
          var wasRootExec = beginMicroTickScope(), outerScope = PSD;
          try {
            switchToZone(psd, true);
            return fn.apply(this, arguments);
          } catch (e2) {
            errorCatcher && errorCatcher(e2);
          } finally {
            switchToZone(outerScope, false);
            if (wasRootExec)
              endMicroTickScope();
          }
        };
      }
      var task = { awaits: 0, echoes: 0, id: 0 };
      var taskCounter = 0;
      var zoneStack = [];
      var zoneEchoes = 0;
      var totalEchoes = 0;
      var zone_id_counter = 0;
      function newScope(fn, props2, a1, a2) {
        var parent = PSD, psd = Object.create(parent);
        psd.parent = parent;
        psd.ref = 0;
        psd.global = false;
        psd.id = ++zone_id_counter;
        globalPSD.env;
        psd.env = patchGlobalPromise ? {
          Promise: DexiePromise,
          PromiseProp: { value: DexiePromise, configurable: true, writable: true },
          all: DexiePromise.all,
          race: DexiePromise.race,
          allSettled: DexiePromise.allSettled,
          any: DexiePromise.any,
          resolve: DexiePromise.resolve,
          reject: DexiePromise.reject
        } : {};
        if (props2)
          extend(psd, props2);
        ++parent.ref;
        psd.finalize = function() {
          --this.parent.ref || this.parent.finalize();
        };
        var rv = usePSD(psd, fn, a1, a2);
        if (psd.ref === 0)
          psd.finalize();
        return rv;
      }
      function incrementExpectedAwaits() {
        if (!task.id)
          task.id = ++taskCounter;
        ++task.awaits;
        task.echoes += ZONE_ECHO_LIMIT;
        return task.id;
      }
      function decrementExpectedAwaits() {
        if (!task.awaits)
          return false;
        if (--task.awaits === 0)
          task.id = 0;
        task.echoes = task.awaits * ZONE_ECHO_LIMIT;
        return true;
      }
      if (("" + nativePromiseThen).indexOf("[native code]") === -1) {
        incrementExpectedAwaits = decrementExpectedAwaits = nop;
      }
      function onPossibleParallellAsync(possiblePromise) {
        if (task.echoes && possiblePromise && possiblePromise.constructor === NativePromise) {
          incrementExpectedAwaits();
          return possiblePromise.then(function(x2) {
            decrementExpectedAwaits();
            return x2;
          }, function(e2) {
            decrementExpectedAwaits();
            return rejection(e2);
          });
        }
        return possiblePromise;
      }
      function zoneEnterEcho(targetZone) {
        ++totalEchoes;
        if (!task.echoes || --task.echoes === 0) {
          task.echoes = task.awaits = task.id = 0;
        }
        zoneStack.push(PSD);
        switchToZone(targetZone, true);
      }
      function zoneLeaveEcho() {
        var zone = zoneStack[zoneStack.length - 1];
        zoneStack.pop();
        switchToZone(zone, false);
      }
      function switchToZone(targetZone, bEnteringZone) {
        var currentZone = PSD;
        if (bEnteringZone ? task.echoes && (!zoneEchoes++ || targetZone !== PSD) : zoneEchoes && (!--zoneEchoes || targetZone !== PSD)) {
          queueMicrotask(bEnteringZone ? zoneEnterEcho.bind(null, targetZone) : zoneLeaveEcho);
        }
        if (targetZone === PSD)
          return;
        PSD = targetZone;
        if (currentZone === globalPSD)
          globalPSD.env = snapShot();
        if (patchGlobalPromise) {
          var GlobalPromise = globalPSD.env.Promise;
          var targetEnv = targetZone.env;
          if (currentZone.global || targetZone.global) {
            Object.defineProperty(_global, "Promise", targetEnv.PromiseProp);
            GlobalPromise.all = targetEnv.all;
            GlobalPromise.race = targetEnv.race;
            GlobalPromise.resolve = targetEnv.resolve;
            GlobalPromise.reject = targetEnv.reject;
            if (targetEnv.allSettled)
              GlobalPromise.allSettled = targetEnv.allSettled;
            if (targetEnv.any)
              GlobalPromise.any = targetEnv.any;
          }
        }
      }
      function snapShot() {
        var GlobalPromise = _global.Promise;
        return patchGlobalPromise ? {
          Promise: GlobalPromise,
          PromiseProp: Object.getOwnPropertyDescriptor(_global, "Promise"),
          all: GlobalPromise.all,
          race: GlobalPromise.race,
          allSettled: GlobalPromise.allSettled,
          any: GlobalPromise.any,
          resolve: GlobalPromise.resolve,
          reject: GlobalPromise.reject
        } : {};
      }
      function usePSD(psd, fn, a1, a2, a3) {
        var outerScope = PSD;
        try {
          switchToZone(psd, true);
          return fn(a1, a2, a3);
        } finally {
          switchToZone(outerScope, false);
        }
      }
      function nativeAwaitCompatibleWrap(fn, zone, possibleAwait, cleanup) {
        return typeof fn !== "function" ? fn : function() {
          var outerZone = PSD;
          if (possibleAwait)
            incrementExpectedAwaits();
          switchToZone(zone, true);
          try {
            return fn.apply(this, arguments);
          } finally {
            switchToZone(outerZone, false);
            if (cleanup)
              queueMicrotask(decrementExpectedAwaits);
          }
        };
      }
      function execInGlobalContext(cb) {
        if (Promise === NativePromise && task.echoes === 0) {
          if (zoneEchoes === 0) {
            cb();
          } else {
            enqueueNativeMicroTask(cb);
          }
        } else {
          setTimeout(cb, 0);
        }
      }
      var rejection = DexiePromise.reject;
      function tempTransaction(db2, mode, storeNames, fn) {
        if (!db2.idbdb || !db2._state.openComplete && (!PSD.letThrough && !db2._vip)) {
          if (db2._state.openComplete) {
            return rejection(new exceptions.DatabaseClosed(db2._state.dbOpenError));
          }
          if (!db2._state.isBeingOpened) {
            if (!db2._state.autoOpen)
              return rejection(new exceptions.DatabaseClosed());
            db2.open().catch(nop);
          }
          return db2._state.dbReadyPromise.then(function() {
            return tempTransaction(db2, mode, storeNames, fn);
          });
        } else {
          var trans = db2._createTransaction(mode, storeNames, db2._dbSchema);
          try {
            trans.create();
            db2._state.PR1398_maxLoop = 3;
          } catch (ex) {
            if (ex.name === errnames.InvalidState && db2.isOpen() && --db2._state.PR1398_maxLoop > 0) {
              console.warn("Dexie: Need to reopen db");
              db2.close({ disableAutoOpen: false });
              return db2.open().then(function() {
                return tempTransaction(db2, mode, storeNames, fn);
              });
            }
            return rejection(ex);
          }
          return trans._promise(mode, function(resolve, reject) {
            return newScope(function() {
              PSD.trans = trans;
              return fn(resolve, reject, trans);
            });
          }).then(function(result) {
            if (mode === "readwrite")
              try {
                trans.idbtrans.commit();
              } catch (_a3) {
              }
            return mode === "readonly" ? result : trans._completion.then(function() {
              return result;
            });
          });
        }
      }
      var DEXIE_VERSION = "4.0.10";
      var maxString = String.fromCharCode(65535);
      var minKey = -Infinity;
      var INVALID_KEY_ARGUMENT = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.";
      var STRING_EXPECTED = "String expected.";
      var connections = [];
      var DBNAMES_DB = "__dbnames";
      var READONLY = "readonly";
      var READWRITE = "readwrite";
      function combine(filter1, filter2) {
        return filter1 ? filter2 ? function() {
          return filter1.apply(this, arguments) && filter2.apply(this, arguments);
        } : filter1 : filter2;
      }
      var AnyRange = {
        type: 3,
        lower: -Infinity,
        lowerOpen: false,
        upper: [[]],
        upperOpen: false
      };
      function workaroundForUndefinedPrimKey(keyPath) {
        return typeof keyPath === "string" && !/\./.test(keyPath) ? function(obj) {
          if (obj[keyPath] === void 0 && keyPath in obj) {
            obj = deepClone(obj);
            delete obj[keyPath];
          }
          return obj;
        } : function(obj) {
          return obj;
        };
      }
      function Entity() {
        throw exceptions.Type();
      }
      function cmp(a, b2) {
        try {
          var ta = type(a);
          var tb = type(b2);
          if (ta !== tb) {
            if (ta === "Array")
              return 1;
            if (tb === "Array")
              return -1;
            if (ta === "binary")
              return 1;
            if (tb === "binary")
              return -1;
            if (ta === "string")
              return 1;
            if (tb === "string")
              return -1;
            if (ta === "Date")
              return 1;
            if (tb !== "Date")
              return NaN;
            return -1;
          }
          switch (ta) {
            case "number":
            case "Date":
            case "string":
              return a > b2 ? 1 : a < b2 ? -1 : 0;
            case "binary": {
              return compareUint8Arrays(getUint8Array(a), getUint8Array(b2));
            }
            case "Array":
              return compareArrays(a, b2);
          }
        } catch (_a3) {
        }
        return NaN;
      }
      function compareArrays(a, b2) {
        var al = a.length;
        var bl = b2.length;
        var l = al < bl ? al : bl;
        for (var i2 = 0; i2 < l; ++i2) {
          var res = cmp(a[i2], b2[i2]);
          if (res !== 0)
            return res;
        }
        return al === bl ? 0 : al < bl ? -1 : 1;
      }
      function compareUint8Arrays(a, b2) {
        var al = a.length;
        var bl = b2.length;
        var l = al < bl ? al : bl;
        for (var i2 = 0; i2 < l; ++i2) {
          if (a[i2] !== b2[i2])
            return a[i2] < b2[i2] ? -1 : 1;
        }
        return al === bl ? 0 : al < bl ? -1 : 1;
      }
      function type(x2) {
        var t2 = typeof x2;
        if (t2 !== "object")
          return t2;
        if (ArrayBuffer.isView(x2))
          return "binary";
        var tsTag = toStringTag(x2);
        return tsTag === "ArrayBuffer" ? "binary" : tsTag;
      }
      function getUint8Array(a) {
        if (a instanceof Uint8Array)
          return a;
        if (ArrayBuffer.isView(a))
          return new Uint8Array(a.buffer, a.byteOffset, a.byteLength);
        return new Uint8Array(a);
      }
      var Table = function() {
        function Table2() {
        }
        Table2.prototype._trans = function(mode, fn, writeLocked) {
          var trans = this._tx || PSD.trans;
          var tableName = this.name;
          var task2 = debug && typeof console !== "undefined" && console.createTask && console.createTask("Dexie: ".concat(mode === "readonly" ? "read" : "write", " ").concat(this.name));
          function checkTableInTransaction(resolve, reject, trans2) {
            if (!trans2.schema[tableName])
              throw new exceptions.NotFound("Table " + tableName + " not part of transaction");
            return fn(trans2.idbtrans, trans2);
          }
          var wasRootExec = beginMicroTickScope();
          try {
            var p2 = trans && trans.db._novip === this.db._novip ? trans === PSD.trans ? trans._promise(mode, checkTableInTransaction, writeLocked) : newScope(function() {
              return trans._promise(mode, checkTableInTransaction, writeLocked);
            }, { trans, transless: PSD.transless || PSD }) : tempTransaction(this.db, mode, [this.name], checkTableInTransaction);
            if (task2) {
              p2._consoleTask = task2;
              p2 = p2.catch(function(err) {
                console.trace(err);
                return rejection(err);
              });
            }
            return p2;
          } finally {
            if (wasRootExec)
              endMicroTickScope();
          }
        };
        Table2.prototype.get = function(keyOrCrit, cb) {
          var _this = this;
          if (keyOrCrit && keyOrCrit.constructor === Object)
            return this.where(keyOrCrit).first(cb);
          if (keyOrCrit == null)
            return rejection(new exceptions.Type("Invalid argument to Table.get()"));
          return this._trans("readonly", function(trans) {
            return _this.core.get({ trans, key: keyOrCrit }).then(function(res) {
              return _this.hook.reading.fire(res);
            });
          }).then(cb);
        };
        Table2.prototype.where = function(indexOrCrit) {
          if (typeof indexOrCrit === "string")
            return new this.db.WhereClause(this, indexOrCrit);
          if (isArray(indexOrCrit))
            return new this.db.WhereClause(this, "[".concat(indexOrCrit.join("+"), "]"));
          var keyPaths = keys(indexOrCrit);
          if (keyPaths.length === 1)
            return this.where(keyPaths[0]).equals(indexOrCrit[keyPaths[0]]);
          var compoundIndex = this.schema.indexes.concat(this.schema.primKey).filter(function(ix) {
            if (ix.compound && keyPaths.every(function(keyPath) {
              return ix.keyPath.indexOf(keyPath) >= 0;
            })) {
              for (var i2 = 0; i2 < keyPaths.length; ++i2) {
                if (keyPaths.indexOf(ix.keyPath[i2]) === -1)
                  return false;
              }
              return true;
            }
            return false;
          }).sort(function(a, b2) {
            return a.keyPath.length - b2.keyPath.length;
          })[0];
          if (compoundIndex && this.db._maxKey !== maxString) {
            var keyPathsInValidOrder = compoundIndex.keyPath.slice(0, keyPaths.length);
            return this.where(keyPathsInValidOrder).equals(keyPathsInValidOrder.map(function(kp) {
              return indexOrCrit[kp];
            }));
          }
          if (!compoundIndex && debug)
            console.warn("The query ".concat(JSON.stringify(indexOrCrit), " on ").concat(this.name, " would benefit from a ") + "compound index [".concat(keyPaths.join("+"), "]"));
          var idxByName = this.schema.idxByName;
          function equals(a, b2) {
            return cmp(a, b2) === 0;
          }
          var _a3 = keyPaths.reduce(function(_a4, keyPath) {
            var prevIndex = _a4[0], prevFilterFn = _a4[1];
            var index = idxByName[keyPath];
            var value = indexOrCrit[keyPath];
            return [
              prevIndex || index,
              prevIndex || !index ? combine(prevFilterFn, index && index.multi ? function(x2) {
                var prop = getByKeyPath(x2, keyPath);
                return isArray(prop) && prop.some(function(item) {
                  return equals(value, item);
                });
              } : function(x2) {
                return equals(value, getByKeyPath(x2, keyPath));
              }) : prevFilterFn
            ];
          }, [null, null]), idx = _a3[0], filterFunction = _a3[1];
          return idx ? this.where(idx.name).equals(indexOrCrit[idx.keyPath]).filter(filterFunction) : compoundIndex ? this.filter(filterFunction) : this.where(keyPaths).equals("");
        };
        Table2.prototype.filter = function(filterFunction) {
          return this.toCollection().and(filterFunction);
        };
        Table2.prototype.count = function(thenShortcut) {
          return this.toCollection().count(thenShortcut);
        };
        Table2.prototype.offset = function(offset) {
          return this.toCollection().offset(offset);
        };
        Table2.prototype.limit = function(numRows) {
          return this.toCollection().limit(numRows);
        };
        Table2.prototype.each = function(callback) {
          return this.toCollection().each(callback);
        };
        Table2.prototype.toArray = function(thenShortcut) {
          return this.toCollection().toArray(thenShortcut);
        };
        Table2.prototype.toCollection = function() {
          return new this.db.Collection(new this.db.WhereClause(this));
        };
        Table2.prototype.orderBy = function(index) {
          return new this.db.Collection(new this.db.WhereClause(this, isArray(index) ? "[".concat(index.join("+"), "]") : index));
        };
        Table2.prototype.reverse = function() {
          return this.toCollection().reverse();
        };
        Table2.prototype.mapToClass = function(constructor) {
          var _a3 = this, db2 = _a3.db, tableName = _a3.name;
          this.schema.mappedClass = constructor;
          if (constructor.prototype instanceof Entity) {
            constructor = function(_super) {
              __extends2(class_1, _super);
              function class_1() {
                return _super !== null && _super.apply(this, arguments) || this;
              }
              Object.defineProperty(class_1.prototype, "db", {
                get: function() {
                  return db2;
                },
                enumerable: false,
                configurable: true
              });
              class_1.prototype.table = function() {
                return tableName;
              };
              return class_1;
            }(constructor);
          }
          var inheritedProps = /* @__PURE__ */ new Set();
          for (var proto = constructor.prototype; proto; proto = getProto(proto)) {
            Object.getOwnPropertyNames(proto).forEach(function(propName) {
              return inheritedProps.add(propName);
            });
          }
          var readHook = function(obj) {
            if (!obj)
              return obj;
            var res = Object.create(constructor.prototype);
            for (var m2 in obj)
              if (!inheritedProps.has(m2))
                try {
                  res[m2] = obj[m2];
                } catch (_) {
                }
            return res;
          };
          if (this.schema.readHook) {
            this.hook.reading.unsubscribe(this.schema.readHook);
          }
          this.schema.readHook = readHook;
          this.hook("reading", readHook);
          return constructor;
        };
        Table2.prototype.defineClass = function() {
          function Class(content) {
            extend(this, content);
          }
          return this.mapToClass(Class);
        };
        Table2.prototype.add = function(obj, key) {
          var _this = this;
          var _a3 = this.schema.primKey, auto = _a3.auto, keyPath = _a3.keyPath;
          var objToAdd = obj;
          if (keyPath && auto) {
            objToAdd = workaroundForUndefinedPrimKey(keyPath)(obj);
          }
          return this._trans("readwrite", function(trans) {
            return _this.core.mutate({ trans, type: "add", keys: key != null ? [key] : null, values: [objToAdd] });
          }).then(function(res) {
            return res.numFailures ? DexiePromise.reject(res.failures[0]) : res.lastResult;
          }).then(function(lastResult) {
            if (keyPath) {
              try {
                setByKeyPath(obj, keyPath, lastResult);
              } catch (_) {
              }
            }
            return lastResult;
          });
        };
        Table2.prototype.update = function(keyOrObject, modifications) {
          if (typeof keyOrObject === "object" && !isArray(keyOrObject)) {
            var key = getByKeyPath(keyOrObject, this.schema.primKey.keyPath);
            if (key === void 0)
              return rejection(new exceptions.InvalidArgument("Given object does not contain its primary key"));
            return this.where(":id").equals(key).modify(modifications);
          } else {
            return this.where(":id").equals(keyOrObject).modify(modifications);
          }
        };
        Table2.prototype.put = function(obj, key) {
          var _this = this;
          var _a3 = this.schema.primKey, auto = _a3.auto, keyPath = _a3.keyPath;
          var objToAdd = obj;
          if (keyPath && auto) {
            objToAdd = workaroundForUndefinedPrimKey(keyPath)(obj);
          }
          return this._trans("readwrite", function(trans) {
            return _this.core.mutate({ trans, type: "put", values: [objToAdd], keys: key != null ? [key] : null });
          }).then(function(res) {
            return res.numFailures ? DexiePromise.reject(res.failures[0]) : res.lastResult;
          }).then(function(lastResult) {
            if (keyPath) {
              try {
                setByKeyPath(obj, keyPath, lastResult);
              } catch (_) {
              }
            }
            return lastResult;
          });
        };
        Table2.prototype.delete = function(key) {
          var _this = this;
          return this._trans("readwrite", function(trans) {
            return _this.core.mutate({ trans, type: "delete", keys: [key] });
          }).then(function(res) {
            return res.numFailures ? DexiePromise.reject(res.failures[0]) : void 0;
          });
        };
        Table2.prototype.clear = function() {
          var _this = this;
          return this._trans("readwrite", function(trans) {
            return _this.core.mutate({ trans, type: "deleteRange", range: AnyRange });
          }).then(function(res) {
            return res.numFailures ? DexiePromise.reject(res.failures[0]) : void 0;
          });
        };
        Table2.prototype.bulkGet = function(keys2) {
          var _this = this;
          return this._trans("readonly", function(trans) {
            return _this.core.getMany({
              keys: keys2,
              trans
            }).then(function(result) {
              return result.map(function(res) {
                return _this.hook.reading.fire(res);
              });
            });
          });
        };
        Table2.prototype.bulkAdd = function(objects, keysOrOptions, options) {
          var _this = this;
          var keys2 = Array.isArray(keysOrOptions) ? keysOrOptions : void 0;
          options = options || (keys2 ? void 0 : keysOrOptions);
          var wantResults = options ? options.allKeys : void 0;
          return this._trans("readwrite", function(trans) {
            var _a3 = _this.schema.primKey, auto = _a3.auto, keyPath = _a3.keyPath;
            if (keyPath && keys2)
              throw new exceptions.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
            if (keys2 && keys2.length !== objects.length)
              throw new exceptions.InvalidArgument("Arguments objects and keys must have the same length");
            var numObjects = objects.length;
            var objectsToAdd = keyPath && auto ? objects.map(workaroundForUndefinedPrimKey(keyPath)) : objects;
            return _this.core.mutate({ trans, type: "add", keys: keys2, values: objectsToAdd, wantResults }).then(function(_a4) {
              var numFailures = _a4.numFailures, results = _a4.results, lastResult = _a4.lastResult, failures = _a4.failures;
              var result = wantResults ? results : lastResult;
              if (numFailures === 0)
                return result;
              throw new BulkError("".concat(_this.name, ".bulkAdd(): ").concat(numFailures, " of ").concat(numObjects, " operations failed"), failures);
            });
          });
        };
        Table2.prototype.bulkPut = function(objects, keysOrOptions, options) {
          var _this = this;
          var keys2 = Array.isArray(keysOrOptions) ? keysOrOptions : void 0;
          options = options || (keys2 ? void 0 : keysOrOptions);
          var wantResults = options ? options.allKeys : void 0;
          return this._trans("readwrite", function(trans) {
            var _a3 = _this.schema.primKey, auto = _a3.auto, keyPath = _a3.keyPath;
            if (keyPath && keys2)
              throw new exceptions.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
            if (keys2 && keys2.length !== objects.length)
              throw new exceptions.InvalidArgument("Arguments objects and keys must have the same length");
            var numObjects = objects.length;
            var objectsToPut = keyPath && auto ? objects.map(workaroundForUndefinedPrimKey(keyPath)) : objects;
            return _this.core.mutate({ trans, type: "put", keys: keys2, values: objectsToPut, wantResults }).then(function(_a4) {
              var numFailures = _a4.numFailures, results = _a4.results, lastResult = _a4.lastResult, failures = _a4.failures;
              var result = wantResults ? results : lastResult;
              if (numFailures === 0)
                return result;
              throw new BulkError("".concat(_this.name, ".bulkPut(): ").concat(numFailures, " of ").concat(numObjects, " operations failed"), failures);
            });
          });
        };
        Table2.prototype.bulkUpdate = function(keysAndChanges) {
          var _this = this;
          var coreTable = this.core;
          var keys2 = keysAndChanges.map(function(entry) {
            return entry.key;
          });
          var changeSpecs = keysAndChanges.map(function(entry) {
            return entry.changes;
          });
          var offsetMap = [];
          return this._trans("readwrite", function(trans) {
            return coreTable.getMany({ trans, keys: keys2, cache: "clone" }).then(function(objs) {
              var resultKeys = [];
              var resultObjs = [];
              keysAndChanges.forEach(function(_a3, idx) {
                var key = _a3.key, changes = _a3.changes;
                var obj = objs[idx];
                if (obj) {
                  for (var _i = 0, _b = Object.keys(changes); _i < _b.length; _i++) {
                    var keyPath = _b[_i];
                    var value = changes[keyPath];
                    if (keyPath === _this.schema.primKey.keyPath) {
                      if (cmp(value, key) !== 0) {
                        throw new exceptions.Constraint("Cannot update primary key in bulkUpdate()");
                      }
                    } else {
                      setByKeyPath(obj, keyPath, value);
                    }
                  }
                  offsetMap.push(idx);
                  resultKeys.push(key);
                  resultObjs.push(obj);
                }
              });
              var numEntries = resultKeys.length;
              return coreTable.mutate({
                trans,
                type: "put",
                keys: resultKeys,
                values: resultObjs,
                updates: {
                  keys: keys2,
                  changeSpecs
                }
              }).then(function(_a3) {
                var numFailures = _a3.numFailures, failures = _a3.failures;
                if (numFailures === 0)
                  return numEntries;
                for (var _i = 0, _b = Object.keys(failures); _i < _b.length; _i++) {
                  var offset = _b[_i];
                  var mappedOffset = offsetMap[Number(offset)];
                  if (mappedOffset != null) {
                    var failure = failures[offset];
                    delete failures[offset];
                    failures[mappedOffset] = failure;
                  }
                }
                throw new BulkError("".concat(_this.name, ".bulkUpdate(): ").concat(numFailures, " of ").concat(numEntries, " operations failed"), failures);
              });
            });
          });
        };
        Table2.prototype.bulkDelete = function(keys2) {
          var _this = this;
          var numKeys = keys2.length;
          return this._trans("readwrite", function(trans) {
            return _this.core.mutate({ trans, type: "delete", keys: keys2 });
          }).then(function(_a3) {
            var numFailures = _a3.numFailures, lastResult = _a3.lastResult, failures = _a3.failures;
            if (numFailures === 0)
              return lastResult;
            throw new BulkError("".concat(_this.name, ".bulkDelete(): ").concat(numFailures, " of ").concat(numKeys, " operations failed"), failures);
          });
        };
        return Table2;
      }();
      function Events(ctx) {
        var evs = {};
        var rv = function(eventName, subscriber) {
          if (subscriber) {
            var i3 = arguments.length, args = new Array(i3 - 1);
            while (--i3)
              args[i3 - 1] = arguments[i3];
            evs[eventName].subscribe.apply(null, args);
            return ctx;
          } else if (typeof eventName === "string") {
            return evs[eventName];
          }
        };
        rv.addEventType = add3;
        for (var i2 = 1, l = arguments.length; i2 < l; ++i2) {
          add3(arguments[i2]);
        }
        return rv;
        function add3(eventName, chainFunction, defaultFunction) {
          if (typeof eventName === "object")
            return addConfiguredEvents(eventName);
          if (!chainFunction)
            chainFunction = reverseStoppableEventChain;
          if (!defaultFunction)
            defaultFunction = nop;
          var context = {
            subscribers: [],
            fire: defaultFunction,
            subscribe: function(cb) {
              if (context.subscribers.indexOf(cb) === -1) {
                context.subscribers.push(cb);
                context.fire = chainFunction(context.fire, cb);
              }
            },
            unsubscribe: function(cb) {
              context.subscribers = context.subscribers.filter(function(fn) {
                return fn !== cb;
              });
              context.fire = context.subscribers.reduce(chainFunction, defaultFunction);
            }
          };
          evs[eventName] = rv[eventName] = context;
          return context;
        }
        function addConfiguredEvents(cfg) {
          keys(cfg).forEach(function(eventName) {
            var args = cfg[eventName];
            if (isArray(args)) {
              add3(eventName, cfg[eventName][0], cfg[eventName][1]);
            } else if (args === "asap") {
              var context = add3(eventName, mirror, function fire() {
                var i3 = arguments.length, args2 = new Array(i3);
                while (i3--)
                  args2[i3] = arguments[i3];
                context.subscribers.forEach(function(fn) {
                  asap$1(function fireEvent() {
                    fn.apply(null, args2);
                  });
                });
              });
            } else
              throw new exceptions.InvalidArgument("Invalid event config");
          });
        }
      }
      function makeClassConstructor(prototype, constructor) {
        derive(constructor).from({ prototype });
        return constructor;
      }
      function createTableConstructor(db2) {
        return makeClassConstructor(Table.prototype, function Table2(name, tableSchema, trans) {
          this.db = db2;
          this._tx = trans;
          this.name = name;
          this.schema = tableSchema;
          this.hook = db2._allTables[name] ? db2._allTables[name].hook : Events(null, {
            "creating": [hookCreatingChain, nop],
            "reading": [pureFunctionChain, mirror],
            "updating": [hookUpdatingChain, nop],
            "deleting": [hookDeletingChain, nop]
          });
        });
      }
      function isPlainKeyRange(ctx, ignoreLimitFilter) {
        return !(ctx.filter || ctx.algorithm || ctx.or) && (ignoreLimitFilter ? ctx.justLimit : !ctx.replayFilter);
      }
      function addFilter(ctx, fn) {
        ctx.filter = combine(ctx.filter, fn);
      }
      function addReplayFilter(ctx, factory, isLimitFilter) {
        var curr = ctx.replayFilter;
        ctx.replayFilter = curr ? function() {
          return combine(curr(), factory());
        } : factory;
        ctx.justLimit = isLimitFilter && !curr;
      }
      function addMatchFilter(ctx, fn) {
        ctx.isMatch = combine(ctx.isMatch, fn);
      }
      function getIndexOrStore(ctx, coreSchema) {
        if (ctx.isPrimKey)
          return coreSchema.primaryKey;
        var index = coreSchema.getIndexByKeyPath(ctx.index);
        if (!index)
          throw new exceptions.Schema("KeyPath " + ctx.index + " on object store " + coreSchema.name + " is not indexed");
        return index;
      }
      function openCursor(ctx, coreTable, trans) {
        var index = getIndexOrStore(ctx, coreTable.schema);
        return coreTable.openCursor({
          trans,
          values: !ctx.keysOnly,
          reverse: ctx.dir === "prev",
          unique: !!ctx.unique,
          query: {
            index,
            range: ctx.range
          }
        });
      }
      function iter(ctx, fn, coreTrans, coreTable) {
        var filter = ctx.replayFilter ? combine(ctx.filter, ctx.replayFilter()) : ctx.filter;
        if (!ctx.or) {
          return iterate(openCursor(ctx, coreTable, coreTrans), combine(ctx.algorithm, filter), fn, !ctx.keysOnly && ctx.valueMapper);
        } else {
          var set_1 = {};
          var union = function(item, cursor, advance) {
            if (!filter || filter(cursor, advance, function(result) {
              return cursor.stop(result);
            }, function(err) {
              return cursor.fail(err);
            })) {
              var primaryKey = cursor.primaryKey;
              var key = "" + primaryKey;
              if (key === "[object ArrayBuffer]")
                key = "" + new Uint8Array(primaryKey);
              if (!hasOwn(set_1, key)) {
                set_1[key] = true;
                fn(item, cursor, advance);
              }
            }
          };
          return Promise.all([
            ctx.or._iterate(union, coreTrans),
            iterate(openCursor(ctx, coreTable, coreTrans), ctx.algorithm, union, !ctx.keysOnly && ctx.valueMapper)
          ]);
        }
      }
      function iterate(cursorPromise, filter, fn, valueMapper) {
        var mappedFn = valueMapper ? function(x2, c2, a) {
          return fn(valueMapper(x2), c2, a);
        } : fn;
        var wrappedFn = wrap2(mappedFn);
        return cursorPromise.then(function(cursor) {
          if (cursor) {
            return cursor.start(function() {
              var c2 = function() {
                return cursor.continue();
              };
              if (!filter || filter(cursor, function(advancer) {
                return c2 = advancer;
              }, function(val) {
                cursor.stop(val);
                c2 = nop;
              }, function(e2) {
                cursor.fail(e2);
                c2 = nop;
              }))
                wrappedFn(cursor.value, cursor, function(advancer) {
                  return c2 = advancer;
                });
              c2();
            });
          }
        });
      }
      var PropModSymbol = Symbol();
      var PropModification = function() {
        function PropModification2(spec) {
          Object.assign(this, spec);
        }
        PropModification2.prototype.execute = function(value) {
          var _a3;
          if (this.add !== void 0) {
            var term = this.add;
            if (isArray(term)) {
              return __spreadArray2(__spreadArray2([], isArray(value) ? value : [], true), term).sort();
            }
            if (typeof term === "number")
              return (Number(value) || 0) + term;
            if (typeof term === "bigint") {
              try {
                return BigInt(value) + term;
              } catch (_b) {
                return BigInt(0) + term;
              }
            }
            throw new TypeError("Invalid term ".concat(term));
          }
          if (this.remove !== void 0) {
            var subtrahend_1 = this.remove;
            if (isArray(subtrahend_1)) {
              return isArray(value) ? value.filter(function(item) {
                return !subtrahend_1.includes(item);
              }).sort() : [];
            }
            if (typeof subtrahend_1 === "number")
              return Number(value) - subtrahend_1;
            if (typeof subtrahend_1 === "bigint") {
              try {
                return BigInt(value) - subtrahend_1;
              } catch (_c) {
                return BigInt(0) - subtrahend_1;
              }
            }
            throw new TypeError("Invalid subtrahend ".concat(subtrahend_1));
          }
          var prefixToReplace = (_a3 = this.replacePrefix) === null || _a3 === void 0 ? void 0 : _a3[0];
          if (prefixToReplace && typeof value === "string" && value.startsWith(prefixToReplace)) {
            return this.replacePrefix[1] + value.substring(prefixToReplace.length);
          }
          return value;
        };
        return PropModification2;
      }();
      var Collection = function() {
        function Collection2() {
        }
        Collection2.prototype._read = function(fn, cb) {
          var ctx = this._ctx;
          return ctx.error ? ctx.table._trans(null, rejection.bind(null, ctx.error)) : ctx.table._trans("readonly", fn).then(cb);
        };
        Collection2.prototype._write = function(fn) {
          var ctx = this._ctx;
          return ctx.error ? ctx.table._trans(null, rejection.bind(null, ctx.error)) : ctx.table._trans("readwrite", fn, "locked");
        };
        Collection2.prototype._addAlgorithm = function(fn) {
          var ctx = this._ctx;
          ctx.algorithm = combine(ctx.algorithm, fn);
        };
        Collection2.prototype._iterate = function(fn, coreTrans) {
          return iter(this._ctx, fn, coreTrans, this._ctx.table.core);
        };
        Collection2.prototype.clone = function(props2) {
          var rv = Object.create(this.constructor.prototype), ctx = Object.create(this._ctx);
          if (props2)
            extend(ctx, props2);
          rv._ctx = ctx;
          return rv;
        };
        Collection2.prototype.raw = function() {
          this._ctx.valueMapper = null;
          return this;
        };
        Collection2.prototype.each = function(fn) {
          var ctx = this._ctx;
          return this._read(function(trans) {
            return iter(ctx, fn, trans, ctx.table.core);
          });
        };
        Collection2.prototype.count = function(cb) {
          var _this = this;
          return this._read(function(trans) {
            var ctx = _this._ctx;
            var coreTable = ctx.table.core;
            if (isPlainKeyRange(ctx, true)) {
              return coreTable.count({
                trans,
                query: {
                  index: getIndexOrStore(ctx, coreTable.schema),
                  range: ctx.range
                }
              }).then(function(count2) {
                return Math.min(count2, ctx.limit);
              });
            } else {
              var count = 0;
              return iter(ctx, function() {
                ++count;
                return false;
              }, trans, coreTable).then(function() {
                return count;
              });
            }
          }).then(cb);
        };
        Collection2.prototype.sortBy = function(keyPath, cb) {
          var parts = keyPath.split(".").reverse(), lastPart = parts[0], lastIndex = parts.length - 1;
          function getval(obj, i2) {
            if (i2)
              return getval(obj[parts[i2]], i2 - 1);
            return obj[lastPart];
          }
          var order = this._ctx.dir === "next" ? 1 : -1;
          function sorter(a, b2) {
            var aVal = getval(a, lastIndex), bVal = getval(b2, lastIndex);
            return cmp(aVal, bVal) * order;
          }
          return this.toArray(function(a) {
            return a.sort(sorter);
          }).then(cb);
        };
        Collection2.prototype.toArray = function(cb) {
          var _this = this;
          return this._read(function(trans) {
            var ctx = _this._ctx;
            if (ctx.dir === "next" && isPlainKeyRange(ctx, true) && ctx.limit > 0) {
              var valueMapper_1 = ctx.valueMapper;
              var index = getIndexOrStore(ctx, ctx.table.core.schema);
              return ctx.table.core.query({
                trans,
                limit: ctx.limit,
                values: true,
                query: {
                  index,
                  range: ctx.range
                }
              }).then(function(_a3) {
                var result = _a3.result;
                return valueMapper_1 ? result.map(valueMapper_1) : result;
              });
            } else {
              var a_1 = [];
              return iter(ctx, function(item) {
                return a_1.push(item);
              }, trans, ctx.table.core).then(function() {
                return a_1;
              });
            }
          }, cb);
        };
        Collection2.prototype.offset = function(offset) {
          var ctx = this._ctx;
          if (offset <= 0)
            return this;
          ctx.offset += offset;
          if (isPlainKeyRange(ctx)) {
            addReplayFilter(ctx, function() {
              var offsetLeft = offset;
              return function(cursor, advance) {
                if (offsetLeft === 0)
                  return true;
                if (offsetLeft === 1) {
                  --offsetLeft;
                  return false;
                }
                advance(function() {
                  cursor.advance(offsetLeft);
                  offsetLeft = 0;
                });
                return false;
              };
            });
          } else {
            addReplayFilter(ctx, function() {
              var offsetLeft = offset;
              return function() {
                return --offsetLeft < 0;
              };
            });
          }
          return this;
        };
        Collection2.prototype.limit = function(numRows) {
          this._ctx.limit = Math.min(this._ctx.limit, numRows);
          addReplayFilter(this._ctx, function() {
            var rowsLeft = numRows;
            return function(cursor, advance, resolve) {
              if (--rowsLeft <= 0)
                advance(resolve);
              return rowsLeft >= 0;
            };
          }, true);
          return this;
        };
        Collection2.prototype.until = function(filterFunction, bIncludeStopEntry) {
          addFilter(this._ctx, function(cursor, advance, resolve) {
            if (filterFunction(cursor.value)) {
              advance(resolve);
              return bIncludeStopEntry;
            } else {
              return true;
            }
          });
          return this;
        };
        Collection2.prototype.first = function(cb) {
          return this.limit(1).toArray(function(a) {
            return a[0];
          }).then(cb);
        };
        Collection2.prototype.last = function(cb) {
          return this.reverse().first(cb);
        };
        Collection2.prototype.filter = function(filterFunction) {
          addFilter(this._ctx, function(cursor) {
            return filterFunction(cursor.value);
          });
          addMatchFilter(this._ctx, filterFunction);
          return this;
        };
        Collection2.prototype.and = function(filter) {
          return this.filter(filter);
        };
        Collection2.prototype.or = function(indexName) {
          return new this.db.WhereClause(this._ctx.table, indexName, this);
        };
        Collection2.prototype.reverse = function() {
          this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev";
          if (this._ondirectionchange)
            this._ondirectionchange(this._ctx.dir);
          return this;
        };
        Collection2.prototype.desc = function() {
          return this.reverse();
        };
        Collection2.prototype.eachKey = function(cb) {
          var ctx = this._ctx;
          ctx.keysOnly = !ctx.isMatch;
          return this.each(function(val, cursor) {
            cb(cursor.key, cursor);
          });
        };
        Collection2.prototype.eachUniqueKey = function(cb) {
          this._ctx.unique = "unique";
          return this.eachKey(cb);
        };
        Collection2.prototype.eachPrimaryKey = function(cb) {
          var ctx = this._ctx;
          ctx.keysOnly = !ctx.isMatch;
          return this.each(function(val, cursor) {
            cb(cursor.primaryKey, cursor);
          });
        };
        Collection2.prototype.keys = function(cb) {
          var ctx = this._ctx;
          ctx.keysOnly = !ctx.isMatch;
          var a = [];
          return this.each(function(item, cursor) {
            a.push(cursor.key);
          }).then(function() {
            return a;
          }).then(cb);
        };
        Collection2.prototype.primaryKeys = function(cb) {
          var ctx = this._ctx;
          if (ctx.dir === "next" && isPlainKeyRange(ctx, true) && ctx.limit > 0) {
            return this._read(function(trans) {
              var index = getIndexOrStore(ctx, ctx.table.core.schema);
              return ctx.table.core.query({
                trans,
                values: false,
                limit: ctx.limit,
                query: {
                  index,
                  range: ctx.range
                }
              });
            }).then(function(_a3) {
              var result = _a3.result;
              return result;
            }).then(cb);
          }
          ctx.keysOnly = !ctx.isMatch;
          var a = [];
          return this.each(function(item, cursor) {
            a.push(cursor.primaryKey);
          }).then(function() {
            return a;
          }).then(cb);
        };
        Collection2.prototype.uniqueKeys = function(cb) {
          this._ctx.unique = "unique";
          return this.keys(cb);
        };
        Collection2.prototype.firstKey = function(cb) {
          return this.limit(1).keys(function(a) {
            return a[0];
          }).then(cb);
        };
        Collection2.prototype.lastKey = function(cb) {
          return this.reverse().firstKey(cb);
        };
        Collection2.prototype.distinct = function() {
          var ctx = this._ctx, idx = ctx.index && ctx.table.schema.idxByName[ctx.index];
          if (!idx || !idx.multi)
            return this;
          var set = {};
          addFilter(this._ctx, function(cursor) {
            var strKey = cursor.primaryKey.toString();
            var found = hasOwn(set, strKey);
            set[strKey] = true;
            return !found;
          });
          return this;
        };
        Collection2.prototype.modify = function(changes) {
          var _this = this;
          var ctx = this._ctx;
          return this._write(function(trans) {
            var modifyer;
            if (typeof changes === "function") {
              modifyer = changes;
            } else {
              var keyPaths = keys(changes);
              var numKeys = keyPaths.length;
              modifyer = function(item) {
                var anythingModified = false;
                for (var i2 = 0; i2 < numKeys; ++i2) {
                  var keyPath = keyPaths[i2];
                  var val = changes[keyPath];
                  var origVal = getByKeyPath(item, keyPath);
                  if (val instanceof PropModification) {
                    setByKeyPath(item, keyPath, val.execute(origVal));
                    anythingModified = true;
                  } else if (origVal !== val) {
                    setByKeyPath(item, keyPath, val);
                    anythingModified = true;
                  }
                }
                return anythingModified;
              };
            }
            var coreTable = ctx.table.core;
            var _a3 = coreTable.schema.primaryKey, outbound = _a3.outbound, extractKey = _a3.extractKey;
            var limit = 200;
            var modifyChunkSize = _this.db._options.modifyChunkSize;
            if (modifyChunkSize) {
              if (typeof modifyChunkSize == "object") {
                limit = modifyChunkSize[coreTable.name] || modifyChunkSize["*"] || 200;
              } else {
                limit = modifyChunkSize;
              }
            }
            var totalFailures = [];
            var successCount = 0;
            var failedKeys = [];
            var applyMutateResult = function(expectedCount, res) {
              var failures = res.failures, numFailures = res.numFailures;
              successCount += expectedCount - numFailures;
              for (var _i = 0, _a4 = keys(failures); _i < _a4.length; _i++) {
                var pos = _a4[_i];
                totalFailures.push(failures[pos]);
              }
            };
            return _this.clone().primaryKeys().then(function(keys2) {
              var criteria = isPlainKeyRange(ctx) && ctx.limit === Infinity && (typeof changes !== "function" || changes === deleteCallback) && {
                index: ctx.index,
                range: ctx.range
              };
              var nextChunk = function(offset) {
                var count = Math.min(limit, keys2.length - offset);
                return coreTable.getMany({
                  trans,
                  keys: keys2.slice(offset, offset + count),
                  cache: "immutable"
                }).then(function(values) {
                  var addValues = [];
                  var putValues = [];
                  var putKeys = outbound ? [] : null;
                  var deleteKeys = [];
                  for (var i2 = 0; i2 < count; ++i2) {
                    var origValue = values[i2];
                    var ctx_1 = {
                      value: deepClone(origValue),
                      primKey: keys2[offset + i2]
                    };
                    if (modifyer.call(ctx_1, ctx_1.value, ctx_1) !== false) {
                      if (ctx_1.value == null) {
                        deleteKeys.push(keys2[offset + i2]);
                      } else if (!outbound && cmp(extractKey(origValue), extractKey(ctx_1.value)) !== 0) {
                        deleteKeys.push(keys2[offset + i2]);
                        addValues.push(ctx_1.value);
                      } else {
                        putValues.push(ctx_1.value);
                        if (outbound)
                          putKeys.push(keys2[offset + i2]);
                      }
                    }
                  }
                  return Promise.resolve(addValues.length > 0 && coreTable.mutate({ trans, type: "add", values: addValues }).then(function(res) {
                    for (var pos in res.failures) {
                      deleteKeys.splice(parseInt(pos), 1);
                    }
                    applyMutateResult(addValues.length, res);
                  })).then(function() {
                    return (putValues.length > 0 || criteria && typeof changes === "object") && coreTable.mutate({
                      trans,
                      type: "put",
                      keys: putKeys,
                      values: putValues,
                      criteria,
                      changeSpec: typeof changes !== "function" && changes,
                      isAdditionalChunk: offset > 0
                    }).then(function(res) {
                      return applyMutateResult(putValues.length, res);
                    });
                  }).then(function() {
                    return (deleteKeys.length > 0 || criteria && changes === deleteCallback) && coreTable.mutate({
                      trans,
                      type: "delete",
                      keys: deleteKeys,
                      criteria,
                      isAdditionalChunk: offset > 0
                    }).then(function(res) {
                      return applyMutateResult(deleteKeys.length, res);
                    });
                  }).then(function() {
                    return keys2.length > offset + count && nextChunk(offset + limit);
                  });
                });
              };
              return nextChunk(0).then(function() {
                if (totalFailures.length > 0)
                  throw new ModifyError("Error modifying one or more objects", totalFailures, successCount, failedKeys);
                return keys2.length;
              });
            });
          });
        };
        Collection2.prototype.delete = function() {
          var ctx = this._ctx, range = ctx.range;
          if (isPlainKeyRange(ctx) && (ctx.isPrimKey || range.type === 3)) {
            return this._write(function(trans) {
              var primaryKey = ctx.table.core.schema.primaryKey;
              var coreRange = range;
              return ctx.table.core.count({ trans, query: { index: primaryKey, range: coreRange } }).then(function(count) {
                return ctx.table.core.mutate({ trans, type: "deleteRange", range: coreRange }).then(function(_a3) {
                  var failures = _a3.failures;
                  _a3.lastResult;
                  _a3.results;
                  var numFailures = _a3.numFailures;
                  if (numFailures)
                    throw new ModifyError("Could not delete some values", Object.keys(failures).map(function(pos) {
                      return failures[pos];
                    }), count - numFailures);
                  return count - numFailures;
                });
              });
            });
          }
          return this.modify(deleteCallback);
        };
        return Collection2;
      }();
      var deleteCallback = function(value, ctx) {
        return ctx.value = null;
      };
      function createCollectionConstructor(db2) {
        return makeClassConstructor(Collection.prototype, function Collection2(whereClause, keyRangeGenerator) {
          this.db = db2;
          var keyRange = AnyRange, error = null;
          if (keyRangeGenerator)
            try {
              keyRange = keyRangeGenerator();
            } catch (ex) {
              error = ex;
            }
          var whereCtx = whereClause._ctx;
          var table = whereCtx.table;
          var readingHook = table.hook.reading.fire;
          this._ctx = {
            table,
            index: whereCtx.index,
            isPrimKey: !whereCtx.index || table.schema.primKey.keyPath && whereCtx.index === table.schema.primKey.name,
            range: keyRange,
            keysOnly: false,
            dir: "next",
            unique: "",
            algorithm: null,
            filter: null,
            replayFilter: null,
            justLimit: true,
            isMatch: null,
            offset: 0,
            limit: Infinity,
            error,
            or: whereCtx.or,
            valueMapper: readingHook !== mirror ? readingHook : null
          };
        });
      }
      function simpleCompare(a, b2) {
        return a < b2 ? -1 : a === b2 ? 0 : 1;
      }
      function simpleCompareReverse(a, b2) {
        return a > b2 ? -1 : a === b2 ? 0 : 1;
      }
      function fail(collectionOrWhereClause, err, T) {
        var collection = collectionOrWhereClause instanceof WhereClause ? new collectionOrWhereClause.Collection(collectionOrWhereClause) : collectionOrWhereClause;
        collection._ctx.error = T ? new T(err) : new TypeError(err);
        return collection;
      }
      function emptyCollection(whereClause) {
        return new whereClause.Collection(whereClause, function() {
          return rangeEqual("");
        }).limit(0);
      }
      function upperFactory(dir) {
        return dir === "next" ? function(s2) {
          return s2.toUpperCase();
        } : function(s2) {
          return s2.toLowerCase();
        };
      }
      function lowerFactory(dir) {
        return dir === "next" ? function(s2) {
          return s2.toLowerCase();
        } : function(s2) {
          return s2.toUpperCase();
        };
      }
      function nextCasing(key, lowerKey, upperNeedle, lowerNeedle, cmp2, dir) {
        var length = Math.min(key.length, lowerNeedle.length);
        var llp = -1;
        for (var i2 = 0; i2 < length; ++i2) {
          var lwrKeyChar = lowerKey[i2];
          if (lwrKeyChar !== lowerNeedle[i2]) {
            if (cmp2(key[i2], upperNeedle[i2]) < 0)
              return key.substr(0, i2) + upperNeedle[i2] + upperNeedle.substr(i2 + 1);
            if (cmp2(key[i2], lowerNeedle[i2]) < 0)
              return key.substr(0, i2) + lowerNeedle[i2] + upperNeedle.substr(i2 + 1);
            if (llp >= 0)
              return key.substr(0, llp) + lowerKey[llp] + upperNeedle.substr(llp + 1);
            return null;
          }
          if (cmp2(key[i2], lwrKeyChar) < 0)
            llp = i2;
        }
        if (length < lowerNeedle.length && dir === "next")
          return key + upperNeedle.substr(key.length);
        if (length < key.length && dir === "prev")
          return key.substr(0, upperNeedle.length);
        return llp < 0 ? null : key.substr(0, llp) + lowerNeedle[llp] + upperNeedle.substr(llp + 1);
      }
      function addIgnoreCaseAlgorithm(whereClause, match, needles, suffix) {
        var upper, lower, compare, upperNeedles, lowerNeedles, direction, nextKeySuffix, needlesLen = needles.length;
        if (!needles.every(function(s2) {
          return typeof s2 === "string";
        })) {
          return fail(whereClause, STRING_EXPECTED);
        }
        function initDirection(dir) {
          upper = upperFactory(dir);
          lower = lowerFactory(dir);
          compare = dir === "next" ? simpleCompare : simpleCompareReverse;
          var needleBounds = needles.map(function(needle) {
            return { lower: lower(needle), upper: upper(needle) };
          }).sort(function(a, b2) {
            return compare(a.lower, b2.lower);
          });
          upperNeedles = needleBounds.map(function(nb) {
            return nb.upper;
          });
          lowerNeedles = needleBounds.map(function(nb) {
            return nb.lower;
          });
          direction = dir;
          nextKeySuffix = dir === "next" ? "" : suffix;
        }
        initDirection("next");
        var c2 = new whereClause.Collection(whereClause, function() {
          return createRange(upperNeedles[0], lowerNeedles[needlesLen - 1] + suffix);
        });
        c2._ondirectionchange = function(direction2) {
          initDirection(direction2);
        };
        var firstPossibleNeedle = 0;
        c2._addAlgorithm(function(cursor, advance, resolve) {
          var key = cursor.key;
          if (typeof key !== "string")
            return false;
          var lowerKey = lower(key);
          if (match(lowerKey, lowerNeedles, firstPossibleNeedle)) {
            return true;
          } else {
            var lowestPossibleCasing = null;
            for (var i2 = firstPossibleNeedle; i2 < needlesLen; ++i2) {
              var casing = nextCasing(key, lowerKey, upperNeedles[i2], lowerNeedles[i2], compare, direction);
              if (casing === null && lowestPossibleCasing === null)
                firstPossibleNeedle = i2 + 1;
              else if (lowestPossibleCasing === null || compare(lowestPossibleCasing, casing) > 0) {
                lowestPossibleCasing = casing;
              }
            }
            if (lowestPossibleCasing !== null) {
              advance(function() {
                cursor.continue(lowestPossibleCasing + nextKeySuffix);
              });
            } else {
              advance(resolve);
            }
            return false;
          }
        });
        return c2;
      }
      function createRange(lower, upper, lowerOpen, upperOpen) {
        return {
          type: 2,
          lower,
          upper,
          lowerOpen,
          upperOpen
        };
      }
      function rangeEqual(value) {
        return {
          type: 1,
          lower: value,
          upper: value
        };
      }
      var WhereClause = function() {
        function WhereClause2() {
        }
        Object.defineProperty(WhereClause2.prototype, "Collection", {
          get: function() {
            return this._ctx.table.db.Collection;
          },
          enumerable: false,
          configurable: true
        });
        WhereClause2.prototype.between = function(lower, upper, includeLower, includeUpper) {
          includeLower = includeLower !== false;
          includeUpper = includeUpper === true;
          try {
            if (this._cmp(lower, upper) > 0 || this._cmp(lower, upper) === 0 && (includeLower || includeUpper) && !(includeLower && includeUpper))
              return emptyCollection(this);
            return new this.Collection(this, function() {
              return createRange(lower, upper, !includeLower, !includeUpper);
            });
          } catch (e2) {
            return fail(this, INVALID_KEY_ARGUMENT);
          }
        };
        WhereClause2.prototype.equals = function(value) {
          if (value == null)
            return fail(this, INVALID_KEY_ARGUMENT);
          return new this.Collection(this, function() {
            return rangeEqual(value);
          });
        };
        WhereClause2.prototype.above = function(value) {
          if (value == null)
            return fail(this, INVALID_KEY_ARGUMENT);
          return new this.Collection(this, function() {
            return createRange(value, void 0, true);
          });
        };
        WhereClause2.prototype.aboveOrEqual = function(value) {
          if (value == null)
            return fail(this, INVALID_KEY_ARGUMENT);
          return new this.Collection(this, function() {
            return createRange(value, void 0, false);
          });
        };
        WhereClause2.prototype.below = function(value) {
          if (value == null)
            return fail(this, INVALID_KEY_ARGUMENT);
          return new this.Collection(this, function() {
            return createRange(void 0, value, false, true);
          });
        };
        WhereClause2.prototype.belowOrEqual = function(value) {
          if (value == null)
            return fail(this, INVALID_KEY_ARGUMENT);
          return new this.Collection(this, function() {
            return createRange(void 0, value);
          });
        };
        WhereClause2.prototype.startsWith = function(str) {
          if (typeof str !== "string")
            return fail(this, STRING_EXPECTED);
          return this.between(str, str + maxString, true, true);
        };
        WhereClause2.prototype.startsWithIgnoreCase = function(str) {
          if (str === "")
            return this.startsWith(str);
          return addIgnoreCaseAlgorithm(this, function(x2, a) {
            return x2.indexOf(a[0]) === 0;
          }, [str], maxString);
        };
        WhereClause2.prototype.equalsIgnoreCase = function(str) {
          return addIgnoreCaseAlgorithm(this, function(x2, a) {
            return x2 === a[0];
          }, [str], "");
        };
        WhereClause2.prototype.anyOfIgnoreCase = function() {
          var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
          if (set.length === 0)
            return emptyCollection(this);
          return addIgnoreCaseAlgorithm(this, function(x2, a) {
            return a.indexOf(x2) !== -1;
          }, set, "");
        };
        WhereClause2.prototype.startsWithAnyOfIgnoreCase = function() {
          var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
          if (set.length === 0)
            return emptyCollection(this);
          return addIgnoreCaseAlgorithm(this, function(x2, a) {
            return a.some(function(n2) {
              return x2.indexOf(n2) === 0;
            });
          }, set, maxString);
        };
        WhereClause2.prototype.anyOf = function() {
          var _this = this;
          var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
          var compare = this._cmp;
          try {
            set.sort(compare);
          } catch (e2) {
            return fail(this, INVALID_KEY_ARGUMENT);
          }
          if (set.length === 0)
            return emptyCollection(this);
          var c2 = new this.Collection(this, function() {
            return createRange(set[0], set[set.length - 1]);
          });
          c2._ondirectionchange = function(direction) {
            compare = direction === "next" ? _this._ascending : _this._descending;
            set.sort(compare);
          };
          var i2 = 0;
          c2._addAlgorithm(function(cursor, advance, resolve) {
            var key = cursor.key;
            while (compare(key, set[i2]) > 0) {
              ++i2;
              if (i2 === set.length) {
                advance(resolve);
                return false;
              }
            }
            if (compare(key, set[i2]) === 0) {
              return true;
            } else {
              advance(function() {
                cursor.continue(set[i2]);
              });
              return false;
            }
          });
          return c2;
        };
        WhereClause2.prototype.notEqual = function(value) {
          return this.inAnyRange([[minKey, value], [value, this.db._maxKey]], { includeLowers: false, includeUppers: false });
        };
        WhereClause2.prototype.noneOf = function() {
          var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
          if (set.length === 0)
            return new this.Collection(this);
          try {
            set.sort(this._ascending);
          } catch (e2) {
            return fail(this, INVALID_KEY_ARGUMENT);
          }
          var ranges = set.reduce(function(res, val) {
            return res ? res.concat([[res[res.length - 1][1], val]]) : [[minKey, val]];
          }, null);
          ranges.push([set[set.length - 1], this.db._maxKey]);
          return this.inAnyRange(ranges, { includeLowers: false, includeUppers: false });
        };
        WhereClause2.prototype.inAnyRange = function(ranges, options) {
          var _this = this;
          var cmp2 = this._cmp, ascending = this._ascending, descending = this._descending, min = this._min, max = this._max;
          if (ranges.length === 0)
            return emptyCollection(this);
          if (!ranges.every(function(range) {
            return range[0] !== void 0 && range[1] !== void 0 && ascending(range[0], range[1]) <= 0;
          })) {
            return fail(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", exceptions.InvalidArgument);
          }
          var includeLowers = !options || options.includeLowers !== false;
          var includeUppers = options && options.includeUppers === true;
          function addRange2(ranges2, newRange) {
            var i2 = 0, l = ranges2.length;
            for (; i2 < l; ++i2) {
              var range = ranges2[i2];
              if (cmp2(newRange[0], range[1]) < 0 && cmp2(newRange[1], range[0]) > 0) {
                range[0] = min(range[0], newRange[0]);
                range[1] = max(range[1], newRange[1]);
                break;
              }
            }
            if (i2 === l)
              ranges2.push(newRange);
            return ranges2;
          }
          var sortDirection = ascending;
          function rangeSorter(a, b2) {
            return sortDirection(a[0], b2[0]);
          }
          var set;
          try {
            set = ranges.reduce(addRange2, []);
            set.sort(rangeSorter);
          } catch (ex) {
            return fail(this, INVALID_KEY_ARGUMENT);
          }
          var rangePos = 0;
          var keyIsBeyondCurrentEntry = includeUppers ? function(key) {
            return ascending(key, set[rangePos][1]) > 0;
          } : function(key) {
            return ascending(key, set[rangePos][1]) >= 0;
          };
          var keyIsBeforeCurrentEntry = includeLowers ? function(key) {
            return descending(key, set[rangePos][0]) > 0;
          } : function(key) {
            return descending(key, set[rangePos][0]) >= 0;
          };
          function keyWithinCurrentRange(key) {
            return !keyIsBeyondCurrentEntry(key) && !keyIsBeforeCurrentEntry(key);
          }
          var checkKey = keyIsBeyondCurrentEntry;
          var c2 = new this.Collection(this, function() {
            return createRange(set[0][0], set[set.length - 1][1], !includeLowers, !includeUppers);
          });
          c2._ondirectionchange = function(direction) {
            if (direction === "next") {
              checkKey = keyIsBeyondCurrentEntry;
              sortDirection = ascending;
            } else {
              checkKey = keyIsBeforeCurrentEntry;
              sortDirection = descending;
            }
            set.sort(rangeSorter);
          };
          c2._addAlgorithm(function(cursor, advance, resolve) {
            var key = cursor.key;
            while (checkKey(key)) {
              ++rangePos;
              if (rangePos === set.length) {
                advance(resolve);
                return false;
              }
            }
            if (keyWithinCurrentRange(key)) {
              return true;
            } else if (_this._cmp(key, set[rangePos][1]) === 0 || _this._cmp(key, set[rangePos][0]) === 0) {
              return false;
            } else {
              advance(function() {
                if (sortDirection === ascending)
                  cursor.continue(set[rangePos][0]);
                else
                  cursor.continue(set[rangePos][1]);
              });
              return false;
            }
          });
          return c2;
        };
        WhereClause2.prototype.startsWithAnyOf = function() {
          var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
          if (!set.every(function(s2) {
            return typeof s2 === "string";
          })) {
            return fail(this, "startsWithAnyOf() only works with strings");
          }
          if (set.length === 0)
            return emptyCollection(this);
          return this.inAnyRange(set.map(function(str) {
            return [str, str + maxString];
          }));
        };
        return WhereClause2;
      }();
      function createWhereClauseConstructor(db2) {
        return makeClassConstructor(WhereClause.prototype, function WhereClause2(table, index, orCollection) {
          this.db = db2;
          this._ctx = {
            table,
            index: index === ":id" ? null : index,
            or: orCollection
          };
          this._cmp = this._ascending = cmp;
          this._descending = function(a, b2) {
            return cmp(b2, a);
          };
          this._max = function(a, b2) {
            return cmp(a, b2) > 0 ? a : b2;
          };
          this._min = function(a, b2) {
            return cmp(a, b2) < 0 ? a : b2;
          };
          this._IDBKeyRange = db2._deps.IDBKeyRange;
          if (!this._IDBKeyRange)
            throw new exceptions.MissingAPI();
        });
      }
      function eventRejectHandler(reject) {
        return wrap2(function(event) {
          preventDefault(event);
          reject(event.target.error);
          return false;
        });
      }
      function preventDefault(event) {
        if (event.stopPropagation)
          event.stopPropagation();
        if (event.preventDefault)
          event.preventDefault();
      }
      var DEXIE_STORAGE_MUTATED_EVENT_NAME = "storagemutated";
      var STORAGE_MUTATED_DOM_EVENT_NAME = "x-storagemutated-1";
      var globalEvents = Events(null, DEXIE_STORAGE_MUTATED_EVENT_NAME);
      var Transaction2 = function() {
        function Transaction3() {
        }
        Transaction3.prototype._lock = function() {
          assert(!PSD.global);
          ++this._reculock;
          if (this._reculock === 1 && !PSD.global)
            PSD.lockOwnerFor = this;
          return this;
        };
        Transaction3.prototype._unlock = function() {
          assert(!PSD.global);
          if (--this._reculock === 0) {
            if (!PSD.global)
              PSD.lockOwnerFor = null;
            while (this._blockedFuncs.length > 0 && !this._locked()) {
              var fnAndPSD = this._blockedFuncs.shift();
              try {
                usePSD(fnAndPSD[1], fnAndPSD[0]);
              } catch (e2) {
              }
            }
          }
          return this;
        };
        Transaction3.prototype._locked = function() {
          return this._reculock && PSD.lockOwnerFor !== this;
        };
        Transaction3.prototype.create = function(idbtrans) {
          var _this = this;
          if (!this.mode)
            return this;
          var idbdb = this.db.idbdb;
          var dbOpenError = this.db._state.dbOpenError;
          assert(!this.idbtrans);
          if (!idbtrans && !idbdb) {
            switch (dbOpenError && dbOpenError.name) {
              case "DatabaseClosedError":
                throw new exceptions.DatabaseClosed(dbOpenError);
              case "MissingAPIError":
                throw new exceptions.MissingAPI(dbOpenError.message, dbOpenError);
              default:
                throw new exceptions.OpenFailed(dbOpenError);
            }
          }
          if (!this.active)
            throw new exceptions.TransactionInactive();
          assert(this._completion._state === null);
          idbtrans = this.idbtrans = idbtrans || (this.db.core ? this.db.core.transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability }) : idbdb.transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability }));
          idbtrans.onerror = wrap2(function(ev) {
            preventDefault(ev);
            _this._reject(idbtrans.error);
          });
          idbtrans.onabort = wrap2(function(ev) {
            preventDefault(ev);
            _this.active && _this._reject(new exceptions.Abort(idbtrans.error));
            _this.active = false;
            _this.on("abort").fire(ev);
          });
          idbtrans.oncomplete = wrap2(function() {
            _this.active = false;
            _this._resolve();
            if ("mutatedParts" in idbtrans) {
              globalEvents.storagemutated.fire(idbtrans["mutatedParts"]);
            }
          });
          return this;
        };
        Transaction3.prototype._promise = function(mode, fn, bWriteLock) {
          var _this = this;
          if (mode === "readwrite" && this.mode !== "readwrite")
            return rejection(new exceptions.ReadOnly("Transaction is readonly"));
          if (!this.active)
            return rejection(new exceptions.TransactionInactive());
          if (this._locked()) {
            return new DexiePromise(function(resolve, reject) {
              _this._blockedFuncs.push([function() {
                _this._promise(mode, fn, bWriteLock).then(resolve, reject);
              }, PSD]);
            });
          } else if (bWriteLock) {
            return newScope(function() {
              var p3 = new DexiePromise(function(resolve, reject) {
                _this._lock();
                var rv = fn(resolve, reject, _this);
                if (rv && rv.then)
                  rv.then(resolve, reject);
              });
              p3.finally(function() {
                return _this._unlock();
              });
              p3._lib = true;
              return p3;
            });
          } else {
            var p2 = new DexiePromise(function(resolve, reject) {
              var rv = fn(resolve, reject, _this);
              if (rv && rv.then)
                rv.then(resolve, reject);
            });
            p2._lib = true;
            return p2;
          }
        };
        Transaction3.prototype._root = function() {
          return this.parent ? this.parent._root() : this;
        };
        Transaction3.prototype.waitFor = function(promiseLike) {
          var root = this._root();
          var promise = DexiePromise.resolve(promiseLike);
          if (root._waitingFor) {
            root._waitingFor = root._waitingFor.then(function() {
              return promise;
            });
          } else {
            root._waitingFor = promise;
            root._waitingQueue = [];
            var store = root.idbtrans.objectStore(root.storeNames[0]);
            (function spin() {
              ++root._spinCount;
              while (root._waitingQueue.length)
                root._waitingQueue.shift()();
              if (root._waitingFor)
                store.get(-Infinity).onsuccess = spin;
            })();
          }
          var currentWaitPromise = root._waitingFor;
          return new DexiePromise(function(resolve, reject) {
            promise.then(function(res) {
              return root._waitingQueue.push(wrap2(resolve.bind(null, res)));
            }, function(err) {
              return root._waitingQueue.push(wrap2(reject.bind(null, err)));
            }).finally(function() {
              if (root._waitingFor === currentWaitPromise) {
                root._waitingFor = null;
              }
            });
          });
        };
        Transaction3.prototype.abort = function() {
          if (this.active) {
            this.active = false;
            if (this.idbtrans)
              this.idbtrans.abort();
            this._reject(new exceptions.Abort());
          }
        };
        Transaction3.prototype.table = function(tableName) {
          var memoizedTables = this._memoizedTables || (this._memoizedTables = {});
          if (hasOwn(memoizedTables, tableName))
            return memoizedTables[tableName];
          var tableSchema = this.schema[tableName];
          if (!tableSchema) {
            throw new exceptions.NotFound("Table " + tableName + " not part of transaction");
          }
          var transactionBoundTable = new this.db.Table(tableName, tableSchema, this);
          transactionBoundTable.core = this.db.core.table(tableName);
          memoizedTables[tableName] = transactionBoundTable;
          return transactionBoundTable;
        };
        return Transaction3;
      }();
      function createTransactionConstructor(db2) {
        return makeClassConstructor(Transaction2.prototype, function Transaction3(mode, storeNames, dbschema, chromeTransactionDurability, parent) {
          var _this = this;
          this.db = db2;
          this.mode = mode;
          this.storeNames = storeNames;
          this.schema = dbschema;
          this.chromeTransactionDurability = chromeTransactionDurability;
          this.idbtrans = null;
          this.on = Events(this, "complete", "error", "abort");
          this.parent = parent || null;
          this.active = true;
          this._reculock = 0;
          this._blockedFuncs = [];
          this._resolve = null;
          this._reject = null;
          this._waitingFor = null;
          this._waitingQueue = null;
          this._spinCount = 0;
          this._completion = new DexiePromise(function(resolve, reject) {
            _this._resolve = resolve;
            _this._reject = reject;
          });
          this._completion.then(function() {
            _this.active = false;
            _this.on.complete.fire();
          }, function(e2) {
            var wasActive = _this.active;
            _this.active = false;
            _this.on.error.fire(e2);
            _this.parent ? _this.parent._reject(e2) : wasActive && _this.idbtrans && _this.idbtrans.abort();
            return rejection(e2);
          });
        });
      }
      function createIndexSpec(name, keyPath, unique, multi, auto, compound, isPrimKey) {
        return {
          name,
          keyPath,
          unique,
          multi,
          auto,
          compound,
          src: (unique && !isPrimKey ? "&" : "") + (multi ? "*" : "") + (auto ? "++" : "") + nameFromKeyPath(keyPath)
        };
      }
      function nameFromKeyPath(keyPath) {
        return typeof keyPath === "string" ? keyPath : keyPath ? "[" + [].join.call(keyPath, "+") + "]" : "";
      }
      function createTableSchema(name, primKey, indexes) {
        return {
          name,
          primKey,
          indexes,
          mappedClass: null,
          idxByName: arrayToObject(indexes, function(index) {
            return [index.name, index];
          })
        };
      }
      function safariMultiStoreFix(storeNames) {
        return storeNames.length === 1 ? storeNames[0] : storeNames;
      }
      var getMaxKey = function(IdbKeyRange) {
        try {
          IdbKeyRange.only([[]]);
          getMaxKey = function() {
            return [[]];
          };
          return [[]];
        } catch (e2) {
          getMaxKey = function() {
            return maxString;
          };
          return maxString;
        }
      };
      function getKeyExtractor(keyPath) {
        if (keyPath == null) {
          return function() {
            return void 0;
          };
        } else if (typeof keyPath === "string") {
          return getSinglePathKeyExtractor(keyPath);
        } else {
          return function(obj) {
            return getByKeyPath(obj, keyPath);
          };
        }
      }
      function getSinglePathKeyExtractor(keyPath) {
        var split2 = keyPath.split(".");
        if (split2.length === 1) {
          return function(obj) {
            return obj[keyPath];
          };
        } else {
          return function(obj) {
            return getByKeyPath(obj, keyPath);
          };
        }
      }
      function arrayify(arrayLike) {
        return [].slice.call(arrayLike);
      }
      var _id_counter = 0;
      function getKeyPathAlias(keyPath) {
        return keyPath == null ? ":id" : typeof keyPath === "string" ? keyPath : "[".concat(keyPath.join("+"), "]");
      }
      function createDBCore(db2, IdbKeyRange, tmpTrans) {
        function extractSchema(db3, trans) {
          var tables2 = arrayify(db3.objectStoreNames);
          return {
            schema: {
              name: db3.name,
              tables: tables2.map(function(table) {
                return trans.objectStore(table);
              }).map(function(store) {
                var keyPath = store.keyPath, autoIncrement = store.autoIncrement;
                var compound = isArray(keyPath);
                var outbound = keyPath == null;
                var indexByKeyPath = {};
                var result = {
                  name: store.name,
                  primaryKey: {
                    name: null,
                    isPrimaryKey: true,
                    outbound,
                    compound,
                    keyPath,
                    autoIncrement,
                    unique: true,
                    extractKey: getKeyExtractor(keyPath)
                  },
                  indexes: arrayify(store.indexNames).map(function(indexName) {
                    return store.index(indexName);
                  }).map(function(index) {
                    var name = index.name, unique = index.unique, multiEntry = index.multiEntry, keyPath2 = index.keyPath;
                    var compound2 = isArray(keyPath2);
                    var result2 = {
                      name,
                      compound: compound2,
                      keyPath: keyPath2,
                      unique,
                      multiEntry,
                      extractKey: getKeyExtractor(keyPath2)
                    };
                    indexByKeyPath[getKeyPathAlias(keyPath2)] = result2;
                    return result2;
                  }),
                  getIndexByKeyPath: function(keyPath2) {
                    return indexByKeyPath[getKeyPathAlias(keyPath2)];
                  }
                };
                indexByKeyPath[":id"] = result.primaryKey;
                if (keyPath != null) {
                  indexByKeyPath[getKeyPathAlias(keyPath)] = result.primaryKey;
                }
                return result;
              })
            },
            hasGetAll: tables2.length > 0 && "getAll" in trans.objectStore(tables2[0]) && !(typeof navigator !== "undefined" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604)
          };
        }
        function makeIDBKeyRange(range) {
          if (range.type === 3)
            return null;
          if (range.type === 4)
            throw new Error("Cannot convert never type to IDBKeyRange");
          var lower = range.lower, upper = range.upper, lowerOpen = range.lowerOpen, upperOpen = range.upperOpen;
          var idbRange = lower === void 0 ? upper === void 0 ? null : IdbKeyRange.upperBound(upper, !!upperOpen) : upper === void 0 ? IdbKeyRange.lowerBound(lower, !!lowerOpen) : IdbKeyRange.bound(lower, upper, !!lowerOpen, !!upperOpen);
          return idbRange;
        }
        function createDbCoreTable(tableSchema) {
          var tableName = tableSchema.name;
          function mutate(_a4) {
            var trans = _a4.trans, type2 = _a4.type, keys2 = _a4.keys, values = _a4.values, range = _a4.range;
            return new Promise(function(resolve, reject) {
              resolve = wrap2(resolve);
              var store = trans.objectStore(tableName);
              var outbound = store.keyPath == null;
              var isAddOrPut = type2 === "put" || type2 === "add";
              if (!isAddOrPut && type2 !== "delete" && type2 !== "deleteRange")
                throw new Error("Invalid operation type: " + type2);
              var length = (keys2 || values || { length: 1 }).length;
              if (keys2 && values && keys2.length !== values.length) {
                throw new Error("Given keys array must have same length as given values array.");
              }
              if (length === 0)
                return resolve({ numFailures: 0, failures: {}, results: [], lastResult: void 0 });
              var req;
              var reqs = [];
              var failures = [];
              var numFailures = 0;
              var errorHandler = function(event) {
                ++numFailures;
                preventDefault(event);
              };
              if (type2 === "deleteRange") {
                if (range.type === 4)
                  return resolve({ numFailures, failures, results: [], lastResult: void 0 });
                if (range.type === 3)
                  reqs.push(req = store.clear());
                else
                  reqs.push(req = store.delete(makeIDBKeyRange(range)));
              } else {
                var _a5 = isAddOrPut ? outbound ? [values, keys2] : [values, null] : [keys2, null], args1 = _a5[0], args2 = _a5[1];
                if (isAddOrPut) {
                  for (var i2 = 0; i2 < length; ++i2) {
                    reqs.push(req = args2 && args2[i2] !== void 0 ? store[type2](args1[i2], args2[i2]) : store[type2](args1[i2]));
                    req.onerror = errorHandler;
                  }
                } else {
                  for (var i2 = 0; i2 < length; ++i2) {
                    reqs.push(req = store[type2](args1[i2]));
                    req.onerror = errorHandler;
                  }
                }
              }
              var done = function(event) {
                var lastResult = event.target.result;
                reqs.forEach(function(req2, i3) {
                  return req2.error != null && (failures[i3] = req2.error);
                });
                resolve({
                  numFailures,
                  failures,
                  results: type2 === "delete" ? keys2 : reqs.map(function(req2) {
                    return req2.result;
                  }),
                  lastResult
                });
              };
              req.onerror = function(event) {
                errorHandler(event);
                done(event);
              };
              req.onsuccess = done;
            });
          }
          function openCursor2(_a4) {
            var trans = _a4.trans, values = _a4.values, query2 = _a4.query, reverse = _a4.reverse, unique = _a4.unique;
            return new Promise(function(resolve, reject) {
              resolve = wrap2(resolve);
              var index = query2.index, range = query2.range;
              var store = trans.objectStore(tableName);
              var source = index.isPrimaryKey ? store : store.index(index.name);
              var direction = reverse ? unique ? "prevunique" : "prev" : unique ? "nextunique" : "next";
              var req = values || !("openKeyCursor" in source) ? source.openCursor(makeIDBKeyRange(range), direction) : source.openKeyCursor(makeIDBKeyRange(range), direction);
              req.onerror = eventRejectHandler(reject);
              req.onsuccess = wrap2(function(ev) {
                var cursor = req.result;
                if (!cursor) {
                  resolve(null);
                  return;
                }
                cursor.___id = ++_id_counter;
                cursor.done = false;
                var _cursorContinue = cursor.continue.bind(cursor);
                var _cursorContinuePrimaryKey = cursor.continuePrimaryKey;
                if (_cursorContinuePrimaryKey)
                  _cursorContinuePrimaryKey = _cursorContinuePrimaryKey.bind(cursor);
                var _cursorAdvance = cursor.advance.bind(cursor);
                var doThrowCursorIsNotStarted = function() {
                  throw new Error("Cursor not started");
                };
                var doThrowCursorIsStopped = function() {
                  throw new Error("Cursor not stopped");
                };
                cursor.trans = trans;
                cursor.stop = cursor.continue = cursor.continuePrimaryKey = cursor.advance = doThrowCursorIsNotStarted;
                cursor.fail = wrap2(reject);
                cursor.next = function() {
                  var _this = this;
                  var gotOne = 1;
                  return this.start(function() {
                    return gotOne-- ? _this.continue() : _this.stop();
                  }).then(function() {
                    return _this;
                  });
                };
                cursor.start = function(callback) {
                  var iterationPromise = new Promise(function(resolveIteration, rejectIteration) {
                    resolveIteration = wrap2(resolveIteration);
                    req.onerror = eventRejectHandler(rejectIteration);
                    cursor.fail = rejectIteration;
                    cursor.stop = function(value) {
                      cursor.stop = cursor.continue = cursor.continuePrimaryKey = cursor.advance = doThrowCursorIsStopped;
                      resolveIteration(value);
                    };
                  });
                  var guardedCallback = function() {
                    if (req.result) {
                      try {
                        callback();
                      } catch (err) {
                        cursor.fail(err);
                      }
                    } else {
                      cursor.done = true;
                      cursor.start = function() {
                        throw new Error("Cursor behind last entry");
                      };
                      cursor.stop();
                    }
                  };
                  req.onsuccess = wrap2(function(ev2) {
                    req.onsuccess = guardedCallback;
                    guardedCallback();
                  });
                  cursor.continue = _cursorContinue;
                  cursor.continuePrimaryKey = _cursorContinuePrimaryKey;
                  cursor.advance = _cursorAdvance;
                  guardedCallback();
                  return iterationPromise;
                };
                resolve(cursor);
              }, reject);
            });
          }
          function query(hasGetAll2) {
            return function(request) {
              return new Promise(function(resolve, reject) {
                resolve = wrap2(resolve);
                var trans = request.trans, values = request.values, limit = request.limit, query2 = request.query;
                var nonInfinitLimit = limit === Infinity ? void 0 : limit;
                var index = query2.index, range = query2.range;
                var store = trans.objectStore(tableName);
                var source = index.isPrimaryKey ? store : store.index(index.name);
                var idbKeyRange = makeIDBKeyRange(range);
                if (limit === 0)
                  return resolve({ result: [] });
                if (hasGetAll2) {
                  var req = values ? source.getAll(idbKeyRange, nonInfinitLimit) : source.getAllKeys(idbKeyRange, nonInfinitLimit);
                  req.onsuccess = function(event) {
                    return resolve({ result: event.target.result });
                  };
                  req.onerror = eventRejectHandler(reject);
                } else {
                  var count_1 = 0;
                  var req_1 = values || !("openKeyCursor" in source) ? source.openCursor(idbKeyRange) : source.openKeyCursor(idbKeyRange);
                  var result_1 = [];
                  req_1.onsuccess = function(event) {
                    var cursor = req_1.result;
                    if (!cursor)
                      return resolve({ result: result_1 });
                    result_1.push(values ? cursor.value : cursor.primaryKey);
                    if (++count_1 === limit)
                      return resolve({ result: result_1 });
                    cursor.continue();
                  };
                  req_1.onerror = eventRejectHandler(reject);
                }
              });
            };
          }
          return {
            name: tableName,
            schema: tableSchema,
            mutate,
            getMany: function(_a4) {
              var trans = _a4.trans, keys2 = _a4.keys;
              return new Promise(function(resolve, reject) {
                resolve = wrap2(resolve);
                var store = trans.objectStore(tableName);
                var length = keys2.length;
                var result = new Array(length);
                var keyCount = 0;
                var callbackCount = 0;
                var req;
                var successHandler = function(event) {
                  var req2 = event.target;
                  if ((result[req2._pos] = req2.result) != null)
                    ;
                  if (++callbackCount === keyCount)
                    resolve(result);
                };
                var errorHandler = eventRejectHandler(reject);
                for (var i2 = 0; i2 < length; ++i2) {
                  var key = keys2[i2];
                  if (key != null) {
                    req = store.get(keys2[i2]);
                    req._pos = i2;
                    req.onsuccess = successHandler;
                    req.onerror = errorHandler;
                    ++keyCount;
                  }
                }
                if (keyCount === 0)
                  resolve(result);
              });
            },
            get: function(_a4) {
              var trans = _a4.trans, key = _a4.key;
              return new Promise(function(resolve, reject) {
                resolve = wrap2(resolve);
                var store = trans.objectStore(tableName);
                var req = store.get(key);
                req.onsuccess = function(event) {
                  return resolve(event.target.result);
                };
                req.onerror = eventRejectHandler(reject);
              });
            },
            query: query(hasGetAll),
            openCursor: openCursor2,
            count: function(_a4) {
              var query2 = _a4.query, trans = _a4.trans;
              var index = query2.index, range = query2.range;
              return new Promise(function(resolve, reject) {
                var store = trans.objectStore(tableName);
                var source = index.isPrimaryKey ? store : store.index(index.name);
                var idbKeyRange = makeIDBKeyRange(range);
                var req = idbKeyRange ? source.count(idbKeyRange) : source.count();
                req.onsuccess = wrap2(function(ev) {
                  return resolve(ev.target.result);
                });
                req.onerror = eventRejectHandler(reject);
              });
            }
          };
        }
        var _a3 = extractSchema(db2, tmpTrans), schema = _a3.schema, hasGetAll = _a3.hasGetAll;
        var tables = schema.tables.map(function(tableSchema) {
          return createDbCoreTable(tableSchema);
        });
        var tableMap = {};
        tables.forEach(function(table) {
          return tableMap[table.name] = table;
        });
        return {
          stack: "dbcore",
          transaction: db2.transaction.bind(db2),
          table: function(name) {
            var result = tableMap[name];
            if (!result)
              throw new Error("Table '".concat(name, "' not found"));
            return tableMap[name];
          },
          MIN_KEY: -Infinity,
          MAX_KEY: getMaxKey(IdbKeyRange),
          schema
        };
      }
      function createMiddlewareStack(stackImpl, middlewares) {
        return middlewares.reduce(function(down, _a3) {
          var create = _a3.create;
          return __assign2(__assign2({}, down), create(down));
        }, stackImpl);
      }
      function createMiddlewareStacks(middlewares, idbdb, _a3, tmpTrans) {
        var IDBKeyRange = _a3.IDBKeyRange;
        _a3.indexedDB;
        var dbcore = createMiddlewareStack(createDBCore(idbdb, IDBKeyRange, tmpTrans), middlewares.dbcore);
        return {
          dbcore
        };
      }
      function generateMiddlewareStacks(db2, tmpTrans) {
        var idbdb = tmpTrans.db;
        var stacks = createMiddlewareStacks(db2._middlewares, idbdb, db2._deps, tmpTrans);
        db2.core = stacks.dbcore;
        db2.tables.forEach(function(table) {
          var tableName = table.name;
          if (db2.core.schema.tables.some(function(tbl) {
            return tbl.name === tableName;
          })) {
            table.core = db2.core.table(tableName);
            if (db2[tableName] instanceof db2.Table) {
              db2[tableName].core = table.core;
            }
          }
        });
      }
      function setApiOnPlace(db2, objs, tableNames, dbschema) {
        tableNames.forEach(function(tableName) {
          var schema = dbschema[tableName];
          objs.forEach(function(obj) {
            var propDesc = getPropertyDescriptor(obj, tableName);
            if (!propDesc || "value" in propDesc && propDesc.value === void 0) {
              if (obj === db2.Transaction.prototype || obj instanceof db2.Transaction) {
                setProp(obj, tableName, {
                  get: function() {
                    return this.table(tableName);
                  },
                  set: function(value) {
                    defineProperty(this, tableName, { value, writable: true, configurable: true, enumerable: true });
                  }
                });
              } else {
                obj[tableName] = new db2.Table(tableName, schema);
              }
            }
          });
        });
      }
      function removeTablesApi(db2, objs) {
        objs.forEach(function(obj) {
          for (var key in obj) {
            if (obj[key] instanceof db2.Table)
              delete obj[key];
          }
        });
      }
      function lowerVersionFirst(a, b2) {
        return a._cfg.version - b2._cfg.version;
      }
      function runUpgraders(db2, oldVersion, idbUpgradeTrans, reject) {
        var globalSchema = db2._dbSchema;
        if (idbUpgradeTrans.objectStoreNames.contains("$meta") && !globalSchema.$meta) {
          globalSchema.$meta = createTableSchema("$meta", parseIndexSyntax("")[0], []);
          db2._storeNames.push("$meta");
        }
        var trans = db2._createTransaction("readwrite", db2._storeNames, globalSchema);
        trans.create(idbUpgradeTrans);
        trans._completion.catch(reject);
        var rejectTransaction = trans._reject.bind(trans);
        var transless = PSD.transless || PSD;
        newScope(function() {
          PSD.trans = trans;
          PSD.transless = transless;
          if (oldVersion === 0) {
            keys(globalSchema).forEach(function(tableName) {
              createTable(idbUpgradeTrans, tableName, globalSchema[tableName].primKey, globalSchema[tableName].indexes);
            });
            generateMiddlewareStacks(db2, idbUpgradeTrans);
            DexiePromise.follow(function() {
              return db2.on.populate.fire(trans);
            }).catch(rejectTransaction);
          } else {
            generateMiddlewareStacks(db2, idbUpgradeTrans);
            return getExistingVersion(db2, trans, oldVersion).then(function(oldVersion2) {
              return updateTablesAndIndexes(db2, oldVersion2, trans, idbUpgradeTrans);
            }).catch(rejectTransaction);
          }
        });
      }
      function patchCurrentVersion(db2, idbUpgradeTrans) {
        createMissingTables(db2._dbSchema, idbUpgradeTrans);
        if (idbUpgradeTrans.db.version % 10 === 0 && !idbUpgradeTrans.objectStoreNames.contains("$meta")) {
          idbUpgradeTrans.db.createObjectStore("$meta").add(Math.ceil(idbUpgradeTrans.db.version / 10 - 1), "version");
        }
        var globalSchema = buildGlobalSchema(db2, db2.idbdb, idbUpgradeTrans);
        adjustToExistingIndexNames(db2, db2._dbSchema, idbUpgradeTrans);
        var diff = getSchemaDiff(globalSchema, db2._dbSchema);
        var _loop_1 = function(tableChange2) {
          if (tableChange2.change.length || tableChange2.recreate) {
            console.warn("Unable to patch indexes of table ".concat(tableChange2.name, " because it has changes on the type of index or primary key."));
            return { value: void 0 };
          }
          var store = idbUpgradeTrans.objectStore(tableChange2.name);
          tableChange2.add.forEach(function(idx) {
            if (debug)
              console.debug("Dexie upgrade patch: Creating missing index ".concat(tableChange2.name, ".").concat(idx.src));
            addIndex(store, idx);
          });
        };
        for (var _i = 0, _a3 = diff.change; _i < _a3.length; _i++) {
          var tableChange = _a3[_i];
          var state_1 = _loop_1(tableChange);
          if (typeof state_1 === "object")
            return state_1.value;
        }
      }
      function getExistingVersion(db2, trans, oldVersion) {
        if (trans.storeNames.includes("$meta")) {
          return trans.table("$meta").get("version").then(function(metaVersion) {
            return metaVersion != null ? metaVersion : oldVersion;
          });
        } else {
          return DexiePromise.resolve(oldVersion);
        }
      }
      function updateTablesAndIndexes(db2, oldVersion, trans, idbUpgradeTrans) {
        var queue = [];
        var versions = db2._versions;
        var globalSchema = db2._dbSchema = buildGlobalSchema(db2, db2.idbdb, idbUpgradeTrans);
        var versToRun = versions.filter(function(v2) {
          return v2._cfg.version >= oldVersion;
        });
        if (versToRun.length === 0) {
          return DexiePromise.resolve();
        }
        versToRun.forEach(function(version) {
          queue.push(function() {
            var oldSchema = globalSchema;
            var newSchema = version._cfg.dbschema;
            adjustToExistingIndexNames(db2, oldSchema, idbUpgradeTrans);
            adjustToExistingIndexNames(db2, newSchema, idbUpgradeTrans);
            globalSchema = db2._dbSchema = newSchema;
            var diff = getSchemaDiff(oldSchema, newSchema);
            diff.add.forEach(function(tuple) {
              createTable(idbUpgradeTrans, tuple[0], tuple[1].primKey, tuple[1].indexes);
            });
            diff.change.forEach(function(change) {
              if (change.recreate) {
                throw new exceptions.Upgrade("Not yet support for changing primary key");
              } else {
                var store_1 = idbUpgradeTrans.objectStore(change.name);
                change.add.forEach(function(idx) {
                  return addIndex(store_1, idx);
                });
                change.change.forEach(function(idx) {
                  store_1.deleteIndex(idx.name);
                  addIndex(store_1, idx);
                });
                change.del.forEach(function(idxName) {
                  return store_1.deleteIndex(idxName);
                });
              }
            });
            var contentUpgrade = version._cfg.contentUpgrade;
            if (contentUpgrade && version._cfg.version > oldVersion) {
              generateMiddlewareStacks(db2, idbUpgradeTrans);
              trans._memoizedTables = {};
              var upgradeSchema_1 = shallowClone(newSchema);
              diff.del.forEach(function(table) {
                upgradeSchema_1[table] = oldSchema[table];
              });
              removeTablesApi(db2, [db2.Transaction.prototype]);
              setApiOnPlace(db2, [db2.Transaction.prototype], keys(upgradeSchema_1), upgradeSchema_1);
              trans.schema = upgradeSchema_1;
              var contentUpgradeIsAsync_1 = isAsyncFunction(contentUpgrade);
              if (contentUpgradeIsAsync_1) {
                incrementExpectedAwaits();
              }
              var returnValue_1;
              var promiseFollowed = DexiePromise.follow(function() {
                returnValue_1 = contentUpgrade(trans);
                if (returnValue_1) {
                  if (contentUpgradeIsAsync_1) {
                    var decrementor = decrementExpectedAwaits.bind(null, null);
                    returnValue_1.then(decrementor, decrementor);
                  }
                }
              });
              return returnValue_1 && typeof returnValue_1.then === "function" ? DexiePromise.resolve(returnValue_1) : promiseFollowed.then(function() {
                return returnValue_1;
              });
            }
          });
          queue.push(function(idbtrans) {
            var newSchema = version._cfg.dbschema;
            deleteRemovedTables(newSchema, idbtrans);
            removeTablesApi(db2, [db2.Transaction.prototype]);
            setApiOnPlace(db2, [db2.Transaction.prototype], db2._storeNames, db2._dbSchema);
            trans.schema = db2._dbSchema;
          });
          queue.push(function(idbtrans) {
            if (db2.idbdb.objectStoreNames.contains("$meta")) {
              if (Math.ceil(db2.idbdb.version / 10) === version._cfg.version) {
                db2.idbdb.deleteObjectStore("$meta");
                delete db2._dbSchema.$meta;
                db2._storeNames = db2._storeNames.filter(function(name) {
                  return name !== "$meta";
                });
              } else {
                idbtrans.objectStore("$meta").put(version._cfg.version, "version");
              }
            }
          });
        });
        function runQueue() {
          return queue.length ? DexiePromise.resolve(queue.shift()(trans.idbtrans)).then(runQueue) : DexiePromise.resolve();
        }
        return runQueue().then(function() {
          createMissingTables(globalSchema, idbUpgradeTrans);
        });
      }
      function getSchemaDiff(oldSchema, newSchema) {
        var diff = {
          del: [],
          add: [],
          change: []
        };
        var table;
        for (table in oldSchema) {
          if (!newSchema[table])
            diff.del.push(table);
        }
        for (table in newSchema) {
          var oldDef = oldSchema[table], newDef = newSchema[table];
          if (!oldDef) {
            diff.add.push([table, newDef]);
          } else {
            var change = {
              name: table,
              def: newDef,
              recreate: false,
              del: [],
              add: [],
              change: []
            };
            if ("" + (oldDef.primKey.keyPath || "") !== "" + (newDef.primKey.keyPath || "") || oldDef.primKey.auto !== newDef.primKey.auto) {
              change.recreate = true;
              diff.change.push(change);
            } else {
              var oldIndexes = oldDef.idxByName;
              var newIndexes = newDef.idxByName;
              var idxName = void 0;
              for (idxName in oldIndexes) {
                if (!newIndexes[idxName])
                  change.del.push(idxName);
              }
              for (idxName in newIndexes) {
                var oldIdx = oldIndexes[idxName], newIdx = newIndexes[idxName];
                if (!oldIdx)
                  change.add.push(newIdx);
                else if (oldIdx.src !== newIdx.src)
                  change.change.push(newIdx);
              }
              if (change.del.length > 0 || change.add.length > 0 || change.change.length > 0) {
                diff.change.push(change);
              }
            }
          }
        }
        return diff;
      }
      function createTable(idbtrans, tableName, primKey, indexes) {
        var store = idbtrans.db.createObjectStore(tableName, primKey.keyPath ? { keyPath: primKey.keyPath, autoIncrement: primKey.auto } : { autoIncrement: primKey.auto });
        indexes.forEach(function(idx) {
          return addIndex(store, idx);
        });
        return store;
      }
      function createMissingTables(newSchema, idbtrans) {
        keys(newSchema).forEach(function(tableName) {
          if (!idbtrans.db.objectStoreNames.contains(tableName)) {
            if (debug)
              console.debug("Dexie: Creating missing table", tableName);
            createTable(idbtrans, tableName, newSchema[tableName].primKey, newSchema[tableName].indexes);
          }
        });
      }
      function deleteRemovedTables(newSchema, idbtrans) {
        [].slice.call(idbtrans.db.objectStoreNames).forEach(function(storeName) {
          return newSchema[storeName] == null && idbtrans.db.deleteObjectStore(storeName);
        });
      }
      function addIndex(store, idx) {
        store.createIndex(idx.name, idx.keyPath, { unique: idx.unique, multiEntry: idx.multi });
      }
      function buildGlobalSchema(db2, idbdb, tmpTrans) {
        var globalSchema = {};
        var dbStoreNames = slice(idbdb.objectStoreNames, 0);
        dbStoreNames.forEach(function(storeName) {
          var store = tmpTrans.objectStore(storeName);
          var keyPath = store.keyPath;
          var primKey = createIndexSpec(nameFromKeyPath(keyPath), keyPath || "", true, false, !!store.autoIncrement, keyPath && typeof keyPath !== "string", true);
          var indexes = [];
          for (var j2 = 0; j2 < store.indexNames.length; ++j2) {
            var idbindex = store.index(store.indexNames[j2]);
            keyPath = idbindex.keyPath;
            var index = createIndexSpec(idbindex.name, keyPath, !!idbindex.unique, !!idbindex.multiEntry, false, keyPath && typeof keyPath !== "string", false);
            indexes.push(index);
          }
          globalSchema[storeName] = createTableSchema(storeName, primKey, indexes);
        });
        return globalSchema;
      }
      function readGlobalSchema(db2, idbdb, tmpTrans) {
        db2.verno = idbdb.version / 10;
        var globalSchema = db2._dbSchema = buildGlobalSchema(db2, idbdb, tmpTrans);
        db2._storeNames = slice(idbdb.objectStoreNames, 0);
        setApiOnPlace(db2, [db2._allTables], keys(globalSchema), globalSchema);
      }
      function verifyInstalledSchema(db2, tmpTrans) {
        var installedSchema = buildGlobalSchema(db2, db2.idbdb, tmpTrans);
        var diff = getSchemaDiff(installedSchema, db2._dbSchema);
        return !(diff.add.length || diff.change.some(function(ch) {
          return ch.add.length || ch.change.length;
        }));
      }
      function adjustToExistingIndexNames(db2, schema, idbtrans) {
        var storeNames = idbtrans.db.objectStoreNames;
        for (var i2 = 0; i2 < storeNames.length; ++i2) {
          var storeName = storeNames[i2];
          var store = idbtrans.objectStore(storeName);
          db2._hasGetAll = "getAll" in store;
          for (var j2 = 0; j2 < store.indexNames.length; ++j2) {
            var indexName = store.indexNames[j2];
            var keyPath = store.index(indexName).keyPath;
            var dexieName = typeof keyPath === "string" ? keyPath : "[" + slice(keyPath).join("+") + "]";
            if (schema[storeName]) {
              var indexSpec = schema[storeName].idxByName[dexieName];
              if (indexSpec) {
                indexSpec.name = indexName;
                delete schema[storeName].idxByName[dexieName];
                schema[storeName].idxByName[indexName] = indexSpec;
              }
            }
          }
        }
        if (typeof navigator !== "undefined" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && _global.WorkerGlobalScope && _global instanceof _global.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604) {
          db2._hasGetAll = false;
        }
      }
      function parseIndexSyntax(primKeyAndIndexes) {
        return primKeyAndIndexes.split(",").map(function(index, indexNum) {
          index = index.trim();
          var name = index.replace(/([&*]|\+\+)/g, "");
          var keyPath = /^\[/.test(name) ? name.match(/^\[(.*)\]$/)[1].split("+") : name;
          return createIndexSpec(name, keyPath || null, /\&/.test(index), /\*/.test(index), /\+\+/.test(index), isArray(keyPath), indexNum === 0);
        });
      }
      var Version = function() {
        function Version2() {
        }
        Version2.prototype._parseStoresSpec = function(stores, outSchema) {
          keys(stores).forEach(function(tableName) {
            if (stores[tableName] !== null) {
              var indexes = parseIndexSyntax(stores[tableName]);
              var primKey = indexes.shift();
              primKey.unique = true;
              if (primKey.multi)
                throw new exceptions.Schema("Primary key cannot be multi-valued");
              indexes.forEach(function(idx) {
                if (idx.auto)
                  throw new exceptions.Schema("Only primary key can be marked as autoIncrement (++)");
                if (!idx.keyPath)
                  throw new exceptions.Schema("Index must have a name and cannot be an empty string");
              });
              outSchema[tableName] = createTableSchema(tableName, primKey, indexes);
            }
          });
        };
        Version2.prototype.stores = function(stores) {
          var db2 = this.db;
          this._cfg.storesSource = this._cfg.storesSource ? extend(this._cfg.storesSource, stores) : stores;
          var versions = db2._versions;
          var storesSpec = {};
          var dbschema = {};
          versions.forEach(function(version) {
            extend(storesSpec, version._cfg.storesSource);
            dbschema = version._cfg.dbschema = {};
            version._parseStoresSpec(storesSpec, dbschema);
          });
          db2._dbSchema = dbschema;
          removeTablesApi(db2, [db2._allTables, db2, db2.Transaction.prototype]);
          setApiOnPlace(db2, [db2._allTables, db2, db2.Transaction.prototype, this._cfg.tables], keys(dbschema), dbschema);
          db2._storeNames = keys(dbschema);
          return this;
        };
        Version2.prototype.upgrade = function(upgradeFunction) {
          this._cfg.contentUpgrade = promisableChain(this._cfg.contentUpgrade || nop, upgradeFunction);
          return this;
        };
        return Version2;
      }();
      function createVersionConstructor(db2) {
        return makeClassConstructor(Version.prototype, function Version2(versionNumber) {
          this.db = db2;
          this._cfg = {
            version: versionNumber,
            storesSource: null,
            dbschema: {},
            tables: {},
            contentUpgrade: null
          };
        });
      }
      function getDbNamesTable(indexedDB2, IDBKeyRange) {
        var dbNamesDB = indexedDB2["_dbNamesDB"];
        if (!dbNamesDB) {
          dbNamesDB = indexedDB2["_dbNamesDB"] = new Dexie$1(DBNAMES_DB, {
            addons: [],
            indexedDB: indexedDB2,
            IDBKeyRange
          });
          dbNamesDB.version(1).stores({ dbnames: "name" });
        }
        return dbNamesDB.table("dbnames");
      }
      function hasDatabasesNative(indexedDB2) {
        return indexedDB2 && typeof indexedDB2.databases === "function";
      }
      function getDatabaseNames(_a3) {
        var indexedDB2 = _a3.indexedDB, IDBKeyRange = _a3.IDBKeyRange;
        return hasDatabasesNative(indexedDB2) ? Promise.resolve(indexedDB2.databases()).then(function(infos) {
          return infos.map(function(info) {
            return info.name;
          }).filter(function(name) {
            return name !== DBNAMES_DB;
          });
        }) : getDbNamesTable(indexedDB2, IDBKeyRange).toCollection().primaryKeys();
      }
      function _onDatabaseCreated(_a3, name) {
        var indexedDB2 = _a3.indexedDB, IDBKeyRange = _a3.IDBKeyRange;
        !hasDatabasesNative(indexedDB2) && name !== DBNAMES_DB && getDbNamesTable(indexedDB2, IDBKeyRange).put({ name }).catch(nop);
      }
      function _onDatabaseDeleted(_a3, name) {
        var indexedDB2 = _a3.indexedDB, IDBKeyRange = _a3.IDBKeyRange;
        !hasDatabasesNative(indexedDB2) && name !== DBNAMES_DB && getDbNamesTable(indexedDB2, IDBKeyRange).delete(name).catch(nop);
      }
      function vip(fn) {
        return newScope(function() {
          PSD.letThrough = true;
          return fn();
        });
      }
      function idbReady() {
        var isSafari = !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent);
        if (!isSafari || !indexedDB.databases)
          return Promise.resolve();
        var intervalId;
        return new Promise(function(resolve) {
          var tryIdb = function() {
            return indexedDB.databases().finally(resolve);
          };
          intervalId = setInterval(tryIdb, 100);
          tryIdb();
        }).finally(function() {
          return clearInterval(intervalId);
        });
      }
      var _a2;
      function isEmptyRange(node) {
        return !("from" in node);
      }
      var RangeSet = function(fromOrTree, to) {
        if (this) {
          extend(this, arguments.length ? { d: 1, from: fromOrTree, to: arguments.length > 1 ? to : fromOrTree } : { d: 0 });
        } else {
          var rv = new RangeSet();
          if (fromOrTree && "d" in fromOrTree) {
            extend(rv, fromOrTree);
          }
          return rv;
        }
      };
      props(RangeSet.prototype, (_a2 = {
        add: function(rangeSet) {
          mergeRanges(this, rangeSet);
          return this;
        },
        addKey: function(key) {
          addRange(this, key, key);
          return this;
        },
        addKeys: function(keys2) {
          var _this = this;
          keys2.forEach(function(key) {
            return addRange(_this, key, key);
          });
          return this;
        },
        hasKey: function(key) {
          var node = getRangeSetIterator(this).next(key).value;
          return node && cmp(node.from, key) <= 0 && cmp(node.to, key) >= 0;
        }
      }, _a2[iteratorSymbol] = function() {
        return getRangeSetIterator(this);
      }, _a2));
      function addRange(target, from, to) {
        var diff = cmp(from, to);
        if (isNaN(diff))
          return;
        if (diff > 0)
          throw RangeError();
        if (isEmptyRange(target))
          return extend(target, { from, to, d: 1 });
        var left = target.l;
        var right = target.r;
        if (cmp(to, target.from) < 0) {
          left ? addRange(left, from, to) : target.l = { from, to, d: 1, l: null, r: null };
          return rebalance(target);
        }
        if (cmp(from, target.to) > 0) {
          right ? addRange(right, from, to) : target.r = { from, to, d: 1, l: null, r: null };
          return rebalance(target);
        }
        if (cmp(from, target.from) < 0) {
          target.from = from;
          target.l = null;
          target.d = right ? right.d + 1 : 1;
        }
        if (cmp(to, target.to) > 0) {
          target.to = to;
          target.r = null;
          target.d = target.l ? target.l.d + 1 : 1;
        }
        var rightWasCutOff = !target.r;
        if (left && !target.l) {
          mergeRanges(target, left);
        }
        if (right && rightWasCutOff) {
          mergeRanges(target, right);
        }
      }
      function mergeRanges(target, newSet) {
        function _addRangeSet(target2, _a3) {
          var from = _a3.from, to = _a3.to, l = _a3.l, r2 = _a3.r;
          addRange(target2, from, to);
          if (l)
            _addRangeSet(target2, l);
          if (r2)
            _addRangeSet(target2, r2);
        }
        if (!isEmptyRange(newSet))
          _addRangeSet(target, newSet);
      }
      function rangesOverlap(rangeSet1, rangeSet2) {
        var i1 = getRangeSetIterator(rangeSet2);
        var nextResult1 = i1.next();
        if (nextResult1.done)
          return false;
        var a = nextResult1.value;
        var i2 = getRangeSetIterator(rangeSet1);
        var nextResult2 = i2.next(a.from);
        var b2 = nextResult2.value;
        while (!nextResult1.done && !nextResult2.done) {
          if (cmp(b2.from, a.to) <= 0 && cmp(b2.to, a.from) >= 0)
            return true;
          cmp(a.from, b2.from) < 0 ? a = (nextResult1 = i1.next(b2.from)).value : b2 = (nextResult2 = i2.next(a.from)).value;
        }
        return false;
      }
      function getRangeSetIterator(node) {
        var state = isEmptyRange(node) ? null : { s: 0, n: node };
        return {
          next: function(key) {
            var keyProvided = arguments.length > 0;
            while (state) {
              switch (state.s) {
                case 0:
                  state.s = 1;
                  if (keyProvided) {
                    while (state.n.l && cmp(key, state.n.from) < 0)
                      state = { up: state, n: state.n.l, s: 1 };
                  } else {
                    while (state.n.l)
                      state = { up: state, n: state.n.l, s: 1 };
                  }
                case 1:
                  state.s = 2;
                  if (!keyProvided || cmp(key, state.n.to) <= 0)
                    return { value: state.n, done: false };
                case 2:
                  if (state.n.r) {
                    state.s = 3;
                    state = { up: state, n: state.n.r, s: 0 };
                    continue;
                  }
                case 3:
                  state = state.up;
              }
            }
            return { done: true };
          }
        };
      }
      function rebalance(target) {
        var _a3, _b;
        var diff = (((_a3 = target.r) === null || _a3 === void 0 ? void 0 : _a3.d) || 0) - (((_b = target.l) === null || _b === void 0 ? void 0 : _b.d) || 0);
        var r2 = diff > 1 ? "r" : diff < -1 ? "l" : "";
        if (r2) {
          var l = r2 === "r" ? "l" : "r";
          var rootClone = __assign2({}, target);
          var oldRootRight = target[r2];
          target.from = oldRootRight.from;
          target.to = oldRootRight.to;
          target[r2] = oldRootRight[r2];
          rootClone[r2] = oldRootRight[l];
          target[l] = rootClone;
          rootClone.d = computeDepth(rootClone);
        }
        target.d = computeDepth(target);
      }
      function computeDepth(_a3) {
        var r2 = _a3.r, l = _a3.l;
        return (r2 ? l ? Math.max(r2.d, l.d) : r2.d : l ? l.d : 0) + 1;
      }
      function extendObservabilitySet(target, newSet) {
        keys(newSet).forEach(function(part) {
          if (target[part])
            mergeRanges(target[part], newSet[part]);
          else
            target[part] = cloneSimpleObjectTree(newSet[part]);
        });
        return target;
      }
      function obsSetsOverlap(os1, os2) {
        return os1.all || os2.all || Object.keys(os1).some(function(key) {
          return os2[key] && rangesOverlap(os2[key], os1[key]);
        });
      }
      var cache = {};
      var unsignaledParts = {};
      var isTaskEnqueued = false;
      function signalSubscribersLazily(part, optimistic) {
        extendObservabilitySet(unsignaledParts, part);
        if (!isTaskEnqueued) {
          isTaskEnqueued = true;
          setTimeout(function() {
            isTaskEnqueued = false;
            var parts = unsignaledParts;
            unsignaledParts = {};
            signalSubscribersNow(parts, false);
          }, 0);
        }
      }
      function signalSubscribersNow(updatedParts, deleteAffectedCacheEntries) {
        if (deleteAffectedCacheEntries === void 0) {
          deleteAffectedCacheEntries = false;
        }
        var queriesToSignal = /* @__PURE__ */ new Set();
        if (updatedParts.all) {
          for (var _i = 0, _a3 = Object.values(cache); _i < _a3.length; _i++) {
            var tblCache = _a3[_i];
            collectTableSubscribers(tblCache, updatedParts, queriesToSignal, deleteAffectedCacheEntries);
          }
        } else {
          for (var key in updatedParts) {
            var parts = /^idb\:\/\/(.*)\/(.*)\//.exec(key);
            if (parts) {
              var dbName = parts[1], tableName = parts[2];
              var tblCache = cache["idb://".concat(dbName, "/").concat(tableName)];
              if (tblCache)
                collectTableSubscribers(tblCache, updatedParts, queriesToSignal, deleteAffectedCacheEntries);
            }
          }
        }
        queriesToSignal.forEach(function(requery) {
          return requery();
        });
      }
      function collectTableSubscribers(tblCache, updatedParts, outQueriesToSignal, deleteAffectedCacheEntries) {
        var updatedEntryLists = [];
        for (var _i = 0, _a3 = Object.entries(tblCache.queries.query); _i < _a3.length; _i++) {
          var _b = _a3[_i], indexName = _b[0], entries = _b[1];
          var filteredEntries = [];
          for (var _c = 0, entries_1 = entries; _c < entries_1.length; _c++) {
            var entry = entries_1[_c];
            if (obsSetsOverlap(updatedParts, entry.obsSet)) {
              entry.subscribers.forEach(function(requery) {
                return outQueriesToSignal.add(requery);
              });
            } else if (deleteAffectedCacheEntries) {
              filteredEntries.push(entry);
            }
          }
          if (deleteAffectedCacheEntries)
            updatedEntryLists.push([indexName, filteredEntries]);
        }
        if (deleteAffectedCacheEntries) {
          for (var _d = 0, updatedEntryLists_1 = updatedEntryLists; _d < updatedEntryLists_1.length; _d++) {
            var _e = updatedEntryLists_1[_d], indexName = _e[0], filteredEntries = _e[1];
            tblCache.queries.query[indexName] = filteredEntries;
          }
        }
      }
      function dexieOpen(db2) {
        var state = db2._state;
        var indexedDB2 = db2._deps.indexedDB;
        if (state.isBeingOpened || db2.idbdb)
          return state.dbReadyPromise.then(function() {
            return state.dbOpenError ? rejection(state.dbOpenError) : db2;
          });
        state.isBeingOpened = true;
        state.dbOpenError = null;
        state.openComplete = false;
        var openCanceller = state.openCanceller;
        var nativeVerToOpen = Math.round(db2.verno * 10);
        var schemaPatchMode = false;
        function throwIfCancelled() {
          if (state.openCanceller !== openCanceller)
            throw new exceptions.DatabaseClosed("db.open() was cancelled");
        }
        var resolveDbReady = state.dbReadyResolve, upgradeTransaction = null, wasCreated = false;
        var tryOpenDB = function() {
          return new DexiePromise(function(resolve, reject) {
            throwIfCancelled();
            if (!indexedDB2)
              throw new exceptions.MissingAPI();
            var dbName = db2.name;
            var req = state.autoSchema || !nativeVerToOpen ? indexedDB2.open(dbName) : indexedDB2.open(dbName, nativeVerToOpen);
            if (!req)
              throw new exceptions.MissingAPI();
            req.onerror = eventRejectHandler(reject);
            req.onblocked = wrap2(db2._fireOnBlocked);
            req.onupgradeneeded = wrap2(function(e2) {
              upgradeTransaction = req.transaction;
              if (state.autoSchema && !db2._options.allowEmptyDB) {
                req.onerror = preventDefault;
                upgradeTransaction.abort();
                req.result.close();
                var delreq = indexedDB2.deleteDatabase(dbName);
                delreq.onsuccess = delreq.onerror = wrap2(function() {
                  reject(new exceptions.NoSuchDatabase("Database ".concat(dbName, " doesnt exist")));
                });
              } else {
                upgradeTransaction.onerror = eventRejectHandler(reject);
                var oldVer = e2.oldVersion > Math.pow(2, 62) ? 0 : e2.oldVersion;
                wasCreated = oldVer < 1;
                db2.idbdb = req.result;
                if (schemaPatchMode) {
                  patchCurrentVersion(db2, upgradeTransaction);
                }
                runUpgraders(db2, oldVer / 10, upgradeTransaction, reject);
              }
            }, reject);
            req.onsuccess = wrap2(function() {
              upgradeTransaction = null;
              var idbdb = db2.idbdb = req.result;
              var objectStoreNames = slice(idbdb.objectStoreNames);
              if (objectStoreNames.length > 0)
                try {
                  var tmpTrans = idbdb.transaction(safariMultiStoreFix(objectStoreNames), "readonly");
                  if (state.autoSchema)
                    readGlobalSchema(db2, idbdb, tmpTrans);
                  else {
                    adjustToExistingIndexNames(db2, db2._dbSchema, tmpTrans);
                    if (!verifyInstalledSchema(db2, tmpTrans) && !schemaPatchMode) {
                      console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this.");
                      idbdb.close();
                      nativeVerToOpen = idbdb.version + 1;
                      schemaPatchMode = true;
                      return resolve(tryOpenDB());
                    }
                  }
                  generateMiddlewareStacks(db2, tmpTrans);
                } catch (e2) {
                }
              connections.push(db2);
              idbdb.onversionchange = wrap2(function(ev) {
                state.vcFired = true;
                db2.on("versionchange").fire(ev);
              });
              idbdb.onclose = wrap2(function(ev) {
                db2.on("close").fire(ev);
              });
              if (wasCreated)
                _onDatabaseCreated(db2._deps, dbName);
              resolve();
            }, reject);
          }).catch(function(err) {
            switch (err === null || err === void 0 ? void 0 : err.name) {
              case "UnknownError":
                if (state.PR1398_maxLoop > 0) {
                  state.PR1398_maxLoop--;
                  console.warn("Dexie: Workaround for Chrome UnknownError on open()");
                  return tryOpenDB();
                }
                break;
              case "VersionError":
                if (nativeVerToOpen > 0) {
                  nativeVerToOpen = 0;
                  return tryOpenDB();
                }
                break;
            }
            return DexiePromise.reject(err);
          });
        };
        return DexiePromise.race([
          openCanceller,
          (typeof navigator === "undefined" ? DexiePromise.resolve() : idbReady()).then(tryOpenDB)
        ]).then(function() {
          throwIfCancelled();
          state.onReadyBeingFired = [];
          return DexiePromise.resolve(vip(function() {
            return db2.on.ready.fire(db2.vip);
          })).then(function fireRemainders() {
            if (state.onReadyBeingFired.length > 0) {
              var remainders_1 = state.onReadyBeingFired.reduce(promisableChain, nop);
              state.onReadyBeingFired = [];
              return DexiePromise.resolve(vip(function() {
                return remainders_1(db2.vip);
              })).then(fireRemainders);
            }
          });
        }).finally(function() {
          if (state.openCanceller === openCanceller) {
            state.onReadyBeingFired = null;
            state.isBeingOpened = false;
          }
        }).catch(function(err) {
          state.dbOpenError = err;
          try {
            upgradeTransaction && upgradeTransaction.abort();
          } catch (_a3) {
          }
          if (openCanceller === state.openCanceller) {
            db2._close();
          }
          return rejection(err);
        }).finally(function() {
          state.openComplete = true;
          resolveDbReady();
        }).then(function() {
          if (wasCreated) {
            var everything_1 = {};
            db2.tables.forEach(function(table) {
              table.schema.indexes.forEach(function(idx) {
                if (idx.name)
                  everything_1["idb://".concat(db2.name, "/").concat(table.name, "/").concat(idx.name)] = new RangeSet(-Infinity, [[[]]]);
              });
              everything_1["idb://".concat(db2.name, "/").concat(table.name, "/")] = everything_1["idb://".concat(db2.name, "/").concat(table.name, "/:dels")] = new RangeSet(-Infinity, [[[]]]);
            });
            globalEvents(DEXIE_STORAGE_MUTATED_EVENT_NAME).fire(everything_1);
            signalSubscribersNow(everything_1, true);
          }
          return db2;
        });
      }
      function awaitIterator(iterator) {
        var callNext = function(result) {
          return iterator.next(result);
        }, doThrow = function(error) {
          return iterator.throw(error);
        }, onSuccess = step(callNext), onError = step(doThrow);
        function step(getNext) {
          return function(val) {
            var next = getNext(val), value = next.value;
            return next.done ? value : !value || typeof value.then !== "function" ? isArray(value) ? Promise.all(value).then(onSuccess, onError) : onSuccess(value) : value.then(onSuccess, onError);
          };
        }
        return step(callNext)();
      }
      function extractTransactionArgs(mode, _tableArgs_, scopeFunc) {
        var i2 = arguments.length;
        if (i2 < 2)
          throw new exceptions.InvalidArgument("Too few arguments");
        var args = new Array(i2 - 1);
        while (--i2)
          args[i2 - 1] = arguments[i2];
        scopeFunc = args.pop();
        var tables = flatten(args);
        return [mode, tables, scopeFunc];
      }
      function enterTransactionScope(db2, mode, storeNames, parentTransaction, scopeFunc) {
        return DexiePromise.resolve().then(function() {
          var transless = PSD.transless || PSD;
          var trans = db2._createTransaction(mode, storeNames, db2._dbSchema, parentTransaction);
          trans.explicit = true;
          var zoneProps = {
            trans,
            transless
          };
          if (parentTransaction) {
            trans.idbtrans = parentTransaction.idbtrans;
          } else {
            try {
              trans.create();
              trans.idbtrans._explicit = true;
              db2._state.PR1398_maxLoop = 3;
            } catch (ex) {
              if (ex.name === errnames.InvalidState && db2.isOpen() && --db2._state.PR1398_maxLoop > 0) {
                console.warn("Dexie: Need to reopen db");
                db2.close({ disableAutoOpen: false });
                return db2.open().then(function() {
                  return enterTransactionScope(db2, mode, storeNames, null, scopeFunc);
                });
              }
              return rejection(ex);
            }
          }
          var scopeFuncIsAsync = isAsyncFunction(scopeFunc);
          if (scopeFuncIsAsync) {
            incrementExpectedAwaits();
          }
          var returnValue;
          var promiseFollowed = DexiePromise.follow(function() {
            returnValue = scopeFunc.call(trans, trans);
            if (returnValue) {
              if (scopeFuncIsAsync) {
                var decrementor = decrementExpectedAwaits.bind(null, null);
                returnValue.then(decrementor, decrementor);
              } else if (typeof returnValue.next === "function" && typeof returnValue.throw === "function") {
                returnValue = awaitIterator(returnValue);
              }
            }
          }, zoneProps);
          return (returnValue && typeof returnValue.then === "function" ? DexiePromise.resolve(returnValue).then(function(x2) {
            return trans.active ? x2 : rejection(new exceptions.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"));
          }) : promiseFollowed.then(function() {
            return returnValue;
          })).then(function(x2) {
            if (parentTransaction)
              trans._resolve();
            return trans._completion.then(function() {
              return x2;
            });
          }).catch(function(e2) {
            trans._reject(e2);
            return rejection(e2);
          });
        });
      }
      function pad(a, value, count) {
        var result = isArray(a) ? a.slice() : [a];
        for (var i2 = 0; i2 < count; ++i2)
          result.push(value);
        return result;
      }
      function createVirtualIndexMiddleware(down) {
        return __assign2(__assign2({}, down), { table: function(tableName) {
          var table = down.table(tableName);
          var schema = table.schema;
          var indexLookup = {};
          var allVirtualIndexes = [];
          function addVirtualIndexes(keyPath, keyTail, lowLevelIndex) {
            var keyPathAlias = getKeyPathAlias(keyPath);
            var indexList = indexLookup[keyPathAlias] = indexLookup[keyPathAlias] || [];
            var keyLength = keyPath == null ? 0 : typeof keyPath === "string" ? 1 : keyPath.length;
            var isVirtual = keyTail > 0;
            var virtualIndex = __assign2(__assign2({}, lowLevelIndex), { name: isVirtual ? "".concat(keyPathAlias, "(virtual-from:").concat(lowLevelIndex.name, ")") : lowLevelIndex.name, lowLevelIndex, isVirtual, keyTail, keyLength, extractKey: getKeyExtractor(keyPath), unique: !isVirtual && lowLevelIndex.unique });
            indexList.push(virtualIndex);
            if (!virtualIndex.isPrimaryKey) {
              allVirtualIndexes.push(virtualIndex);
            }
            if (keyLength > 1) {
              var virtualKeyPath = keyLength === 2 ? keyPath[0] : keyPath.slice(0, keyLength - 1);
              addVirtualIndexes(virtualKeyPath, keyTail + 1, lowLevelIndex);
            }
            indexList.sort(function(a, b2) {
              return a.keyTail - b2.keyTail;
            });
            return virtualIndex;
          }
          var primaryKey = addVirtualIndexes(schema.primaryKey.keyPath, 0, schema.primaryKey);
          indexLookup[":id"] = [primaryKey];
          for (var _i = 0, _a3 = schema.indexes; _i < _a3.length; _i++) {
            var index = _a3[_i];
            addVirtualIndexes(index.keyPath, 0, index);
          }
          function findBestIndex(keyPath) {
            var result2 = indexLookup[getKeyPathAlias(keyPath)];
            return result2 && result2[0];
          }
          function translateRange(range, keyTail) {
            return {
              type: range.type === 1 ? 2 : range.type,
              lower: pad(range.lower, range.lowerOpen ? down.MAX_KEY : down.MIN_KEY, keyTail),
              lowerOpen: true,
              upper: pad(range.upper, range.upperOpen ? down.MIN_KEY : down.MAX_KEY, keyTail),
              upperOpen: true
            };
          }
          function translateRequest(req) {
            var index2 = req.query.index;
            return index2.isVirtual ? __assign2(__assign2({}, req), { query: {
              index: index2.lowLevelIndex,
              range: translateRange(req.query.range, index2.keyTail)
            } }) : req;
          }
          var result = __assign2(__assign2({}, table), { schema: __assign2(__assign2({}, schema), { primaryKey, indexes: allVirtualIndexes, getIndexByKeyPath: findBestIndex }), count: function(req) {
            return table.count(translateRequest(req));
          }, query: function(req) {
            return table.query(translateRequest(req));
          }, openCursor: function(req) {
            var _a4 = req.query.index, keyTail = _a4.keyTail, isVirtual = _a4.isVirtual, keyLength = _a4.keyLength;
            if (!isVirtual)
              return table.openCursor(req);
            function createVirtualCursor(cursor) {
              function _continue(key) {
                key != null ? cursor.continue(pad(key, req.reverse ? down.MAX_KEY : down.MIN_KEY, keyTail)) : req.unique ? cursor.continue(cursor.key.slice(0, keyLength).concat(req.reverse ? down.MIN_KEY : down.MAX_KEY, keyTail)) : cursor.continue();
              }
              var virtualCursor = Object.create(cursor, {
                continue: { value: _continue },
                continuePrimaryKey: {
                  value: function(key, primaryKey2) {
                    cursor.continuePrimaryKey(pad(key, down.MAX_KEY, keyTail), primaryKey2);
                  }
                },
                primaryKey: {
                  get: function() {
                    return cursor.primaryKey;
                  }
                },
                key: {
                  get: function() {
                    var key = cursor.key;
                    return keyLength === 1 ? key[0] : key.slice(0, keyLength);
                  }
                },
                value: {
                  get: function() {
                    return cursor.value;
                  }
                }
              });
              return virtualCursor;
            }
            return table.openCursor(translateRequest(req)).then(function(cursor) {
              return cursor && createVirtualCursor(cursor);
            });
          } });
          return result;
        } });
      }
      var virtualIndexMiddleware = {
        stack: "dbcore",
        name: "VirtualIndexMiddleware",
        level: 1,
        create: createVirtualIndexMiddleware
      };
      function getObjectDiff(a, b2, rv, prfx) {
        rv = rv || {};
        prfx = prfx || "";
        keys(a).forEach(function(prop) {
          if (!hasOwn(b2, prop)) {
            rv[prfx + prop] = void 0;
          } else {
            var ap = a[prop], bp = b2[prop];
            if (typeof ap === "object" && typeof bp === "object" && ap && bp) {
              var apTypeName = toStringTag(ap);
              var bpTypeName = toStringTag(bp);
              if (apTypeName !== bpTypeName) {
                rv[prfx + prop] = b2[prop];
              } else if (apTypeName === "Object") {
                getObjectDiff(ap, bp, rv, prfx + prop + ".");
              } else if (ap !== bp) {
                rv[prfx + prop] = b2[prop];
              }
            } else if (ap !== bp)
              rv[prfx + prop] = b2[prop];
          }
        });
        keys(b2).forEach(function(prop) {
          if (!hasOwn(a, prop)) {
            rv[prfx + prop] = b2[prop];
          }
        });
        return rv;
      }
      function getEffectiveKeys(primaryKey, req) {
        if (req.type === "delete")
          return req.keys;
        return req.keys || req.values.map(primaryKey.extractKey);
      }
      var hooksMiddleware = {
        stack: "dbcore",
        name: "HooksMiddleware",
        level: 2,
        create: function(downCore) {
          return __assign2(__assign2({}, downCore), { table: function(tableName) {
            var downTable = downCore.table(tableName);
            var primaryKey = downTable.schema.primaryKey;
            var tableMiddleware = __assign2(__assign2({}, downTable), { mutate: function(req) {
              var dxTrans = PSD.trans;
              var _a3 = dxTrans.table(tableName).hook, deleting = _a3.deleting, creating = _a3.creating, updating = _a3.updating;
              switch (req.type) {
                case "add":
                  if (creating.fire === nop)
                    break;
                  return dxTrans._promise("readwrite", function() {
                    return addPutOrDelete(req);
                  }, true);
                case "put":
                  if (creating.fire === nop && updating.fire === nop)
                    break;
                  return dxTrans._promise("readwrite", function() {
                    return addPutOrDelete(req);
                  }, true);
                case "delete":
                  if (deleting.fire === nop)
                    break;
                  return dxTrans._promise("readwrite", function() {
                    return addPutOrDelete(req);
                  }, true);
                case "deleteRange":
                  if (deleting.fire === nop)
                    break;
                  return dxTrans._promise("readwrite", function() {
                    return deleteRange(req);
                  }, true);
              }
              return downTable.mutate(req);
              function addPutOrDelete(req2) {
                var dxTrans2 = PSD.trans;
                var keys2 = req2.keys || getEffectiveKeys(primaryKey, req2);
                if (!keys2)
                  throw new Error("Keys missing");
                req2 = req2.type === "add" || req2.type === "put" ? __assign2(__assign2({}, req2), { keys: keys2 }) : __assign2({}, req2);
                if (req2.type !== "delete")
                  req2.values = __spreadArray2([], req2.values);
                if (req2.keys)
                  req2.keys = __spreadArray2([], req2.keys);
                return getExistingValues(downTable, req2, keys2).then(function(existingValues) {
                  var contexts = keys2.map(function(key, i2) {
                    var existingValue = existingValues[i2];
                    var ctx = { onerror: null, onsuccess: null };
                    if (req2.type === "delete") {
                      deleting.fire.call(ctx, key, existingValue, dxTrans2);
                    } else if (req2.type === "add" || existingValue === void 0) {
                      var generatedPrimaryKey = creating.fire.call(ctx, key, req2.values[i2], dxTrans2);
                      if (key == null && generatedPrimaryKey != null) {
                        key = generatedPrimaryKey;
                        req2.keys[i2] = key;
                        if (!primaryKey.outbound) {
                          setByKeyPath(req2.values[i2], primaryKey.keyPath, key);
                        }
                      }
                    } else {
                      var objectDiff = getObjectDiff(existingValue, req2.values[i2]);
                      var additionalChanges_1 = updating.fire.call(ctx, objectDiff, key, existingValue, dxTrans2);
                      if (additionalChanges_1) {
                        var requestedValue_1 = req2.values[i2];
                        Object.keys(additionalChanges_1).forEach(function(keyPath) {
                          if (hasOwn(requestedValue_1, keyPath)) {
                            requestedValue_1[keyPath] = additionalChanges_1[keyPath];
                          } else {
                            setByKeyPath(requestedValue_1, keyPath, additionalChanges_1[keyPath]);
                          }
                        });
                      }
                    }
                    return ctx;
                  });
                  return downTable.mutate(req2).then(function(_a4) {
                    var failures = _a4.failures, results = _a4.results, numFailures = _a4.numFailures, lastResult = _a4.lastResult;
                    for (var i2 = 0; i2 < keys2.length; ++i2) {
                      var primKey = results ? results[i2] : keys2[i2];
                      var ctx = contexts[i2];
                      if (primKey == null) {
                        ctx.onerror && ctx.onerror(failures[i2]);
                      } else {
                        ctx.onsuccess && ctx.onsuccess(
                          req2.type === "put" && existingValues[i2] ? req2.values[i2] : primKey
                        );
                      }
                    }
                    return { failures, results, numFailures, lastResult };
                  }).catch(function(error) {
                    contexts.forEach(function(ctx) {
                      return ctx.onerror && ctx.onerror(error);
                    });
                    return Promise.reject(error);
                  });
                });
              }
              function deleteRange(req2) {
                return deleteNextChunk(req2.trans, req2.range, 1e4);
              }
              function deleteNextChunk(trans, range, limit) {
                return downTable.query({ trans, values: false, query: { index: primaryKey, range }, limit }).then(function(_a4) {
                  var result = _a4.result;
                  return addPutOrDelete({ type: "delete", keys: result, trans }).then(function(res) {
                    if (res.numFailures > 0)
                      return Promise.reject(res.failures[0]);
                    if (result.length < limit) {
                      return { failures: [], numFailures: 0, lastResult: void 0 };
                    } else {
                      return deleteNextChunk(trans, __assign2(__assign2({}, range), { lower: result[result.length - 1], lowerOpen: true }), limit);
                    }
                  });
                });
              }
            } });
            return tableMiddleware;
          } });
        }
      };
      function getExistingValues(table, req, effectiveKeys) {
        return req.type === "add" ? Promise.resolve([]) : table.getMany({ trans: req.trans, keys: effectiveKeys, cache: "immutable" });
      }
      function getFromTransactionCache(keys2, cache2, clone) {
        try {
          if (!cache2)
            return null;
          if (cache2.keys.length < keys2.length)
            return null;
          var result = [];
          for (var i2 = 0, j2 = 0; i2 < cache2.keys.length && j2 < keys2.length; ++i2) {
            if (cmp(cache2.keys[i2], keys2[j2]) !== 0)
              continue;
            result.push(clone ? deepClone(cache2.values[i2]) : cache2.values[i2]);
            ++j2;
          }
          return result.length === keys2.length ? result : null;
        } catch (_a3) {
          return null;
        }
      }
      var cacheExistingValuesMiddleware = {
        stack: "dbcore",
        level: -1,
        create: function(core) {
          return {
            table: function(tableName) {
              var table = core.table(tableName);
              return __assign2(__assign2({}, table), { getMany: function(req) {
                if (!req.cache) {
                  return table.getMany(req);
                }
                var cachedResult = getFromTransactionCache(req.keys, req.trans["_cache"], req.cache === "clone");
                if (cachedResult) {
                  return DexiePromise.resolve(cachedResult);
                }
                return table.getMany(req).then(function(res) {
                  req.trans["_cache"] = {
                    keys: req.keys,
                    values: req.cache === "clone" ? deepClone(res) : res
                  };
                  return res;
                });
              }, mutate: function(req) {
                if (req.type !== "add")
                  req.trans["_cache"] = null;
                return table.mutate(req);
              } });
            }
          };
        }
      };
      function isCachableContext(ctx, table) {
        return ctx.trans.mode === "readonly" && !!ctx.subscr && !ctx.trans.explicit && ctx.trans.db._options.cache !== "disabled" && !table.schema.primaryKey.outbound;
      }
      function isCachableRequest(type2, req) {
        switch (type2) {
          case "query":
            return req.values && !req.unique;
          case "get":
            return false;
          case "getMany":
            return false;
          case "count":
            return false;
          case "openCursor":
            return false;
        }
      }
      var observabilityMiddleware = {
        stack: "dbcore",
        level: 0,
        name: "Observability",
        create: function(core) {
          var dbName = core.schema.name;
          var FULL_RANGE = new RangeSet(core.MIN_KEY, core.MAX_KEY);
          return __assign2(__assign2({}, core), { transaction: function(stores, mode, options) {
            if (PSD.subscr && mode !== "readonly") {
              throw new exceptions.ReadOnly("Readwrite transaction in liveQuery context. Querier source: ".concat(PSD.querier));
            }
            return core.transaction(stores, mode, options);
          }, table: function(tableName) {
            var table = core.table(tableName);
            var schema = table.schema;
            var primaryKey = schema.primaryKey, indexes = schema.indexes;
            var extractKey = primaryKey.extractKey, outbound = primaryKey.outbound;
            var indexesWithAutoIncPK = primaryKey.autoIncrement && indexes.filter(function(index) {
              return index.compound && index.keyPath.includes(primaryKey.keyPath);
            });
            var tableClone = __assign2(__assign2({}, table), { mutate: function(req) {
              var _a3, _b;
              var trans = req.trans;
              var mutatedParts = req.mutatedParts || (req.mutatedParts = {});
              var getRangeSet = function(indexName) {
                var part = "idb://".concat(dbName, "/").concat(tableName, "/").concat(indexName);
                return mutatedParts[part] || (mutatedParts[part] = new RangeSet());
              };
              var pkRangeSet = getRangeSet("");
              var delsRangeSet = getRangeSet(":dels");
              var type2 = req.type;
              var _c = req.type === "deleteRange" ? [req.range] : req.type === "delete" ? [req.keys] : req.values.length < 50 ? [getEffectiveKeys(primaryKey, req).filter(function(id2) {
                return id2;
              }), req.values] : [], keys2 = _c[0], newObjs = _c[1];
              var oldCache = req.trans["_cache"];
              if (isArray(keys2)) {
                pkRangeSet.addKeys(keys2);
                var oldObjs = type2 === "delete" || keys2.length === newObjs.length ? getFromTransactionCache(keys2, oldCache) : null;
                if (!oldObjs) {
                  delsRangeSet.addKeys(keys2);
                }
                if (oldObjs || newObjs) {
                  trackAffectedIndexes(getRangeSet, schema, oldObjs, newObjs);
                }
              } else if (keys2) {
                var range = {
                  from: (_a3 = keys2.lower) !== null && _a3 !== void 0 ? _a3 : core.MIN_KEY,
                  to: (_b = keys2.upper) !== null && _b !== void 0 ? _b : core.MAX_KEY
                };
                delsRangeSet.add(range);
                pkRangeSet.add(range);
              } else {
                pkRangeSet.add(FULL_RANGE);
                delsRangeSet.add(FULL_RANGE);
                schema.indexes.forEach(function(idx) {
                  return getRangeSet(idx.name).add(FULL_RANGE);
                });
              }
              return table.mutate(req).then(function(res) {
                if (keys2 && (req.type === "add" || req.type === "put")) {
                  pkRangeSet.addKeys(res.results);
                  if (indexesWithAutoIncPK) {
                    indexesWithAutoIncPK.forEach(function(idx) {
                      var idxVals = req.values.map(function(v2) {
                        return idx.extractKey(v2);
                      });
                      var pkPos = idx.keyPath.findIndex(function(prop) {
                        return prop === primaryKey.keyPath;
                      });
                      for (var i2 = 0, len = res.results.length; i2 < len; ++i2) {
                        idxVals[i2][pkPos] = res.results[i2];
                      }
                      getRangeSet(idx.name).addKeys(idxVals);
                    });
                  }
                }
                trans.mutatedParts = extendObservabilitySet(trans.mutatedParts || {}, mutatedParts);
                return res;
              });
            } });
            var getRange = function(_a3) {
              var _b, _c;
              var _d = _a3.query, index = _d.index, range = _d.range;
              return [
                index,
                new RangeSet((_b = range.lower) !== null && _b !== void 0 ? _b : core.MIN_KEY, (_c = range.upper) !== null && _c !== void 0 ? _c : core.MAX_KEY)
              ];
            };
            var readSubscribers = {
              get: function(req) {
                return [primaryKey, new RangeSet(req.key)];
              },
              getMany: function(req) {
                return [primaryKey, new RangeSet().addKeys(req.keys)];
              },
              count: getRange,
              query: getRange,
              openCursor: getRange
            };
            keys(readSubscribers).forEach(function(method) {
              tableClone[method] = function(req) {
                var subscr = PSD.subscr;
                var isLiveQuery = !!subscr;
                var cachable = isCachableContext(PSD, table) && isCachableRequest(method, req);
                var obsSet = cachable ? req.obsSet = {} : subscr;
                if (isLiveQuery) {
                  var getRangeSet = function(indexName) {
                    var part = "idb://".concat(dbName, "/").concat(tableName, "/").concat(indexName);
                    return obsSet[part] || (obsSet[part] = new RangeSet());
                  };
                  var pkRangeSet_1 = getRangeSet("");
                  var delsRangeSet_1 = getRangeSet(":dels");
                  var _a3 = readSubscribers[method](req), queriedIndex = _a3[0], queriedRanges = _a3[1];
                  if (method === "query" && queriedIndex.isPrimaryKey && !req.values) {
                    delsRangeSet_1.add(queriedRanges);
                  } else {
                    getRangeSet(queriedIndex.name || "").add(queriedRanges);
                  }
                  if (!queriedIndex.isPrimaryKey) {
                    if (method === "count") {
                      delsRangeSet_1.add(FULL_RANGE);
                    } else {
                      var keysPromise_1 = method === "query" && outbound && req.values && table.query(__assign2(__assign2({}, req), { values: false }));
                      return table[method].apply(this, arguments).then(function(res) {
                        if (method === "query") {
                          if (outbound && req.values) {
                            return keysPromise_1.then(function(_a4) {
                              var resultingKeys = _a4.result;
                              pkRangeSet_1.addKeys(resultingKeys);
                              return res;
                            });
                          }
                          var pKeys = req.values ? res.result.map(extractKey) : res.result;
                          if (req.values) {
                            pkRangeSet_1.addKeys(pKeys);
                          } else {
                            delsRangeSet_1.addKeys(pKeys);
                          }
                        } else if (method === "openCursor") {
                          var cursor_1 = res;
                          var wantValues_1 = req.values;
                          return cursor_1 && Object.create(cursor_1, {
                            key: {
                              get: function() {
                                delsRangeSet_1.addKey(cursor_1.primaryKey);
                                return cursor_1.key;
                              }
                            },
                            primaryKey: {
                              get: function() {
                                var pkey = cursor_1.primaryKey;
                                delsRangeSet_1.addKey(pkey);
                                return pkey;
                              }
                            },
                            value: {
                              get: function() {
                                wantValues_1 && pkRangeSet_1.addKey(cursor_1.primaryKey);
                                return cursor_1.value;
                              }
                            }
                          });
                        }
                        return res;
                      });
                    }
                  }
                }
                return table[method].apply(this, arguments);
              };
            });
            return tableClone;
          } });
        }
      };
      function trackAffectedIndexes(getRangeSet, schema, oldObjs, newObjs) {
        function addAffectedIndex(ix) {
          var rangeSet = getRangeSet(ix.name || "");
          function extractKey(obj) {
            return obj != null ? ix.extractKey(obj) : null;
          }
          var addKeyOrKeys = function(key) {
            return ix.multiEntry && isArray(key) ? key.forEach(function(key2) {
              return rangeSet.addKey(key2);
            }) : rangeSet.addKey(key);
          };
          (oldObjs || newObjs).forEach(function(_, i2) {
            var oldKey = oldObjs && extractKey(oldObjs[i2]);
            var newKey = newObjs && extractKey(newObjs[i2]);
            if (cmp(oldKey, newKey) !== 0) {
              if (oldKey != null)
                addKeyOrKeys(oldKey);
              if (newKey != null)
                addKeyOrKeys(newKey);
            }
          });
        }
        schema.indexes.forEach(addAffectedIndex);
      }
      function adjustOptimisticFromFailures(tblCache, req, res) {
        if (res.numFailures === 0)
          return req;
        if (req.type === "deleteRange") {
          return null;
        }
        var numBulkOps = req.keys ? req.keys.length : "values" in req && req.values ? req.values.length : 1;
        if (res.numFailures === numBulkOps) {
          return null;
        }
        var clone = __assign2({}, req);
        if (isArray(clone.keys)) {
          clone.keys = clone.keys.filter(function(_, i2) {
            return !(i2 in res.failures);
          });
        }
        if ("values" in clone && isArray(clone.values)) {
          clone.values = clone.values.filter(function(_, i2) {
            return !(i2 in res.failures);
          });
        }
        return clone;
      }
      function isAboveLower(key, range) {
        return range.lower === void 0 ? true : range.lowerOpen ? cmp(key, range.lower) > 0 : cmp(key, range.lower) >= 0;
      }
      function isBelowUpper(key, range) {
        return range.upper === void 0 ? true : range.upperOpen ? cmp(key, range.upper) < 0 : cmp(key, range.upper) <= 0;
      }
      function isWithinRange(key, range) {
        return isAboveLower(key, range) && isBelowUpper(key, range);
      }
      function applyOptimisticOps(result, req, ops, table, cacheEntry, immutable) {
        if (!ops || ops.length === 0)
          return result;
        var index = req.query.index;
        var multiEntry = index.multiEntry;
        var queryRange = req.query.range;
        var primaryKey = table.schema.primaryKey;
        var extractPrimKey = primaryKey.extractKey;
        var extractIndex = index.extractKey;
        var extractLowLevelIndex = (index.lowLevelIndex || index).extractKey;
        var finalResult = ops.reduce(function(result2, op) {
          var modifedResult = result2;
          var includedValues = [];
          if (op.type === "add" || op.type === "put") {
            var includedPKs = new RangeSet();
            for (var i2 = op.values.length - 1; i2 >= 0; --i2) {
              var value = op.values[i2];
              var pk = extractPrimKey(value);
              if (includedPKs.hasKey(pk))
                continue;
              var key = extractIndex(value);
              if (multiEntry && isArray(key) ? key.some(function(k) {
                return isWithinRange(k, queryRange);
              }) : isWithinRange(key, queryRange)) {
                includedPKs.addKey(pk);
                includedValues.push(value);
              }
            }
          }
          switch (op.type) {
            case "add": {
              var existingKeys_1 = new RangeSet().addKeys(req.values ? result2.map(function(v2) {
                return extractPrimKey(v2);
              }) : result2);
              modifedResult = result2.concat(req.values ? includedValues.filter(function(v2) {
                var key2 = extractPrimKey(v2);
                if (existingKeys_1.hasKey(key2))
                  return false;
                existingKeys_1.addKey(key2);
                return true;
              }) : includedValues.map(function(v2) {
                return extractPrimKey(v2);
              }).filter(function(k) {
                if (existingKeys_1.hasKey(k))
                  return false;
                existingKeys_1.addKey(k);
                return true;
              }));
              break;
            }
            case "put": {
              var keySet_1 = new RangeSet().addKeys(op.values.map(function(v2) {
                return extractPrimKey(v2);
              }));
              modifedResult = result2.filter(
                function(item) {
                  return !keySet_1.hasKey(req.values ? extractPrimKey(item) : item);
                }
              ).concat(
                req.values ? includedValues : includedValues.map(function(v2) {
                  return extractPrimKey(v2);
                })
              );
              break;
            }
            case "delete":
              var keysToDelete_1 = new RangeSet().addKeys(op.keys);
              modifedResult = result2.filter(function(item) {
                return !keysToDelete_1.hasKey(req.values ? extractPrimKey(item) : item);
              });
              break;
            case "deleteRange":
              var range_1 = op.range;
              modifedResult = result2.filter(function(item) {
                return !isWithinRange(extractPrimKey(item), range_1);
              });
              break;
          }
          return modifedResult;
        }, result);
        if (finalResult === result)
          return result;
        finalResult.sort(function(a, b2) {
          return cmp(extractLowLevelIndex(a), extractLowLevelIndex(b2)) || cmp(extractPrimKey(a), extractPrimKey(b2));
        });
        if (req.limit && req.limit < Infinity) {
          if (finalResult.length > req.limit) {
            finalResult.length = req.limit;
          } else if (result.length === req.limit && finalResult.length < req.limit) {
            cacheEntry.dirty = true;
          }
        }
        return immutable ? Object.freeze(finalResult) : finalResult;
      }
      function areRangesEqual(r1, r2) {
        return cmp(r1.lower, r2.lower) === 0 && cmp(r1.upper, r2.upper) === 0 && !!r1.lowerOpen === !!r2.lowerOpen && !!r1.upperOpen === !!r2.upperOpen;
      }
      function compareLowers(lower1, lower2, lowerOpen1, lowerOpen2) {
        if (lower1 === void 0)
          return lower2 !== void 0 ? -1 : 0;
        if (lower2 === void 0)
          return 1;
        var c2 = cmp(lower1, lower2);
        if (c2 === 0) {
          if (lowerOpen1 && lowerOpen2)
            return 0;
          if (lowerOpen1)
            return 1;
          if (lowerOpen2)
            return -1;
        }
        return c2;
      }
      function compareUppers(upper1, upper2, upperOpen1, upperOpen2) {
        if (upper1 === void 0)
          return upper2 !== void 0 ? 1 : 0;
        if (upper2 === void 0)
          return -1;
        var c2 = cmp(upper1, upper2);
        if (c2 === 0) {
          if (upperOpen1 && upperOpen2)
            return 0;
          if (upperOpen1)
            return -1;
          if (upperOpen2)
            return 1;
        }
        return c2;
      }
      function isSuperRange(r1, r2) {
        return compareLowers(r1.lower, r2.lower, r1.lowerOpen, r2.lowerOpen) <= 0 && compareUppers(r1.upper, r2.upper, r1.upperOpen, r2.upperOpen) >= 0;
      }
      function findCompatibleQuery(dbName, tableName, type2, req) {
        var tblCache = cache["idb://".concat(dbName, "/").concat(tableName)];
        if (!tblCache)
          return [];
        var queries = tblCache.queries[type2];
        if (!queries)
          return [null, false, tblCache, null];
        var indexName = req.query ? req.query.index.name : null;
        var entries = queries[indexName || ""];
        if (!entries)
          return [null, false, tblCache, null];
        switch (type2) {
          case "query":
            var equalEntry = entries.find(function(entry) {
              return entry.req.limit === req.limit && entry.req.values === req.values && areRangesEqual(entry.req.query.range, req.query.range);
            });
            if (equalEntry)
              return [
                equalEntry,
                true,
                tblCache,
                entries
              ];
            var superEntry = entries.find(function(entry) {
              var limit = "limit" in entry.req ? entry.req.limit : Infinity;
              return limit >= req.limit && (req.values ? entry.req.values : true) && isSuperRange(entry.req.query.range, req.query.range);
            });
            return [superEntry, false, tblCache, entries];
          case "count":
            var countQuery = entries.find(function(entry) {
              return areRangesEqual(entry.req.query.range, req.query.range);
            });
            return [countQuery, !!countQuery, tblCache, entries];
        }
      }
      function subscribeToCacheEntry(cacheEntry, container, requery, signal) {
        cacheEntry.subscribers.add(requery);
        signal.addEventListener("abort", function() {
          cacheEntry.subscribers.delete(requery);
          if (cacheEntry.subscribers.size === 0) {
            enqueForDeletion(cacheEntry, container);
          }
        });
      }
      function enqueForDeletion(cacheEntry, container) {
        setTimeout(function() {
          if (cacheEntry.subscribers.size === 0) {
            delArrayItem(container, cacheEntry);
          }
        }, 3e3);
      }
      var cacheMiddleware = {
        stack: "dbcore",
        level: 0,
        name: "Cache",
        create: function(core) {
          var dbName = core.schema.name;
          var coreMW = __assign2(__assign2({}, core), { transaction: function(stores, mode, options) {
            var idbtrans = core.transaction(stores, mode, options);
            if (mode === "readwrite") {
              var ac_1 = new AbortController();
              var signal = ac_1.signal;
              var endTransaction = function(wasCommitted) {
                return function() {
                  ac_1.abort();
                  if (mode === "readwrite") {
                    var affectedSubscribers_1 = /* @__PURE__ */ new Set();
                    for (var _i = 0, stores_1 = stores; _i < stores_1.length; _i++) {
                      var storeName = stores_1[_i];
                      var tblCache = cache["idb://".concat(dbName, "/").concat(storeName)];
                      if (tblCache) {
                        var table = core.table(storeName);
                        var ops = tblCache.optimisticOps.filter(function(op) {
                          return op.trans === idbtrans;
                        });
                        if (idbtrans._explicit && wasCommitted && idbtrans.mutatedParts) {
                          for (var _a3 = 0, _b = Object.values(tblCache.queries.query); _a3 < _b.length; _a3++) {
                            var entries = _b[_a3];
                            for (var _c = 0, _d = entries.slice(); _c < _d.length; _c++) {
                              var entry = _d[_c];
                              if (obsSetsOverlap(entry.obsSet, idbtrans.mutatedParts)) {
                                delArrayItem(entries, entry);
                                entry.subscribers.forEach(function(requery) {
                                  return affectedSubscribers_1.add(requery);
                                });
                              }
                            }
                          }
                        } else if (ops.length > 0) {
                          tblCache.optimisticOps = tblCache.optimisticOps.filter(function(op) {
                            return op.trans !== idbtrans;
                          });
                          for (var _e = 0, _f = Object.values(tblCache.queries.query); _e < _f.length; _e++) {
                            var entries = _f[_e];
                            for (var _g = 0, _h = entries.slice(); _g < _h.length; _g++) {
                              var entry = _h[_g];
                              if (entry.res != null && idbtrans.mutatedParts) {
                                if (wasCommitted && !entry.dirty) {
                                  var freezeResults = Object.isFrozen(entry.res);
                                  var modRes = applyOptimisticOps(entry.res, entry.req, ops, table, entry, freezeResults);
                                  if (entry.dirty) {
                                    delArrayItem(entries, entry);
                                    entry.subscribers.forEach(function(requery) {
                                      return affectedSubscribers_1.add(requery);
                                    });
                                  } else if (modRes !== entry.res) {
                                    entry.res = modRes;
                                    entry.promise = DexiePromise.resolve({ result: modRes });
                                  }
                                } else {
                                  if (entry.dirty) {
                                    delArrayItem(entries, entry);
                                  }
                                  entry.subscribers.forEach(function(requery) {
                                    return affectedSubscribers_1.add(requery);
                                  });
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                    affectedSubscribers_1.forEach(function(requery) {
                      return requery();
                    });
                  }
                };
              };
              idbtrans.addEventListener("abort", endTransaction(false), {
                signal
              });
              idbtrans.addEventListener("error", endTransaction(false), {
                signal
              });
              idbtrans.addEventListener("complete", endTransaction(true), {
                signal
              });
            }
            return idbtrans;
          }, table: function(tableName) {
            var downTable = core.table(tableName);
            var primKey = downTable.schema.primaryKey;
            var tableMW = __assign2(__assign2({}, downTable), { mutate: function(req) {
              var trans = PSD.trans;
              if (primKey.outbound || trans.db._options.cache === "disabled" || trans.explicit || trans.idbtrans.mode !== "readwrite") {
                return downTable.mutate(req);
              }
              var tblCache = cache["idb://".concat(dbName, "/").concat(tableName)];
              if (!tblCache)
                return downTable.mutate(req);
              var promise = downTable.mutate(req);
              if ((req.type === "add" || req.type === "put") && (req.values.length >= 50 || getEffectiveKeys(primKey, req).some(function(key) {
                return key == null;
              }))) {
                promise.then(function(res) {
                  var reqWithResolvedKeys = __assign2(__assign2({}, req), { values: req.values.map(function(value, i2) {
                    var _a3;
                    if (res.failures[i2])
                      return value;
                    var valueWithKey = ((_a3 = primKey.keyPath) === null || _a3 === void 0 ? void 0 : _a3.includes(".")) ? deepClone(value) : __assign2({}, value);
                    setByKeyPath(valueWithKey, primKey.keyPath, res.results[i2]);
                    return valueWithKey;
                  }) });
                  var adjustedReq = adjustOptimisticFromFailures(tblCache, reqWithResolvedKeys, res);
                  tblCache.optimisticOps.push(adjustedReq);
                  queueMicrotask(function() {
                    return req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
                  });
                });
              } else {
                tblCache.optimisticOps.push(req);
                req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
                promise.then(function(res) {
                  if (res.numFailures > 0) {
                    delArrayItem(tblCache.optimisticOps, req);
                    var adjustedReq = adjustOptimisticFromFailures(tblCache, req, res);
                    if (adjustedReq) {
                      tblCache.optimisticOps.push(adjustedReq);
                    }
                    req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
                  }
                });
                promise.catch(function() {
                  delArrayItem(tblCache.optimisticOps, req);
                  req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
                });
              }
              return promise;
            }, query: function(req) {
              var _a3;
              if (!isCachableContext(PSD, downTable) || !isCachableRequest("query", req))
                return downTable.query(req);
              var freezeResults = ((_a3 = PSD.trans) === null || _a3 === void 0 ? void 0 : _a3.db._options.cache) === "immutable";
              var _b = PSD, requery = _b.requery, signal = _b.signal;
              var _c = findCompatibleQuery(dbName, tableName, "query", req), cacheEntry = _c[0], exactMatch = _c[1], tblCache = _c[2], container = _c[3];
              if (cacheEntry && exactMatch) {
                cacheEntry.obsSet = req.obsSet;
              } else {
                var promise = downTable.query(req).then(function(res) {
                  var result = res.result;
                  if (cacheEntry)
                    cacheEntry.res = result;
                  if (freezeResults) {
                    for (var i2 = 0, l = result.length; i2 < l; ++i2) {
                      Object.freeze(result[i2]);
                    }
                    Object.freeze(result);
                  } else {
                    res.result = deepClone(result);
                  }
                  return res;
                }).catch(function(error) {
                  if (container && cacheEntry)
                    delArrayItem(container, cacheEntry);
                  return Promise.reject(error);
                });
                cacheEntry = {
                  obsSet: req.obsSet,
                  promise,
                  subscribers: /* @__PURE__ */ new Set(),
                  type: "query",
                  req,
                  dirty: false
                };
                if (container) {
                  container.push(cacheEntry);
                } else {
                  container = [cacheEntry];
                  if (!tblCache) {
                    tblCache = cache["idb://".concat(dbName, "/").concat(tableName)] = {
                      queries: {
                        query: {},
                        count: {}
                      },
                      objs: /* @__PURE__ */ new Map(),
                      optimisticOps: [],
                      unsignaledParts: {}
                    };
                  }
                  tblCache.queries.query[req.query.index.name || ""] = container;
                }
              }
              subscribeToCacheEntry(cacheEntry, container, requery, signal);
              return cacheEntry.promise.then(function(res) {
                return {
                  result: applyOptimisticOps(res.result, req, tblCache === null || tblCache === void 0 ? void 0 : tblCache.optimisticOps, downTable, cacheEntry, freezeResults)
                };
              });
            } });
            return tableMW;
          } });
          return coreMW;
        }
      };
      function vipify(target, vipDb) {
        return new Proxy(target, {
          get: function(target2, prop, receiver) {
            if (prop === "db")
              return vipDb;
            return Reflect.get(target2, prop, receiver);
          }
        });
      }
      var Dexie$1 = function() {
        function Dexie3(name, options) {
          var _this = this;
          this._middlewares = {};
          this.verno = 0;
          var deps = Dexie3.dependencies;
          this._options = options = __assign2({
            addons: Dexie3.addons,
            autoOpen: true,
            indexedDB: deps.indexedDB,
            IDBKeyRange: deps.IDBKeyRange,
            cache: "cloned"
          }, options);
          this._deps = {
            indexedDB: options.indexedDB,
            IDBKeyRange: options.IDBKeyRange
          };
          var addons = options.addons;
          this._dbSchema = {};
          this._versions = [];
          this._storeNames = [];
          this._allTables = {};
          this.idbdb = null;
          this._novip = this;
          var state = {
            dbOpenError: null,
            isBeingOpened: false,
            onReadyBeingFired: null,
            openComplete: false,
            dbReadyResolve: nop,
            dbReadyPromise: null,
            cancelOpen: nop,
            openCanceller: null,
            autoSchema: true,
            PR1398_maxLoop: 3,
            autoOpen: options.autoOpen
          };
          state.dbReadyPromise = new DexiePromise(function(resolve) {
            state.dbReadyResolve = resolve;
          });
          state.openCanceller = new DexiePromise(function(_, reject) {
            state.cancelOpen = reject;
          });
          this._state = state;
          this.name = name;
          this.on = Events(this, "populate", "blocked", "versionchange", "close", { ready: [promisableChain, nop] });
          this.on.ready.subscribe = override(this.on.ready.subscribe, function(subscribe) {
            return function(subscriber, bSticky) {
              Dexie3.vip(function() {
                var state2 = _this._state;
                if (state2.openComplete) {
                  if (!state2.dbOpenError)
                    DexiePromise.resolve().then(subscriber);
                  if (bSticky)
                    subscribe(subscriber);
                } else if (state2.onReadyBeingFired) {
                  state2.onReadyBeingFired.push(subscriber);
                  if (bSticky)
                    subscribe(subscriber);
                } else {
                  subscribe(subscriber);
                  var db_1 = _this;
                  if (!bSticky)
                    subscribe(function unsubscribe() {
                      db_1.on.ready.unsubscribe(subscriber);
                      db_1.on.ready.unsubscribe(unsubscribe);
                    });
                }
              });
            };
          });
          this.Collection = createCollectionConstructor(this);
          this.Table = createTableConstructor(this);
          this.Transaction = createTransactionConstructor(this);
          this.Version = createVersionConstructor(this);
          this.WhereClause = createWhereClauseConstructor(this);
          this.on("versionchange", function(ev) {
            if (ev.newVersion > 0)
              console.warn("Another connection wants to upgrade database '".concat(_this.name, "'. Closing db now to resume the upgrade."));
            else
              console.warn("Another connection wants to delete database '".concat(_this.name, "'. Closing db now to resume the delete request."));
            _this.close({ disableAutoOpen: false });
          });
          this.on("blocked", function(ev) {
            if (!ev.newVersion || ev.newVersion < ev.oldVersion)
              console.warn("Dexie.delete('".concat(_this.name, "') was blocked"));
            else
              console.warn("Upgrade '".concat(_this.name, "' blocked by other connection holding version ").concat(ev.oldVersion / 10));
          });
          this._maxKey = getMaxKey(options.IDBKeyRange);
          this._createTransaction = function(mode, storeNames, dbschema, parentTransaction) {
            return new _this.Transaction(mode, storeNames, dbschema, _this._options.chromeTransactionDurability, parentTransaction);
          };
          this._fireOnBlocked = function(ev) {
            _this.on("blocked").fire(ev);
            connections.filter(function(c2) {
              return c2.name === _this.name && c2 !== _this && !c2._state.vcFired;
            }).map(function(c2) {
              return c2.on("versionchange").fire(ev);
            });
          };
          this.use(cacheExistingValuesMiddleware);
          this.use(cacheMiddleware);
          this.use(observabilityMiddleware);
          this.use(virtualIndexMiddleware);
          this.use(hooksMiddleware);
          var vipDB = new Proxy(this, {
            get: function(_, prop, receiver) {
              if (prop === "_vip")
                return true;
              if (prop === "table")
                return function(tableName) {
                  return vipify(_this.table(tableName), vipDB);
                };
              var rv = Reflect.get(_, prop, receiver);
              if (rv instanceof Table)
                return vipify(rv, vipDB);
              if (prop === "tables")
                return rv.map(function(t2) {
                  return vipify(t2, vipDB);
                });
              if (prop === "_createTransaction")
                return function() {
                  var tx = rv.apply(this, arguments);
                  return vipify(tx, vipDB);
                };
              return rv;
            }
          });
          this.vip = vipDB;
          addons.forEach(function(addon) {
            return addon(_this);
          });
        }
        Dexie3.prototype.version = function(versionNumber) {
          if (isNaN(versionNumber) || versionNumber < 0.1)
            throw new exceptions.Type("Given version is not a positive number");
          versionNumber = Math.round(versionNumber * 10) / 10;
          if (this.idbdb || this._state.isBeingOpened)
            throw new exceptions.Schema("Cannot add version when database is open");
          this.verno = Math.max(this.verno, versionNumber);
          var versions = this._versions;
          var versionInstance = versions.filter(function(v2) {
            return v2._cfg.version === versionNumber;
          })[0];
          if (versionInstance)
            return versionInstance;
          versionInstance = new this.Version(versionNumber);
          versions.push(versionInstance);
          versions.sort(lowerVersionFirst);
          versionInstance.stores({});
          this._state.autoSchema = false;
          return versionInstance;
        };
        Dexie3.prototype._whenReady = function(fn) {
          var _this = this;
          return this.idbdb && (this._state.openComplete || PSD.letThrough || this._vip) ? fn() : new DexiePromise(function(resolve, reject) {
            if (_this._state.openComplete) {
              return reject(new exceptions.DatabaseClosed(_this._state.dbOpenError));
            }
            if (!_this._state.isBeingOpened) {
              if (!_this._state.autoOpen) {
                reject(new exceptions.DatabaseClosed());
                return;
              }
              _this.open().catch(nop);
            }
            _this._state.dbReadyPromise.then(resolve, reject);
          }).then(fn);
        };
        Dexie3.prototype.use = function(_a3) {
          var stack = _a3.stack, create = _a3.create, level = _a3.level, name = _a3.name;
          if (name)
            this.unuse({ stack, name });
          var middlewares = this._middlewares[stack] || (this._middlewares[stack] = []);
          middlewares.push({ stack, create, level: level == null ? 10 : level, name });
          middlewares.sort(function(a, b2) {
            return a.level - b2.level;
          });
          return this;
        };
        Dexie3.prototype.unuse = function(_a3) {
          var stack = _a3.stack, name = _a3.name, create = _a3.create;
          if (stack && this._middlewares[stack]) {
            this._middlewares[stack] = this._middlewares[stack].filter(function(mw) {
              return create ? mw.create !== create : name ? mw.name !== name : false;
            });
          }
          return this;
        };
        Dexie3.prototype.open = function() {
          var _this = this;
          return usePSD(
            globalPSD,
            function() {
              return dexieOpen(_this);
            }
          );
        };
        Dexie3.prototype._close = function() {
          var state = this._state;
          var idx = connections.indexOf(this);
          if (idx >= 0)
            connections.splice(idx, 1);
          if (this.idbdb) {
            try {
              this.idbdb.close();
            } catch (e2) {
            }
            this.idbdb = null;
          }
          if (!state.isBeingOpened) {
            state.dbReadyPromise = new DexiePromise(function(resolve) {
              state.dbReadyResolve = resolve;
            });
            state.openCanceller = new DexiePromise(function(_, reject) {
              state.cancelOpen = reject;
            });
          }
        };
        Dexie3.prototype.close = function(_a3) {
          var _b = _a3 === void 0 ? { disableAutoOpen: true } : _a3, disableAutoOpen = _b.disableAutoOpen;
          var state = this._state;
          if (disableAutoOpen) {
            if (state.isBeingOpened) {
              state.cancelOpen(new exceptions.DatabaseClosed());
            }
            this._close();
            state.autoOpen = false;
            state.dbOpenError = new exceptions.DatabaseClosed();
          } else {
            this._close();
            state.autoOpen = this._options.autoOpen || state.isBeingOpened;
            state.openComplete = false;
            state.dbOpenError = null;
          }
        };
        Dexie3.prototype.delete = function(closeOptions) {
          var _this = this;
          if (closeOptions === void 0) {
            closeOptions = { disableAutoOpen: true };
          }
          var hasInvalidArguments = arguments.length > 0 && typeof arguments[0] !== "object";
          var state = this._state;
          return new DexiePromise(function(resolve, reject) {
            var doDelete = function() {
              _this.close(closeOptions);
              var req = _this._deps.indexedDB.deleteDatabase(_this.name);
              req.onsuccess = wrap2(function() {
                _onDatabaseDeleted(_this._deps, _this.name);
                resolve();
              });
              req.onerror = eventRejectHandler(reject);
              req.onblocked = _this._fireOnBlocked;
            };
            if (hasInvalidArguments)
              throw new exceptions.InvalidArgument("Invalid closeOptions argument to db.delete()");
            if (state.isBeingOpened) {
              state.dbReadyPromise.then(doDelete);
            } else {
              doDelete();
            }
          });
        };
        Dexie3.prototype.backendDB = function() {
          return this.idbdb;
        };
        Dexie3.prototype.isOpen = function() {
          return this.idbdb !== null;
        };
        Dexie3.prototype.hasBeenClosed = function() {
          var dbOpenError = this._state.dbOpenError;
          return dbOpenError && dbOpenError.name === "DatabaseClosed";
        };
        Dexie3.prototype.hasFailed = function() {
          return this._state.dbOpenError !== null;
        };
        Dexie3.prototype.dynamicallyOpened = function() {
          return this._state.autoSchema;
        };
        Object.defineProperty(Dexie3.prototype, "tables", {
          get: function() {
            var _this = this;
            return keys(this._allTables).map(function(name) {
              return _this._allTables[name];
            });
          },
          enumerable: false,
          configurable: true
        });
        Dexie3.prototype.transaction = function() {
          var args = extractTransactionArgs.apply(this, arguments);
          return this._transaction.apply(this, args);
        };
        Dexie3.prototype._transaction = function(mode, tables, scopeFunc) {
          var _this = this;
          var parentTransaction = PSD.trans;
          if (!parentTransaction || parentTransaction.db !== this || mode.indexOf("!") !== -1)
            parentTransaction = null;
          var onlyIfCompatible = mode.indexOf("?") !== -1;
          mode = mode.replace("!", "").replace("?", "");
          var idbMode, storeNames;
          try {
            storeNames = tables.map(function(table) {
              var storeName = table instanceof _this.Table ? table.name : table;
              if (typeof storeName !== "string")
                throw new TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
              return storeName;
            });
            if (mode == "r" || mode === READONLY)
              idbMode = READONLY;
            else if (mode == "rw" || mode == READWRITE)
              idbMode = READWRITE;
            else
              throw new exceptions.InvalidArgument("Invalid transaction mode: " + mode);
            if (parentTransaction) {
              if (parentTransaction.mode === READONLY && idbMode === READWRITE) {
                if (onlyIfCompatible) {
                  parentTransaction = null;
                } else
                  throw new exceptions.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
              }
              if (parentTransaction) {
                storeNames.forEach(function(storeName) {
                  if (parentTransaction && parentTransaction.storeNames.indexOf(storeName) === -1) {
                    if (onlyIfCompatible) {
                      parentTransaction = null;
                    } else
                      throw new exceptions.SubTransaction("Table " + storeName + " not included in parent transaction.");
                  }
                });
              }
              if (onlyIfCompatible && parentTransaction && !parentTransaction.active) {
                parentTransaction = null;
              }
            }
          } catch (e2) {
            return parentTransaction ? parentTransaction._promise(null, function(_, reject) {
              reject(e2);
            }) : rejection(e2);
          }
          var enterTransaction = enterTransactionScope.bind(null, this, idbMode, storeNames, parentTransaction, scopeFunc);
          return parentTransaction ? parentTransaction._promise(idbMode, enterTransaction, "lock") : PSD.trans ? usePSD(PSD.transless, function() {
            return _this._whenReady(enterTransaction);
          }) : this._whenReady(enterTransaction);
        };
        Dexie3.prototype.table = function(tableName) {
          if (!hasOwn(this._allTables, tableName)) {
            throw new exceptions.InvalidTable("Table ".concat(tableName, " does not exist"));
          }
          return this._allTables[tableName];
        };
        return Dexie3;
      }();
      var symbolObservable = typeof Symbol !== "undefined" && "observable" in Symbol ? Symbol.observable : "@@observable";
      var Observable = function() {
        function Observable2(subscribe) {
          this._subscribe = subscribe;
        }
        Observable2.prototype.subscribe = function(x2, error, complete) {
          return this._subscribe(!x2 || typeof x2 === "function" ? { next: x2, error, complete } : x2);
        };
        Observable2.prototype[symbolObservable] = function() {
          return this;
        };
        return Observable2;
      }();
      var domDeps;
      try {
        domDeps = {
          indexedDB: _global.indexedDB || _global.mozIndexedDB || _global.webkitIndexedDB || _global.msIndexedDB,
          IDBKeyRange: _global.IDBKeyRange || _global.webkitIDBKeyRange
        };
      } catch (e2) {
        domDeps = { indexedDB: null, IDBKeyRange: null };
      }
      function liveQuery(querier) {
        var hasValue = false;
        var currentValue;
        var observable = new Observable(function(observer) {
          var scopeFuncIsAsync = isAsyncFunction(querier);
          function execute(ctx) {
            var wasRootExec = beginMicroTickScope();
            try {
              if (scopeFuncIsAsync) {
                incrementExpectedAwaits();
              }
              var rv = newScope(querier, ctx);
              if (scopeFuncIsAsync) {
                rv = rv.finally(decrementExpectedAwaits);
              }
              return rv;
            } finally {
              wasRootExec && endMicroTickScope();
            }
          }
          var closed = false;
          var abortController;
          var accumMuts = {};
          var currentObs = {};
          var subscription = {
            get closed() {
              return closed;
            },
            unsubscribe: function() {
              if (closed)
                return;
              closed = true;
              if (abortController)
                abortController.abort();
              if (startedListening)
                globalEvents.storagemutated.unsubscribe(mutationListener);
            }
          };
          observer.start && observer.start(subscription);
          var startedListening = false;
          var doQuery = function() {
            return execInGlobalContext(_doQuery);
          };
          function shouldNotify() {
            return obsSetsOverlap(currentObs, accumMuts);
          }
          var mutationListener = function(parts) {
            extendObservabilitySet(accumMuts, parts);
            if (shouldNotify()) {
              doQuery();
            }
          };
          var _doQuery = function() {
            if (closed || !domDeps.indexedDB) {
              return;
            }
            accumMuts = {};
            var subscr = {};
            if (abortController)
              abortController.abort();
            abortController = new AbortController();
            var ctx = {
              subscr,
              signal: abortController.signal,
              requery: doQuery,
              querier,
              trans: null
            };
            var ret = execute(ctx);
            Promise.resolve(ret).then(function(result) {
              hasValue = true;
              currentValue = result;
              if (closed || ctx.signal.aborted) {
                return;
              }
              accumMuts = {};
              currentObs = subscr;
              if (!objectIsEmpty(currentObs) && !startedListening) {
                globalEvents(DEXIE_STORAGE_MUTATED_EVENT_NAME, mutationListener);
                startedListening = true;
              }
              execInGlobalContext(function() {
                return !closed && observer.next && observer.next(result);
              });
            }, function(err) {
              hasValue = false;
              if (!["DatabaseClosedError", "AbortError"].includes(err === null || err === void 0 ? void 0 : err.name)) {
                if (!closed)
                  execInGlobalContext(function() {
                    if (closed)
                      return;
                    observer.error && observer.error(err);
                  });
              }
            });
          };
          setTimeout(doQuery, 0);
          return subscription;
        });
        observable.hasValue = function() {
          return hasValue;
        };
        observable.getValue = function() {
          return currentValue;
        };
        return observable;
      }
      var Dexie2 = Dexie$1;
      props(Dexie2, __assign2(__assign2({}, fullNameExceptions), {
        delete: function(databaseName) {
          var db2 = new Dexie2(databaseName, { addons: [] });
          return db2.delete();
        },
        exists: function(name) {
          return new Dexie2(name, { addons: [] }).open().then(function(db2) {
            db2.close();
            return true;
          }).catch("NoSuchDatabaseError", function() {
            return false;
          });
        },
        getDatabaseNames: function(cb) {
          try {
            return getDatabaseNames(Dexie2.dependencies).then(cb);
          } catch (_a3) {
            return rejection(new exceptions.MissingAPI());
          }
        },
        defineClass: function() {
          function Class(content) {
            extend(this, content);
          }
          return Class;
        },
        ignoreTransaction: function(scopeFunc) {
          return PSD.trans ? usePSD(PSD.transless, scopeFunc) : scopeFunc();
        },
        vip,
        async: function(generatorFn) {
          return function() {
            try {
              var rv = awaitIterator(generatorFn.apply(this, arguments));
              if (!rv || typeof rv.then !== "function")
                return DexiePromise.resolve(rv);
              return rv;
            } catch (e2) {
              return rejection(e2);
            }
          };
        },
        spawn: function(generatorFn, args, thiz) {
          try {
            var rv = awaitIterator(generatorFn.apply(thiz, args || []));
            if (!rv || typeof rv.then !== "function")
              return DexiePromise.resolve(rv);
            return rv;
          } catch (e2) {
            return rejection(e2);
          }
        },
        currentTransaction: {
          get: function() {
            return PSD.trans || null;
          }
        },
        waitFor: function(promiseOrFunction, optionalTimeout) {
          var promise = DexiePromise.resolve(typeof promiseOrFunction === "function" ? Dexie2.ignoreTransaction(promiseOrFunction) : promiseOrFunction).timeout(optionalTimeout || 6e4);
          return PSD.trans ? PSD.trans.waitFor(promise) : promise;
        },
        Promise: DexiePromise,
        debug: {
          get: function() {
            return debug;
          },
          set: function(value) {
            setDebug(value);
          }
        },
        derive,
        extend,
        props,
        override,
        Events,
        on: globalEvents,
        liveQuery,
        extendObservabilitySet,
        getByKeyPath,
        setByKeyPath,
        delByKeyPath,
        shallowClone,
        deepClone,
        getObjectDiff,
        cmp,
        asap: asap$1,
        minKey,
        addons: [],
        connections,
        errnames,
        dependencies: domDeps,
        cache,
        semVer: DEXIE_VERSION,
        version: DEXIE_VERSION.split(".").map(function(n2) {
          return parseInt(n2);
        }).reduce(function(p2, c2, i2) {
          return p2 + c2 / Math.pow(10, i2 * 2);
        })
      }));
      Dexie2.maxKey = getMaxKey(Dexie2.dependencies.IDBKeyRange);
      if (typeof dispatchEvent !== "undefined" && typeof addEventListener !== "undefined") {
        globalEvents(DEXIE_STORAGE_MUTATED_EVENT_NAME, function(updatedParts) {
          if (!propagatingLocally) {
            var event_1;
            event_1 = new CustomEvent(STORAGE_MUTATED_DOM_EVENT_NAME, {
              detail: updatedParts
            });
            propagatingLocally = true;
            dispatchEvent(event_1);
            propagatingLocally = false;
          }
        });
        addEventListener(STORAGE_MUTATED_DOM_EVENT_NAME, function(_a3) {
          var detail = _a3.detail;
          if (!propagatingLocally) {
            propagateLocally(detail);
          }
        });
      }
      function propagateLocally(updateParts) {
        var wasMe = propagatingLocally;
        try {
          propagatingLocally = true;
          globalEvents.storagemutated.fire(updateParts);
          signalSubscribersNow(updateParts, true);
        } finally {
          propagatingLocally = wasMe;
        }
      }
      var propagatingLocally = false;
      var bc;
      var createBC = function() {
      };
      if (typeof BroadcastChannel !== "undefined") {
        createBC = function() {
          bc = new BroadcastChannel(STORAGE_MUTATED_DOM_EVENT_NAME);
          bc.onmessage = function(ev) {
            return ev.data && propagateLocally(ev.data);
          };
        };
        createBC();
        if (typeof bc.unref === "function") {
          bc.unref();
        }
        globalEvents(DEXIE_STORAGE_MUTATED_EVENT_NAME, function(changedParts) {
          if (!propagatingLocally) {
            bc.postMessage(changedParts);
          }
        });
      }
      if (typeof addEventListener !== "undefined") {
        addEventListener("pagehide", function(event) {
          if (!Dexie$1.disableBfCache && event.persisted) {
            if (debug)
              console.debug("Dexie: handling persisted pagehide");
            bc === null || bc === void 0 ? void 0 : bc.close();
            for (var _i = 0, connections_1 = connections; _i < connections_1.length; _i++) {
              var db2 = connections_1[_i];
              db2.close({ disableAutoOpen: false });
            }
          }
        });
        addEventListener("pageshow", function(event) {
          if (!Dexie$1.disableBfCache && event.persisted) {
            if (debug)
              console.debug("Dexie: handling persisted pageshow");
            createBC();
            propagateLocally({ all: new RangeSet(-Infinity, [[]]) });
          }
        });
      }
      function add2(value) {
        return new PropModification({ add: value });
      }
      function remove(value) {
        return new PropModification({ remove: value });
      }
      function replacePrefix(a, b2) {
        return new PropModification({ replacePrefix: [a, b2] });
      }
      DexiePromise.rejectionMapper = mapError;
      setDebug(debug);
      var namedExports = /* @__PURE__ */ Object.freeze({
        __proto__: null,
        Dexie: Dexie$1,
        liveQuery,
        Entity,
        cmp,
        PropModSymbol,
        PropModification,
        replacePrefix,
        add: add2,
        remove,
        "default": Dexie$1,
        RangeSet,
        mergeRanges,
        rangesOverlap
      });
      __assign2(Dexie$1, namedExports, { default: Dexie$1 });
      return Dexie$1;
    });
  })(dexie);
  var dexieExports = dexie.exports;
  var _Dexie = /* @__PURE__ */ getDefaultExportFromCjs(dexieExports);
  const DexieSymbol = Symbol.for("Dexie");
  const Dexie = globalThis[DexieSymbol] || (globalThis[DexieSymbol] = _Dexie);
  if (_Dexie.semVer !== Dexie.semVer) {
    throw new Error(`Two different versions of Dexie loaded in the same app: ${_Dexie.semVer} and ${Dexie.semVer}`);
  }
  class WorkerDB extends Dexie {
    constructor() {
      super("vault_secure_storage");
      __publicField(this, "secureVaultMetadata");
      __publicField(this, "secureKeys");
      __publicField(this, "keyIdStorage");
      __publicField(this, "keyStorage");
      this.version(1).stores({
        secureVaultMetadata: "id",
        secureKeys: "id",
        keyIdStorage: "methodDigest, keyId",
        keyStorage: "++id, jwk"
      });
      this.secureVaultMetadata = this.table("secureVaultMetadata");
      this.secureKeys = this.table("secureKeys");
      this.keyIdStorage = this.table("keyIdStorage");
      this.keyStorage = this.table("keyStorage");
    }
  }
  const db$1 = new WorkerDB();
  class SecureVaultWorker {
    constructor() {
      __publicField(this, "masterKey", null);
      __publicField(this, "masterKeyTimeout", null);
      __publicField(this, "masterKeyExpirationTime", 5 * 60 * 1e3);
      __publicField(this, "vaultMetadata", null);
      __publicField(this, "_status", { type: "initializing" });
      __publicField(this, "statusListeners", []);
      __publicField(this, "wasmError", null);
    }
    // Method to add status listeners (useful for Comlink)
    onStatusChange(callback) {
      const listenerId = Math.random().toString(36).substring(7);
      this.statusListeners.push({ id: listenerId, callback });
      callback(this._status);
      return listenerId;
    }
    // Add a new method to remove the listener  
    removeStatusListener(listenerId) {
      this.statusListeners = this.statusListeners.filter(
        (listener) => "id" in listener && listener.id !== listenerId
      );
    }
    // Method to update status and notify listeners
    updateStatus(status) {
      this._status = status;
      for (const listener of this.statusListeners) {
        listener.callback(status);
      }
    }
    /**
     * Initialize the vault
     */
    async initialize() {
      console.log("[vault] initialize()");
      if (this.wasmError) {
        return "error";
      }
      try {
        console.log("[vault] trying to load vault");
        await this.loadVault();
        this.updateStatus({ type: "locked" });
        return "locked";
      } catch (error) {
        console.log("[vault] not created");
        const errorStatus = {
          type: "not_created",
          error: error instanceof Error ? error.message : String(error)
        };
        this.updateStatus(errorStatus);
        return "not_created";
      }
    }
    /**
     * Delete vault, clear database, reset stauts
     */
    async clearVault() {
      try {
        if (this.isUnlocked()) {
          this.lock();
        }
        await db$1.secureVaultMetadata.clear();
        await db$1.secureKeys.clear();
        await db$1.keyIdStorage.clear();
        this.masterKey = null;
        this.vaultMetadata = null;
        this.updateStatus({ type: "not_created" });
        console.log("[vault] Vault cleared successfully");
        return true;
      } catch (error) {
        console.error("[vault] Error clearing vault:", error);
        this.updateStatus({
          type: "error",
          error: error instanceof Error ? error.message : String(error)
        });
        return false;
      }
    }
    /**
     * Sets a WASM error state
     */
    setError(error) {
      this.wasmError = error;
      this.updateStatus({
        type: "error",
        error: error.message
      });
    }
    /**
     * Checks if WASM is properly initialized before operations
     */
    checkWasmInitialized() {
      if (this.wasmError) {
        throw new Error(`WASM initialization failed: ${this.wasmError.message}`);
      }
    }
    /**
     * Get the current vault status
     */
    get status() {
      console.log("[vault] Requested status");
      return this._status;
    }
    /**
     * Load vault metadata
     */
    async loadVault() {
      const metadata = await db$1.secureVaultMetadata.get("vault-metadata");
      if (!metadata) {
        console.log("[vault] Vault not initialized");
        throw new Error("Vault not initialized");
      }
      this.vaultMetadata = JSON.parse(metadata.metadata);
    }
    /**
     * Extend unlock period
     */
    resetAutoLockTimer() {
      if (this.masterKeyTimeout) {
        clearTimeout(this.masterKeyTimeout);
        this.masterKeyTimeout = null;
      }
      if (this.isUnlocked()) {
        this.masterKeyTimeout = setTimeout(() => {
          this.lock();
        }, this.masterKeyExpirationTime);
      }
    }
    /**
     * Derive key from password and parameters
     */
    async deriveKeyFromParams(password, salt, iterations) {
      const pwdKey = await crypto.subtle.importKey(
        "raw",
        new TextEncoder().encode(password),
        "PBKDF2",
        false,
        ["deriveKey"]
      );
      return crypto.subtle.deriveKey(
        {
          name: "PBKDF2",
          salt,
          iterations,
          hash: "SHA-256"
        },
        pwdKey,
        { name: "AES-GCM", length: 256 },
        false,
        // Not exportable
        ["encrypt", "decrypt"]
      );
    }
    /**
     * Create a new vault with a password
     */
    async createVault(password) {
      try {
        await this.loadVault();
        throw new Error("Existing Vault");
      } catch (error) {
        if (error.message !== "Vault not initialized") {
          throw error;
        }
      }
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const saltBase64 = btoa(String.fromCharCode(...salt));
      const iterations = 1e5;
      const masterKey = await this.deriveKeyFromParams(password, salt, iterations);
      this.masterKey = masterKey;
      const verificationText = "Password verification successful!";
      const verificationIv = crypto.getRandomValues(new Uint8Array(12));
      const encryptedVerification = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: verificationIv },
        masterKey,
        new TextEncoder().encode(verificationText)
      );
      this.vaultMetadata = {
        salt: saltBase64,
        iterations,
        keyIdsInVault: [],
        verificationData: btoa(String.fromCharCode(...new Uint8Array(encryptedVerification))),
        verificationIv: btoa(String.fromCharCode(...verificationIv))
      };
      await db$1.secureVaultMetadata.put({
        id: "vault-metadata",
        metadata: JSON.stringify(this.vaultMetadata)
      });
      this.resetAutoLockTimer();
      this.updateStatus({ type: "unlocked" });
      return true;
    }
    /**
     * Unlock vault with password
     */
    async unlock(password) {
      if (!this.vaultMetadata) {
        try {
          await this.loadVault();
        } catch (error) {
          this.updateStatus({
            type: "not_created",
            error: error instanceof Error ? error.message : String(error)
          });
          return false;
        }
      }
      try {
        const saltBuffer = Uint8Array.from(atob(this.vaultMetadata.salt), (c2) => c2.charCodeAt(0));
        const masterKey = await this.deriveKeyFromParams(
          password,
          saltBuffer,
          this.vaultMetadata.iterations
        );
        const verificationIv = Uint8Array.from(
          atob(this.vaultMetadata.verificationIv),
          (c2) => c2.charCodeAt(0)
        );
        const encryptedVerification = Uint8Array.from(
          atob(this.vaultMetadata.verificationData),
          (c2) => c2.charCodeAt(0)
        );
        await crypto.subtle.decrypt(
          { name: "AES-GCM", iv: verificationIv },
          masterKey,
          encryptedVerification
        );
        this.masterKey = masterKey;
        this.updateStatus({ type: "unlocked" });
        console.log("[vault]: unlocked");
        this.resetAutoLockTimer();
        return true;
      } catch (error) {
        console.error("Error while unlocking vault:", error);
        this.updateStatus({
          type: "locked",
          error: "Wrong password or damaged vault"
        });
        return false;
      }
    }
    /**
     * Lock vault manually
     */
    lock() {
      this.masterKey = null;
      this.updateStatus({ type: "locked" });
      if (this.masterKeyTimeout) {
        clearTimeout(this.masterKeyTimeout);
        this.masterKeyTimeout = null;
      }
    }
    /**
     * Check if vault is unlocked
     */
    isUnlocked() {
      return this.masterKey !== null;
    }
    /**
     * Utility function to generate a random key ID
     */
    randomKeyId() {
      const randomness = new Uint8Array(20);
      crypto.getRandomValues(randomness);
      return encodeB64(randomness);
    }
    /**
     * Create public JWK from public key bytes
     */
    createPublicJwk(publicKey, algorithm) {
      const x2 = encodeB64(publicKey);
      if (algorithm === JwsAlgorithm.EdDSA) {
        return new Jwk({
          kty: JwkType.Okp,
          crv: "Ed25519",
          x: x2,
          alg: algorithm
        });
      } else if (algorithm === JwsAlgorithm.MLDSA44 || algorithm === JwsAlgorithm.MLDSA65 || algorithm === JwsAlgorithm.MLDSA87) {
        return new Jwk({
          "kty": JwkType.MLDSA,
          pub: x2,
          alg: algorithm
        });
      }
      throw new Error(`Unsupported algorithm: ${algorithm}`);
    }
    /**
     * Generate a new key directly in the vault
     */
    async generateKey(keyType, algorithm) {
      console.log("[vault] generate");
      this.checkWasmInitialized();
      if (!this.isUnlocked()) {
        throw new Error("Vault is locked. Unlock the vault first");
      }
      this.resetAutoLockTimer();
      try {
        let privateKey;
        let publicKey;
        let alg = algorithm;
        if (keyType === "Ed25519") {
          if (alg !== JwsAlgorithm.EdDSA) {
            throw new Error(`unsupported algorithm for Ed25519`);
          }
          privateKey = ed25519.utils.randomPrivateKey();
          publicKey = await ed25519.getPublicKey(privateKey);
        } else if (keyType === "ML-DSA") {
          const seed = new TextEncoder().encode(this.randomKeyId());
          let keys;
          if (alg === JwsAlgorithm.MLDSA44) {
            keys = ml_dsa44.keygen(seed);
          } else if (algorithm === JwsAlgorithm.MLDSA65) {
            keys = ml_dsa65.keygen(seed);
          } else if (algorithm === JwsAlgorithm.MLDSA87) {
            keys = ml_dsa87.keygen(seed);
          } else {
            throw new Error(`unsupported algorithm for ML-DSA`);
          }
          privateKey = keys.secretKey;
          publicKey = keys.publicKey;
        } else {
          throw new Error(`unsupported key type ${keyType}`);
        }
        const keyId = this.randomKeyId();
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const encryptedData = await crypto.subtle.encrypt(
          { name: "AES-GCM", iv },
          this.masterKey,
          privateKey
        );
        const publicJWK = this.createPublicJwk(publicKey, alg);
        await db$1.secureKeys.put({
          id: keyId,
          encryptedkey: btoa(String.fromCharCode(...new Uint8Array(encryptedData))),
          iv: btoa(String.fromCharCode(...iv)),
          algorithm: alg
        });
        await db$1.keyStorage.put({
          id: keyId,
          public: publicJWK.toString()
        });
        if (this.vaultMetadata && !this.vaultMetadata.keyIdsInVault.includes(keyId)) {
          this.vaultMetadata.keyIdsInVault.push(keyId);
          await db$1.secureVaultMetadata.put({
            id: "vault-metadata",
            metadata: JSON.stringify(this.vaultMetadata)
          });
        }
        privateKey.fill(0);
        const out = new JwkGenOutput(keyId, publicJWK);
        console.log(out.toString());
        return out;
      } catch (error) {
        console.error("Error generating key in vault:", error);
        throw error;
      }
    }
    /**
     * Utility method to sign with secure key
     */
    async signWithSecureKey(keyId, data, alg) {
      this.checkWasmInitialized();
      try {
        if (!this.isUnlocked()) {
          throw new Error("Vault is locked. Unlock the vault first");
        }
        this.resetAutoLockTimer();
        const secureKey = await db$1.secureKeys.get(keyId);
        if (!secureKey) {
          throw new Error(`Secure key with id ${keyId} not found`);
        }
        const iv = Uint8Array.from(atob(secureKey.iv), (c2) => c2.charCodeAt(0));
        const encryptedData = Uint8Array.from(atob(secureKey.encryptedkey), (c2) => c2.charCodeAt(0));
        const privateKeyBuffer = await crypto.subtle.decrypt(
          {
            name: "AES-GCM",
            iv
          },
          this.masterKey,
          encryptedData
        );
        const privateKey = new Uint8Array(privateKeyBuffer);
        let signature = null;
        try {
          if (alg === JwsAlgorithm.EdDSA) {
            signature = await ed25519.sign(data, privateKey);
          } else {
            z(alg).with(JwsAlgorithm.MLDSA44, () => {
              signature = ml_dsa44.sign(privateKey, data);
            }).with(JwsAlgorithm.MLDSA65, () => {
              signature = ml_dsa65.sign(privateKey, data);
            }).with(JwsAlgorithm.MLDSA87, () => {
              signature = ml_dsa87.sign(privateKey, data);
            }).run();
          }
        } finally {
          privateKey.fill(0);
        }
        if (!signature) {
          throw new Error("Failed to generate signature");
        }
        return signature;
      } catch (error) {
        console.error("Error while signing:", error);
        throw error;
      }
    }
    /**
     * Get list of protected key IDs
     */
    async getProtectedKeyIds() {
      var _a2;
      if (!this.vaultMetadata) {
        try {
          await this.loadVault();
        } catch (error) {
          return [];
        }
      }
      return ((_a2 = this.vaultMetadata) == null ? void 0 : _a2.keyIdsInVault) || [];
    }
    /**
     * Delete a protected key
     */
    async deleteSecureKey(keyId) {
      try {
        await db$1.secureKeys.delete(keyId);
        await db$1.keyStorage.delete(keyId);
        if (this.vaultMetadata) {
          const index = this.vaultMetadata.keyIdsInVault.indexOf(keyId);
          if (index !== -1) {
            this.vaultMetadata.keyIdsInVault.splice(index, 1);
            await db$1.secureVaultMetadata.put({
              id: "vault-metadata",
              metadata: JSON.stringify(this.vaultMetadata)
            });
          }
        }
        return true;
      } catch (error) {
        console.error("Error while deleting key:", error);
        return false;
      }
    }
    /**
     * Change vault password securely
     * This implementation minimizes exposure of private keys
     */
    async changePassword(currentPassword, newPassword) {
      if (!this.isUnlocked()) {
        const unlocked = await this.unlock(currentPassword);
        if (!unlocked) {
          throw new Error("Wrong current password ");
        }
      }
      try {
        const keyIds = this.vaultMetadata.keyIdsInVault;
        const newSalt = crypto.getRandomValues(new Uint8Array(16));
        const newSaltBase64 = btoa(String.fromCharCode(...newSalt));
        const newMasterKey = await this.deriveKeyFromParams(
          newPassword,
          newSalt,
          this.vaultMetadata.iterations
        );
        const verificationText = "Password verification successful!";
        const verificationIv = crypto.getRandomValues(new Uint8Array(12));
        const encryptedVerification = await crypto.subtle.encrypt(
          { name: "AES-GCM", iv: verificationIv },
          newMasterKey,
          new TextEncoder().encode(verificationText)
        );
        const updatedMetadata = {
          ...this.vaultMetadata,
          salt: newSaltBase64,
          verificationData: btoa(String.fromCharCode(...new Uint8Array(encryptedVerification))),
          verificationIv: btoa(String.fromCharCode(...verificationIv))
        };
        for (const keyId of keyIds) {
          const secureKey = await db$1.secureKeys.get(keyId);
          if (!secureKey) continue;
          const iv = Uint8Array.from(atob(secureKey.iv), (c2) => c2.charCodeAt(0));
          const encryptedData = Uint8Array.from(atob(secureKey.encryptedkey), (c2) => c2.charCodeAt(0));
          const decryptedBuffer = await crypto.subtle.decrypt(
            { name: "AES-GCM", iv },
            this.masterKey,
            encryptedData
          );
          const newIv = crypto.getRandomValues(new Uint8Array(12));
          const newEncryptedData = await crypto.subtle.encrypt(
            { name: "AES-GCM", iv: newIv },
            newMasterKey,
            decryptedBuffer
          );
          await db$1.secureKeys.put({
            id: keyId,
            encryptedkey: btoa(String.fromCharCode(...new Uint8Array(newEncryptedData))),
            iv: btoa(String.fromCharCode(...newIv)),
            algorithm: secureKey.algorithm
          });
        }
        await db$1.secureVaultMetadata.put({
          id: "vault-metadata",
          metadata: JSON.stringify(updatedMetadata)
        });
        this.vaultMetadata = updatedMetadata;
        this.masterKey = newMasterKey;
        this.resetAutoLockTimer();
        return true;
      } catch (error) {
        console.error("Error during change password:", error);
        return false;
      }
    }
  }
  const _WasmManager = class _WasmManager {
    constructor() {
      __publicField(this, "initPromise", null);
    }
    static getInstance() {
      if (!_WasmManager.instance) {
        _WasmManager.instance = new _WasmManager();
      }
      return _WasmManager.instance;
    }
    /**
     * Initialize WASM bindings
     * @param iotaWasmPath File path for IOTA SDK WASM 
     * @param identityWasmPath File path for IDENTITY WASM 
     * @returns Promise that resolves if initialization succeeds
     */
    initialize(iotaWasmPath, identityWasmPath) {
      if (!this.initPromise) {
        this.initPromise = (async () => {
          try {
            await init(iotaWasmPath);
            await init$1(identityWasmPath);
            console.log("WASM bindings initialized successfully");
            return true;
          } catch (error) {
            console.error("Failed to initialize WASM:", error);
            this.initPromise = null;
            return false;
          }
        })();
      }
      return this.initPromise;
    }
    /**
     * Checks if the bindings are initialized
     * @returns Promise that resolves if bindings are initialized
     */
    isInitialized() {
      if (!this.initPromise) {
        return Promise.resolve(false);
      }
      return this.initPromise;
    }
  };
  __publicField(_WasmManager, "instance");
  let WasmManager = _WasmManager;
  const wasmManager = WasmManager.getInstance();
  class JwkBrowserStore {
    constructor(vault) {
      __publicField(this, "vault");
      this.vault = vault;
    }
    static ed25519KeyType() {
      return "Ed25519";
    }
    static mldsaKeyType() {
      return "ML-DSA";
    }
    async generate(keyType, algorithm) {
      return await this.vault.generateKey(keyType, algorithm.toString());
    }
    async generatePQKey(keyType, algorithm) {
      if (keyType !== JwkBrowserStore.mldsaKeyType()) {
        throw new Error(`unsupported key type ${keyType}`);
      }
      return await this.vault.generateKey(JwkBrowserStore.mldsaKeyType(), algorithm);
    }
    async sign(keyId, data, publicKey) {
      var _a2;
      const keyExists = await this.exists(keyId);
      const alg = (_a2 = publicKey.alg()) == null ? void 0 : _a2.toString();
      if (keyExists) {
        if (!alg) {
          throw new Error("Algorithm is undefined");
        }
        return await this.vault.signWithSecureKey(keyId, data, alg);
      }
      throw new Error("Error while signing: key not found or vault locked");
    }
    async insert(jwk) {
      throw new Error("Method 'insert' is deprecated and no longer supported");
    }
    async delete(keyId) {
      await this.vault.deleteSecureKey(keyId);
    }
    /** Returns `true` if the key with the given `keyId` exists in storage, `false` otherwise. */
    async exists(keyId) {
      const result = await db$1.keyStorage.get(keyId);
      if (result === void 0) return false;
      return true;
    }
  }
  function methodDigestToString(methodDigest) {
    const arrayBuffer = methodDigest.pack().buffer;
    return encode(arrayBuffer);
  }
  class KeyIdBrowserStore {
    /**
    * Insert a key id into the `KeyIdStorage` under the given {@link MethodDigest}.
    * 
    * If an entry for `key` already exists in the storage an error must be returned
    * immediately without altering the state of the storage.
    */
    async insertKeyId(methodDigest, keyId) {
      const methodDigestAsString = methodDigestToString(methodDigest);
      const dbKeyId = await db$1.keyIdStorage.get(methodDigestAsString);
      if (dbKeyId !== void 0) {
        throw new Error("KeyId already exists");
      }
      await db$1.keyIdStorage.add({ keyId, methodDigest: methodDigestAsString });
    }
    /**
     * Obtain the key id associated with the given {@link MethodDigest}.
     */
    async getKeyId(methodDigest) {
      const methodDigestAsString = methodDigestToString(methodDigest);
      const keyId = await db$1.keyIdStorage.get(methodDigestAsString);
      if (keyId === void 0) {
        throw new Error("KeyId not found");
      }
      return String(keyId.keyId);
    }
    /**
     * Delete the `KeyId` associated with the given {@link MethodDigest} from the {@link KeyIdStorage}.
     * 
     * If `key` is not found in storage, an Error must be returned.
     */
    async deleteKeyId(methodDigest) {
      const methodDigestAsString = methodDigestToString(methodDigest);
      try {
        await db$1.keyIdStorage.delete(methodDigestAsString);
      } catch {
        console.log("KeyId not found!");
        throw new Error("KeyId not found");
      }
    }
  }
  const db = new Dexie("identity_wallet_db");
  db.version(1).stores({
    dids: "++id, level, type, alg, did",
    // primary key "id" (for the runtime!)
    verifiableCredentials: "++id, jwt"
  });
  async function createDid(type) {
    console.log("[IdentityAPI] Creating DID of type:", type);
    try {
      let document;
      let did;
      switch (type) {
        case "Ed25519":
          document = await createDidJwk();
          console.log("Traditional DID created:", document.id().toString());
          did = {
            did: document.id().toString(),
            type: "TRAD",
            alg: "Ed25519",
            level: ""
          };
          break;
        case "ML-DSA-44":
          document = await createDidJwkPQ("ML-DSA-44");
          console.log("PQ DID ML-DSA-44 created:", document.id().toString());
          did = {
            did: document.id().toString(),
            type: "PQC ",
            alg: "ML-DSA-44",
            level: "2"
          };
          break;
        case "ML-DSA-65":
          document = await createDidJwkPQ("ML-DSA-65");
          console.log("PQ DID ML-DSA-65 created:", document.id().toString());
          did = {
            did: document.id().toString(),
            type: "PQC ",
            alg: "ML-DSA-65",
            level: "3"
          };
          break;
        case "ML-DSA-87":
          document = await createDidJwkPQ("ML-DSA-87");
          console.log("PQ DID ML-DSA-87 created:", document.id().toString());
          did = {
            did: document.id().toString(),
            type: "PQC ",
            alg: "ML-DSA-87",
            level: "5"
          };
          break;
        case "id-MLDSA44-Ed25519-SHA512":
          document = await createDidJwkHybrid("id-MLDSA44-Ed25519-SHA512");
          console.log("Hybrid DID MLDSA44-Ed25519 created:", document.id().toString());
          did = {
            did: document.id().toString(),
            type: "PQ/T",
            alg: "id-MLDSA44-Ed25519-SHA512",
            level: "2"
          };
          break;
        case "id-MLDSA65-Ed25519-SHA512":
          document = await createDidJwkHybrid("id-MLDSA65-Ed25519-SHA512");
          console.log("Hybrid DID MLDSA65-Ed25519 created:", document.id().toString());
          did = {
            did: document.id().toString(),
            type: "PQ/T",
            alg: "id-MLDSA65-Ed25519-SHA512",
            level: "3"
          };
          break;
        default:
          throw new Error(`Unsupported DID type: ${type}`);
      }
      return JSON.stringify(did);
    } catch (error) {
      console.error("[IdentityAPI] Error creating DID:", error);
      throw error;
    }
  }
  function resolveDid(did) {
    console.log("Resolving a DID:", did);
    let did_document = null;
    if (did.startsWith("did:compositejwk")) {
      did_document = CoreDocument.expandDIDCompositeJwk(DIDCompositeJwk.parse(did));
    } else if (did.startsWith("did:jwk")) {
      did_document = CoreDocument.expandDIDJwk(DIDJwk.parse(did));
    } else ;
    const docJson = JSON.parse(JSON.stringify(did_document == null ? void 0 : did_document.toJSON()));
    const doc = {
      id: docJson.id,
      controller: docJson.controller,
      verificationMethod: docJson.verificationMethod.map((vm) => ({
        id: vm.id,
        type: vm.type,
        controller: vm.controller,
        publicKeyJwk: vm.publicKeyJwk
      })),
      authentication: docJson.authentication,
      assertionMethod: docJson.assertionMethod
    };
    return { did_document, doc };
  }
  function getFragment(did) {
    if (did.startsWith("did:iota:rms")) {
      return "key-1";
    } else {
      return "0";
    }
  }
  async function signChallenge(did, nonce) {
    try {
      let jws;
      let did_document = resolveDid(did).did_document;
      let fragment = getFragment(did);
      const storage = getStorage();
      let options = new JwsSignatureOptions();
      options.setNonce(nonce);
      if (did.startsWith("did:compositejwk")) {
        jws = (await did_document.createHybridJws(
          storage,
          fragment,
          nonce,
          options
        )).toString();
      } else {
        let core = did_document;
        console.log(did_document);
        console.log(core.verificationMethod()[0].data().tryPublicKeyJwk().alg());
        const alg = did_document.verificationMethod()[0].data().tryPublicKeyJwk().alg().toString();
        if (alg === "ML-DSA-44" || alg === "ML-DSA-65" || alg === "ML-DSA-87") {
          jws = (await did_document.createPqJws(
            storage,
            fragment,
            nonce,
            options
          )).toString();
        } else {
          jws = (await did_document.createJws(
            storage,
            fragment,
            nonce,
            options
          )).toString();
        }
      }
      if (!jws) {
        throw new Error("JWS creation failed");
      }
      return jws;
    } catch (error) {
      console.error("[IdentityAPI] Error signing challenge:", error);
      throw error;
    }
  }
  async function createDidJwk() {
    const storage = getStorage();
    const document = await CoreDocument.newDidJwk(
      storage,
      JwkBrowserStore.ed25519KeyType(),
      JwsAlgorithm.EdDSA
    );
    return document;
  }
  async function createDidJwkPQ(alg) {
    const storage = getStorage();
    let diddocument;
    if (alg === "ML-DSA-44") {
      diddocument = await CoreDocument.newDidJwkPq(
        storage,
        JwkBrowserStore.mldsaKeyType(),
        JwsAlgorithm.MLDSA44
      );
    } else if (alg === "ML-DSA-65") {
      diddocument = await CoreDocument.newDidJwkPq(
        storage,
        JwkBrowserStore.mldsaKeyType(),
        JwsAlgorithm.MLDSA65
      );
    } else if (alg === "ML-DSA-87") {
      diddocument = await CoreDocument.newDidJwkPq(
        storage,
        JwkBrowserStore.mldsaKeyType(),
        JwsAlgorithm.MLDSA87
      );
    }
    return diddocument;
  }
  async function createDidJwkHybrid(alg) {
    const storage = getStorage();
    let diddocument;
    if (alg === "id-MLDSA44-Ed25519-SHA512") {
      diddocument = await CoreDocument.newDidCompositeJwk(
        storage,
        CompositeAlgId.IdMldsa44Ed25519Sha512
      );
    } else if (alg === "id-MLDSA65-Ed25519-SHA512") {
      diddocument = await CoreDocument.newDidCompositeJwk(
        storage,
        CompositeAlgId.IdMldsa65Ed25519Sha512
      );
    }
    return diddocument;
  }
  let storageInstance = null;
  let jwkStoreInstance = null;
  let keyIdStoreInstance = null;
  function initializeStorage(vault) {
    if (!jwkStoreInstance) {
      jwkStoreInstance = new JwkBrowserStore(vault);
    }
    if (!keyIdStoreInstance) {
      keyIdStoreInstance = new KeyIdBrowserStore();
    }
    if (!storageInstance) {
      storageInstance = new Storage(jwkStoreInstance, keyIdStoreInstance);
    }
  }
  function getStorage() {
    if (!storageInstance) {
      throw new Error("Storage not initialized");
    }
    return storageInstance;
  }
  async function initializeWasm() {
    console.log("Worker: Initializing WASM...");
    const initialized = await wasmManager.initialize(
      "/libs/iota_sdk_wasm_bg.wasm",
      "/libs/identity_wasm_bg.wasm"
    );
    if (!initialized) {
      console.error("Worker: WASM initialization failed");
      throw new Error("WASM initialization failed");
    }
    console.log("WASM bindings initialized successfully");
  }
  async function initializeWorker() {
    console.log("Worker: Initializing...");
    try {
      await initializeWasm();
      console.log("Worker: Creating SecureVaultWorker, JwkBrowserStore, KeyIdBrowserStore instances");
      const vaultWorker = new SecureVaultWorker();
      initializeStorage(vaultWorker);
      console.log("Worker: Exposing SecureVaultWorker, JwkBrowserStore, KeyIdBrowserStore instances");
      expose({
        // Metodi principali
        initialize: () => vaultWorker.initialize(),
        createVault: (password) => vaultWorker.createVault(password),
        unlock: (password) => vaultWorker.unlock(password),
        lock: () => vaultWorker.lock(),
        isUnlocked: () => vaultWorker.isUnlocked(),
        // Gestione delle chiavi
        changePassword: (currentPassword, newPassword) => vaultWorker.changePassword(currentPassword, newPassword),
        // Gestione status e callback
        onStatusChange: (callback) => vaultWorker.onStatusChange(callback),
        removeStatusListener: (listenerId) => vaultWorker.removeStatusListener(listenerId),
        // Proprietà
        get status() {
          return vaultWorker.status;
        },
        // Pulizia
        clearVault: () => vaultWorker.clearVault(),
        createDid: (type) => createDid(type),
        signChallenge: (did, nonce) => signChallenge(did, nonce)
      });
      self.postMessage({ type: "worker-ready" });
      console.log("Worker: SecureVaultWorker instance ready");
    } catch (error) {
      console.error("Worker: Error during initialization:", error);
      self.postMessage({ type: "worker-error", error: String(error) });
      expose({
        initialize: () => Promise.resolve("error"),
        status: { type: "error", error: String(error) }
      });
    }
  }
  initializeWorker();
})();
//# sourceMappingURL=vaultWorker-AD_OeRAT.js.map
